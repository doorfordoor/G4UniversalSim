# R03/R04 当前构建独立复现

本目录是本次真实运行的新证据，未修改源码/正式配置/测试或原 D 工作区。四个病例各 1 事件、1 worker；均退出 0、摘要 completed。R03/R04 均仍存在，不能将全量既有测试绿色当成它们已修复。

- results.json：本轮可执行文件 SHA-256、实际命令、cwd、退出码、耗时、摘要及关键 CSV 摘录。运行前后 exe hash 一致。
- conclusions.json：独立质量/剂量计算及 GDML 实际 mesh 灵敏体标记。
- 每病例保留改为本工作区路径的输入、stdout/stderr、mesh、完整输出。
- manifest.json：本目录逐文件 SHA-256（不包含清单自身）。

R03：水母体本体应为 0.000488 kg，实际 0.0062992 kg；0.1 MeV 本体沉积对应实际 Dose 2.5434604934e-12 Gy，预期 3.28314884016e-11 Gy。叶体对照 0.001 kg 正确。

R04：Sensor=true、sensor=false；源在 sensor 的病例 event_edep=0、无 hits、Dose CSV 无数据行。改名 SensorA/SensorB 后两体均 sensitive=true，第二体积恢复 0.1 MeV hit/Dose。

这不是统一平台报告，也不证明其他粒子、复制/参数化几何、MT 或独立物理基准已验收。
