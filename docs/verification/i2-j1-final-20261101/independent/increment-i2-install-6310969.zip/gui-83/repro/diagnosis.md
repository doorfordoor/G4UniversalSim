# 03d M0 Windows gui_i2_install 集合失败：真实8.3反例与最小提案

只读源码；tracked文件未改。本机C盘真实GetShortPathNameW别名，不使用D盘假定8.3。完整原smoke以离屏子进程执行；out诊断副本只固定原ROOT并在原集合assert前打印操作数。另一个out候选仅额外将fixture根Path(directory)改成Path(directory).resolve()。AST核对两副本的所有原assert谓词及顺序完全保留，没有降低集合要求、加等待或删用例。

| 完整smoke变体 | 实际TEMP | exit | v3入口 | 观察 |
|---|---|---:|---:|---|
| 原代码+操作数诊断 | C盘规范长路径 | 0 | 59 | 两边集合完全相同 |
| 原代码+操作数诊断 | C盘真实8.3别名 | 1 | 54 | 实际两个长路径候选，期望两个短路径候选；与CI同一原assert/54入口失败 |
| 仅fixture根.resolve()+诊断 | 同一真实8.3 TEMP父目录 | 0 | 59 | 完整smoke通过，两个候选及全部原断言保持 |

根因机制：smoke_i2_install.py:39的root保留TemporaryDirectory返回的路径拼写；:148–149 old_backend/new_backend沿该拼写构造。environment_discovery.py:372先调用_resolve_executable，而:141返回Path(...).resolve()，再:385把这个规范Path传给mock probe，mock str(path)因此是规范长路径。原:166将其与raw root构造的集合比较，真实别名下不相等。产品按规范身份去重/探测符合原I1契约。

未观察到automatic/additional候选丢失：三轮的第一份实际observations仅含old；第二份均含old+new。automatic._candidates始终None；_additional_candidates保留new；rediscovery原等待条件未改。失败轮的实际与期望集合基数均2，且相对后缀installed/bin/backend与resume-install/bin/backend逐一对应，仅父路径长短拼写不同。这排除了本反例中的集合遗漏/等待时序原因。不能仅靠该反例宣称已直接读取CI上的TEMP拼写：CI旧日志未记录操作数；这里是同源完整smoke的确定复现。

最小提案（由Root统一应用）：gui/smoke_tests/smoke_i2_install.py:39

```python
# Discovery returns canonical executable paths, including Windows8.3 TEMP aliases.
root = Path(directory).resolve()
```

保留原:166集合相等和:167补充候选列表相等全部原要求；不改product discovery，不扩大等待。建议同时保留失败assert消息中的actual/expected以便后续诊断，但它不是修复必要条件。

完整证据：out/collab/i2-gui-short-temp-repro/evidence.json；三组同名*-temp.{json,log}含实际两边集合、自动/补充候选、两次worker真实observations、argv、TEMP、原始日志SHA和运行时间。original-with-operands.py与canonical-root-with-operands.py源副本SHA、原tracked source SHA均已记录；完整驱动out/collab/i2-repro-gui-short-temp.py。不重写原CI失败、不把out副本通过冒新提交验收。
