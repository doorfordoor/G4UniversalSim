# 03d2c48 M0 Windows 实际GUI失败

Run41314991465 / job124873021877，head03d2c483afc0082ad464d2d9a1750fd2e4415a3a，attempt1。

Windows static44/44、3959断言通过；GUI58/59、总6734断言，gui_i2_install执行54断言后在gui/smoke_tests/smoke_i2_install.py:166失败：`assert {item["executable"] for item in automatic.facts["environments"]} == {old_backend, new_backend}`。CI原日志未打印左右操作数，当前不能当作已确定产品缺陷或已定位根因。

原GUI报告、gui_i2_install.log与所有逐case日志在extracted/m0-report-windows-latest-13086759271/20261101-141705-b14b231e/。工件实际大小及SHA见terminal-artifacts-41314991465.json和artifacts/13086759271-verified.json；原ZIP已核GitHub SHA256。发布strict gate如实fail，allow-incomplete仅用于完整性triage通过，不把GUI记为成功。

Linux M0 static44/3966与GUI59/6739均通过。desktop两平台已success，Linux两个版本backend与full-install两平台生命周期仍在运行。既有只读监控96716继续，未重启jobs或重复模拟。旧5fe失败不覆盖。
