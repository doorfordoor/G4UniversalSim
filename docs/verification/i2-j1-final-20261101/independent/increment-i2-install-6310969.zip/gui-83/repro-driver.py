from pathlib import Path
import ast,ctypes,hashlib,json,os,subprocess,sys,time
root=Path.cwd();work=root/'out/collab/i2-gui-short-temp-repro';work.mkdir(exist_ok=True)
source=root/'gui/smoke_tests/smoke_i2_install.py';original=source.read_text(encoding='utf-8-sig')
identity=hashlib.sha256(source.read_bytes()).hexdigest()
base=original.replace('ROOT = Path(__file__).resolve().parents[2]', 'ROOT = Path('+repr(root.as_posix())+')',1)
needle='            assert {item["executable"] for item in automatic.facts["environments"]} == {old_backend, new_backend}'
assert needle in base
instrument='''            print('G4USIM_I2_CANDIDATE_DIAGNOSTIC=' + __import__('json').dumps({
                'root': str(root), 'canonical_root': str(root.resolve()),
                'actual': sorted(item['executable'] for item in automatic.facts['environments']),
                'expected': sorted({old_backend, new_backend}),
                'automatic_candidates': automatic._candidates,
                'additional_candidates': automatic._additional_candidates,
                'observations': [[item['executable'] for item in facts['environments']] for facts in observations],
            }), flush=True)
'''
base=base.replace(needle,instrument+needle,1)
raw_copy=work/'original-with-operands.py';raw_copy.write_text(base,encoding='utf-8')
fixed_copy=work/'canonical-root-with-operands.py';fixed_copy.write_text(base.replace('root = Path(directory)','root = Path(directory).resolve()',1),encoding='utf-8')
original_conditions=[ast.dump(n.test,include_attributes=False) for n in ast.walk(ast.parse(original)) if isinstance(n,ast.Assert)]
for path in (raw_copy,fixed_copy):
    conditions=[ast.dump(n.test,include_attributes=False) for n in ast.walk(ast.parse(path.read_text())) if isinstance(n,ast.Assert)]
    assert conditions==original_conditions, path
parent=work/'Deliberately long temporary parent';parent.mkdir(exist_ok=True)
long_path=str(parent.resolve());api=ctypes.windll.kernel32.GetShortPathNameW;api.argtypes=[ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_uint];api.restype=ctypes.c_uint
buffer=ctypes.create_unicode_buffer(32768);length=api(long_path,buffer,len(buffer));assert 0<length<len(buffer)
short_path=buffer.value;assert short_path.casefold()!=long_path.casefold() and Path(short_path).resolve()==Path(long_path)
records=[]
for label,temp_path,target,expected_exit in [('original-long-temp',long_path,raw_copy,0),('original-short-temp',short_path,raw_copy,1),('canonical-short-temp',short_path,fixed_copy,0)]:
    env=os.environ.copy();env['QT_QPA_PLATFORM']='offscreen'
    for key in ('TMPDIR','TEMP','TMP'):env[key]=temp_path
    command=['D:/Geant4/G4UniversalSim/gui/.venv/Scripts/python.exe','-B',str(root/'tools/test_assert_probe.py'),str(target)]
    started=time.time_ns();r=subprocess.run(command,cwd=root,env=env,capture_output=True,timeout=90)
    log=work/(label+'.log');log.write_bytes(r.stdout+r.stderr)
    text=log.read_text(encoding='utf-8-sig',errors='replace');markers=[line.split('=',1)[1] for line in text.splitlines() if line.startswith('G4USIM_I2_CANDIDATE_DIAGNOSTIC=')]
    diag=json.loads(markers[0]) if len(markers)==1 else None
    record={'label':label,'argv':command,'temp':temp_path,'exit_code':r.returncode,'expected_exit_code':expected_exit,'diagnostic':diag,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'started_time_ns':started,'finished_time_ns':time.time_ns()}
    records.append(record);(work/(label+'.json')).write_text(json.dumps(record,indent=2))
    print(json.dumps({'label':label,'exit_code':r.returncode,'diagnostic':diag},indent=2))
    assert r.returncode==expected_exit,(label,text[-5000:])
    assert diag is not None,(label,text[-5000:])
    if expected_exit:assert set(diag['actual'])!=set(diag['expected'])
    else:assert set(diag['actual'])==set(diag['expected'])
assert hashlib.sha256(source.read_bytes()).hexdigest()==identity,'tracked source changed during experiment'
report={'schema':'g4usim_i2_gui_83_temp_repro_v1','status':'verified','source':str(source),'source_sha256':identity,'all_original_assert_conditions_preserved':True,'long_temp':long_path,'actual_short_temp':short_path,'copies':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (raw_copy,fixed_copy)],'records':records,'scope':'full original GUI smoke offscreen; diagnostic out copies preserve actual ROOT and assertion predicates; fixed copy changes only fixture root canonicalization'}
(work/'evidence.json').write_text(json.dumps(report,indent=2))
