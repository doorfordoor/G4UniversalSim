# 03d2c48 Windows114 integration 最终独立复核

结论：29/29通过、6045个v3入口、0失败/0跳过，独立严格门禁exit0。报告out/verification/i2-j1-03d2c48/windows114-integration/20261101-221315-6389b5dd/report.json。原5fe的28/29失败保持，不追改。

源码/产品映射：新正式报告HEAD03d2c483afc0082ad464d2d9a1750fd2e4415a3a，git_dirty=false、git_status_porcelain为空，tracked source gate通过。5fe→03d完整git diff仅scripts/test_effective_gdml.py与scripts/test_platform_install_layout.py。GUI/后端/CMake/packaging产品源码均相同；当前114实际EXE SHA仍为cd8321257d3e2f222eb7f17771acbbbe5641de1f350f66066d0dea7e8b65053c，与原独立capabilities收据精确相同。故原BuildInfo保持5fe clean Release / MSVC19.51 / Geant41143，不冒写成03d产品重建。

C++ source SHA890635b6d521659e43cf735d07f862c6ebd5959e6c5ea68d023d55332a8a930a；新测试指纹a19f074ef4dd7fbdaad5a333aea59d7ba5bf627081927055ca6f404a498d0866。精确29项清单、逐项status/exit、probe v3、禁止skip及原始log SHA由独立检查复核；无legacy/incomplete放宽参数。

GDML组件：effective_gdml实际选择independent current-source helper，SHA f1e850ce7dda1f71cc7283a8d4390e2689ed15821e4b40e57f06f6446e1d7025；selected_application为实际114后端。scope明确standalone native Xerces exact-byte adapter，不宣称应用GDML支持。helper五个源码/headerSHA与构建收据及当前产品源码匹配，helper当前实际字节未变。应用GDML仍false；此前GDML OFF导入/导出真实拒绝证据保持独立。

原始报告与严格门禁日志原始SHA、完整helper输出、映射文件和检查结果：out/verification/i2-j1-03d2c48/identity/windows114-integration-review.json及windows114-integration-frozen-map.json；gate日志windows114-integration-strict-gate.log。Root真实session45975 exit0由Root另持有，本复核未轮询或重启该session。

同v3 K1→本轮113基线另已核实：182→193项，无缺项或逐项/总量下降，57181→93592。10项站点/入口差异及源码原因见out/collab/i2-k1-windows113-v3-baseline-review.md，机械JSON保留原报告SHA。此复核不代替仍须关闭的03d M0 Windows GUI短路径fixture失败；其原失败单独保留，由Root按真实8.3反例修订测试。
