# K1 → I2/J1 Windows113 同v3逐项基线复核

**结论：无缺项、无逐项下降、无总量下降。未重跑测试，未放宽门槛。**

基线为K1 `2914b3962167325628ede699b1c14a9d224dec41` 的182项完整Windows报告；本轮为 `5fe0a1052e33c96d033375d0920f29b15d432dcc` 的实际113四profile，44 static + 59 GUI + 61 backend + 29 integration = 193。各项均pass/exit0/非零断言，均使用 `settrace_assert_lines_v3`；C++源码指纹均为890635b6…，没有跨probe比较。

总量57181→93592（+36411）；原182项净增加35783，11项新增合计628。missing_cases=[]，regressions=[]。原报告/日志及SHA均保持；JSON记录四份当前报告与基线的原始SHA及每项差异日志身份。

| Profile | 用例 | 实际断言入口 |
|---|---:|---:|
| static | 44 | 3964 |
| gui | 59 | 6760 |
| backend | 61 | 76814 |
| integration | 29 | 6054 |

以下列出所有10项计数或站点差异；其余172个既有用例两项计数均相同。

| 用例/文件 | 入口旧→新 | 站点旧→新 | 原因 |
|---|---:|---:|---|
| fields_a7 / `scripts/test_fields_a7.py` | 336→336 | 23→24 | 新增GDML能力分支及OFF拒绝时输入未改断言；113实际GDML ON，OFF新增站点未执行，原336个入口保持。 |
| gdml_bias_identity / `scripts/test_gdml_bias_identity.py` | 97→97 | 10→12 | 新增GDML OFF拒绝、无dump及原始输入未改分支；113走原ON附件/过程证据路径，原97个入口保持。 |
| gdml_touchable_identity / `scripts/test_gdml_touchable_identity.py` | 65→65 | 13→14 | 新增GDML OFF输入未改/拒绝路径；113保留原ON触摸路径身份检查，原65个入口保持。 |
| geometry_a5 / `scripts/test_geometry_a5.py` | 4320→4321 | 48→56 | 主入口新增实际capabilities中的唯一GDML条目/布尔类型检查，ON原往返/敏感体测试保留；执行入口增加1，另有OFF专用未执行站点。 |
| gui_config_editors / `gui/smoke_tests/smoke_config_editors.py` | 33→38 | 23→28 | J1将3D实际组件移入preview dock，测试增加滚动容器、真实组件归属、激活入口及正常关闭收尾检查，执行入口33→38。 |
| gui_f4_layout / `gui/smoke_tests/smoke_f4_layout.py` | 257→265 | 31→32 | 按J1共享logs dock检查实际可见/归属与裁剪链，新增站点在语言/窗口布局循环中执行；站点31→32，实际入口257→265。 |
| gui_i1_environment / `gui/smoke_tests/smoke_i1_environment.py` | 464→488 | 103→103 | 脚本字节未变。环境dialog的_buttons从4个增加为5个（安装按钮）；3种语言×4种宽度×每按钮2个断言，恰增加24个入口。 |
| gui_i1_environment_backend / `gui/smoke_tests/smoke_i1_environment.py` | 468→492 | 103→103 | 与gui_i1_environment相同的按钮布局循环；脚本未变，真实后端模式原附加检查保持，增加24个入口。 |
| k1_staging_alias / `scripts/test_k1_staging_alias.py` | 16→36 | 17→39 | 2914基线后增加晚变化reparse/junction资源路径反例及真实staging清理拒绝检查；对应K1已有独审回归，入口16→36，未放宽链接边界。 |
| run_summary / `scripts/test_run_summary.py` | 1570→37271 | 460→476 | 新增真实MT逐事件/逐hit的runID、事件归属、初级粒子能量/位置检查和完整worker参与证据；CSV数据行循环贡献大量入口（1570→37271）。本次source-change/native-interleave均attempt1且每run两worker实际被观察到。增加的入口不是35701个独立站点或物理基准，原站点460→476；总量增加主要来自逐行验证。 |

新增11项：`ci_geant4_data`, `frozen_startup`, `gui_i2_install`, `gui_j1_appearance`, `gui_workspace_layout`, `install_ci_delivery`, `install_plan`, `install_service`, `platform_install_layout`, `platform_path_fixture_policy`, `run_summary_mt_observation`。

证据：`out/collab/i2-k1-windows113-v3-baseline-comparison.json`。该文件是四份真实报告的只读比较视图，不是声称另执行了一轮193项测试的合成报告。逐项不下降门禁独立于新增项/总量，不让新用例掩盖旧用例下降。

当前114重跑及其新测试提交03d2c48另有正式报告。这里专门按Root指定的113四profile对比K1，不把114 GDML OFF的不同能力路径混入113同能力基线，也不把该比较当作新增物理验证。
