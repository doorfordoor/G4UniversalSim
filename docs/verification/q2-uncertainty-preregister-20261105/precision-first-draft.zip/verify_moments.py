#!/usr/bin/env python3
"""Pure mathematics checks for the Q2-4 pre-registration (no backend, no output).

Three independent identities that the future execution task will use:

1. Ratio (delta-method) relative error: for per-event numerator/denominator
   pairs, the uncorrected-moment formula printed by the project
       R^2 = sumSq_B/B^2 + sumSq_A/A^2 - 2*sum_AB/(A B)
   equals the first-order delta propagation with the 1/N terms included, i.e.
   the documented claim "the 1/N terms cancel" is an algebraic identity, not an
   assumption. The frozen covariance fixture A=[1,2,0], B=[2,1,0] gives
   A=B=3, sumSq_A=sumSq_B=5, sum_AB=4, Q=B/A=1, R=sqrt(2)/3.

2. Twelve-significant-digit printing: the project prints public moments with
   std::setprecision(12). A half-unit interval propagates through
   let_d - let_t; for the frozen REF-LET-01-EM 100 MeV values the interval is
   about 4.2e-4 relative (the printed difference is only 2.365e-8), which is
   *larger* than 1e-12 and *much* smaller than 5%, so a uniform 1e-12 relative
   comparison of the difference would be invalid while the pre-registered
   half-unit interval is safe to use.

3. Bernoulli fluence: with K hit events each contributing 0.1 mm / 10 mm^3 =
   0.01 mm^-2, sum = K/100, sumSq = K/10000, so the uncorrected relative error
   is exactly sqrt(1/K - 1/N) for 0 < K <= N.
"""

from __future__ import annotations

import json
import math
import sys
from decimal import Decimal, getcontext
from fractions import Fraction
from pathlib import Path

getcontext().prec = 60
ROOT = Path(__file__).resolve().parent


def check(checks: list[dict], cid: str, ok: bool, detail: str) -> None:
    checks.append({"id": cid, "status": "pass" if ok else "fail", "detail": detail})


def ratio_relative_error(a: list[float], b: list[float]) -> dict:
    """Both expressions: raw-moment formula and delta propagation with 1/N terms."""
    n = len(a)
    A = math.fsum(a)
    B = math.fsum(b)
    sa = math.fsum(x * x for x in a)
    sb = math.fsum(x * x for x in b)
    ab = math.fsum(x * y for x, y in zip(a, b))
    raw = sb / B ** 2 + sa / A ** 2 - 2.0 * ab / (A * B)
    # same first-order variance written with the explicit 1/N contributions
    var_a = sa - A * A / n
    var_b = sb - B * B / n
    cov = ab - A * B / n
    delta = var_b / B ** 2 + var_a / A ** 2 - 2.0 * cov / (A * B)
    return {"A": A, "B": B, "sumSqA": sa, "sumSqB": sb, "sumAB": ab,
            "R2_raw": raw, "R2_with_1_over_N": delta,
            "R": math.sqrt(max(raw, 0.0)), "ratio": B / A if A else float("nan")}


def half_unit_interval(printed: str) -> tuple[Decimal, Decimal]:
    """Additive half-unit interval of a decimal string printed with 12 sig digits."""
    value = Decimal(printed)
    exponent = value.as_tuple().exponent
    half = Decimal(1).scaleb(exponent) / Decimal(2)
    return value - half, value + half


def relative_half_width(low: Decimal, high: Decimal, value: Decimal) -> Decimal:
    return (high - low) / (2 * abs(value))


def main() -> int:
    checks: list[dict] = []

    # ---- 1. ratio delta identity and the frozen covariance fixture ----
    fixture = ratio_relative_error([1.0, 2.0, 0.0], [2.0, 1.0, 0.0])
    check(checks, "RATIO-FIXTURE-SUMS",
          fixture["A"] == 3.0 and fixture["B"] == 3.0 and fixture["sumSqA"] == 5.0
          and fixture["sumSqB"] == 5.0 and fixture["sumAB"] == 4.0,
          f"frozen fixture moments: {fixture['A']}, {fixture['B']}, "
          f"{fixture['sumSqA']}, {fixture['sumSqB']}, {fixture['sumAB']}")
    check(checks, "RATIO-FIXTURE-R", abs(fixture["R"] - math.sqrt(2) / 3) < 1e-15,
          f"R = sqrt(2)/3 = {math.sqrt(2) / 3}, computed {fixture['R']}")
    check(checks, "RATIO-1OVER-N-CANCEL",
          abs(fixture["R2_raw"] - fixture["R2_with_1_over_N"]) < 1e-15,
          "raw-moment formula equals the 1/N-explicit delta form for the fixture")

    # a few deterministic, non-degenerate event pairs
    sample_a = [0.3, 1.2, 0.0, 0.7, 2.0, 0.1, 1.5, 0.0, 0.9, 0.4]
    sample_b = [1.0, 0.5, 0.0, 2.0, 1.5, 0.2, 0.0, 3.0, 1.1, 0.6]
    sample = ratio_relative_error(sample_a, sample_b)
    check(checks, "RATIO-CANCEL-SAMPLE",
          abs(sample["R2_raw"] - sample["R2_with_1_over_N"]) < 1e-13,
          f"raw {sample['R2_raw']} vs 1/N form {sample['R2_with_1_over_N']} "
          f"(difference {abs(sample['R2_raw'] - sample['R2_with_1_over_N']):.3e})")

    # ---- 2. 12-digit half-unit propagation through let_d - let_t ----
    # values are the frozen REF-LET-01-EM 100 MeV public results
    let_t_low, let_t_high = half_unit_interval("1.36016812632")
    let_d_low, let_d_high = half_unit_interval("1.36016814997")
    let_t = Decimal("1.36016812632")
    let_d = Decimal("1.36016814997")
    diff_low = let_d_low - let_t_high
    diff_high = let_d_high - let_t_low
    diff = let_d - let_t
    rel_let_t = relative_half_width(let_t_low, let_t_high, let_t)
    rel_diff = relative_half_width(diff_low, diff_high, diff)
    check(checks, "PRECISION-LET-HALF-UNIT-BELOW-5PCT",
          rel_diff < Decimal("0.05"),
          f"relative half-width of let_d-let_t = {rel_diff:.3e} < 0.05")
    check(checks, "PRECISION-DIFFERENCE-NOT-1E12",
          rel_diff > Decimal("1e-12"),
          f"relative half-width of the difference = {rel_diff:.3e} > 1e-12, so a "
          f"uniform 1e-12 relative test of the difference would be invalid")
    check(checks, "PRECISION-LET-T-SMALL",
          rel_let_t < Decimal("1e-11"),
          f"single-value let_t half-width = {rel_let_t:.3e} < 1e-11 "
          f"(12 printed significant digits)")
    check(checks, "PRECISION-POSITIVE-DIFFERENCE", diff > 0,
          f"let_d-let_t = {diff} (printed precision) is positive")
    # the difference including half-units stays positive: the sign is not a
    # printing artefact
    check(checks, "PRECISION-DIFFERENCE-SIGN-ROBUST", diff_low > 0,
          f"lower half-unit bound of let_d-let_t = {diff_low} > 0")

    # ---- 3. Bernoulli fluence moments and 2-sigma criterion ----
    n = 2000
    bad = []
    for k in (1347, 1429, 1, 1999, 1000):
        phi = Fraction(k, 1) / 100
        sum_sq = Fraction(k, 1) / 10000
        r_sq = sum_sq / phi ** 2 - Fraction(1, n)
        if r_sq != Fraction(1, k) - Fraction(1, n):
            bad.append(k)
    check(checks, "FLUENCE-BERNOULLI-R", not bad,
          "sumSq/sum^2 - 1/N == 1/K - 1/N exactly for the frozen Bernoulli model"
          + (f"; mismatches {bad}" if bad else ""))
    # 2-sigma interval in fluence units versus the exact integer interval
    bad = []
    for k in range(1, n + 1):
        phi = k / 100.0
        sigma = phi * math.sqrt(1.0 / k - 1.0 / n)
        float_ok = abs(phi - n / 144) <= 2.0 * sigma
        exact_ok = n * (144 * k - 100 * n) ** 2 <= 4 * 144 * 144 * k * (n - k)
        if float_ok != exact_ok:
            bad.append(k)
    check(checks, "FLUENCE-2SIGMA-EQUIVALENCE", not bad,
          "float 2-sigma criterion == exact integer criterion for K=1..2000"
          + (f"; mismatches {bad[:5]}" if bad else ""))

    failed = [c for c in checks if c["status"] != "pass"]
    result = {
        "schema": "g4usim_q2_uncertainty_moments_v1",
        "program": "verify_moments.py",
        "checks": checks,
        "checks_total": len(checks),
        "checks_pass": len(checks) - len(failed),
        "checks_fail": len(failed),
        "status": "pass" if not failed else "fail",
        "values": {
            "ratio_fixture": fixture,
            "ratio_cancel_sample": {
                "R2_raw": sample["R2_raw"],
                "R2_with_1_over_N": sample["R2_with_1_over_N"],
            },
            "let_100MeV_half_units": {
                "let_t_interval": [str(let_t_low), str(let_t_high)],
                "let_d_interval": [str(let_d_low), str(let_d_high)],
                "difference": str(diff),
                "difference_interval": [str(diff_low), str(diff_high)],
                "relative_half_width_let_t": str(rel_let_t),
                "relative_half_width_difference": str(rel_diff),
            },
        },
    }
    (ROOT / "verify_moments_results.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "checks": f"{result['checks_pass']}/{result['checks_total']}",
        "failed": [c["id"] for c in failed],
        "values": result["values"],
    }, indent=1, default=str))
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
