#!/usr/bin/env python3
"""Build proposal.json for the Q2-4 pre-registration (deterministic, no backend)."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]


def sha(path: str) -> str:
    return hashlib.sha256((REPO / path).read_bytes()).hexdigest()


BACKEND = {
    "build": "864bc036d6d7752475e52db4efd2b950cabfcc3d",
    "exe_sha256": "f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f",
    "geant4": "11.3.2",
    "data_check_command": "--check-geant4-data",
}

EXEC_ROOT = "out/collab/q2-uncertainty-v1"

OUTPUT_SEMANTICS = {
    "run_summary.txt": {
        "scope": "run", "required": True,
        "notes": "status must be completed, program_exit_code 0, actual_completed_event_count must equal the number of events that actually ran; never use generated-file count as completion.",
    },
    "run_metadata.json": {
        "scope": "run", "required": True,
        "notes": "schema run_metadata_json_v1; values.actual_completed_event_count, values.actual_threads, runs[].completed_events and generated_files[].sha256 are the completion and asset-identity evidence; run_metadata.json records itself with integrity_status=self_reference_excluded.",
    },
    "dose_volume_summary_t0.csv": {
        "scope": "thread",
        "required_when": "dose=true",
        "rows": "one row per sensitive volume that received at least one non-zero deposition in that worker; header-only file is a valid representation when nothing was scored",
        "columns": ["runID", "volume_path", "volume_name", "mass_kg", "raw_edep_MeV", "weighted_edep_MeV", "raw_dose_Gy", "weighted_dose_Gy", "raw_edep_sum_sq_MeV2", "weighted_edep_sum_sq_MeV2", "n_events"],
        "notes": "n_events is the worker's completed-event count (each event including zero-deposition events); rows are per worker (suffix _tN).",
    },
    "let_volume_summary_t0.csv": {
        "scope": "thread",
        "required_when": "let=true",
        "rows": "one row per sensitive volume that received at least one valid LET step in that worker; header-only file is a valid representation when nothing was scored",
        "columns": ["runID", "volume_path", "volume_name", "particles", "steps", "sum_wl_mm", "sum_wSl_MeV", "sum_wS2l_MeV2_per_mm", "let_t_keV_per_um", "let_d_keV_per_um", "sum_sq_wl_mm2", "sum_sq_wSl_MeV2", "sum_sq_wS2l_MeV4_per_mm2", "sum_wl_x_wSl_MeV_mm", "sum_wSl_x_wS2l_MeV3_per_mm", "n_events"],
        "notes": "valid LET step = stepLength>0, positive track weight, non-neutral particle (ElectronicStoppingPower of a geantino is 0) and a passing particle filter; n_events is the worker's completed-event count.",
    },
    "event_edep_t0.csv": {
        "scope": "thread",
        "required_when": "event_edep=true",
        "rows": "exactly one row per completed event handled by the worker, including events with zero deposition; 20 rows for 20 events on one thread",
        "columns": ["runID", "eventID", "raw_edep_MeV", "weighted_edep_MeV"],
        "notes": "raw_edep_MeV is the sum of every positive-deposition step's edep in MeV for the event (unweighted); weighted_edep_MeV is the same sum with edep*trackWeight; all sensitive volumes contribute to the single per-event row, so a single sensitive volume is required for per-volume attribution.",
    },
    "scorer_statistics.csv": {
        "scope": "run",
        "required_when": "any HistoryStatistics entry was submitted",
        "rows": "one row per (scorer, quantity, key); absent when nothing was scored (for example the zero-deposition case)",
        "columns": ["runID", "scorer", "quantity", "key", "name", "unit", "estimator", "n_events", "entries", "value", "mean_per_event", "std_error", "rel_error", "fom_per_s", "run_wall_time_s", "sum", "sum_sq", "uncertainty_estimator", "uncertainty_status"],
        "notes": "n_events is the global run event count (zero contributions included); entries is the number of events with a non-zero contribution; rel_error uses sqrt(sum_sq/sum^2 - 1/N) with the global N; uncertainty_status follows the HistoryStatistics priority (events<2 insufficient_events, ratio denominator zero undefined_ratio, numerator zero zero_total, else approximate); estimator total for scalar quantities and ratio for LET ratios.",
    },
}

FORMULAS = {
    "dose_generation": "dose_Gy_per_event_i = edep_MeV_i * 1.602176634e-13 / mass_kg; sum_Gy = sum_i dose_i; the dose CSV n_events is N (zero-deposition events contribute zero dose but count in N).",
    "dose_moments": "S = sum_i x_i over all completed events (x_i=0 for zero deposition); S2 = sum_i x_i^2; R = sqrt(S2/S^2 - 1/N); sigma = R*|S|; do not use the number of hits rows as N.",
    "event_edep_merge": "For every completed event there is exactly one event_edep row; the dose S output must equal sum(raw_edep_MeV_i)*1.602176634e-13/mass_kg within the pre-registered half-unit interval, and the event_edep raw sum must equal the dose CSV raw_edep_MeV.",
    "ratio_delta": "Q = B/A with unweighted per-event moments: R_Q^2 = sumSq_B/B^2 + sumSq_A/A^2 - 2*sum_AB/(A*B). For LET: let_t = sum_wSl/sum_wl (A=sum_wl, B=sum_wSl, sum_AB=sum_wl_x_wSl); let_d = sum_wS2l/sum_wSl (A=sum_wSl, B=sum_wS2l, sum_AB=sum_wSl_x_wS2l). Both delta ratios use their own cross moment; the unknown covariance between the two ratios is not set to zero.",
    "half_unit_interval": "Every project CSV scalar is printed with std::setprecision(12). A printed value d is treated as the interval [d - 0.5*10^e, d + 0.5*10^e] where e is the printed decimal exponent. Comparisons use the propagated interval, never a uniform 1e-12 relative tolerance. Pure math verification (verify_moments.py) shows the half-unit interval of let_d - let_t for the frozen REF-LET-01-EM 100 MeV values is about 4.2e-4 relative while the single values are 3.7e-12 relative.",
    "fluence_bernoulli": "For a fully covering 12x12 mm beam and a 10x10x0.1 mm Galactic slab, every crossing event contributes exactly 0.1 mm / 10 mm^3 = 0.01 mm^-2, so Phi = K/100 mm^-2 and sumSq/sum^2 - 1/N = 1/K - 1/N exactly for the uncorrected event-moment estimator. This is a model assumption that the execution must verify per batch: every event with a fluence entry has merged path length 0.1 mm.",
    "coverage_single_batch": "covered(K) := |K/100 - N/144| <= 2*(K/100)*sqrt(1/K - 1/N). With N=2000 and p=25/36 the exact integer equivalent used by verify_coverage.py is 36*|K - 12500/9| <= 2*sqrt(K*(1 - K/2000))*36; the frozen values are K in [1347,1429], probability 0.9559137115315595. The execution must apply the criterion to printed Phi and rel_error (half-unit intervals) and cross-check it with the exact integer form.",
}


def case(cid, title, purpose, main_ini, geometry, macro, seed, threads, events,
         physics, scoring, expected, quantities, checks, missing_rows, note, limitations):
    return {
        "id": cid,
        "title": title,
        "purpose": purpose,
        "inputs": {
            "main_ini": f"{EXEC_ROOT}/inputs/{main_ini}",
            "geometry": f"{EXEC_ROOT}/inputs/{geometry}",
            "materials": f"{EXEC_ROOT}/inputs/materials.ini",
            "macro": f"{EXEC_ROOT}/inputs/{macro}",
            "seed": seed,
            "threads": threads,
            "events": events,
            "physics": physics,
            "scoring": scoring,
        },
        "backend_command_template": (
            "<backend exe> --config {root}/inputs/" + main_ini
            + " --macro {root}/inputs/" + macro
            + " --output {root}/runs/" + cid.lower().replace("unc-", "unc_").replace("-", "_")
            + "/output"),
        "expected_artifacts": expected,
        "raw_quantities": quantities,
        "checks": checks,
        "missing_row_semantics": missing_rows,
        "notes": note,
        "limitations": limitations,
    }


CASES = [
    case(
        "UNC-TOT", "Event totals and zero contributions",
        "Merge the raw per-event depositions, recompute S, S^2 and entries with the completed events that never appear (zero contribution) folded into N.",
        "main_unc_tot.ini", "geometry_unc_tot.ini", "run_unc_tot.mac",
        20261120, 1, 20,
        "EM option4 only; default_cut 10 um",
        "dose=true, event_edep=true, hits=false; single sensitive Slab (10x10x0.02 mm Si, mass 4.66e-06 kg); 12x12 mm square proton beam at z=-1 mm",
        ["run_summary.txt", "run_metadata.json", "dose_volume_summary_t0.csv",
         "event_edep_t0.csv", "scorer_statistics.csv"],
        [
            {"name": "S", "source": "event_edep_t0.csv raw_edep_MeV", "unit": "MeV", "semantics": "sum over all completed events, zero rows included"},
            {"name": "S2", "source": "event_edep_t0.csv raw_edep_MeV", "unit": "MeV^2", "semantics": "sum of squares over the same rows"},
            {"name": "N", "source": "run_summary.actual_completed_event_count and run_metadata.runs[0].completed_events", "unit": "events", "semantics": "must be 20, not the number of hits rows"},
            {"name": "dose_sum", "source": "dose_volume_summary_t0.csv raw_dose_Gy/weighted_dose_Gy", "unit": "Gy", "semantics": "summed per event, mass from the same row"},
            {"name": "dose_stats", "source": "scorer_statistics.csv rows scorer=dose quantity=raw_dose|weighted_dose", "unit": "Gy", "semantics": "value, mean_per_event, std_error, rel_error, n_events, entries, uncertainty_status"},
        ],
        [
            {"id": "TOT-COMPLETED", "rule": "run_summary.status=completed, program_exit_code=0, actual_completed_event_count=20; run_metadata.runs[0].completed_events=20"},
            {"id": "TOT-EVENT-ROWS", "rule": "event_edep_t0.csv has exactly 20 data rows and eventID values are exactly the 20 completed event ids (one row per event; duplicates or missing ids fail)"},
            {"id": "TOT-ZERO-ROWS-KEPT", "rule": "if any event has zero deposition, its event_edep row exists with raw_edep_MeV=0; no row may be dropped and no zero row may be fabricated for a non-completed event"},
            {"id": "TOT-EDEP-EQ-DOSE", "rule": "sum(event_edep raw_edep_MeV)*1.602176634e-13/mass_kg equals dose CSV raw_dose_Gy within the half-unit interval propagated from both printed values and mass_kg; weighted uses weighted_edep and the event weight column is not available, so weighted equality is checked only when all weights are 1"},
            {"id": "TOT-MOMENTS", "rule": "R = sqrt(S2/S^2 - 1/N) equals the printed dose rel_error within the propagated half-unit interval; entries equals count(raw_edep>0); n_events=20; uncertainty_status=approximate"},
            {"id": "TOT-NOT-HITS-ROWS", "rule": "N comes from run_summary/metadata; if the number of event_edep rows were used as N the recomputation must be rejected by TOT-MOMENTS"},
            {"id": "TOT-MASS", "rule": "dose CSV mass_kg equals the geometric Si mass 4.66e-06 kg within the half-unit interval; no hit-count-based mass"},
        ],
        ({**OUTPUT_SEMANTICS}),
        "Single sensitive volume only, so the per-event event_edep row has unambiguous per-volume attribution. The comparison uses the half-unit interval of printed 12-digit values, not a relative tolerance.",
        ["Only one geometry and one sensitive volume; conclusions do not generalize to multiple SDs.",
         "event_edep raw weights are unavailable in the public CSV, so weighted identities are restricted to unit-weight events."],
    ),
    case(
        "UNC-N1", "N<2 statistics status",
        "A deterministic in-volume point source guarantees a scored event; verify the N=1 public statistics are labelled insufficient rather than treated as a valid zero error.",
        "main_unc_n1.ini", "geometry_unc_n1.ini", "run_unc_n1.mac",
        20261121, 1, 1,
        "EM option4 only; default_cut 10 um",
        "dose=true, let=true (particles=proton), hits=false; sensitive Si slab 10x10x2 mm centred at the origin; point proton 10 MeV at (0,0,0) along +z",
        ["run_summary.txt", "run_metadata.json", "dose_volume_summary_t0.csv",
         "let_volume_summary_t0.csv", "scorer_statistics.csv"],
        [
            {"name": "dose", "source": "dose_volume_summary_t0.csv", "unit": "Gy", "semantics": "non-zero single event; n_events=1"},
            {"name": "let", "source": "let_volume_summary_t0.csv", "unit": "keV/um", "semantics": "let_t, let_d from a valid proton step"},
            {"name": "stats", "source": "scorer_statistics.csv", "unit": "mixed", "semantics": "4 rows: dose raw/weighted (total) and let_t/let_d (ratio)"},
        ],
        [
            {"id": "N1-COMPLETED", "rule": "actual_completed_event_count=1; run_metadata.runs[0].completed_events=1"},
            {"id": "N1-DOSE-ROW", "rule": "dose CSV has exactly one row for the sensitive volume with finite raw_dose_Gy>0, mass 4.66e-04 kg, n_events=1"},
            {"id": "N1-LET-ROW", "rule": "let CSV has exactly one row with finite positive let_t>0 and let_d>0, n_events=1; the geometry and 10 MeV point source make a valid LET step deterministic, so a missing row is a failure rather than an expected zero"},
            {"id": "N1-STATUS", "rule": "all four scorer_statistics rows have n_events=1 and uncertainty_status=insufficient_events; the printed rel_error must not be reported as a valid zero error"},
            {"id": "N1-NO-ZERO-FABRICATION", "rule": "no row may be added with status approximate or with a fabricated non-zero error; the status priority from HistoryStatistics (N<2 first) is the arbiter"},
        ],
        ({**OUTPUT_SEMANTICS}),
        "The expectation is written before execution from the producer source: DoseScorer/LETScorer score the in-volume primary, and HistoryStatistics marks N<2 as insufficient_events. If the fixed input produces a missing row, report a real failure (do not change the seed or the geometry).",
        ["Single event in a 2 mm slab; the result says nothing about dose accuracy or LET physics."],
    ),
    case(
        "UNC-ZERO", "No deposition and no selected particles",
        "A geantino point source inside the same slab gives zero deposition and no charged-physics LET step; verify the producer's public representation of empty scoring (header-only files, no statistics file, no fabricated zero rows).",
        "main_unc_zero.ini", "geometry_unc_n1.ini", "run_unc_zero.mac",
        20261122, 1, 100,
        "EM option4 only; default_cut 10 um",
        "dose=true, let=true (particles=proton), hits=false, event_edep=false; geantino 100 MeV point at (0,0,0) along +z",
        ["run_summary.txt", "run_metadata.json", "dose_volume_summary_t0.csv",
         "let_volume_summary_t0.csv"],
        [
            {"name": "dose_empty", "source": "dose_volume_summary_t0.csv", "unit": "none", "semantics": "header-only file, no data rows"},
            {"name": "let_empty", "source": "let_volume_summary_t0.csv", "unit": "none", "semantics": "header-only file, no data rows"},
            {"name": "stats", "source": "scorer_statistics.csv", "unit": "none", "semantics": "absent because no HistoryStatistics entry is submitted"},
        ],
        [
            {"id": "ZERO-COMPLETED", "rule": "actual_completed_event_count=100; run_summary.status=completed"},
            {"id": "ZERO-DOSE-HEADER-ONLY", "rule": "dose_volume_summary_t0.csv exists with the exact header and zero data rows"},
            {"id": "ZERO-LET-HEADER-ONLY", "rule": "let_volume_summary_t0.csv exists with the exact header and zero data rows"},
            {"id": "ZERO-STATS-ABSENT", "rule": "scorer_statistics.csv is absent; absence is the contract, not a zero-error row"},
            {"id": "ZERO-NO-FABRICATION", "rule": "no zero_total or undefined_ratio row exists anywhere; a fabricated row is a failure"},
            {"id": "ZERO-METADATA", "rule": "run_metadata.generated_files lists the two header-only files with their sha256 and the run completion is still recorded"},
        ],
        ({**OUTPUT_SEMANTICS}),
        "DoseScorer/LETScorer write their CSV at run end even with no scored volume; WriteScorerStatisticsCsv is only called for submitted entries. Both are verified from source before this case. If a producer instead skips the empty file, report the contract mismatch; do not invent the row.",
        ["Empty scoring representation only; it says nothing about detector behaviour under real particles."],
    ),
    case(
        "UNC-LET-COV", "Ratio covariance from public cross moments",
        "Recompute both LET delta-method relative errors from the public A/B/C and BA/AC moments; no physical 5% LET_d/LET_t bound is used here.",
        "main_unc_let_cov.ini", "geometry_unc_let_cov.ini", "run_unc_let_cov.mac",
        20261123, 1, 2000,
        "reference = FTFP_BERT_EMZ; default_cut 10 um (same as the frozen REF-LET-v1 case)",
        "let=true (particles=proton), hits=false, event_edep=false, dose=false; LetTarget 10x10x0.02 mm Si; point proton 100 MeV at (0,0,-3) mm along +z",
        ["run_summary.txt", "run_metadata.json", "let_volume_summary_t0.csv", "scorer_statistics.csv"],
        [
            {"name": "A", "source": "let CSV sum_wl_mm", "unit": "mm", "semantics": "sum of weighted step length per event"},
            {"name": "B", "source": "let CSV sum_wSl_MeV", "unit": "MeV", "semantics": "sum of weighted stopping-power*length"},
            {"name": "C", "source": "let CSV sum_wS2l_MeV2_per_mm", "unit": "MeV^2/mm", "semantics": "sum of weighted squared stopping-power*length"},
            {"name": "BA", "source": "let CSV sum_wl_x_wSl_MeV_mm", "unit": "MeV*mm", "semantics": "cross moment of let_t numerator and denominator"},
            {"name": "AC", "source": "let CSV sum_wSl_x_wS2l_MeV3_per_mm", "unit": "MeV^3/mm", "semantics": "cross moment of let_d numerator and denominator"},
            {"name": "stats", "source": "scorer_statistics.csv rows scorer=let quantity=let_t|let_d", "unit": "keV/um", "semantics": "value, rel_error, std_error, n_events, entries"},
        ],
        [
            {"id": "LET-COV-ROWS", "rule": "exactly one let CSV row; n_events=2000; particles=proton; steps>0"},
            {"id": "LET-COV-LET-VALUES", "rule": "let_t = B/A and let_d = C/B equal the printed let_t_keV_per_um and let_d_keV_per_um within the half-unit interval"},
            {"id": "LET-COV-RT", "rule": "R_t^2 = sum_sq_wSl/B^2 + sum_sq_wl/A^2 - 2*BA/(A*B) equals the printed let_t rel_error^2 within the propagated interval; n_events=2000; status=approximate"},
            {"id": "LET-COV-RD", "rule": "R_d^2 = sum_sq_wS2l/B^2 + sum_sq_wSl/C^2 - 2*AC/(C*B) equals the printed let_d rel_error^2 within the propagated interval"},
            {"id": "LET-COV-CROSS-MOMENTS", "rule": "the recomputation uses BA and AC from the CSV; setting either cross moment to zero must be detected as a mismatch (counterexample)"},
            {"id": "LET-COV-NO-PHYSICAL-BOUND", "rule": "no comparison against 0.05 or any LET_d/LET_t physical bound is part of this case; only the statistical identity is checked"},
        ],
        ({**OUTPUT_SEMANTICS}),
        "No distributional threshold and no old LET_d/LET_t 5% external bound; the case only checks the public covariance arithmetic. The two delta ratios keep their own cross moments; the covariance between them is unknown and not assumed zero.",
        ["A single 100 MeV point in 20 um Si; no physical validation of LET or of the physics list."],
    ),
    case(
        "UNC-MT-SPARSE", "Sparse multi-thread merging",
        "N=2 on 4 workers guarantees at least two workers cannot have events; merge by global event id and worker moments, never by averaging per-worker relative errors.",
        "main_unc_mt_sparse.ini", "geometry_unc_n1.ini", "run_unc_mt_sparse.mac",
        20261124, 4, 2,
        "EM option4 only; default_cut 10 um",
        "dose=true, let=true, event_edep=true, hits=false; point proton 10 MeV at (0,0,0) in the 10x10x2 mm Si slab",
        ["run_summary.txt", "run_metadata.json", "event_edep_t*.csv (any subset of {0,1,2,3})",
         "dose_volume_summary_t*.csv", "let_volume_summary_t*.csv", "scorer_statistics.csv"],
        [
            {"name": "global_events", "source": "all event_edep_t*.csv rows", "unit": "events", "semantics": "exactly 2 unique global event ids across all workers; no duplicated id is allowed to double count"},
            {"name": "global_S", "source": "sum raw_edep_MeV over the 2 rows", "unit": "MeV", "semantics": "equals the merged dose sum; N=2"},
            {"name": "worker_dose", "source": "dose_volume_summary_t*.csv", "unit": "Gy", "semantics": "sums and n_events add across workers"},
            {"name": "worker_let", "source": "let_volume_summary_t*.csv", "unit": "mixed", "semantics": "A/B/C/BA/AC add across workers; ratios are computed only after merging"},
        ],
        [
            {"id": "MT-METADATA", "rule": "actual_threads=4; actual_completed_event_count=2; run_metadata.runs[0].completed_events=2"},
            {"id": "MT-EVENT-IDS", "rule": "the union of event_edep eventIDs has size 2 and no duplicate; empty/missing worker files are allowed and are not an error"},
            {"id": "MT-EDEP-MERGE", "rule": "sum(raw_edep_MeV) equals dose CSV raw_dose_Gy*mass/1.602176634e-13 within the half-unit interval; weighted identity only if all weights are 1"},
            {"id": "MT-DOSE-STATS", "rule": "dose scorer_statistics n_events=2, entries=number of events with deposition, rel_error equals sqrt(S2/S^2-1/2) from the merged moments"},
            {"id": "MT-LET-MERGE", "rule": "merge A,B,C,BA,AC by summation; let_t/let_d and both rel_errors match the printed rows; worker ratio averaging must fail"},
            {"id": "MT-NO-WORKER-AVERAGE", "rule": "the comparator records both the merged rel_error and the (wrong) average of per-worker relative errors; equality with the printed row uses the merged value and the difference from the worker average is reported"},
        ],
        ({**OUTPUT_SEMANTICS}),
        "N<threads guarantees at least two empty workers; the proposal never assumes worker 0 has an event or that every worker writes a non-empty file. Sparse per-worker files are expected, not a failure.",
        ["Only two events; the case checks merge arithmetic, not statistical accuracy.", "Path-type quantities are not recovered from ordinary hits when hits are disabled."],
    ),
    case(
        "UNC-COMPONENT", "Real shared-implementation status boundaries",
        "Call the real HistoryStatistics implementation through a one-off component probe (not a Python mirror) for the status-priority fixtures and the frozen covariance fixture; no product interface is added.",
        "n/a (C++ probe, not an INI)", "n/a", "n/a", 0, 1, 0,
        "none (no Geant4 run)", "component-level only",
        ["probe results JSON produced under out/collab/q2-uncertainty-v1/probe/"],
        [
            {"name": "status_and_moments", "source": "probe output", "unit": "n/a", "semantics": "each fixture returns the documented status and moments"},
        ],
        [
            {"id": "CMP-BUILD", "rule": "the probe compiles against the repository's real src/Scoring/HistoryStatistics.cc; the build command and the source SHA are recorded"},
            {"id": "CMP-FIXTURES", "rule": "fixtures: N=0,num=1,total -> insufficient_events; N=1,num=0,ratio,den=0 -> insufficient_events; N=2,num=1,ratio,den=0 -> undefined_ratio; N=2,num=0,total -> zero_total; N=2,num=0,ratio,den=1 -> zero_total; N=2,num=1,total -> approximate; N=2,num=1,ratio,den=1 -> approximate"},
            {"id": "CMP-COVARIANCE", "rule": "fixture A=[1,2,0], B=[2,1,0]: A=B=3, sumSqA=sumSqB=5, sum_AB=4, ratio=1, R=sqrt(2)/3"},
            {"id": "CMP-NO-MIRROR", "rule": "the probe source must link the real implementation (compile line includes src/Scoring/HistoryStatistics.cc); a self-contained Python re-implementation is not acceptable"},
        ],
        "n/a",
        "Component evidence only; it does not prove run-level files exist or that any case's statistics are correct.",
        ["The probe is a one-off artifact under the candidate directory, not a new product interface or test framework.", "Finite-value protection is out of scope for this pre-registration."],
    ),
    case(
        "UNC-COVERAGE", "Independent finite coverage batches",
        "64 fixed-seed independent geantino batches test whether the reported uncorrected-event standard error covers the known total fluence; coverage is asserted only for this frozen model and sample.",
        "main_unc_coverage.ini", "geometry_unc_coverage.ini", "run_unc_coverage.mac",
        "220001..220064 (one seed per batch, CLI override)", 1, 2000,
        "EM option4; default_cut 0.7 mm (frozen fluence reference settings)",
        "fluence=true, hits=false, event_edep=false; 10x10x0.1 mm Galactic slab; 12x12 mm square geantino beam at z=-2 mm along +z",
        ["64 x (run_summary.txt, run_metadata.json, fluence_volume_summary_t0.csv, scorer_statistics.csv)"],
        [
            {"name": "K", "source": "per batch: scorer_statistics.csv entries for raw_fluence/weighted_fluence, cross-checked with tracksum/0.1 and per-event 0.1 mm path", "unit": "events", "semantics": "number of events with a fluence entry; must equal round(track_length/0.1)"},
            {"name": "Phi", "source": "fluence CSV raw_fluence_mm-2", "unit": "mm^-2", "semantics": "K/100 for the full-coverage model"},
            {"name": "R", "source": "scorer_statistics.csv rel_error", "unit": "none", "semantics": "sqrt(1/K-1/N) exactly for this Bernoulli model"},
            {"name": "covered", "source": "K and printed Phi/R", "unit": "bool", "semantics": "|Phi - N/144| <= 2*Phi*R with half-unit intervals, and the exact integer criterion as cross-check"},
        ],
        [
            {"id": "COV-BATCHES", "rule": "exactly 64 runs with seeds 220001..220064, one each, all completed with N=2000; no extra batches, no resampling, no seed changes; unavailable samples are retained and reported, and any genuine failure stops the comparison instead of being replaced"},
            {"id": "COV-PATH", "rule": "per batch every fluence row's event path is 0.1 mm (merged per event) and K=round(track_length/0.1); otherwise the Bernoulli model does not apply and the case fails closed instead of tuning"},
            {"id": "COV-K-RANGE", "rule": "report all K; the frozen single-batch covered range is [1347,1429]; do not widen it"},
            {"id": "COV-MODEL-PROB", "rule": "reproduce the frozen design probability 0.9559137115315595 and the minimum covered count 57 (P(C<57)=0.006980515324) from the exact binomial; the design input is reproduced by verify_coverage.py (19/19 pass)"},
            {"id": "COV-COUNT", "rule": "C = count(covered batches); C >= 57 must pass; C < 57 must fail without resampling"},
            {"id": "COV-AGGREGATE", "rule": "sum(K) must lie in the frozen central 99% range [88464,89313]; the expected total is 88888.888...; a miss is a fail, not a reason to extend sampling"},
            {"id": "COV-SCOPE", "rule": "the conclusion is limited to this frozen distribution/model/sample; no universal confidence claim"},
        ],
        "n/a (all batches must produce the same files)",
        "The Bernoulli model requires the full 12x12 mm beam to cross the 10x10x0.1 mm slab with a full 0.1 mm path for every hit event; execution verifies this per batch and fails closed otherwise.",
        ["64 batches are independent only in the fixed-seed sense; the design does not claim universal coverage.",
         "Two tests each at 1% control; the union-bound false-rejection probability is <=2%, not a joint 1% claim."],
    ),
]

proposal = {
    "schema": "g4usim_q2_uncertainty_preregister_v1",
    "task_id": "q2-uncertainty-preregister-v1-20261105",
    "status": "draft",
    "execution_authorized": False,
    "created": "2026-11-05",
    "purpose": "Turn the frozen Q2-4 list into a finite, executable and independently repeatable contract: cases, draft inputs, row/missing-row semantics, checks, tolerances, counterexamples, and stopping conditions. No Geant4 run is performed or authorized by this document.",
    "scope": [
        "Seven pre-registered cases: UNC-TOT, UNC-N1, UNC-ZERO, UNC-LET-COV, UNC-MT-SPARSE, UNC-COMPONENT, UNC-COVERAGE.",
        "Pure mathematics and component-level checks for the statistics, plus a finite independent-batch coverage experiment.",
        "Public CSV and metadata evidence only; every raw quantity has a named source column and file.",
    ],
    "out_of_scope": [
        "No product, test, benchmark, freeze or table changes; no new observation fields, CLI or acceptance framework.",
        "No universal confidence/coverage claim; no physical dose/LET validation.",
        "No new cases, resampling, extra batches, or tolerance/seed changes after seeing results.",
        "Finite-value protection is not re-verified beyond the existing product behaviour.",
    ],
    "backend": BACKEND,
    "reference_documents": [
        {"path": "docs/collab/decisions/20261105-q2-uncertainty-coverage-design-v1.json",
         "sha256": sha("docs/collab/decisions/20261105-q2-uncertainty-coverage-design-v1.json")},
        {"path": "docs/collab/reviews/20261105-q2-uncertainty-preregister-review.md",
         "sha256": sha("docs/collab/reviews/20261105-q2-uncertainty-preregister-review.md")},
        {"path": "docs/collab/decisions/20261105-q2-dose-reference-freeze-v1.json",
         "sha256": sha("docs/collab/decisions/20261105-q2-dose-reference-freeze-v1.json")},
        {"path": "docs/collab/decisions/20261105-q2-fluence-reference-freeze-v1.json",
         "sha256": sha("docs/collab/decisions/20261105-q2-fluence-reference-freeze-v1.json")},
        {"path": "docs/collab/decisions/20261105-q2-let-reference-freeze-v1.json",
         "sha256": sha("docs/collab/decisions/20261105-q2-let-reference-freeze-v1.json")},
    ],
    "design_input": {
        "path": "docs/collab/decisions/20261105-q2-uncertainty-coverage-design-v1.json",
        "sha256": sha("docs/collab/decisions/20261105-q2-uncertainty-coverage-design-v1.json"),
        "reproduced": {
            "p": "25/36",
            "single_batch_covered_K_range": [1347, 1429],
            "single_batch_coverage_probability": "0.955913711531559450469938471146634229478641391760449724745053",
            "coverage_count_minimum": 57,
            "probability_below_minimum": "0.00698051532398270997145110458852696896657979204623148452122967",
            "aggregate_central_99_range": [88464, 89313],
            "aggregate_expected_K": "88888.8888888888888888888888888888888888888888888888888888889",
            "method": "independent exact-rational derivation: exact binomial normaliser 36^N, integer-interval equivalence, Decimal tails; see verify_coverage.py",
        },
    },
    "pure_math": {
        "coverage": {
            "program": "out/collab/q2-uncertainty-proposal-v1/verify_coverage.py",
            "sha256": sha("out/collab/q2-uncertainty-proposal-v1/verify_coverage.py"),
            "results": "out/collab/q2-uncertainty-proposal-v1/verify_coverage_results.json",
            "results_sha256": sha("out/collab/q2-uncertainty-proposal-v1/verify_coverage_results.json"),
            "status": "pass",
            "checks": "19/19",
            "command": "python -B out/collab/q2-uncertainty-proposal-v1/verify_coverage.py",
        },
        "moments": {
            "program": "out/collab/q2-uncertainty-proposal-v1/verify_moments.py",
            "sha256": sha("out/collab/q2-uncertainty-proposal-v1/verify_moments.py"),
            "results": "out/collab/q2-uncertainty-proposal-v1/verify_moments_results.json",
            "results_sha256": sha("out/collab/q2-uncertainty-proposal-v1/verify_moments_results.json"),
            "status": "pass",
            "checks": "11/11",
            "command": "python -B out/collab/q2-uncertainty-proposal-v1/verify_moments.py",
        },
    },
    "inputs": {
        "draft_root": "out/collab/q2-uncertainty-proposal-v1/inputs",
        "manifest": "out/collab/q2-uncertainty-proposal-v1/inputs_manifest.json",
        "manifest_sha256": sha("out/collab/q2-uncertainty-proposal-v1/inputs_manifest.json"),
        "generator": "out/collab/q2-uncertainty-proposal-v1/make_inputs.py",
        "generator_sha256": sha("out/collab/q2-uncertainty-proposal-v1/make_inputs.py"),
        "note": "Draft INI files use output paths under out/collab/q2-uncertainty-v1/runs/<case>/output; the execution task must copy them into its own candidate directory, verify every SHA, and may override the output directory with --output. The coverage batches must override only the seed with --seed.",
    },
    "output_semantics": OUTPUT_SEMANTICS,
    "formulas": FORMULAS,
    "cases": CASES,
    "execution": {
        "candidate_root": EXEC_ROOT,
        "forbidden_changes": [
            "product code, build files, tests, benchmarks, frozen decisions, NIEL tables, ROADMAP, STATUS",
            "frozen seeds/N/threads/cut/geometries/tolerances after observing results",
            "Git commits",
        ],
        "run_command": "<backend> --config <root>/inputs/<main_ini> --macro <root>/inputs/<macro> --output <root>/runs/<case>/output"
                       + " (coverage adds --seed <2200NN> for batch NN)",
        "required_identity_checks": [
            "backend exe SHA = f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f and build 864bc036",
            "Geant4 11.3.2 and --check-geant4-data required_complete",
            "every input INI SHA from inputs_manifest.json",
            "run_summary/metadata completion fields and every generated asset SHA",
        ],
        "failure_action": "Keep the original inputs/outputs/logs and report the failure; never tune seeds, N, cut, tolerances, geometry or reference values to make a comparison pass.",
    },
    "counterexamples": [
        {"id": "CE-DROP-ZERO-ROW", "target": "UNC-TOT", "mutation": "delete one zero-deposition event_edep row", "must_fail": "TOT-EVENT-ROWS"},
        {"id": "CE-HITS-AS-N", "target": "UNC-TOT", "mutation": "use hits/event-row count as N", "must_fail": "TOT-MOMENTS"},
        {"id": "CE-ZERO-ERROR", "target": "UNC-ZERO", "mutation": "fabricate a zero_total row in scorer_statistics.csv", "must_fail": "ZERO-STATS-ABSENT / ZERO-NO-FABRICATION"},
        {"id": "CE-UNKNOWN-COVARIANCE-ZERO", "target": "UNC-LET-COV", "mutation": "set BA and AC to zero in the recomputation", "must_fail": "LET-COV-CROSS-MOMENTS"},
        {"id": "CE-WORKER-AVERAGE", "target": "UNC-MT-SPARSE", "mutation": "average per-worker rel_error instead of merging moments", "must_fail": "MT-NO-WORKER-AVERAGE / MT-DOSE-STATS"},
        {"id": "CE-MISSING-METADATA", "target": "all", "mutation": "delete run_metadata.json", "must_fail": "EVID-METADATA"},
        {"id": "CE-RESAMPLE", "target": "UNC-COVERAGE", "mutation": "replace a batch seed or add a batch", "must_fail": "COV-BATCHES"},
        {"id": "CE-MASS-UNIT", "target": "UNC-TOT", "mutation": "use mass in grams where kg is required in the dose identity", "must_fail": "TOT-EDEP-EQ-DOSE"},
    ],
    "stopping": {
        "deliverable": "out/collab/q2-uncertainty-v1/** plus docs/collab/outbox/20261105-q2-uncertainty-v1.md; candidate stops after independent review",
        "no_extension": "no extra batches, no re-runs to replace results, no tolerance changes after observing results",
        "unavailable": "a genuine unavailable sample (missing output, execution failure) is retained and reported; coverage comparison is not completed by replacement",
    },
    "boundaries": [
        "No universal coverage or confidence claim; results apply to this frozen model (12x12 mm beam, 10x10x0.1 mm Galactic slab, p=25/36, N=2000, seeds 220001..220064).",
        "UNC-COMPONENT is component-level evidence only; it does not prove run-level products.",
        "UNC-N1 and UNC-ZERO deliberately exercise extreme statistics; they say nothing about detector physics.",
        "The dose/MC cross-check uses printed 12-digit values and half-unit intervals; absolute mc-truth accuracy is not claimed.",
    ],
    "open_questions_for_supervisor": [
        "Confirm that empty dose/let summary files (header only) are the intended public representation for UNC-ZERO; the proposal assumes the current producers keep writing them and fails closed on mismatch instead of editing the product.",
        "Confirm whether the one-off UNC-COMPONENT C++ probe compiled under the candidate directory against src/Scoring/HistoryStatistics.cc is acceptable (no product/test/build changes).",
        "Confirm that UNC-COVERAGE should keep em=option4 by analogy with the frozen fluence reference settings even though geantino has no EM interactions.",
        "Confirm that a genuine unavailable coverage batch stops the comparison rather than being resampled.",
    ],
    "next_task": {
        "id": "q2-uncertainty-execution-v1",
        "summary": "After this draft is frozen and independently reviewed: copy inputs, run the seven cases (64 coverage batches), build the component probe, write the analysis/comparator and counterexample suite, produce README + receipt, run doc_links and git checks, then stop for independent review.",
    },
}

out = ROOT / "proposal.json"
out.write_text(json.dumps(proposal, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(out, out.stat().st_size)
