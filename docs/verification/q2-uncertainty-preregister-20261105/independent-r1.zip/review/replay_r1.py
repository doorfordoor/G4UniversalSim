from pathlib import Path
from decimal import Decimal
import hashlib, importlib.util, json, shutil, subprocess, sys

D=Path('D:/Geant4/G4UniversalSim')
C=Path('C:/Users/123/.codex/worktrees/j3-final/G4UniversalSim')
rel=Path('out/collab/q2-uncertainty-proposal-v1')
src=D/rel; dst=C/rel
assert not dst.exists(), 'Preserve any prior independent snapshot; inspect before reuse'
dst.mkdir(parents=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
manifest=read(src/'inputs_manifest.json')['files']
names=['proposal.json','cases.md','make_inputs.py','build_proposal.py','inputs_manifest.json','verify_coverage.py','verify_moments.py']
names += ['inputs/'+n for n in manifest]
before={n:sha(src/n) for n in names}
for n in names:
    p=dst/n; p.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src/n,p)
    assert sha(p)==before[n]
for n,h in manifest.items(): assert sha(dst/'inputs'/n)==h
design=Path('docs/collab/decisions/20261105-q2-uncertainty-coverage-design-v1.json')
(C/design).parent.mkdir(parents=True,exist_ok=True)
if (C/design).exists(): assert sha(C/design)==sha(D/design)
else: shutil.copyfile(D/design,C/design)
steps=[]
for program in ['verify_coverage.py','verify_moments.py']:
    r=subprocess.run([sys.executable,'-B',str(dst/program)],cwd=dst,capture_output=True,timeout=90)
    p=dst/('independent-'+program+'.log');p.write_bytes(r.stdout+r.stderr)
    assert r.returncode==0,(program,r.returncode,r.stderr[-1000:])
    result=read(dst/(program.replace('.py','_results.json')))
    assert result['status']=='pass' and result['checks_fail']==0
    steps.append({'script':program,'exit_code':r.returncode,'checks_pass':result['checks_pass'],'log_sha256':sha(p)})
spec=importlib.util.spec_from_file_location('r1_moments',dst/'verify_moments.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
own=[]
for value,h in [('1','5e-12'),('1000','5e-9'),('1e-9','5e-21'),('-1000','5e-9')]:
    lo,hi,exact=mod.half_unit_interval(value)
    assert not exact and (hi-lo)/2==Decimal(h)
    own.append({'fixture':value,'half_width':h,'status':'pass'})
lo,hi,exact=mod.half_unit_interval('0');assert exact and lo==hi==0
own.append({'fixture':'0','status':'pass','exact':True})
# A new asymmetric fixture, independently derived as a rational expression.
expected=Decimal(74)/144+Decimal(13)/25-Decimal(62)/60
wrong=Decimal(74)/25+Decimal(13)/144-Decimal(62)/60
got=mod.ratio_relative_error([2,3,0],[5,7,0])
assert abs(Decimal(str(got['R2_raw']))-expected)<Decimal('1e-14') and abs(wrong-expected)>1
own.append({'fixture':'asymmetric_B_2_3_0_C_5_7_0','expected_R2':str(expected),'swapped_R2':str(wrong),'observed_R2':got['R2_raw'],'status':'pass'})
after={n:sha(src/n) for n in names}; assert before==after,'Draft changed: do not freeze this snapshot'
receipt={'schema':'q2_uncertainty_preregister_independent_r1_v1','status':'pass','geant4_executed':False,'source_snapshot':before,'source_unchanged_during_replay':True,'steps':steps,'independent_extra_checks':own,'scope':'Pure mathematics and immutable input identities only; no C++ component or simulation result claimed.'}
(dst/'independent-review-receipt.json').write_bytes((json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'status':'pass','source_files':len(before),'inputs':len(manifest),'steps':steps,'own_checks':len(own),'proposal_sha256':before['proposal.json']}))
