#!/usr/bin/env python3
"""Draft input generator for the Q2-4 pre-registration (no backend run).

Writes inputs/ drafts under out/collab/q2-uncertainty-proposal-v1/inputs and
prints a JSON manifest of their SHA-256. These are drafts: proposal.json marks
execution_authorized=false, and no Geant4 invocation happens here.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs"
EXEC_ROOT = "out/collab/q2-uncertainty-v1"

MATERIALS = """[galactic]
material = G4_Galactic

[silicon]
material = G4_Si
"""

GEOMETRY_TOT = """[world]
shape = box
size = 3000 mm, 3000 mm, 3000 mm
material = G4_Galactic

[volume.Block]
parent = world
shape = box
size = 40 mm, 40 mm, 0.12 mm
material = G4_Si
position = 0 mm, 0 mm, 0.06 mm

[volume.Slab]
parent = Block
shape = box
size = 10 mm, 10 mm, 0.02 mm
material = G4_Si
position = 0 mm, 0 mm, 0 mm
sensitive = true
"""

GEOMETRY_N1 = """[world]
shape = box
size = 20 mm, 20 mm, 20 mm
material = G4_Galactic

[volume.Slab]
parent = world
shape = box
size = 10 mm, 10 mm, 2 mm
material = G4_Si
position = 0 mm, 0 mm, 0 mm
sensitive = true
"""

GEOMETRY_LET = """[world]
shape = box
size = 20 mm, 20 mm, 20 mm
material = G4_Galactic

[volume.LetTarget]
parent = world
shape = box
size = 10 mm, 10 mm, 0.02 mm
material = G4_Si
position = 0 mm, 0 mm, 0 mm
sensitive = true
"""

GEOMETRY_COVERAGE = """[world]
shape = box
size = 3000 mm, 3000 mm, 3000 mm
material = G4_Galactic

[volume.Slab]
parent = world
shape = box
size = 10 mm, 10 mm, 0.1 mm
material = G4_Galactic
position = 0 mm, 0 mm, 0 mm
sensitive = true
"""


def main_ini(name: str, seed: int, threads: int, geometry: str, physics: str,
             scoring: str, source: str, output_case: str) -> str:
    return f"""[run]
name = {name}
threads = {threads}
seed = {seed}
interactive = false
verbose = 0
check_overlaps = false
dry_run = false

[output]
dir = D:/Geant4/G4UniversalSim/{EXEC_ROOT}/runs/{output_case}/output
format = csv

[materials]
file = D:/Geant4/G4UniversalSim/{EXEC_ROOT}/inputs/materials.ini

[geometry]
template = hierarchical
config = D:/Geant4/G4UniversalSim/{EXEC_ROOT}/inputs/{geometry}
default_world_material = G4_Galactic

[physics]
{physics}

[scoring]
{scoring}

[source]
{source}
"""


def main() -> int:
    INPUTS.mkdir(parents=True, exist_ok=True)
    files: dict[str, str] = {}

    def put(name: str, text: str) -> None:
        (INPUTS / name).write_text(text, encoding="utf-8")
        files[name] = text

    put("materials.ini", MATERIALS)
    put("geometry_unc_tot.ini", GEOMETRY_TOT)
    put("geometry_unc_n1.ini", GEOMETRY_N1)
    put("geometry_unc_let_cov.ini", GEOMETRY_LET)
    put("geometry_unc_coverage.ini", GEOMETRY_COVERAGE)

    put("main_unc_tot.ini", main_ini(
        "unc_tot", 20261120, 1, "geometry_unc_tot.ini",
        "em = option4\ndefault_cut = 10 um",
        "enabled = true\nhits = false\nevent_edep = true\nedep = false\n"
        "dose = true\nauto_create_default_scorers = true",
        "particle = proton\nenergy = 10 MeV\nposition_type = plane\nshape = square\n"
        "halfx = 6 mm\ncenter = 0, 0, -1 mm\ndirection = 0, 0, 1",
        "unc_tot"))

    n1_structure = ("em = option4\ndefault_cut = 10 um",
                    "enabled = true\nhits = false\nevent_edep = false\nedep = false\n"
                    "dose = true\nlet = true\nauto_create_default_scorers = true\n"
                    "[scoring.let]\nparticles = proton",
                    "particle = proton\nenergy = 10 MeV\nposition_type = point\n"
                    "position = 0, 0, 0 mm\ndirection = 0, 0, 1")
    put("main_unc_n1.ini", main_ini(
        "unc_n1", 20261121, 1, "geometry_unc_n1.ini", *n1_structure, "unc_n1"))

    put("main_unc_zero.ini", main_ini(
        "unc_zero", 20261122, 1, "geometry_unc_n1.ini",
        "em = option4\ndefault_cut = 10 um",
        "enabled = true\nhits = false\nevent_edep = false\nedep = false\n"
        "dose = true\nlet = true\nauto_create_default_scorers = true\n"
        "[scoring.let]\nparticles = proton",
        "particle = geantino\nenergy = 100 MeV\nposition_type = point\n"
        "position = 0, 0, 0 mm\ndirection = 0, 0, 1",
        "unc_zero"))

    put("main_unc_mt_sparse.ini", main_ini(
        "unc_mt_sparse", 20261124, 4, "geometry_unc_n1.ini",
        "em = option4\ndefault_cut = 10 um",
        "enabled = true\nhits = false\nevent_edep = true\nedep = false\n"
        "dose = true\nlet = true\nauto_create_default_scorers = true\n"
        "[scoring.let]\nparticles = proton",
        "particle = proton\nenergy = 10 MeV\nposition_type = point\n"
        "position = 0, 0, 0 mm\ndirection = 0, 0, 1",
        "unc_mt_sparse"))

    put("main_unc_let_cov.ini", main_ini(
        "unc_let_cov", 20261123, 1, "geometry_unc_let_cov.ini",
        "reference = FTFP_BERT_EMZ\ndefault_cut = 10 um",
        "enabled = true\nhits = false\nevent_edep = false\nedep = false\n"
        "let = true\nauto_create_default_scorers = true\n"
        "[scoring.let]\nparticles = proton",
        "particle = proton\nenergy = 100 MeV\nposition_type = point\n"
        "position = 0, 0, -3 mm\ndirection = 0, 0, 1",
        "unc_let_cov"))

    put("main_unc_coverage.ini", main_ini(
        "unc_coverage", 220001, 1, "geometry_unc_coverage.ini",
        "em = option4\ndefault_cut = 0.7 mm",
        "enabled = true\nhits = false\nevent_edep = false\nedep = false\n"
        "dose = false\nfluence = true\nauto_create_default_scorers = true",
        "particle = geantino\nenergy = 100 MeV\nposition_type = plane\n"
        "shape = square\nhalfx = 6 mm\ncenter = 0, 0, -2 mm\ndirection = 0, 0, 1",
        "unc_coverage"))

    macros = {
        "run_unc_tot.mac": "# UNC-TOT: 20 events, one thread\n/run/initialize\n/run/beamOn 20\n",
        "run_unc_n1.mac": "# UNC-N1: exactly one event\n/run/initialize\n/run/beamOn 1\n",
        "run_unc_zero.mac": "# UNC-ZERO: 100 geantino events, no energy deposit\n/run/initialize\n/run/beamOn 100\n",
        "run_unc_mt_sparse.mac": "# UNC-MT-SPARSE: 2 events on 4 workers\n/run/initialize\n/run/beamOn 2\n",
        "run_unc_let_cov.mac": "# UNC-LET-COV: 2000 events\n/run/initialize\n/run/beamOn 2000\n",
        "run_unc_coverage.mac": "# UNC-COVERAGE: 2000 events per batch; batch seed is a CLI override\n/run/initialize\n/run/beamOn 2000\n",
    }
    for name, text in macros.items():
        put(name, text)

    hashes = {name: hashlib.sha256((INPUTS / name).read_bytes()).hexdigest()
              for name in sorted(files)}
    (ROOT / "inputs_manifest.json").write_text(
        json.dumps({"schema": "g4usim_q2_uncertainty_inputs_manifest_v1",
                    "draft": True,
                    "files": hashes}, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(hashes, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
