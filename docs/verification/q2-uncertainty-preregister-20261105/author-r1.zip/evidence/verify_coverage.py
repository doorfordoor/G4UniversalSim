#!/usr/bin/env python3
"""Pure mathematics verification for the Q2-4 uncertainty pre-registration.

This program never starts the backend and never reads simulation output. It
recomputes the frozen thresholds of
``docs/collab/decisions/20261105-q2-uncertainty-coverage-design-v1.json`` with
two independent computational paths:

  path A  exact rational arithmetic with Python big integers (single-batch
          coverage probability) and a 60-digit Decimal recurrence started from
          an exactly computed mode probability (aggregate binomial);
  path B  binary floating point, mode-centred recurrence normalised with
          math.fsum (the method named in the design JSON), plus math.lgamma
          log-pmf sums for the aggregate case.

The two paths must agree. A disagreement is reported, never silently tuned.

Coverage criterion of the design: a batch is covered when
    |fluence - N/144| <= 2 * fluence * R,   R = sqrt(1/K - 1/N),
where fluence = K/100 mm^-2. Each of the K hit events contributes exactly one
0.1 mm straight path through the 10 mm^3 sensitive volume (established by the
frozen REF-FLU-01 candidate), so K is the Bernoulli hit count and
R = sqrt(1/K - 1/N) is the project's uncorrected event-moment relative error.
The exact integer form of the same inequality is
    N * (144 K - 100 N)^2 <= 4 * 144^2 * K * (N - K)
which path A uses without floating point.
"""

from __future__ import annotations

import hashlib
import json
import math
import sys
from decimal import Decimal, getcontext
from fractions import Fraction
from pathlib import Path

getcontext().prec = 60

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
DESIGN = REPO / "docs" / "collab" / "decisions" / "20261105-q2-uncertainty-coverage-design-v1.json"

N = 2000
BATCHES = 64
P = Fraction(25, 36)          # (10 mm / 12 mm)^2
EXPECTED_FLUENCE_DEN = 144    # true expected total fluence is N / 144 mm^-2
Z = Decimal(2)


# ---------------------------------------------------------------- path A (exact)
def exact_inequality_holds(k: int, n: int) -> bool:
    if k < 0 or k > n:
        return False
    return n * (144 * k - 100 * n) ** 2 <= 4 * 144 * 144 * k * (n - k)


def exact_covered_k_range(n: int) -> list[int]:
    return [k for k in range(n + 1) if exact_inequality_holds(k, n)]


def path_a_single_batch(n: int) -> dict:
    covered = exact_covered_k_range(n)
    total = 0
    denominator = 36 ** n
    for k in covered:
        total += math.comb(n, k) * 25 ** k * 11 ** (n - k)
    probability = Fraction(total, denominator)
    return {
        "k_range": [covered[0], covered[-1]],
        "covered_probability": Decimal(probability.numerator) / Decimal(probability.denominator),
        "below_range_covered": exact_inequality_holds(covered[0] - 1, n),
        "above_range_covered": exact_inequality_holds(covered[-1] + 1, n),
    }


# ------------------------------------------------------- path B (float recurrence)
def path_b_single_batch(n: int) -> dict:
    mode = int((n + 1) * 25 / 36)
    probs: dict[int, float] = {mode: math.exp(
        math.lgamma(n + 1) - math.lgamma(mode + 1) - math.lgamma(n - mode + 1)
        + mode * math.log(25 / 36) + (n - mode) * math.log(11 / 36))}
    mass = probs[mode]
    k = mode
    while k > 0:
        k -= 1
        mass = mass * ((k + 1) / (n - k)) * (11 / 25)
        probs[k] = mass
    mass = probs[mode]
    k = mode
    while k < n:
        k += 1
        mass = mass * ((n - k + 1) / k) * (25 / 11)
        probs[k] = mass
    normaliser = math.fsum(probs.values())
    covered = exact_covered_k_range(n)
    return {
        "covered_probability": math.fsum(probs[k] / normaliser for k in covered),
        "normaliser": normaliser,
    }


# ------------------------------------------------ coverage-count test (64 batches)
def count_lower_tail_decimal(q: Decimal, batches: int, threshold: int) -> Decimal:
    total = Decimal(0)
    one_minus = Decimal(1) - q
    for k in range(threshold):
        total += Decimal(math.comb(batches, k)) * q ** k * one_minus ** (batches - k)
    return total


def count_lower_tail_float(q: float, batches: int, threshold: int) -> float:
    return math.fsum(
        math.comb(batches, k) * q ** k * (1 - q) ** (batches - k)
        for k in range(threshold))


# -------------------------------------- aggregate binomial (128 000 events) CDF
def mode_probability_decimal(n: int, mode: int) -> Decimal:
    numerator = math.comb(n, mode) * 25 ** mode * 11 ** (n - mode)
    return Decimal(numerator) / Decimal(36 ** n)


def aggregate_cdf_decimal(n: int) -> dict:
    mode = int((n + 1) * 25 / 36)
    pmf = {mode: mode_probability_decimal(n, mode)}
    mass = pmf[mode]
    k = mode
    while k > 0:
        k -= 1
        mass = mass * Decimal(k + 1) / Decimal(n - k) * Decimal(11) / Decimal(25)
        pmf[k] = mass
    mass = pmf[mode]
    k = mode
    while k < n:
        k += 1
        mass = mass * Decimal(n - k + 1) / Decimal(k) * Decimal(25) / Decimal(11)
        pmf[k] = mass
    normaliser = sum(pmf.values(), Decimal(0))
    cumulative = {}
    running = Decimal(0)
    for k in range(n + 1):
        running += pmf[k]
        cumulative[k] = running / normaliser
    return {"mode": mode, "cdf": cumulative, "normaliser": normaliser}


def aggregate_cdf_float(n: int) -> dict:
    mode = int((n + 1) * 25 / 36)

    def logpmf(k: int) -> float:
        return (math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)
                + k * math.log(25 / 36) + (n - k) * math.log(11 / 36))

    pmf = {k: math.exp(logpmf(k)) for k in range(n + 1)}
    normaliser = math.fsum(pmf.values())
    running = 0.0
    cdf = {}
    for k in range(n + 1):
        running += pmf[k]
        cdf[k] = running / normaliser
    return {"mode": mode, "cdf": cdf, "normaliser": normaliser}


def main() -> int:
    design = json.loads(DESIGN.read_text(encoding="utf-8"))
    checks: list[dict] = []

    def check(cid: str, ok: bool, detail: str) -> None:
        checks.append({"id": cid, "status": "pass" if ok else "fail", "detail": detail})

    # ---- single-batch coverage probability ----
    a = path_a_single_batch(N)
    b = path_b_single_batch(N)
    design_range = design["single_batch_covered_K_range"]
    design_cov = Decimal(str(design["single_batch_coverage_probability"]))
    check("MATH-P", P == Fraction(25, 36), f"p = {P}")
    check("MATH-K-RANGE", a["k_range"] == design_range,
          f"exact range {a['k_range']} vs design {design_range}")
    check("MATH-K-BOUNDARIES", not a["below_range_covered"] and not a["above_range_covered"],
          "K one below/above the exact range fails the integer inequality")
    check("MATH-COVERAGE-PROB", abs(a["covered_probability"] - design_cov) < Decimal("1e-12"),
          f"exact {a['covered_probability']} vs design {design_cov}")
    check("MATH-COVERAGE-PATHS",
          abs(Decimal(str(b["covered_probability"])) - a["covered_probability"]) < Decimal("1e-12"),
          f"path A {a['covered_probability']} vs float path {b['covered_probability']}")

    # ---- exact normaliser: the single-batch exact path sums to one ----
    exact_total = sum(math.comb(N, k) * 25 ** k * 11 ** (N - k) for k in range(N + 1))
    check("MATH-EXACT-NORMALISER", exact_total == 36 ** N,
          "sum_k C(N,k) 25^k 11^(N-k) == 36^N, so the exact probability needs no rescaling")

    # ---- exact integer inequality == floating point 2-sigma inequality ----
    mismatches = []
    for k in range(1, N + 1):
        phi = k / 100.0
        sigma = phi * math.sqrt(1.0 / k - 1.0 / N)
        float_ok = abs(phi - N / EXPECTED_FLUENCE_DEN) <= 2.0 * sigma
        if float_ok != exact_inequality_holds(k, N):
            mismatches.append(k)
    check("MATH-INEQUALITY-EQUIVALENCE", not mismatches,
          f"the 2-sigma float test and the exact integer form agree on K=1..{N}"
          + (f"; mismatches {mismatches[:5]}" if mismatches else ""))

    # ---- coverage-count test: at least 57 of 64 batches covered ----
    q = a["covered_probability"]
    threshold = design["coverage_count_minimum_at_lower_tail_alpha_0_01"]
    alpha_decimal = count_lower_tail_decimal(q, BATCHES, threshold)
    alpha_float = count_lower_tail_float(float(q), BATCHES, threshold)
    design_alpha = Decimal(str(design["probability_below_minimum_under_model"]))
    check("MATH-ALPHA", abs(alpha_decimal - design_alpha) < Decimal("1e-12"),
          f"P(covered batches < {threshold}) = {alpha_decimal} vs design {design_alpha}")
    check("MATH-ALPHA-PATHS", abs(Decimal(str(alpha_float)) - alpha_decimal) < Decimal("1e-12"),
          f"decimal {alpha_decimal} vs float {alpha_float}")
    check("MATH-ALPHA-AT-BOUND", alpha_decimal <= Decimal("0.01"),
          f"actual lower tail {alpha_decimal} <= the declared 0.01 bound")
    all_terms = sum(
        Decimal(math.comb(BATCHES, k)) * q ** k * (Decimal(1) - q) ** (BATCHES - k)
        for k in range(BATCHES + 1))
    check("MATH-COUNT-NORMALISER", abs(all_terms - Decimal(1)) < Decimal("1e-45"),
          f"64-batch coverage-count distribution normaliser = {all_terms}")
    mean_cov = Decimal(BATCHES) * q
    check("MATH-ALPHA-THRESHOLD-BELOW-MEAN", Decimal(threshold) < mean_cov,
          f"mean covered batches {mean_cov} > threshold {threshold}")
    union = alpha_decimal + Decimal("0.01")
    check("MATH-UNION-BOUND", union <= Decimal("0.02"),
          f"actual lower tail + second test alpha = {union} <= 0.02 union bound")

    # ---- aggregate binomial central 99 percent range ----
    n_total = N * BATCHES
    design_lo, design_hi = design["aggregate_K_central_99_percent_range"]
    dec = aggregate_cdf_decimal(n_total)
    flo = aggregate_cdf_float(n_total)
    probes = [design_lo - 1, design_lo, design_hi - 1, design_hi, design_hi + 1]
    cdf = dec["cdf"]
    check("MATH-AGG-LOWER", cdf[design_lo - 1] < Decimal("0.005") <= cdf[design_lo],
          f"F({design_lo - 1}) = {cdf[design_lo - 1]} < 0.005 <= F({design_lo}) = {cdf[design_lo]}")
    check("MATH-AGG-UPPER", cdf[design_hi - 1] < Decimal("0.995") <= cdf[design_hi],
          f"upper tail: P(X > {design_hi}) = {1 - cdf[design_hi]} <= 0.005 < "
          f"P(X > {design_hi - 1}) = {1 - cdf[design_hi - 1]}")
    check("MATH-AGG-PATHS", all(
        abs(Decimal(str(flo["cdf"][k])) - cdf[k]) < Decimal("5e-10") for k in probes),
        "Decimal recurrence and lgamma-float CDF agree within 5e-10 at the probes")
    expected_total = Decimal(n_total) * Decimal(25) / Decimal(36)
    check("MATH-AGG-CENTRE", abs(expected_total - Decimal(str(design["aggregate_expected_K"]))) < Decimal("1e-9"),
          f"expected total K = {expected_total} vs design {design['aggregate_expected_K']}")
    check("MATH-AGG-WIDTH", design_hi - design_lo == 849,
          f"integer range width = {design_hi - design_lo}")
    check("MATH-AGG-MODE", dec["mode"] == flo["mode"] == (n_total + 1) * 25 // 36,
          f"binomial mode = {dec['mode']}")

    failed = [c for c in checks if c["status"] != "pass"]
    result = {
        "schema": "g4usim_q2_uncertainty_math_v1",
        "program": "verify_coverage.py",
        "design_input": str(DESIGN.relative_to(REPO)).replace("\\", "/"),
        "design_sha256": hashlib.sha256(DESIGN.read_bytes()).hexdigest(),
        "checks": checks,
        "checks_total": len(checks),
        "checks_pass": len(checks) - len(failed),
        "checks_fail": len(failed),
        "status": "pass" if not failed else "fail",
        "values": {
            "p": str(P),
            "single_batch_covered_K_range": a["k_range"],
            "single_batch_coverage_probability_decimal": str(a["covered_probability"]),
            "single_batch_coverage_probability_float": b["covered_probability"],
            "coverage_count_minimum": threshold,
            "probability_below_minimum_decimal": str(alpha_decimal),
            "probability_below_minimum_float": alpha_float,
            "coverage_count_mean": str(mean_cov),
            "union_bound_alpha_sum": str(union),
            "aggregate_M": n_total,
            "aggregate_mode": dec["mode"],
            "aggregate_central_99_range": [design_lo, design_hi],
            "aggregate_cdf_decimal": {str(k): str(cdf[k]) for k in probes},
            "aggregate_cdf_float": {str(k): flo["cdf"][k] for k in probes},
            "aggregate_expected_K": str(expected_total),
        },
    }
    out = ROOT / "verify_coverage_results.json"
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "checks": f"{result['checks_pass']}/{result['checks_total']}",
        "failed": [c["id"] for c in failed],
        "values": result["values"],
    }, indent=1))
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
