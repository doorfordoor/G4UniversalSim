# Q2-4 统计不确定度预注册 v1（草案，R1 精度边界修订）

- 日期：2026-11-05
- 任务：`q2-uncertainty-preregister-v1-20261105`
- 状态：**draft**，`execution_authorized=false`；未编译、未运行 Geant4，未提交 Git。等待独立复验与冻结。
- R1：按 `docs/collab/reviews/20261105-q2-uncertainty-preregister-r1.md` 仅修订本方案的 12 位有效数字半单位定义、N=1 与覆盖批次 `hits=false` 措辞，复算纯数学核验；未动生产、既有冻结参考、其它候选与阶段状态。

## 1. 交付物

目录 `out/collab/q2-uncertainty-proposal-v1/`：

| 文件 | 大小 | SHA-256 |
|---|---|---|
| `proposal.json`（机器合同，7 案例） | 67890 | `14c16822facb53b0ec3e09ba2de7b7c8d852e04b9882db0c142974b497b9b48c` |
| `cases.md`（本说明的人类文档） | 19068 | `5b2e58a88b15881392821d21cbdb1e7e1196260d5acd708bb1ecb92fd2f6cea7` |
| `inputs_manifest.json`（17 个草案输入 SHA） | 1725 | `048bec9bd7582c2ced7ace5654056b4c20ca9c6d6db1b0d1122bcaf53f0009e4` |
| `make_inputs.py`（确定性输入生成器） | 6918 | `9b4390578560ccb9559529cff5e568b04e91a44d3b6692d8a7506758f01ad1bd` |
| `build_proposal.py`（确定性 proposal 生成器） | 39633 | `0c301084d64a4daafd803894682910d29f6d59c44aa9d42c330195451e3d91be` |
| `verify_coverage.py` | 13120 | `7fc7db48b7b8889ef16744130640d7d7616ad3345b1cc84cd0e0aa2bc57cfb5a` |
| `verify_coverage_results.json` | 5437 | `fc09a56999d5ea812cb089af76db0dc8585e7e0f46fe95c38bdddd097a3a141e` |
| `verify_moments.py` | 12199 | `d96836d9c5125ce2cb5f613c4bc80d89a11d80e5c975e982d776674e64cc06ec` |
| `verify_moments_results.json` | 4850 | `b46cea6f5232f1cc74e16f5607fdc7e0af4873c1accfc7f6568b75029b657eb2` |

`inputs/` 17 个草案文件 SHA 见 `inputs_manifest.json`（materials/4 个 geometry/6 个 main/6 个 macro；重跑 `make_inputs.py` 可复现，R1 未改动）。R1 的两个文本替换脚本保留在 `patches/r1_apply.py`（`cd3241eb4ed354c3…`）与 `patches/r1_cases_md.py`（`76239b8b500cc4f6…`），仅用于可复现记录，不参与执行。

## 2. R1：12 位有效数字半单位的更正

**缺陷**：`verify_moments.py` 原先用 `Decimal(printed).as_tuple().exponent`（打印串的小数位数）取半单位。生产者是 `std::setprecision(12)` 的 general 输出（`src/Output/OutputManager.cc:837—841`），会省略尾零，因此对 `1`、`1000` 这类打印值会把半宽从 5e-12、5e-9 放宽到 0.5，接受区间被放宽 10¹¹ 倍。

**更正**：对非零有限值 `d` 用 `h = 0.5 × 10^(floor(log10(|d|)) − 11)`（`Decimal.adjusted()`），量级边界取较宽一侧（保守）；打印的精确零按精确 0 处理，不凭空给半宽。`proposal.json` 的 `formulas.half_unit_interval` 已改为该定义，并明确传播到所有原始量、比值与矩的比较；`verify_moments.py` 新增/保留 fixture：

| 打印值 | 旧字符串法半宽 | 量级基保守半宽 | 接受区间 |
|---|---|---|---|
| `1` | 0.5 | 5e-12 | `[0.999999999995, 1.000000000005]` |
| `1000` | 0.5 | 5e-9 | `[999.999999995, 1000.000000005]` |
| `1e-9` | 5e-10 | 5e-21 | `[9.99999999995e-10, 1.000000000005e-9]` |
| `-1000` | 0.5 | 5e-9 | `[-1000.000000005, -999.999999995]` |
| `1.36016812632` | 5e-12 | 5e-12 | `[1.360168126315, 1.360168126325]` |
| `0` | 0.5 | 精确 0（不给容差） | `[0, 0]` |

旧字符串法对 `1` 得到 0.5，比量级基宽 `1.0e11` 倍（`PRECISION-OLD-STRING-RULE-REJECTED`）；`999.9999999995` 按 `%.12g` 打印为 `1000`，落在保守区间内（`PRECISION-MAGNITUDE-BOUNDARY`）。该半单位随后传播到 REF-LET-01-EM 100 MeV 的 `let_d−let_t`：单值相对半宽 `3.676e-12`，差值相对半宽 `4.228e-4`（`PRECISION-DIFFERENCE-NOT-1E12`），不改为统一 1e-12 相对门槛。

## 3. R1：两处定稿措辞

1. **UNC-N1**：`insufficient_events` 是唯一接受的状态；delta 公式在浮点下仍可能打印极小非零 `rel_error`，因此不强制字面 0，也绝不把它作为可用置信误差。合同 `N1-STATUS` 已改为该表述。
2. **UNC-COVERAGE（`hits=false`）**：覆盖批次没有逐事件路径观测；只以冻结直线路径模型的**打印矩一致性**（`K=round(track_length/0.1)`、`sum_sq=K×0.1²`、`sum=K×0.1`）做有限解析检查，不声称读到每个事件的完整路径。合同 `COV-PATH` 与 K 的 `source/semantics`、边界、`cases.md` 与回执均已同步。

## 4. 预审意见的落实（续）

`docs/collab/reviews/20261105-q2-uncertainty-preregister-review.md` 七点仍全部成立：确定性几何/点源（非概率全零）、`insufficient_events` 优先、geantino+proton 过滤、真实 `HistoryStatistics.cc` 组件证据、N=2<threads=4 全局事件 ID 合并、半单位区间（不统一 1e-12）、64 批固定种子与停止条件。R1 仅修正第 4 项中半单位的具体定义和第 5/6 项的措辞。

## 5. 纯数学核验结果（R1 复算）

- `python -B verify_coverage.py`：**19/19 pass**（约 1.4 s），结果 JSON 与 R1 前一致（未改动）。复现 p=25/36、单批覆盖 K `[1347,1429]`、覆盖概率 `0.9559137115315595`、覆盖数下限 57 及 `P(C<57)=0.006980515324`、总 K 中央 99% `[88464,89313]`、联合误拒上界 `0.01698…`；含精确有理归一化与整数-浮点判据等价性。
- `python -B verify_moments.py`：**20/20 pass**。含 R1 新增的量级基 fixture、精确零、量级边界、旧字符串法拒绝，以及原有 LET 半单位传播、符号稳健与 Bernoulli 矩恒等式。

两程序均为纯数学/恒等式，不调用后端、不读取运行输出、不据结果调整阈值；结果 JSON 已冻结。

## 6. 七个案例（合同摘要）

| 案例 | 目的 | 关键输入/数据 | 关键判据 |
|---|---|---|---|
| UNC-TOT | 事件内合并与零贡献 | REF-Dose 10 MeV 单敏感体、N=20、seed 20261120、dose+event_edep | 20 行 event_edep 与 eventID 对应；Σedep↔dose 恒等；S/S²/R 与公开矩一致；entries=非零事件数；N≠行数 |
| UNC-N1 | N<2 | 10×10×2 mm Si 内点源、N=1、seed 20261121、dose+LET | dose/LET 行存在非零、n_events=1、状态 `insufficient_events`；不把微小/零 rel_error 当有效误差 |
| UNC-ZERO | 无沉积/无选中粒子 | 同几何 geantino、N=100、seed 20261122 | dose/let 仅表头；`scorer_statistics.csv` 缺失；禁止伪造 zero_total/undefined_ratio |
| UNC-LET-COV | 比值相关矩 | REF-LET 20 μm Si、100 MeV、2000 事件、seed 20261123 | let_t=B/A、let_d=C/B；R_t/R_d 用 BA/AC 交叉矩对账；无 5% 物理门槛 |
| UNC-MT-SPARSE | 稀疏多线程 | N=2、threads=4、seed 20261124 | 2 个全局事件不重复；合并矩而非平均误差；允许空 worker 文件 |
| UNC-COMPONENT | 共享实现边界 | 一次性 C++ probe 链接真实 `HistoryStatistics.cc` | 7 个状态 fixture 与冻结协方差 fixture；编译命令+源码 SHA |
| UNC-COVERAGE | 独立有限批次 | 64 批、N=2000、seeds 220001…220064、geantino 注量 | 打印矩与直线路径模型一致（`hits=false`，无逐事件路径观测）；C≥57；ΣK∈[88464,89313]；不重采样 |

`event_edep` 字段/单位已从产品代码确认：`runID,eventID,raw_edep_MeV,weighted_edep_MeV`，12 位有效数字，每事件一行（零沉积也写，`ScoringManager.cc:516`、`OutputManager.cc:832`）；`raw_edep_MeV` 为该事件正沉积分步 Σedep，未加权。

## 7. 反例与停止条件

合同预注册 8 个副本反例（删零贡献行、hits 行数冒充 N、伪造 zero_total、交叉矩置 0、平均 worker rel_error、缺 metadata、覆盖批次换种子、kg/g 混用），必须命中 `fail`，并且原件 SHA 前后不变；本预注册没有 `limited` 基线可充数。

冻结输入未变时复用原始运行（比对冻结/后端/输入/产物 SHA 与完成事件），不因报告或比较器更新重跑同一模拟。任何失败保留原始证据、停止调参；缺证据即停；交付后停写等独立复验。

## 8. 边界与已按原授权确定的点

- 不宣称通用置信覆盖：结果只适用于本预注册的模型（12×12 mm 束、10×10×0.1 mm Galactic 靶、p=25/36、N=2000、seeds 220001…220064、Geant4 11.3.2、后端 864bc036）。
- UNC-COMPONENT 只是组件级证据；UNC-N1/UNC-ZERO 是极端统计表示验证，不评价探测器物理；不验证剂量/LET 物理正确性。
- R1 已按原授权确定的点（不改变冻结数值）：
  1. UNC-ZERO 的空 dose/let 汇总文件“仅表头 + 已登记文件”是当前生产者的表示（`DoseScorer.cc:94—114`、`LETScorer.cc:148` 起恒创建并登记）；`scorer_statistics.csv` 无 entry 时不写文件（`OutputManager.cc:290—291`）。生产者若改变该表示，按契约不匹配报告，不改产品。
  2. 候选目录内一次性 C++ probe 直接链接 `src/Scoring/HistoryStatistics.cc` 可用（无产品/测试/构建改动）。
  3. UNC-COVERAGE 保留 `em=option4`（与冻结 fluence 参考设置一致；geantino 无 EM 交互）。
  4. 覆盖批次真实不可用时保留并停止比较，不用替代批次。

## 9. 校验与下一步

- `python -B scripts/check_doc_links.py` 结果见下；`git status` 仅监督端既有 `M docs/ROADMAP.md` 与本回执为新增未跟踪，候选目录在 gitignore 的 `out/` 下；未改产品/测试/基准/冻结/表数据，未提交 Git。
- 复演命令（不需要后端）：
  ```
  cd out/collab/q2-uncertainty-proposal-v1
  python -B make_inputs.py
  python -B build_proposal.py
  python -B verify_coverage.py
  python -B verify_moments.py
  ```
- 下一步：独立复验通过后进入 `q2-uncertainty-execution-v1`（复制输入、运行 7 案例含 64 批、组件 probe、比较器/反例/README/回执、证据与链接校验、停写等复验）。
