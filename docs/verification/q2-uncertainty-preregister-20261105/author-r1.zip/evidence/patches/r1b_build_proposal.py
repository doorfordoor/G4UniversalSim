#!/usr/bin/env python3
"""Apply the R1 structured-contract corrections to build_proposal.py."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "build_proposal.py"
text = path.read_text(encoding="utf-8")


def replace_once(old: str, new: str, label: str) -> None:
    global text
    assert old in text, f"anchor not found: {label}"
    text = text.replace(old, new, 1)


replace_once(
    '    "ratio_delta": "Q = B/A with unweighted per-event moments: R_Q^2 = sumSq_B/B^2 + sumSq_A/A^2 - 2*sum_AB/(A*B). For LET: let_t = sum_wSl/sum_wl (A=sum_wl, B=sum_wSl, sum_AB=sum_wl_x_wSl); let_d = sum_wS2l/sum_wSl (A=sum_wSl, B=sum_wS2l, sum_AB=sum_wSl_x_wS2l). Both delta ratios use their own cross moment; the unknown covariance between the two ratios is not set to zero.",',
    '    "ratio_delta": "Q = B/A where the per-event moments are the moments of the weighted tallies: R_Q^2 = sumSq_B/B^2 + sumSq_A/A^2 - 2*sum_AB/(A*B), with sumSq_A=sum_i a_i^2 and sum_AB=sum_i a_i*b_i over completed events (zero contributions included). For unit-weight runs this coincides with the ordinary sample moments; the general formula is not an unweighted formula. For LET: let_t = B/A (A=sum_wl, B=sum_wSl, sum_AB=BA=sum_wl_x_wSl) so R_t^2 = sumSq_wSl/B^2 + sumSq_wl/A^2 - 2*BA/(A*B); let_d = C/B (denominator B=sum_wSl, numerator C=sum_wS2l, cross AC=sum_wSl_x_wS2l) so R_d^2 = sumSq_wS2l/C^2 + sumSq_wSl/B^2 - 2*AC/(B*C). Both delta ratios use their own cross moment; the unknown covariance between the two ratios is not set to zero.",',
    "ratio_delta",
)

# ---- UNC-TOT: N semantics, direct raw+weighted identity, limitation text ----
replace_once(
    '            {"name": "N", "source": "run_summary.actual_completed_event_count and run_metadata.runs[0].completed_events", "unit": "events", "semantics": "must be 20, not the number of hits rows"},',
    '            {"name": "N", "source": "run_summary.actual_completed_event_count and run_metadata.runs[0].completed_events", "unit": "events", "semantics": "must be 20; a complete event_edep file also has exactly 20 rows by contract, so the row count is not an independent N; nonzero-contribution entries and ordinary hits row counts are not N"},',
    "TOT N semantics",
)
replace_once(
    '            {"id": "TOT-EDEP-EQ-DOSE", "rule": "sum(event_edep raw_edep_MeV)*1.602176634e-13/mass_kg equals dose CSV raw_dose_Gy within the half-unit interval propagated from both printed values and mass_kg; weighted uses weighted_edep and the event weight column is not available, so weighted equality is checked only when all weights are 1"},',
    '            {"id": "TOT-EDEP-EQ-DOSE", "rule": "sum(event_edep raw_edep_MeV)*1.602176634e-13/mass_kg equals dose CSV raw_dose_Gy, and sum(event_edep weighted_edep_MeV)*1.602176634e-13/mass_kg equals dose CSV weighted_dose_Gy, both within the half-unit interval propagated from the printed values and mass_kg; event_edep already provides weighted_edep_MeV, so no per-step weight column is needed for the weighted identity"},',
    "TOT-EDEP-EQ-DOSE",
)
replace_once(
    '            {"id": "TOT-NOT-HITS-ROWS", "rule": "N comes from run_summary/metadata; if the number of event_edep rows were used as N the recomputation must be rejected by TOT-MOMENTS"},',
    '            {"id": "TOT-NOT-HITS-ROWS", "rule": "N comes from run_summary/metadata and must equal the number of data rows of a complete event_edep file (one row per completed event, duplicates or missing event ids rejected by TOT-EVENT-ROWS); using the number of nonzero-contribution entries, or the number of ordinary hits rows, as N is rejected by TOT-MOMENTS/TOT-EVENT-ROWS; because a legitimate complete file has exactly N rows, a same-valued case is never claimed to be detectable — the counterexample mutates a copy with a missing/duplicated event row, or uses the component fixture"},',
    "TOT-NOT-HITS-ROWS",
)
replace_once(
    '         "event_edep raw weights are unavailable in the public CSV, so weighted identities are restricted to unit-weight events."],',
    '         "event_edep provides weighted_edep_MeV directly, so the weighted dose identity is checked without any per-step weight column; a difference in weights is not needed."],',
    "TOT limitation",
)

# ---- UNC-LET-COV: R_d denominators ----
replace_once(
    '            {"id": "LET-COV-RD", "rule": "R_d^2 = sum_sq_wS2l/B^2 + sum_sq_wSl/C^2 - 2*AC/(C*B) equals the printed let_d rel_error^2 within the propagated interval"},',
    '            {"id": "LET-COV-RD", "rule": "with B=sum_wSl and C=sum_wS2l: R_d^2 = sum_sq_wS2l/C^2 + sum_sq_wSl/B^2 - 2*AC/(B*C) equals the printed let_d rel_error^2 within the propagated interval; the two squared moments have different denominators and a swapped-denominator recomputation must be detected (asymmetric fixture in verify_moments.py)"},',
    "LET-COV-RD",
)

# ---- UNC-MT-SPARSE: second moments, no forced worker-average difference ----
replace_once(
    '        "N=2 on 4 workers guarantees at least two workers cannot have events; merge by global event id and worker moments, never by averaging per-worker relative errors.",',
    '        "N=2 on 4 workers guarantees at least two workers cannot have events, but the two events may land on the same worker; merge by global event id and by worker moments, never by averaging per-worker relative errors. The actual allocation is recorded; when fewer than two workers contain events the worker-average comparison is reported as not distinguishable instead of failing.",',
    "MT purpose",
)
replace_once(
    '            {"id": "MT-EDEP-MERGE", "rule": "sum(raw_edep_MeV) equals dose CSV raw_dose_Gy*mass/1.602176634e-13 within the half-unit interval; weighted identity only if all weights are 1"},',
    '            {"id": "MT-EDEP-MERGE", "rule": "sum(raw_edep_MeV) equals dose CSV raw_dose_Gy*mass/1.602176634e-13, and sum(weighted_edep_MeV) equals dose CSV weighted_dose_Gy*mass/1.602176634e-13, both within the half-unit interval; weighted_edep_MeV is directly available, so no per-step weight column is required"},',
    "MT-EDEP-MERGE",
)
replace_once(
    '            {"id": "MT-LET-MERGE", "rule": "merge A,B,C,BA,AC by summation; let_t/let_d and both rel_errors match the printed rows; worker ratio averaging must fail"},',
    '            {"id": "MT-LET-MERGE", "rule": "merge A,B,C,BA,AC and the three second moments sum_sq_wl, sum_sq_wSl, sum_sq_wS2l by summation (never by averaging per-worker errors); then compute let_t=B/A, let_d=C/B and both delta rel_errors from the merged moments and match the printed rows"},',
    "MT-LET-MERGE",
)
replace_once(
    '            {"id": "MT-NO-WORKER-AVERAGE", "rule": "the comparator records both the merged rel_error and the (wrong) average of per-worker relative errors; equality with the printed row uses the merged value and the difference from the worker average is reported"},',
    '            {"id": "MT-NO-WORKER-AVERAGE", "rule": "the comparator records the merged rel_error and, for information, the arithmetic mean of per-worker relative errors when at least two workers contain events; it does NOT require the two numbers to differ under the actual sparse allocation, because N=2 can fall in one worker or the wrong average can be numerically degenerate; distinguishability is established only by a pre-specified component/copy fixture (two non-empty workers with different per-worker errors), keeping the frozen seed"},',
    "MT-NO-WORKER-AVERAGE",
)

# ---- counterexample descriptions ----
replace_once(
    '        {"id": "CE-HITS-AS-N", "target": "UNC-TOT", "mutation": "use hits/event-row count as N", "must_fail": "TOT-MOMENTS"},',
    '        {"id": "CE-HITS-AS-N", "target": "UNC-TOT", "mutation": "use nonzero-contribution entries or ordinary hits row counts as N instead of the complete event count; a same-valued legitimate file is not claimed detectable, so the copy has a missing or duplicated event row", "must_fail": "TOT-NOT-HITS-ROWS / TOT-MOMENTS"},',
    "CE-HITS-AS-N",
)
replace_once(
    '        {"id": "CE-WORKER-AVERAGE", "target": "UNC-MT-SPARSE", "mutation": "average per-worker rel_error instead of merging moments", "must_fail": "MT-NO-WORKER-AVERAGE / MT-DOSE-STATS"},',
    '        {"id": "CE-WORKER-AVERAGE", "target": "UNC-MT-SPARSE", "mutation": "average per-worker rel_error instead of merging moments, applied to the pre-specified two-non-empty-worker fixture (the frozen sparse run is not forced to expose the difference)", "must_fail": "MT-NO-WORKER-AVERAGE / MT-DOSE-STATS"},',
    "CE-WORKER-AVERAGE",
)

# ---- boundaries ----
replace_once(
    '        "The dose/MC cross-check uses printed 12-digit values and magnitude-based half-unit intervals; absolute mc-truth accuracy is not claimed.",',
    '        "The dose/MC cross-check uses printed 12-digit values and magnitude-based half-unit intervals; absolute mc-truth accuracy is not claimed.",\n'
    '        "A complete event_edep file has exactly N data rows by contract, so its row count is not an independent N; rejection of entries/hits-row counts as N uses a mutated copy or the component fixture, never a claim that equal values differ.",\n'
    '        "The wrong per-worker error average is not required to differ under the frozen sparse allocation; distinguishability is shown only with the pre-specified two-worker component/copy fixture.",',
    "boundaries",
)

path.write_text(text, encoding="utf-8")
print("build_proposal.py patched for R1 structured corrections")
