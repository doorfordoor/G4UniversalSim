#!/usr/bin/env python3
"""Add the asymmetric LET_d denominator fixture to verify_moments.py."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "verify_moments.py"
text = path.read_text(encoding="utf-8")

anchor = (
    '          f"(difference {abs(sample[\'R2_raw\'] - sample[\'R2_with_1_over_N\']):.3e})")\n'
)
assert anchor in text, "ratio sample anchor not found"

addition = '''          f"(difference {abs(sample['R2_raw'] - sample['R2_with_1_over_N']):.3e})")

    # LET_d has numerator C=sum_wS2l and denominator B=sum_wSl; the two squared
    # moments use *different* denominators. An asymmetric B/C fixture exposes a
    # swapped-denominator error that a symmetric example would hide.
    let_d_denominator = [1.0, 2.0, 4.0]   # B = sum_wSl = 7
    let_d_numerator = [5.0, 1.0, 2.0]     # C = sum_wS2l = 8
    let_d = ratio_relative_error(let_d_denominator, let_d_numerator)
    check(checks, "RATIO-LET-D-ASYMMETRIC",
          abs(let_d["R2_raw"] - let_d["R2_with_1_over_N"]) < 1e-15,
          f"asymmetric B={let_d['A']}, C={let_d['B']}: raw-moment R_d^2 equals the "
          f"explicit 1/N delta form (difference "
          f"{abs(let_d['R2_raw'] - let_d['R2_with_1_over_N']):.3e})")
    cross_bc = let_d["sumAB"]
    correct = let_d["R2_raw"]
    # wrong order: sumSq_C/B_wSl^2 + sumSq_B/C_wS2l^2 - 2*sum_BC/(B*C)
    swapped = (let_d["sumSqB"] / let_d["A"] ** 2
               + let_d["sumSqA"] / let_d["B"] ** 2
               - 2.0 * cross_bc / (let_d["A"] * let_d["B"]))
    relative_gap = abs(swapped - correct) / correct
    check(checks, "RATIO-LET-D-DENOMINATOR-ORDER",
          relative_gap > 1e-2,
          f"swapped denominators give R_d^2={swapped:.12g} vs correct {correct:.12g} "
          f"({relative_gap:.3%} apart), so this fixture detects the swap")
'''
text = text.replace(anchor, addition, 1)

# Number of frozen checks grows from 20 to 22; nothing else changes.
path.write_text(text, encoding="utf-8")
print("verify_moments.py: asymmetric LET_d fixture added")
