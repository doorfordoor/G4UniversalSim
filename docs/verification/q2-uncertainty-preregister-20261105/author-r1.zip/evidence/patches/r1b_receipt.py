#!/usr/bin/env python3
"""Apply the R1 structured-contract corrections to the preregistration receipt."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
path = ROOT / "docs" / "collab" / "outbox" / "20261105-q2-uncertainty-preregister-v1.md"
text = path.read_text(encoding="utf-8")


def replace_once(old: str, new: str, label: str) -> None:
    global text
    assert old in text, f"anchor not found: {label}"
    text = text.replace(old, new, 1)


replace_once(
    "- R1：按 `docs/collab/reviews/20261105-q2-uncertainty-preregister-r1.md` 仅修订本方案的 12 位有效数字半单位定义、N=1 与覆盖批次 `hits=false` 措辞，复算纯数学核验；未动生产、既有冻结参考、其它候选与阶段状态。\n",
    "- R1：按 `docs/collab/reviews/20261105-q2-uncertainty-preregister-r1.md` 仅修订本方案的 12 位有效数字半单位定义、N=1 与覆盖批次 `hits=false` 措辞，复算纯数学核验；未动生产、既有冻结参考、其它候选与阶段状态。\n"
    "- R1 同轮结构化续审：合并同文件末节四项——LET_d 两平方矩分母、完整 `event_edep` 行数恰为 N、稀疏 MT 三二阶矩与“错误平均可能数值退化”、"
    "`weighted_edep_MeV` 可直接对账；仅改验证器/生成器/文案/SHA，病例、种子、N、范围不变，未运行 Geant4。\n",
    "header R1",
)

# ---- section 1 hash table ----
replace_once(
    "| `proposal.json`（机器合同，7 案例） | 67890 | `14c16822facb53b0ec3e09ba2de7b7c8d852e04b9882db0c142974b497b9b48c` |",
    "| `proposal.json`（机器合同，7 案例） | 70625 | `bfe5e0b2378686741074ed1b6022605e03c569f5debd05003334dc3b31853905` |",
    "proposal row",
)
replace_once(
    "| `cases.md`（本说明的人类文档） | 19068 | `5b2e58a88b15881392821d21cbdb1e7e1196260d5acd708bb1ecb92fd2f6cea7` |",
    "| `cases.md`（本说明的人类文档） | 21164 | `833c075b95fa72a00989730b6932fb0d254681e25edfd38bdf7040bb8c2c790b` |",
    "cases row",
)
replace_once(
    "| `build_proposal.py`（确定性 proposal 生成器） | 39633 | `0c301084d64a4daafd803894682910d29f6d59c44aa9d42c330195451e3d91be` |",
    "| `build_proposal.py`（确定性 proposal 生成器） | 42376 | `8aec4b98db7e5073cd1d9fb4a2d88ea3d0ac3206887cc18205140b1ac0085fdc` |",
    "build row",
)
replace_once(
    "| `verify_moments.py` | 12199 | `d96836d9c5125ce2cb5f613c4bc80d89a11d80e5c975e982d776674e64cc06ec` |",
    "| `verify_moments.py` | 13547 | `270e253de7f941c8add805707a30de8b657f022ddbb6b62a873c7c4fd69b55ab` |",
    "moments row",
)
replace_once(
    "| `verify_moments_results.json` | 4850 | `b46cea6f5232f1cc74e16f5607fdc7e0af4873c1accfc7f6568b75029b657eb2` |",
    "| `verify_moments_results.json` | 5276 | `b3f2131766f826ead9fa32241b0f1e398bce77ef6bfa09195f51e7d74835d0a3` |",
    "moments results row",
)
replace_once(
    "R1 的两个文本替换脚本保留在 `patches/r1_apply.py`（`cd3241eb4ed354c3…`）与 `patches/r1_cases_md.py`（`76239b8b500cc4f6…`），仅用于可复现记录，不参与执行。",
    "文本替换脚本保留在 `patches/`：`r1_apply.py`（`cd3241eb4ed354c3…`）、`r1_cases_md.py`（`76239b8b500cc4f6…`）、"
    "`r1b_verify_moments.py`（`fc73f1897a87e5c2…`）、`r1b_build_proposal.py`（`db35cacea11b1621…`）、"
    "`r1b_cases_md.py`（`1e1a955f74fe9b39…`），仅用于可复现记录，不参与执行。",
    "patches line",
)

# ---- new structured-correction section inserted before old section 4 ----
replace_once(
    "## 4. 预审意见的落实（续）\n",
    "## 3b. R1 结构化续审：四处更正\n\n"
    "1. **LET_d 两平方矩分母**：`let_t=B/A`（A=Σwl、B=ΣwSl）、`let_d=C/B`（C=ΣwS2l）。正确式 "
    "`R_d² = sum_sq_wS2l/C² + sum_sq_wSl/B² − 2·AC/(B·C)`（顶层通式本身无误，错误在逐病例/生成器/文案把两个平方矩的分母写反）。"
    "`verify_moments.py` 增加不对称 fixture B=[1,2,4]（Σ=7）、C=[5,1,2]（Σ=8）：交换分母得 `R_d²=0.404655612245`，"
    "正确值 `0.361607142857`（相差 11.905%），因此该反例可检出分母写反；对称示例不会掩盖。\n"
    "2. **`event_edep` 行数 = N**：完整合法文件的每事件一行就是 N，不能用“行数”本身证明检出。N 必须来自 summary/metadata；"
    "拒绝的是“用非零贡献 entries 或普通 hits 行数替代完整 N”，以及缺行/重复行的不完整文件（`TOT-NOT-HITS-ROWS`、`TOT-EVENT-ROWS`）。"
    "同值合法文件的情形不声称可检出，反例改用缺行/重复行副本或组件 fixture。\n"
    "3. **稀疏 MT 合并**：必须合并三个二阶矩 `sum_sq_wl`、`sum_sq_wSl`、`sum_sq_wS2l` 后再算两条 delta 误差，"
    "不能平均各 worker 误差；但实际分配下“错误平均”可能与合并值数值退化相同（N=2 可能落同一 worker），"
    "`MT-NO-WORKER-AVERAGE` 只记录两者，不强制本次分配暴露差异；可区分性由预先指定的“两个非空 worker、误差不同”的组件/副本 fixture 证明。\n"
    "4. **加权对账**：`event_edep` 的 `weighted_edep_MeV` 可直接与 weighted dose 对账，不需要逐步 weight 列，"
    "也不要求先证明全部权重为 1；`TOT-EDEP-EQ-DOSE` / `MT-EDEP-MERGE` 已按此改写。另：`ratio_delta` 的措辞由"
    "“unweighted per-event moments”改为“每事件加权 tally 的矩”。\n\n"
    "## 4. 预审意见的落实（续）\n",
    "structured section",
)

# ---- pure math results ----
replace_once(
    "- `python -B verify_moments.py`：**20/20 pass**。含 R1 新增的量级基 fixture、精确零、量级边界、旧字符串法拒绝，以及原有 LET 半单位传播、符号稳健与 Bernoulli 矩恒等式。",
    "- `python -B verify_moments.py`：**22/22 pass**。含 R1 新增的量级基 fixture、精确零、量级边界、旧字符串法拒绝，"
    "以及结构化续审新增的 LET_d 分母顺序（不对称 fixture）与原有符号稳健、Bernoulli 矩恒等式。",
    "pure math results",
)

# ---- case table wording ----
replace_once(
    "| UNC-TOT | 事件内合并与零贡献 | REF-Dose 10 MeV 单敏感体、N=20、seed 20261120、dose+event_edep | 20 行 event_edep 与 eventID 对应；Σedep↔dose 恒等；S/S²/R 与公开矩一致；entries=非零事件数；N≠行数 |",
    "| UNC-TOT | 事件内合并与零贡献 | REF-Dose 10 MeV 单敏感体、N=20、seed 20261120、dose+event_edep | 20 行 event_edep 与 eventID 对应；Σraw/Σweighted↔dose 两条恒等（`weighted_edep_MeV` 直接可用）；S/S²/R 与公开矩一致；entries=非零事件数；N 来自 summary（完整文件行数即 N，不作独立检出依据） |",
    "TOT row",
)
replace_once(
    "| UNC-LET-COV | 比值相关矩 | REF-LET 20 μm Si、100 MeV、2000 事件、seed 20261123 | let_t=B/A、let_d=C/B；R_t/R_d 用 BA/AC 交叉矩对账；无 5% 物理门槛 |",
    "| UNC-LET-COV | 比值相关矩 | REF-LET 20 μm Si、100 MeV、2000 事件、seed 20261123 | let_t=B/A、let_d=C/B；`R_d²=sumSq_wS2l/C²+sumSq_wSl/B²−2AC/(B·C)`，R_t 用 BA、R_d 用 AC；无 5% 物理门槛 |",
    "LET-COV row",
)
replace_once(
    "| UNC-MT-SPARSE | 稀疏多线程 | N=2、threads=4、seed 20261124 | 2 个全局事件不重复；合并矩而非平均误差；允许空 worker 文件 |",
    "| UNC-MT-SPARSE | 稀疏多线程 | N=2、threads=4、seed 20261124 | 2 个全局事件不重复；合并三个二阶矩而非平均误差；允许空 worker 文件；记录实际分配，错误平均数值退化时不判检出，可区分性用预指定组件 fixture |",
    "MT row",
)

# ---- counterexample table ----
replace_once(
    "合同预注册 8 个副本反例（删零贡献行、hits 行数冒充 N、伪造 zero_total、交叉矩置 0、平均 worker rel_error、缺 metadata、覆盖批次换种子、kg/g 混用），必须命中 `fail`，并且原件 SHA 前后不变；本预注册没有 `limited` 基线可充数。",
    "合同预注册 8 个副本反例（删零贡献行、用非零贡献 entries/普通 hits 行数冒充完整 N（副本另含缺行/重复行）、伪造 zero_total、"
    "交叉矩置 0、平均 worker rel_error（用预指定两非空 worker 的组件/副本 fixture，不强制冻结稀疏分配暴露差异）、缺 metadata、"
    "覆盖批次换种子、kg/g 混用），必须命中 `fail`，并且原件 SHA 前后不变；本预注册没有 `limited` 基线可充数。",
    "counterexample paragraph",
)

# ---- boundaries ----
replace_once(
    "  4. 覆盖批次真实不可用时保留并停止比较，不用替代批次。\n",
    "  4. 覆盖批次真实不可用时保留并停止比较，不用替代批次。\n"
    "- 完整 `event_edep` 文件的合法行数就是 N，因此不以“行数=N”本身作为检出依据；拒绝用 entries/hits 行数替代 N 用缺行/重复行副本或组件 fixture。\n"
    "- 稀疏 MT 的实际分配可能使“错误平均”数值退化，不强制冻结分配下必然不同；可区分性只由预指定的两非空 worker 组件/副本 fixture 证明。\n"
    "- `weighted_edep_MeV` 直接提供，加权恒等式不依赖逐步 weight 列或“全部权重=1”的前提。\n",
    "boundaries",
)

path.write_text(text, encoding="utf-8")
print("receipt patched for R1 structured corrections")
