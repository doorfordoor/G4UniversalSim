#!/usr/bin/env python3
"""Apply the R1 revisions to cases.md (human document)."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "cases.md"
text = path.read_text(encoding="utf-8")


def replace_once(old: str, new: str, label: str) -> None:
    global text
    assert old in text, f"anchor not found: {label}"
    text = text.replace(old, new, 1)


replace_once(
    "# Q2-4 统计不确定度预注册（草案 v1）\n",
    "# Q2-4 统计不确定度预注册（草案 v2，R1 精度边界修订）\n\n"
    "> 2026-11-05 R1：按独立静态复核 `docs/collab/reviews/20261105-q2-uncertainty-preregister-r1.md` 修订"
    "12 位有效数字半单位定义（改为量级基，不再用打印字符串的小数位）、N=1 与覆盖批次 `hits=false` 的措辞；"
    "仅修订本方案与复算纯数学核验，未运行 Geant4、未改生产/冻结参考。\n",
    "title",
)

replace_once(
    "| `proposal.json` | 66205 | `1d72419d34cd73a176678a52bb3eeba7a325a83f689103f08fe727a2fc0712a0` |",
    "| `proposal.json` | 67890 | `14c16822facb53b0ec3e09ba2de7b7c8d852e04b9882db0c142974b497b9b48c` |",
    "proposal.json row",
)
replace_once(
    "| `build_proposal.py`（确定性 proposal 生成器） | 37944 | `e9beca6db14064d189457cc1b1ed3076349ee838a8c0f4f35cac2bbced3de96e` |",
    "| `build_proposal.py`（确定性 proposal 生成器） | 39633 | `0c301084d64a4daafd803894682910d29f6d59c44aa9d42c330195451e3d91be` |",
    "build_proposal.py row",
)
replace_once(
    "| `verify_moments.py`（纯数学矩/精度核验） | 8718 | `f8e0dc8225bfb10aa38a59d830122ae007c9bdf03cb5c647f02eef239161fd33` |",
    "| `verify_moments.py`（纯数学矩/精度核验） | 12199 | `d96836d9c5125ce2cb5f613c4bc80d89a11d80e5c975e982d776674e64cc06ec` |",
    "verify_moments.py row",
)
replace_once(
    "| `verify_moments_results.json` | 3023 | `dc6caedf5574455fb017d2734786d012ba86c11746ff3725f3079ec963092ae9` |",
    "| `verify_moments_results.json` | 4850 | `b46cea6f5232f1cc74e16f5607fdc7e0af4873c1accfc7f6568b75029b657eb2` |",
    "verify_moments_results row",
)

# ---- 3.2 (run twice from the source title so the body replacement is unique) ----
text = text.replace("### 3.2 矩/精度核验 `verify_moments.py`", "### 3.2 矩/精度核验 `verify_moments.py`", 1)

start = text.find("结果：`status=pass`，**11/11** 项通过")
end = text.find("两份核验都**只做数学/恒等式**")
assert start != -1 and end != -1 and end > start, "3.2 block boundaries not found"
new_block = """结果：`status=pass`，**20/20** 项通过，输出 `verify_moments_results.json`。核验内容：

- 比值 delta 公式的 raw-moment 形式与显式 1/N 形式代数相等（`RATIO-1OVER-N-CANCEL`、`RATIO-CANCEL-SAMPLE`，差 5.6e-17）；
- 冻结协方差 fixture `A=[1,2,0], B=[2,1,0]`：A=B=3、sumSqA=sumSqB=5、sum_AB=4、ratio=1、`R=√2/3=0.4714045207910318`；
- **12 位有效数字半单位改为量级基**：生产者是 `std::setprecision(12)` 的 general 输出，会省略尾零，因此不能用打印字符串的小数位推精度。对非零有限值 `d` 取 `h = 0.5 × 10^(floor(log10(|d|)) − 11)`（`Decimal.adjusted()`），量级边界取较宽一侧；打印的精确零为精确 0，不凭空给 0.5 容差。fixture：

| 打印值 | 旧字符串法半宽 | 量级基保守半宽 | 接受区间 |
|---|---|---|---|
| `1` | 0.5 | `5e-12` | `[0.999999999995, 1.000000000005]` |
| `1000` | 0.5 | `5e-9` | `[999.999999995, 1000.000000005]` |
| `1e-9` | 5e-10 | `5e-21` | `[9.99999999995e-10, 1.000000000005e-9]` |
| `-1000` | 0.5 | `5e-9` | `[-1000.000000005, -999.999999995]` |
| `1.36016812632` | `5e-12` | `5e-12` | `[1.360168126315, 1.360168126325]` |
| `0` | 0.5 | 精确 0（不给容差） | `[0, 0]` |

  旧字符串法对 `1` 给出 0.5，比量级基宽 `1.0e11` 倍，已被 `PRECISION-OLD-STRING-RULE-REJECTED` 明确拒绝；`999.9999999995` 按 `%.12g` 打印为 `1000`，落在保守区间内（`PRECISION-MAGNITUDE-BOUNDARY`）。
- 该半单位区间随后传播到所有原始量、比值与矩的比较（和、平方和、质量、体积、面积、rel_error、sigma 与差值），不改成统一 1e-12 相对门槛；REF-LET-01-EM 100 MeV 的 `let_t=1.36016812632`、`let_d=1.36016814997` 单值相对半宽 `3.676e-12`，差值 `2.365e-8` 的相对半宽 `4.228e-4`（差值为正且下限 `2.3640e-8>0`，仍远小于 5%）；
- Bernoulli 注量恒等式：`sumSq/sum² − 1/N = 1/K − 1/N` 对模型精确成立；浮点 2σ 判据与整数精确判据对 K=1…2000 完全一致。

"""
text = text[:start] + new_block + text[end:]

replace_once(
    "- 所有 CSV 标量为 `std::setprecision(12)` 打印；比较必须用半单位区间传播，尤其 LET 差分有消去。",
    "- 所有 CSV 标量为 `std::setprecision(12)` 的 general 输出，会省略尾零；比较必须按**量级**取半单位 "
    "`h = 0.5 × 10^(floor(log10(|d|)) − 11)` 并传播，尤其 LET 差分有消去；打印的精确零按精确 0 处理，"
    "不赋予半单位容差。不得使用字符串小数位推算半宽，也不得统一改成 1e-12 相对门槛。",
    "output semantics precision bullet",
)

replace_once(
    "- 关键：`rel_error=0` 是 N<2 的表示，不得当作“零误差有效”；不设物理门槛。",
    "- 关键：`insufficient_events` 是唯一接受的状态；delta 公式在浮点下仍可能打印极小非零 "
    "`rel_error`，因此不强制其字面等于 0，但绝不能把它当作可用置信误差；不设物理门槛。",
    "UNC-N1 rel_error wording",
)

replace_once(
    "- 单批：K=有注量事件的条目数（=round(track_length/0.1)），Φ=K/100 mm⁻²；若每事件合并路径不是 0.1 mm 则 Bernoulli 模型不成立，案例失败关闭，不调参。覆盖判据 `|Φ−N/144| ≤ 2ΦR`（半单位区间），并做整数精确式交叉核对；冻结 K 覆盖区间 `[1347,1429]`，单批覆盖概率 `0.9559137115315595`。",
    "- 单批：`hits=false`，因此没有逐事件路径的观测；K=有注量事件的条目数，Φ=K/100 mm⁻²，"
    "并与冻结直线路径模型的**打印矩一致性**交叉核对：`K=round(track_length/0.1)`、"
    "`sum_sq=K×0.1^2`、`sum=K×0.1`。该一致性是有限解析检查，不能表述为“读到了每个事件的完整路径”；"
    "不一致则案例失败关闭，不调参。覆盖判据 `|Φ−N/144| ≤ 2ΦR`（半单位区间），并做整数精确式交叉核对；"
    "冻结 K 覆盖区间 `[1347,1429]`，单批覆盖概率 `0.9559137115315595`。",
    "UNC-COVERAGE single batch",
)

replace_once(
    "建议监督端确认（均不改变冻结数值）：\n\n"
    "1. UNC-ZERO 的“空 dose/let 汇总文件仅表头”是否为预期产品表示；若生产者改为不建文件，按契约不匹配报告，不改产品。\n"
    "2. 候选目录内一次性 C++ probe 直接链接 `src/Scoring/HistoryStatistics.cc` 是否可接受（无产品/测试/构建改动）。\n"
    "3. UNC-COVERAGE 虽用 geantino 仍保留 em=option4 是否维持（与冻结 fluence 参考设置一致，无 EM 交互影响）。\n"
    "4. 覆盖批次出现真实不可用样本时是否按本方案“保留并停止比较”，而不是替换批次。\n",
    "R1 已按原授权确定的点（不改变冻结数值）：\n\n"
    "1. UNC-ZERO 的空 dose/let 汇总文件“仅表头 + 已登记文件”是当前生产者的表示（`DoseScorer.cc:94—114`、"
    "`LETScorer.cc:148` 起恒创建并登记）；`scorer_statistics.csv` 无 entry 时不写文件（`OutputManager.cc:290—291`）。"
    "若生产者改变该表示，按契约不匹配报告，不改产品。\n"
    "2. 候选目录内一次性 C++ probe 直接链接 `src/Scoring/HistoryStatistics.cc` 可用（无产品/测试/构建改动）。\n"
    "3. UNC-COVERAGE 保留 `em=option4`（与冻结 fluence 参考设置一致；geantino 无 EM 交互）。\n"
    "4. 覆盖批次出现真实不可用样本时保留并停止比较，不用替代批次。\n",
    "resolved open questions",
)

replace_once(
    "适用域：仅本预注册冻结的模型（12×12 mm 束、10×10×0.1 mm Galactic 靶、p=25/36、N=2000、seeds 220001…220064、Geant4 11.3.2、后端 864bc036）；UNC-COMPONENT 仅是组件级证据；UNC-N1/UNC-ZERO 是极端统计的产品表示验证，不评价探测器物理；不声称通用置信覆盖或剂量/LET 物理正确性。",
    "适用域：仅本预注册冻结的模型（12×12 mm 束、10×10×0.1 mm Galactic 靶、p=25/36、N=2000、seeds 220001…220064、Geant4 11.3.2、后端 864bc036）；UNC-COMPONENT 仅是组件级证据；UNC-N1/UNC-ZERO 是极端统计的产品表示验证，不评价探测器物理；覆盖批次 `hits=false`，只有条目数、路径总量与事件二阶矩的打印一致性，没有逐事件路径观测；不声称通用置信覆盖或剂量/LET 物理正确性。",
    "scope paragraph",
)

path.write_text(text, encoding="utf-8")
print("cases.md patched for R1")
