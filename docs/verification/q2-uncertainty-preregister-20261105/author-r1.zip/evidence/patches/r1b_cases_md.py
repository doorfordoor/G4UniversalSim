#!/usr/bin/env python3
"""Apply the R1 structured-contract corrections to cases.md."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "cases.md"
text = path.read_text(encoding="utf-8")


def replace_once(old: str, new: str, label: str) -> None:
    global text
    assert old in text, f"anchor not found: {label}"
    text = text.replace(old, new, 1)


replace_once(
    "仅修订本方案与复算纯数学核验，未运行 Geant4、未改生产/冻结参考。\n",
    "仅修订本方案与复算纯数学核验，未运行 Geant4、未改生产/冻结参考。"
    "同轮结构化续审（LET_d 分母、event_edep 行数=N、MT 二阶矩/错误平均可退化、weighted_edep 直接对账）"
    "已并入本文件与 `proposal.json`，不增加病例/种子/N/范围。\n",
    "R1 note",
)

# ---- hash table ----
replace_once(
    "| `proposal.json` | 67890 | `14c16822facb53b0ec3e09ba2de7b7c8d852e04b9882db0c142974b497b9b48c` |",
    "| `proposal.json` | 70625 | `bfe5e0b2378686741074ed1b6022605e03c569f5debd05003334dc3b31853905` |",
    "proposal row",
)
replace_once(
    "| `build_proposal.py`（确定性 proposal 生成器） | 39633 | `0c301084d64a4daafd803894682910d29f6d59c44aa9d42c330195451e3d91be` |",
    "| `build_proposal.py`（确定性 proposal 生成器） | 42376 | `8aec4b98db7e5073cd1d9fb4a2d88ea3d0ac3206887cc18205140b1ac0085fdc` |",
    "build_proposal row",
)
replace_once(
    "| `verify_moments.py`（纯数学矩/精度核验） | 12199 | `d96836d9c5125ce2cb5f613c4bc80d89a11d80e5c975e982d776674e64cc06ec` |",
    "| `verify_moments.py`（纯数学矩/精度核验） | 13547 | `270e253de7f941c8add805707a30de8b657f022ddbb6b62a873c7c4fd69b55ab` |",
    "verify_moments row",
)
replace_once(
    "| `verify_moments_results.json` | 4850 | `b46cea6f5232f1cc74e16f5607fdc7e0af4873c1accfc7f6568b75029b657eb2` |",
    "| `verify_moments_results.json` | 5276 | `b3f2131766f826ead9fa32241b0f1e398bce77ef6bfa09195f51e7d74835d0a3` |",
    "verify_moments_results row",
)

# ---- 3.2 count + asymmetric fixture bullet ----
replace_once(
    "结果：`status=pass`，**20/20** 项通过，输出 `verify_moments_results.json`。核验内容：",
    "结果：`status=pass`，**22/22** 项通过，输出 `verify_moments_results.json`。核验内容：",
    "3.2 count",
)
replace_once(
    "- 冻结协方差 fixture `A=[1,2,0], B=[2,1,0]`：A=B=3、sumSqA=sumSqB=5、sum_AB=4、ratio=1、`R=√2/3=0.4714045207910318`；",
    "- 冻结协方差 fixture `A=[1,2,0], B=[2,1,0]`：A=B=3、sumSqA=sumSqB=5、sum_AB=4、ratio=1、`R=√2/3=0.4714045207910318`；\n"
    "- **LET_d 分母顺序**（结构化续审第 1 点）：令 `B=sum_wSl`、`C=sum_wS2l`，正确式为 "
    "`R_d² = sum_sq_wS2l/C² + sum_sq_wSl/B² − 2·AC/(B·C)`；增加不对称 fixture `B=[1,2,4]`（Σ=7）、"
    "`C=[5,1,2]`（Σ=8），交换分母得到 `R_d²=0.404655612245` 而正确值 `0.361607142857`（相差 11.905%），"
    "因此该 fixture 能检出分母写反，对称示例不会掩盖；",
    "3.2 LET_d fixture",
)

# ---- UNC-TOT ----
replace_once(
    "- 检查：完成数=20、eventID 一一对应、Σevent raw edep×1.602176634e-13/mass == dose raw_dose_Gy（半单位区间）、用全部事件（含零贡献）重算 S/S²/R 与公开 rel_error 一致、entries=非零事件数、N 不得用 hits 行数代替。",
    "- 检查：完成数=20、eventID 一一对应、Σevent raw edep×1.602176634e-13/mass == dose raw_dose_Gy、"
    "Σevent weighted edep×1.602176634e-13/mass == dose weighted_dose_Gy（均在半单位区间内；`event_edep` 直接提供 "
    "`weighted_edep_MeV`，不需要逐步 weight 列）、用全部事件（含零贡献）重算 S/S²/R 与公开 rel_error 一致、"
    "entries=非零事件数。N 来自 summary/metadata；完整 `event_edep` 文件按契约恰好 N 行，因此行数不是独立的 N，"
    "拒绝“用非零贡献 entries 或普通 hits 行数替代完整 N”时用缺行/重复行的副本或组件 fixture——合法完整文件与 N "
    "同值的情形不声称可检出。",
    "UNC-TOT checks",
)
replace_once(
    "- 边界：单一敏感体保证逐体积归属无歧义；公开 CSV 无事件权重列，加权恒等式仅在全部权重为 1 时检查。",
    "- 边界：单一敏感体保证逐体积归属无歧义；`event_edep` 的 `weighted_edep_MeV` 可直接与 weighted dose 对账，"
    "无需额外权重列，也不要求先证明全部权重为 1。",
    "UNC-TOT boundary",
)

# ---- UNC-LET-COV formula ----
replace_once(
    "`R_t²=sumSq_wSl/B²+sumSq_wl/A²−2BA/(AB)`，`R_d²=sumSq_wS2l/B²+sumSq_wSl/C²−2AC/(CB)`，与公开 rel_error 的半单位区间一致；",
    "`R_t²=sumSq_wSl/B²+sumSq_wl/A²−2BA/(A·B)`，"
    "`R_d²=sumSq_wS2l/C²+sumSq_wSl/B²−2AC/(B·C)`（B=sum_wSl、C=sum_wS2l，两个平方矩分母不同），"
    "与公开 rel_error 的半单位区间一致；",
    "LET-COV formula",
)

# ---- UNC-MT-SPARSE ----
replace_once(
    "- 预期：`actual_threads=4`、完成 2 事件；4 个 worker 中至少 2 个无事件，缺失/空 worker 文件是正常；全局 eventID 并集恰为 2 且不重复；剂量与 LET 按“求和/矩合并”后计算比值，禁止平均各 worker 的 rel_error；`scorer_statistics.csv` 的 n_events=2。",
    "- 预期：`actual_threads=4`、完成 2 事件；4 个 worker 中至少 2 个无事件，缺失/空 worker 文件是正常；"
    "全局 eventID 并集恰为 2 且不重复；剂量与 LET 按“求和/矩合并”后计算比值，禁止平均各 worker 的 rel_error；"
    "`scorer_statistics.csv` 的 n_events=2。**实测分配**要记录：N=2 可能同落一个 worker，此时“错误平均”与合并值"
    "可能数值退化相同，`MT-NO-WORKER-AVERAGE` 只要求记录两者、不得强制本次分配下必须不同；可区分的反例用"
    "预先指定的两个非空 worker 的组件/副本 fixture，不换种子强求分配。",
    "UNC-MT-SPARSE expectation",
)
replace_once(
    "- 检查：合并 Σraw、ΣS²、A/B/C/BA/AC 后与公开行对账；记录“合并 rel_error”与“错误地平均 worker 误差”的差值，证明后者不可用。",
    "- 检查：合并 Σraw、ΣS²、A/B/C/BA/AC **以及三个二阶矩** `sumSq_wl`、`sumSq_wSl`、`sumSq_wS2l` 后，"
    "由合并矩计算 `let_t`、`let_d` 与两条 delta rel_error，并与公开行对账；记录“合并 rel_error”与“错误平均”的"
    "差值仅作信息，不把它当作本次分配的必然检出。",
    "UNC-MT-SPARSE checks",
)

# ---- counterexamples ----
replace_once(
    "| CE-HITS-AS-N | UNC-TOT | 用 hits/事件行数当 N | TOT-MOMENTS |",
    "| CE-HITS-AS-N | UNC-TOT | 用非零贡献 entries 或普通 hits 行数替代完整 N；同值的合法完整文件不声称可检出，副本改为缺行/重复行 | TOT-NOT-HITS-ROWS / TOT-MOMENTS |",
    "CE-HITS-AS-N row",
)
replace_once(
    "| CE-WORKER-AVERAGE | UNC-MT-SPARSE | 平均各 worker rel_error | MT-NO-WORKER-AVERAGE / MT-DOSE-STATS |",
    "| CE-WORKER-AVERAGE | UNC-MT-SPARSE | 平均各 worker rel_error；用预先指定的“两个非空 worker、误差不同”的组件/副本 fixture 区分，不强制冻结稀疏分配暴露差异 | MT-NO-WORKER-AVERAGE / MT-DOSE-STATS |",
    "CE-WORKER-AVERAGE row",
)

# ---- scope/boundaries ----
replace_once(
    "覆盖批次 `hits=false`，只有条目数、路径总量与事件二阶矩的打印一致性，没有逐事件路径观测；不声称通用置信覆盖或剂量/LET 物理正确性。",
    "覆盖批次 `hits=false`，只有条目数、路径总量与事件二阶矩的打印一致性，没有逐事件路径观测；"
    "完整 `event_edep` 文件的合法行数就是 N，因此不以“行数=N”本身作为检出依据；"
    "稀疏 MT 下错误平均可能数值退化，可区分性只由预先指定的组件/副本 fixture 证明；"
    "不声称通用置信覆盖或剂量/LET 物理正确性。",
    "scope paragraph",
)

path.write_text(text, encoding="utf-8")
print("cases.md patched for R1 structured corrections")
