#!/usr/bin/env python3
"""Apply the R1 precision-boundary fixes to build_proposal.py (text only)."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "build_proposal.py"
text = path.read_text(encoding="utf-8")

OLD_HALF = (
    '    "half_unit_interval": "Every project CSV scalar is printed with std::setprecision(12). '
    'A printed value d is treated as the interval [d - 0.5*10^e, d + 0.5*10^e] where e is the '
    'printed decimal exponent. Comparisons use the propagated interval, never a uniform 1e-12 '
    'relative tolerance. Pure math verification (verify_moments.py) shows the half-unit interval '
    'of let_d - let_t for the frozen REF-LET-01-EM 100 MeV values is about 4.2e-4 relative while '
    'the single values are 3.7e-12 relative.",'
)
NEW_HALF = (
    '    "half_unit_interval": "Every project CSV scalar is printed with std::setprecision(12) in '
    'general format, which drops trailing zeros; the number of printed decimals therefore does '
    'not state the precision. For a non-zero finite printed value d the conservative half unit is '
    'h = 0.5 * 10^(floor(log10(|d|)) - 11), computed from the magnitude (Decimal.adjusted()), '
    'with the wider side used at a magnitude boundary; e.g. h(1)=5e-12, h(1000)=5e-9, '
    'h(1e-9)=5e-21. A printed exact zero is exact: no 0.5 tolerance is invented and zero is not '
    'given an interval. This half unit is propagated through every comparison of raw quantities, '
    'ratios and moments (sums, sumsq, masses, volumes, areas, rel_error, sigma and differences), '
    'never replaced by a uniform 1e-12 relative tolerance. Pure math verification (verify_moments.py, '
    '20/20 pass) demonstrates the fixtures 1, 1000, 1e-9, -1000, 1.36016812632 and exact 0, shows '
    'the old string-exponent rule would be >=1e9 times looser, and shows the half-unit interval of '
    'let_d - let_t for the frozen REF-LET-01-EM 100 MeV values is about 4.2e-4 relative while the '
    'single values are 3.7e-12 relative.",'
)
assert OLD_HALF in text, "half_unit_interval text not found"
text = text.replace(OLD_HALF, NEW_HALF)

OLD_N1 = (
    '            {"id": "N1-STATUS", "rule": "all four scorer_statistics rows have n_events=1 and '
    'uncertainty_status=insufficient_events; the printed rel_error must not be reported as a valid '
    'zero error"},'
)
NEW_N1 = (
    '            {"id": "N1-STATUS", "rule": "all four scorer_statistics rows have n_events=1 and '
    'uncertainty_status=insufficient_events; the delta formula can still produce a tiny non-zero '
    'floating-point rel_error, so the printed rel_error is not required to be exactly zero and is '
    'never presented as a usable confidence error; insufficient_events is the only accepted status"},'
)
assert OLD_N1 in text, "N1-STATUS rule not found"
text = text.replace(OLD_N1, NEW_N1)

OLD_COV_K = (
    '            {"name": "K", "source": "per batch: scorer_statistics.csv entries for '
    'raw_fluence/weighted_fluence, cross-checked with tracksum/0.1 and per-event 0.1 mm path", '
    '"unit": "events", "semantics": "number of events with a fluence entry; must equal '
    'round(track_length/0.1)"},'
)
NEW_COV_K = (
    '            {"name": "K", "source": "per batch: scorer_statistics.csv entries for '
    'raw_fluence/weighted_fluence, cross-checked with round(track_length/0.1) and with the event '
    'second moment; hits=false, so no per-event path is observable", "unit": "events", '
    '"semantics": "number of events with a fluence entry; the frozen straight-path model predicts '
    'every entry carries exactly 0.1 mm, sum_sq = K*0.1^2 and sum = K*0.1 mm; this is a finite '
    'analytic consistency check of the printed moments, not a reading of each event path"},'
)
assert OLD_COV_K in text, "COV K semantics not found"
text = text.replace(OLD_COV_K, NEW_COV_K)

OLD_COV_PATH = (
    '            {"id": "COV-PATH", "rule": "per batch every fluence row\'s event path is 0.1 mm '
    '(merged per event) and K=round(track_length/0.1); otherwise the Bernoulli model does not apply '
    'and the case fails closed instead of tuning"},'
)
NEW_COV_PATH = (
    '            {"id": "COV-PATH", "rule": "per batch the entry count K, total track length and '
    'event second moment are mutually consistent with the frozen straight-path model (K=round(track_length/0.1), '
    'sum_sq=K*0.1^2); because hits=false the batch has no per-event path observation, so this is a '
    'finite analytic consistency check of the printed moments and must not be described as having '
    'read every event path; any inconsistency fails closed instead of tuning"},'
)
assert OLD_COV_PATH in text, "COV-PATH rule not found"
text = text.replace(OLD_COV_PATH, NEW_COV_PATH)

OLD_NOTE = (
    '        "The Bernoulli model requires the full 12x12 mm beam to cross the 10x10x0.1 mm slab '
    'with a full 0.1 mm path for every hit event; execution verifies this per batch and fails closed '
    'otherwise.",'
)
NEW_NOTE = (
    '        "The Bernoulli model requires the full 12x12 mm beam to cross the 10x10x0.1 mm slab '
    'with a full 0.1 mm path for every hit event. hits=false, so execution checks the model through '
    'the printed entry count, total path and event second moments per batch (not by reading each '
    'event path) and fails closed on inconsistency.",'
)
assert OLD_NOTE in text, "coverage note not found"
text = text.replace(OLD_NOTE, NEW_NOTE)

OLD_BOUNDARY = (
    '        "The dose/MC cross-check uses printed 12-digit values and half-unit intervals; '
    'absolute mc-truth accuracy is not claimed.",'
)
NEW_BOUNDARY = (
    '        "The dose/MC cross-check uses printed 12-digit values and magnitude-based half-unit '
    'intervals; absolute mc-truth accuracy is not claimed.",\n'
    '        "Coverage batches run with hits=false and therefore have no per-event path observation; '
    'the frozen straight-path model is supported only by the consistency of the entry count, total '
    'path and event second moments, not by reading every event path.",'
)
assert OLD_BOUNDARY in text, "boundary text not found"
text = text.replace(OLD_BOUNDARY, NEW_BOUNDARY)

path.write_text(text, encoding="utf-8")
print("build_proposal.py patched for R1")
