# Q2-4 统计不确定度预注册（草案 v2，R1 精度边界修订）

> 2026-11-05 R1：按独立静态复核 `docs/collab/reviews/20261105-q2-uncertainty-preregister-r1.md` 修订 12 位有效数字半单位定义（改为量级基，不再用打印字符串的小数位）、N=1 与覆盖批次 `hits=false` 的措辞；仅修订本方案与复算纯数学核验，未运行 Geant4、未改生产/冻结参考。同轮结构化续审（LET_d 分母、event_edep 行数=N、MT 二阶矩/错误平均可退化、weighted_edep 直接对账）已并入本文件与 `proposal.json`，不增加病例/种子/N/范围。

- 任务 ID：`q2-uncertainty-preregister-v1-20261105`
- 状态：**draft**，`execution_authorized=false`。本文件与 `proposal.json` 不是模拟授权，只把固定清单 Q2-4 化为可执行、可独立复验的有限合同。
- 前置结论：NIEL 表审计（REF-DDD-02）已独立复验（27 pass / 0 fail / 3 limited，结构/算术 pass、物理评价 limited）；Q2-3 按已声明适用域签收；REF-DDD-01 为 limited（257/0/6，7 反例真实 fail）。
- 本轮范围：只写 `out/collab/q2-uncertainty-proposal-v1/` 与回执 `docs/collab/outbox/20261105-q2-uncertainty-preregister-v1.md`。**不编译、不运行 Geant4**，不改产品/测试/基准/冻结/阶段文件，不提交 Git。

## 1. 冻结与依据

| 依据 | SHA-256 |
|---|---|
| `docs/collab/decisions/20261105-q2-uncertainty-coverage-design-v1.json` | `f179a241d77ef483a143c086c31c2e14fd5c63a84422071298d6ae83251a3af3` |
| `docs/collab/reviews/20261105-q2-uncertainty-preregister-review.md` | `55b73bc7ad8817f6adec67c249bf270dfa3b0ff2a8746db9d4f709efbda9e9db` |
| `docs/collab/decisions/20261105-q2-dose-reference-freeze-v1.json`（几何/材料来源） | `a2a799e90bd941b4969beab62be408013420dfbd684c4e8e52f07775308e498d` |
| `docs/collab/decisions/20261105-q2-fluence-reference-freeze-v1.json`（覆盖几何来源） | `d9ceb71f9cb6a3bcf4029010eb2bf2212c6b014dca9967b40277e01379b077b3` |
| `docs/collab/decisions/20261105-q2-let-reference-freeze-v1.json`（LET 几何/物理来源） | `b22b7d6535d226f632719f759003b391d2153f28802a348ae4b071a178136af1` |

冻结后端：build `864bc036d6d7752475e52db4efd2b950cabfcc3d`，exe SHA-256 `f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f`，Geant4 11.3.2，`--check-geant4-data` 必须 `required_complete`。

## 2. 交付物与哈希

| 文件 | 大小 | SHA-256 |
|---|---|---|
| `proposal.json` | 70625 | `bfe5e0b2378686741074ed1b6022605e03c569f5debd05003334dc3b31853905` |
| `inputs_manifest.json` | 1725 | `048bec9bd7582c2ced7ace5654056b4c20ca9c6d6db1b0d1122bcaf53f0009e4` |
| `make_inputs.py`（确定性输入生成器） | 6918 | `9b4390578560ccb9559529cff5e568b04e91a44d3b6692d8a7506758f01ad1bd` |
| `build_proposal.py`（确定性 proposal 生成器） | 42376 | `8aec4b98db7e5073cd1d9fb4a2d88ea3d0ac3206887cc18205140b1ac0085fdc` |
| `verify_coverage.py`（纯数学覆盖核验） | 13120 | `7fc7db48b7b8889ef16744130640d7d7616ad3345b1cc84cd0e0aa2bc57cfb5a` |
| `verify_coverage_results.json` | 5437 | `fc09a56999d5ea812cb089af76db0dc8585e7e0f46fe95c38bdddd097a3a141e` |
| `verify_moments.py`（纯数学矩/精度核验） | 13547 | `270e253de7f941c8add805707a30de8b657f022ddbb6b62a873c7c4fd69b55ab` |
| `verify_moments_results.json` | 5276 | `b3f2131766f826ead9fa32241b0f1e398bce77ef6bfa09195f51e7d74835d0a3` |

`inputs/` 共 17 个草案文件，逐文件 SHA 见 `inputs_manifest.json`（由 `make_inputs.py` 生成，重跑可复现）：
materials.ini `fb05cfd6f448f12805a15c3b423cb16889fc34e64bbbc1a1a7bce45a6d0ef858`；
geometry_unc_tot.ini `68812cef753f32c3171d4180a90860db57fad79cc474e01d39c9c6862ca26964`；
geometry_unc_n1.ini `808fe87c5228b5a3ce8103455ea49cc4b57ff25c9c015a5f2f3afe496df1b42f`；
geometry_unc_let_cov.ini `3802c956bccab42f19d4cfd0c098a0cb7820d0be857491a4a72bdcbbf564ce0a`；
geometry_unc_coverage.ini `cc7d1819f14627a65cbf25a9348b98db7ef950f5db8d7060456e58c01bc93aff`；
main_unc_tot.ini `9356b3582680f4042781d2ab07d9cdee54df9da4a40238b70baceee33a4b6beb`；
main_unc_n1.ini `625157207dcb00e9c0cb99189459889233e26d55ba6130bdef8517a151171672`；
main_unc_zero.ini `c9f5b78f611901d4bc7af83aafd2c0b6c5063cb1a60261bcbde24d6f2b125a07`；
main_unc_let_cov.ini `87a089adb55328eddf9b6b7378efc4e240e6aebbe75197ac5c03ba1e729f41a5`；
main_unc_mt_sparse.ini `263d0486e350b86c192d173108e2dad51caab3f04b9916b9ae447f0f390aef18`；
main_unc_coverage.ini `141180b4206b17d342d92d6f812210741d18c6213c0685c519c50870ac9e3c74`；
run_unc_tot.mac `9cf63a084614a204eb83485f5b5311402fa3946f0b79bb0354513f10c914f86e`；
run_unc_n1.mac `20d1d29510e06e21c09e7ac2c4a08f0eea34f4a9bfc182d0950939fc4a827332`；
run_unc_zero.mac `a268605473384ade5b105f11fa7c6aca8396c721a8687b9b6c1dd021798a4ec1`；
run_unc_let_cov.mac `6201e52c5a8be705923e8286ff9e91c6f7fc2b739d40c81060dab71ee95da7f6`；
run_unc_mt_sparse.mac `0dd940fb9c0c1ad14e0ebc0278969623e0f8ac11cba28cd8136ad86a7cfe0b01`；
run_unc_coverage.mac `af1609b27e72ffe6c226933226ab5207c79676e60bc075366680e25b5f6ceeeb`。

草案 INI 中的 `/output dir` 指向未来执行目录 `out/collab/q2-uncertainty-v1/runs/<case>/output`；执行任务必须复制草案到自己的候选目录、核对全部 SHA，并可用 `--output` 覆盖输出目录。覆盖批次只允许用 `--seed` 覆盖单个批次的种子。

## 3. 纯数学核验（本轮执行）

### 3.1 覆盖设计核验 `verify_coverage.py`

```
cd out/collab/q2-uncertainty-proposal-v1
python -B verify_coverage.py
```

结果：`status=pass`，**19/19** 项通过，输出 `verify_coverage_results.json`（约 1.4 s）。核验内容：

- exact-rational 归一化恒等式：`Σ_k C(2000,k) 25^k 11^(2000−k) = 36^2000`（`MATH-EXACT-NORMALISER`）；
- 单批覆盖 K 的整数区间与 `|K−Np| ≤ 2√(K−K²/N)` 等价（`MATH-INEQUALITY-EQUIVALENCE`、`MATH-K-BOUNDARIES`）；
- 单批覆盖概率精确值 `0.955913711531559450469938471146634229478641391760449724745053`（float 打印值 `0.9559137115315595`）；
- 覆盖数下尾：C 最小 57，`P(C<57) = 0.00698051532398270997145110458852696896657979204623148452122967`，均值 `61.1784775380198048300760621533845906866330490726687823836834`；
- 总 K 的中央 99% 区间 `[88464, 89313]`（`P(X≤88463)=0.004954871384`、`P(X≤89313)=0.995041182838`，两侧各 0.5%），期望 `88888.888…`，众数 88889；
- 联合误拒上界 `0.0169805153239827 = 0.01 + 0.0069805…`（≤2%，不写联合 1%）。

### 3.2 矩/精度核验 `verify_moments.py`

```
python -B verify_moments.py
```

结果：`status=pass`，**22/22** 项通过，输出 `verify_moments_results.json`。核验内容：

- 比值 delta 公式的 raw-moment 形式与显式 1/N 形式代数相等（`RATIO-1OVER-N-CANCEL`、`RATIO-CANCEL-SAMPLE`，差 5.6e-17）；
- 冻结协方差 fixture `A=[1,2,0], B=[2,1,0]`：A=B=3、sumSqA=sumSqB=5、sum_AB=4、ratio=1、`R=√2/3=0.4714045207910318`；
- **LET_d 分母顺序**（结构化续审第 1 点）：令 `B=sum_wSl`、`C=sum_wS2l`，正确式为 `R_d² = sum_sq_wS2l/C² + sum_sq_wSl/B² − 2·AC/(B·C)`；增加不对称 fixture `B=[1,2,4]`（Σ=7）、`C=[5,1,2]`（Σ=8），交换分母得到 `R_d²=0.404655612245` 而正确值 `0.361607142857`（相差 11.905%），因此该 fixture 能检出分母写反，对称示例不会掩盖；
- **12 位有效数字半单位改为量级基**：生产者是 `std::setprecision(12)` 的 general 输出，会省略尾零，因此不能用打印字符串的小数位推精度。对非零有限值 `d` 取 `h = 0.5 × 10^(floor(log10(|d|)) − 11)`（`Decimal.adjusted()`），量级边界取较宽一侧；打印的精确零为精确 0，不凭空给 0.5 容差。fixture：

| 打印值 | 旧字符串法半宽 | 量级基保守半宽 | 接受区间 |
|---|---|---|---|
| `1` | 0.5 | `5e-12` | `[0.999999999995, 1.000000000005]` |
| `1000` | 0.5 | `5e-9` | `[999.999999995, 1000.000000005]` |
| `1e-9` | 5e-10 | `5e-21` | `[9.99999999995e-10, 1.000000000005e-9]` |
| `-1000` | 0.5 | `5e-9` | `[-1000.000000005, -999.999999995]` |
| `1.36016812632` | `5e-12` | `5e-12` | `[1.360168126315, 1.360168126325]` |
| `0` | 0.5 | 精确 0（不给容差） | `[0, 0]` |

  旧字符串法对 `1` 给出 0.5，比量级基宽 `1.0e11` 倍，已被 `PRECISION-OLD-STRING-RULE-REJECTED` 明确拒绝；`999.9999999995` 按 `%.12g` 打印为 `1000`，落在保守区间内（`PRECISION-MAGNITUDE-BOUNDARY`）。
- 该半单位区间随后传播到所有原始量、比值与矩的比较（和、平方和、质量、体积、面积、rel_error、sigma 与差值），不改成统一 1e-12 相对门槛；REF-LET-01-EM 100 MeV 的 `let_t=1.36016812632`、`let_d=1.36016814997` 单值相对半宽 `3.676e-12`，差值 `2.365e-8` 的相对半宽 `4.228e-4`（差值为正且下限 `2.3640e-8>0`，仍远小于 5%）；
- Bernoulli 注量恒等式：`sumSq/sum² − 1/N = 1/K − 1/N` 对模型精确成立；浮点 2σ 判据与整数精确判据对 K=1…2000 完全一致。

两份核验都**只做数学/恒等式**，不调用后端、不读取运行输出、不据结果调整任何阈值。

## 4. 输出语义与缺失行（统一契约）

产品源代码事实（本轮只读确认）：

- `event_edep` 每事件一行、零沉积也写：`src/Scoring/ScoringManager.cc:516` 在 `EndEvent` 中对每个事件写 `EventEdepRecord`；表头与 12 位精度见 `src/Output/OutputManager.cc:832`：`runID,eventID,raw_edep_MeV,weighted_edep_MeV`；`raw_edep_MeV` 是该事件所有正沉积分步的 Σedep（MeV，未加权），`weighted_edep_MeV = Σ edep×trackWeight`；所有敏感体并入同一行，因此 UNC-TOT 只使用单一敏感体。
- `dose_volume_summary_tN.csv` 每 worker 写文件：无计分体积时文件只有表头（`DoseScorer::Write` 恒创建文件）；`n_events` 是该 worker 完成事件数（含零沉积事件），数据行为“该 worker 内有非零沉积的敏感体”。
- `let_volume_summary_tN.csv` 同构；有效 LET 步 = `stepLength>0`、权重为正、非中性（geantino 的阻止本领为 0）且通过粒子过滤；`n_events` 同上。
- `scorer_statistics.csv` 仅当存在 `HistoryStatistics` 提交时写出；无任何计分时**文件缺失是契约**（不得伪造 `zero_total`/`undefined_ratio`）。
- `HistoryStatistics` 状态优先级：N<2 → `insufficient_events`；ratio 分母为 0 → `undefined_ratio`；分子为 0 → `zero_total`；否则 `approximate`。`R=√(sumSq/sum²−1/N)`，N 为 run 事件数（含零贡献）。ratio delta 用交叉矩，未知协方差不得当 0。
- 所有 CSV 标量为 `std::setprecision(12)` 的 general 输出，会省略尾零；比较必须按**量级**取半单位 `h = 0.5 × 10^(floor(log10(|d|)) − 11)` 并传播，尤其 LET 差分有消去；打印的精确零按精确 0 处理，不赋予半单位容差。不得使用字符串小数位推算半宽，也不得统一改成 1e-12 相对门槛。

`proposal.json` 的 `output_semantics` 给出逐文件列名、必需/允许缺失、`n_events` 与 `entries` 语义。

## 5. 病例（7）

每个病例的机器可读条目在 `proposal.json.cases`（输入路径、种子、线程、事件数、预期产物、原始量来源、检查 id、反例、边界）。摘要：

### UNC-TOT 事件内合并与零贡献
- 输入：REF-Dose 10 MeV 嵌套 Si 几何（40×40×0.12 mm 块 + 10×10×0.02 mm 敏感片，质量 `4.66e-06 kg`）、12×12 mm 方束、em=option4、cut 10 um、N=20、threads=1、seed 20261120、dose+event_edep。
- 预期：`event_edep_t0.csv` 恰好 20 行（每个完成事件一行，零沉积行保留）；dose 汇总 1 行、`n_events=20`；`scorer_statistics.csv` 含 dose raw/weighted 两行。
- 检查：完成数=20、eventID 一一对应、Σevent raw edep×1.602176634e-13/mass == dose raw_dose_Gy、Σevent weighted edep×1.602176634e-13/mass == dose weighted_dose_Gy（均在半单位区间内；`event_edep` 直接提供 `weighted_edep_MeV`，不需要逐步 weight 列）、用全部事件（含零贡献）重算 S/S²/R 与公开 rel_error 一致、entries=非零事件数。N 来自 summary/metadata；完整 `event_edep` 文件按契约恰好 N 行，因此行数不是独立的 N，拒绝“用非零贡献 entries 或普通 hits 行数替代完整 N”时用缺行/重复行的副本或组件 fixture——合法完整文件与 N 同值的情形不声称可检出。
- 边界：单一敏感体保证逐体积归属无歧义；`event_edep` 的 `weighted_edep_MeV` 可直接与 weighted dose 对账，无需额外权重列，也不要求先证明全部权重为 1。

### UNC-N1 N<2
- 输入：10×10×2 mm Si 敏感体内点源，10 MeV proton、(0,0,0)、+z、em=option4、cut 10 um、N=1、threads=1、seed 20261121、dose+LET(proton)。
- 预期：dose 行存在且非零、`n_events=1`；LET 行存在（确定性几何+点源必产生有效 LET 步；若缺失按真实失败报告，不换种子）；`scorer_statistics.csv` 4 行（dose raw/weighted、let_t/let_d），状态均为 `insufficient_events`。
- 关键：`insufficient_events` 是唯一接受的状态；delta 公式在浮点下仍可能打印极小非零 `rel_error`，因此不强制其字面等于 0，但绝不能把它当作可用置信误差；不设物理门槛。

### UNC-ZERO 无沉积/无选中粒子
- 输入：同 UNC-N1 几何、geantino 100 MeV 点源、N=100、threads=1、seed 20261122、dose+LET(proton)、hits=false、event_edep=false。
- 预期：dose/let 汇总文件存在但**只有表头**；`scorer_statistics.csv` 缺失；不得出现伪造的 `zero_total`/`undefined_ratio` 行；完成数=100。
- 依据：geantino 在零沉积分支被 LET 的 `PositiveLETStep` 拒绝（阻止本领 0），Dose 只在正沉积分支计分；`WriteScorerStatisticsCsv` 仅对提交项输出。

### UNC-LET-COV 比值相关矩
- 输入：REF-LET-v1 的 20 μm Si、100 MeV 点 proton、FTFP_BERT_EMZ、cut 10 μm、N=2000、threads=1、seed 20261123、let=proton（无 dose、无 hits）。
- 检查：A=`sum_wl_mm`、B=`sum_wSl_MeV`、C=`sum_wS2l_MeV2_per_mm`、BA=`sum_wl_x_wSl_MeV_mm`、AC=`sum_wSl_x_wS2l_MeV3_per_mm`；`let_t=B/A`、`let_d=C/B`；`R_t²=sumSq_wSl/B²+sumSq_wl/A²−2BA/(A·B)`，`R_d²=sumSq_wS2l/C²+sumSq_wSl/B²−2AC/(B·C)`（B=sum_wSl、C=sum_wS2l，两个平方矩分母不同），与公开 rel_error 的半单位区间一致；n_events=2000、状态 approximate。**不使用**旧的 LET_d/LET_t 5% 外部物理门槛；两个 delta 比值各自用交叉矩，不把未知协方差当 0。

### UNC-MT-SPARSE 稀疏多线程
- 输入：同 UNC-N1 几何/源、N=2、threads=4、seed 20261124、dose+LET+event_edep。
- 预期：`actual_threads=4`、完成 2 事件；4 个 worker 中至少 2 个无事件，缺失/空 worker 文件是正常；全局 eventID 并集恰为 2 且不重复；剂量与 LET 按“求和/矩合并”后计算比值，禁止平均各 worker 的 rel_error；`scorer_statistics.csv` 的 n_events=2。**实测分配**要记录：N=2 可能同落一个 worker，此时“错误平均”与合并值可能数值退化相同，`MT-NO-WORKER-AVERAGE` 只要求记录两者、不得强制本次分配下必须不同；可区分的反例用预先指定的两个非空 worker 的组件/副本 fixture，不换种子强求分配。
- 检查：合并 Σraw、ΣS²、A/B/C/BA/AC **以及三个二阶矩** `sumSq_wl`、`sumSq_wSl`、`sumSq_wS2l` 后，由合并矩计算 `let_t`、`let_d` 与两条 delta rel_error，并与公开行对账；记录“合并 rel_error”与“错误平均”的差值仅作信息，不把它当作本次分配的必然检出。

### UNC-COMPONENT 共享实现边界
- 用一次性 C++ probe 直接链接仓库真实实现 `src/Scoring/HistoryStatistics.cc`（不是 Python 镜像，不新增产品接口/测试框架），在候选目录下编译运行，记录编译命令与源码 SHA。
- fixture：N=0,num=1,total→insufficient_events；N=1,num=0,ratio,den=0→insufficient_events；N=2,num=1,ratio,den=0→undefined_ratio；N=2,num=0,total→zero_total；N=2,num=0,ratio,den=1→zero_total；N=2,num=1,total→approximate；N=2,num=1,ratio,den=1→approximate。
- 另加冻结协方差 fixture（同 `verify_moments.py`，A=3/B=3/sumSq=5/AB=4/R=√2/3）。有限性防护不在本预注册范围。

### UNC-COVERAGE 独立有限批次
- 输入：REF-Fluence 几何（Galactic 10×10×0.1 mm 靶、12×12 mm 方束）、geantino 100 MeV、em=option4、cut 0.7 mm、fluence、N=2000、threads=1、64 批、seeds 220001…220064 各一次。
- 单批：`hits=false`，因此没有逐事件路径的观测；K=有注量事件的条目数，Φ=K/100 mm⁻²，并与冻结直线路径模型的**打印矩一致性**交叉核对：`K=round(track_length/0.1)`、`sum_sq=K×0.1^2`、`sum=K×0.1`。该一致性是有限解析检查，不能表述为“读到了每个事件的完整路径”；不一致则案例失败关闭，不调参。覆盖判据 `|Φ−N/144| ≤ 2ΦR`（半单位区间），并做整数精确式交叉核对；冻结 K 覆盖区间 `[1347,1429]`，单批覆盖概率 `0.9559137115315595`。
- 批次层：覆盖批数 C≥57；ΣK∈[88464,89313]；固定 64 个种子，无重试/加批/重采样；不可用样本保留并报告，真实执行失败即停止比较，不用替代样本补齐。
- 两项各 1%，联合误拒绝率只声明上界 2%（不写联合 1%）；不宣称普适覆盖。

## 6. 反例（执行任务实现，仅在副本上）

| id | 目标 | 突变 | 必须被哪项检查判 fail |
|---|---|---|---|
| CE-DROP-ZERO-ROW | UNC-TOT | 删除一条零沉积 event_edep 行 | TOT-EVENT-ROWS |
| CE-HITS-AS-N | UNC-TOT | 用非零贡献 entries 或普通 hits 行数替代完整 N；同值的合法完整文件不声称可检出，副本改为缺行/重复行 | TOT-NOT-HITS-ROWS / TOT-MOMENTS |
| CE-ZERO-ERROR | UNC-ZERO | 伪造 zero_total 行 | ZERO-STATS-ABSENT / ZERO-NO-FABRICATION |
| CE-UNKNOWN-COVARIANCE-ZERO | UNC-LET-COV | 把 BA/AC 置 0 | LET-COV-CROSS-MOMENTS |
| CE-WORKER-AVERAGE | UNC-MT-SPARSE | 平均各 worker rel_error；用预先指定的“两个非空 worker、误差不同”的组件/副本 fixture 区分，不强制冻结稀疏分配暴露差异 | MT-NO-WORKER-AVERAGE / MT-DOSE-STATS |
| CE-MISSING-METADATA | 全部 | 删除 run_metadata.json | EVID-METADATA |
| CE-RESAMPLE | UNC-COVERAGE | 替换/增加批次种子 | COV-BATCHES |
| CE-MASS-UNIT | UNC-TOT | 剂量恒等式把 kg 混成 g | TOT-EDEP-EQ-DOSE |

反例必须落在 `fail`（本预注册没有 `limited` 基线可替代），原件 SHA 在反例前后保持不变。

## 7. 停止条件与完成标准

- 冻结输入未变时复用原始运行（比较冻结 SHA/后端 SHA/输入 SHA/产物 SHA+大小/完成事件），**不因报告或比较器更新重跑同一模拟**；只有 `--force` 才重跑。
- 任何失败保留原始输入/输出/日志/比较器，不调种子、N、cut、容差、几何或参考；缺证据或真实失败即停止比较，不以补采/重试掩盖。
- 完成标准：机器合同逐项判定、7 个反例真实 fail、原件 SHA 不变、证据齐全（身份/完成/产物 SHA）、`check_doc_links` 通过、git 未跟踪且未提交，然后停写等待独立复验。

## 8. 适用域与未决点

适用域：仅本预注册冻结的模型（12×12 mm 束、10×10×0.1 mm Galactic 靶、p=25/36、N=2000、seeds 220001…220064、Geant4 11.3.2、后端 864bc036）；UNC-COMPONENT 仅是组件级证据；UNC-N1/UNC-ZERO 是极端统计的产品表示验证，不评价探测器物理；覆盖批次 `hits=false`，只有条目数、路径总量与事件二阶矩的打印一致性，没有逐事件路径观测；完整 `event_edep` 文件的合法行数就是 N，因此不以“行数=N”本身作为检出依据；稀疏 MT 下错误平均可能数值退化，可区分性只由预先指定的组件/副本 fixture 证明；不声称通用置信覆盖或剂量/LET 物理正确性。

R1 已按原授权确定的点（不改变冻结数值）：

1. UNC-ZERO 的空 dose/let 汇总文件“仅表头 + 已登记文件”是当前生产者的表示（`DoseScorer.cc:94—114`、`LETScorer.cc:148` 起恒创建并登记）；`scorer_statistics.csv` 无 entry 时不写文件（`OutputManager.cc:290—291`）。若生产者改变该表示，按契约不匹配报告，不改产品。
2. 候选目录内一次性 C++ probe 直接链接 `src/Scoring/HistoryStatistics.cc` 可用（无产品/测试/构建改动）。
3. UNC-COVERAGE 保留 `em=option4`（与冻结 fluence 参考设置一致；geantino 无 EM 交互）。
4. 覆盖批次出现真实不可用样本时保留并停止比较，不用替代批次。

下一任务（待冻结与独立复验后）：`q2-uncertainty-execution-v1`——复制输入、运行 7 个案例（含 64 批）、编译组件 probe、写比较器/反例/README/回执、验证证据与链接，再停写等复验。
