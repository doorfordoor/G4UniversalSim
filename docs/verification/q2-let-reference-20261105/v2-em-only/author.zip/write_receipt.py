"""Generate the REF-LET-01-EM (v2) outbox receipt from live delivery artefacts."""

from __future__ import annotations

import collections
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-let-v2"
OUTBOX = ROOT / "docs" / "collab" / "outbox" / "20261105-q2-reference-let-v2.md"
FILES = [
    "README.md",
    "identity.json",
    "reference.py",
    "reference-recompute.json",
    "setup_inputs.py",
    "run_cases.py",
    "compare.py",
    "tamper.py",
    "results.json",
    "tamper-results.json",
    "backend-data-check.txt",
    "inputs/main_ref_let_10.ini",
    "inputs/main_ref_let_100.ini",
    "inputs/geometry_let.ini",
    "inputs/materials.ini",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def file_row(name: str) -> str:
    path = BASE / name
    return "| `" + name + "` | `" + sha256(path)[:16] + "…` | " + str(path.stat().st_size) + " |"


def git(*args: str) -> str:
    return subprocess.run(
        ["git", *args], cwd=ROOT, capture_output=True, text=True, check=True
    ).stdout.strip()


def main() -> int:
    identity = json.loads((BASE / "identity.json").read_text(encoding="utf-8"))
    results = json.loads((BASE / "results.json").read_text(encoding="utf-8"))
    evaluation = results["evaluation"]
    tamper = json.loads((BASE / "tamper-results.json").read_text(encoding="utf-8"))
    reference = json.loads((BASE / "reference-recompute.json").read_text(encoding="utf-8"))
    cases = evaluation["cases"]
    ten = cases["ref_let_10"]["conclusion"]
    hundred = cases["ref_let_100"]["conclusion"]

    groups = collections.Counter(item["id"].split("-")[0] for item in evaluation["checks"])
    group_lines = "\n".join(
        "- `" + prefix + "-*`: " + str(count) + " 项，全部通过；"
        for prefix, count in sorted(groups.items())
    )
    ref_lines = "；".join(
        str(item["energy_MeV"]) + " MeV: mid_delta=" + str(item["mid_delta_MeV"])
        + ", let_delta=" + str(item["let_delta_keV_um"])
        for item in reference["comparison"]
    )
    tamper_lines = "\n".join(
        "- `" + item["id"] + "`: " + item["mutation"] + " → 预期 " + item["expected_check"]
        + "，exit " + str(item["exit_code"]) + "。"
        for item in tamper["tampers"]
    )

    text = f"""# Q2-3 REF-LET-01-EM（仅电磁）回执

状态：**作者交付，待独立复验**（{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} 生成）。
本回执只覆盖 `docs/collab/decisions/20261105-q2-let-reference-freeze-v2.json` 冻结的
**仅电磁 option4** 两例；未改产品源码、正式测试、正式基准、支持等级或 CI，未提交 Git。
**v1（FTFP_BERT_EMZ）的失败仍保留**，v2 是运行前另行冻结的新前瞻实验，不是对 v1 失败的重贴标签。

## 1. 身份与输入

- 仓库：`D:/Geant4/G4UniversalSim`，branch `{git('rev-parse', '--abbrev-ref', 'HEAD')}`，
  生成时 HEAD `{git('rev-parse', 'HEAD')}`。
- 冻结后端：`{identity['backend']['path']}`，sha256 `{identity['backend']['sha256']}`，
  build `{identity['backend']['build_git_commit']}`，
  source fingerprint `{identity['backend']['source_fingerprint']}`，
  Geant4 `{identity['backend']['geant4_version_number']}`。
- 参考数据：`{identity['data_file']['path']}`，sha256 `{identity['data_file']['sha256']}`，
  与冻结值一致（`matches_freeze={identity['data_file']['matches_freeze']}`）。
- 冻结文件：`{identity['freeze']['path']}`，sha256 `{identity['freeze']['sha256']}`，
  schema `{identity['freeze']['schema']}`。
- `--check-geant4-data`：exit {identity['geant4']['data_check_exit']}，输出 sha256
  `{identity['geant4']['data_check_sha256']}`。
- 实际物理：主 INI 只写 `[physics] em = option4`（不写 `reference`）；两例 `run_summary.txt`
  均报 `physics_em = G4EmStandardPhysics_option4`、`physics_reference` 为空。
- 几何/源/cut/事件数/种子：Si 10×10×0.02 mm，点源 (0,0,−3) mm、方向 (0,0,1)，1 um cut，
  1 线程，每例 2000 事件，种子 20261211 / 20261212（运行前已在冻结文件固定）。

## 2. 交付文件

| 文件 | sha256（前缀） | 字节 |
| --- | --- | --- |
{chr(10).join(file_row(name) for name in FILES)}

运行产物在 `runs/ref_let_10/`、`runs/ref_let_100/`（`run.mac`、`backend.log`、`record.json`
与 `output/` 的原始产物）；原始输出与日志保留，未复制覆盖。

## 3. 参考重算（独立于冻结值）

`reference.py` 从 PSTAR_Si 原始字节重算（先校验 sha256、解析 {reference['table_rows']} 行），
两例 E_mid/LET 与冻结值逐位一致：{ref_lines}。结果在 `reference-recompute.json`；
偏差时 `--check` 非零退出。

## 4. 执行与门禁

两例均用冻结后端真实运行：`exit=0`、`completed_events=2000`（约 1.4 s / 1.1 s）。
`results.json` 共 **{evaluation['checks_total']} 项检查，{evaluation['checks_failed']} 项失败**：

{group_lines}

比较器的失败语义与后端退出分开：本交付逐例记录后端真实退出码
`{evaluation['backend_exit_codes']}`，并在 `results.json` 写
`comparison_exit_is_not_backend_exit=true`；比较驱动 exit 1 表示参考/身份比较失败，
不表示后端崩溃。

## 5. 结果（主判据与辅助判据分开）

### 主判据 `REF-LET-T-ABS`：`|LET_t − LET_ref| ≤ 0.015·LET_ref + 3σ`

| 能量 | LET_t | 绝对差 | 允许值 | 相对差 | 结论 |
| --- | --- | --- | --- | --- | --- |
| 10 MeV | {ten['let_t_keV_um']} | {ten['abs_error_keV_um']:.9f} | {ten['allowed_abs_error_keV_um']:.9f} | {ten['relative_error']:.6e} | **{ten['primary_let_t_status']}** |
| 100 MeV | {hundred['let_t_keV_um']} | {hundred['abs_error_keV_um']:.9f} | {hundred['allowed_abs_error_keV_um']:.9f} | {hundred['relative_error']:.6e} | **{hundred['primary_let_t_status']}** |

### 辅助判据 `REF-LET-D-GE-T` + `REF-LET-D-REL (≤0.05)`

| 能量 | LET_d | LET_d−LET_t | 相对差 | 结论 |
| --- | --- | --- | --- | --- |
| 10 MeV | {ten['let_d_keV_um']} | {ten['let_d_minus_let_t_keV_um']:.6e} | {ten['relative_let_d_minus_t']:.6e} | **{ten['auxiliary_let_d_relation_status']}** |
| 100 MeV | {hundred['let_d_keV_um']} | {hundred['let_d_minus_let_t_keV_um']:.6e} | {hundred['relative_let_d_minus_t']:.6e} | **{hundred['auxiliary_let_d_relation_status']}** |

### 两个比值的 δ 方法误差（由公开矩独立重算）

| 能量 | σ(LET_t) | σ(LET_d) | rel_error(LET_t) | rel_error(LET_d) |
| --- | --- | --- | --- | --- |
| 10 MeV | {ten['sigma_let_t_keV_um']:.6e} | {ten['sigma_let_d_keV_um']:.6e} | {ten['rel_error_let_t']:.6e} | {ten['rel_error_let_d']:.6e} |
| 100 MeV | {hundred['sigma_let_t_keV_um']:.6e} | {hundred['sigma_let_d_keV_um']:.6e} | {hundred['rel_error_let_t']:.6e} | {hundred['rel_error_let_d']:.6e} |

**整体结论：两例的全部原判据通过；`evaluation.status = {evaluation['status']}`。**
该结论只在仅电磁 option4 的受限适用域内成立，见 §7。

## 6. 负例

`tamper.py` 在拷贝上构造 {tamper['total']} 个有限反例，全部检出
（{tamper['detected']}/{tamper['total']}），原件、输入与冻结文件未被修改：

{tamper_lines}

## 7. 解释边界与未通过范围

1. **v1 失败保留**：v1 的 `REF-LET-D-REL=0.2106` 仍是失败，v2 不覆盖、不重分类、不把 v1
   称为通过；v1 冻结材料与原始输出继续保留在 `out/collab/q2-reference-let-v1/`。
2. **只适用于仅电磁**：v2 通过不能给强子混合谱 `LET_d` 背书；完整强子病例的适用范围限制
   继续保留，Q2-3 的最终判定仍由主审结合 v1/v2 做出。
3. **不能用无协方差的独立 z 宣布差值通过**：两个 LET 比值相关，本交付没有完整协方差，
   因此不使用独立 σ 的 z 值作为判据，也不声称“差值显著为零”。5% 辅助判据是冻结规则；
   本次两点估计本身远低于 5%，按规则通过。
4. **次级尾部原因未证实**：v1 的“少数高 LET 步骤/次级主导”仍是待检验假设；v2 的通过
   与该假设相容（EM-only 下按构造几乎无强子次级），但不构成证明。
5. 未新增 scorer 字段、未做初级过滤、未改 cut/N/种子/参考/容差；比较器为独立实现，
   不调用产品内部结论。
6. 范围外：其它能量/材料、MT、GUI、强子混合谱、统计覆盖设计（Q2-4 方向）。

## 8. 复现

```bash
python -B out/collab/q2-reference-let-v2/setup_inputs.py
python -B out/collab/q2-reference-let-v2/reference.py --check
python -B out/collab/q2-reference-let-v2/run_cases.py     # 期望 exit 0（两例 pass）
python -B out/collab/q2-reference-let-v2/tamper.py        # 期望 {tamper['detected']}/{tamper['total']}
```

`results.json` 含完整检查列表、逐例原始/重算矩、统计与后端退出码；`identity.json` 含后端、
数据、冻结文件、输入与 Geant4 数据检查的身份；README 在
`out/collab/q2-reference-let-v2/README.md`。

## 9. 限制与停止声明

- 单平台（Windows）、单线程、冻结两例（10/100 MeV，Si 20 µm，仅电磁 option4）、各 2000 事件。
- 作者自测不是独立复验；交付完成后本目录停止写入，等待主审独立复跑、签收与 Q2-3 判定。
- 若主审要求不同判据/参考/适用域，必须以新的预运行冻结实验处理，不得回改本候选。
"""
    OUTBOX.write_text(text, encoding="utf-8")
    print("wrote", OUTBOX, len(text.encode("utf-8")), "bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
