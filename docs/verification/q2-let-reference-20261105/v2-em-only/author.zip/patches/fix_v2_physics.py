from pathlib import Path

path = Path("out/collab/q2-reference-let-v2/setup_inputs.py")
lines = path.read_text(encoding="utf-8").splitlines()
start = next(i for i, line in enumerate(lines) if 'if freeze.get("physics_em")' in line)
end = next(i for i, line in enumerate(lines) if line.startswith('    return f"""[run]'))
replacement = [
    '    if freeze.get("physics_em"):',
    '        physics_block = "em = " + str(freeze["physics_em"]) + chr(10)',
    "    else:",
    '        physics_block = "reference = " + str(freeze["physics_reference"]) + chr(10)',
]
lines[start:end] = replacement
path.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("fixed physics block", start, end)
