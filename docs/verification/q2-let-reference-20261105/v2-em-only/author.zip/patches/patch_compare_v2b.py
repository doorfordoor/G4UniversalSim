from pathlib import Path

path = Path("out/collab/q2-reference-let-v2/compare.py")
text = path.read_text(encoding="utf-8")

anchor = '''    ok &= check(checks, "ID-GEANT4-DATA-CHECK", geant4.get("data_check_exit") == 0,
                f"exit={geant4.get('data_check_exit')} sha={geant4.get('data_check_sha256')}")
    return bool(ok)
'''
assert text.count(anchor) == 1
extra = '''    freeze_info = identity.get("freeze", {})
    freeze_path = ROOT / freeze_info.get("path", "")
    ok &= check(checks, "ID-FREEZE-SHA",
                freeze_path.is_file() and sha256(freeze_path) == freeze_info.get("sha256"),
                f"path={freeze_info.get('path')} recorded={freeze_info.get('sha256')}")
    ok &= check(checks, "ID-FREEZE-SCHEMA",
                freeze_info.get("schema") == freeze.get("schema"),
                f"identity={freeze_info.get('schema')} freeze={freeze.get('schema')}")
    inputs = identity.get("inputs", {})
    for name, item in sorted(inputs.items()):
        input_path = ROOT / item.get("path", "")
        ok &= check(checks, f"ID-INPUT-SHA-{name.upper().replace('.', '-').replace('_', '-')}",
                    input_path.is_file() and sha256(input_path) == item.get("sha256"),
                    f"path={item.get('path')}")
    return bool(ok)
'''
text = text.replace(anchor, extra)

anchor2 = '''    ok &= check(checks, "EVID-BACKEND-EXIT", case["run"].get("exit_code") == 0,
                f"backend_exit={case['run'].get('exit_code')}")
'''
assert text.count(anchor2) == 1
extra2 = anchor2 + '''    ini = Path(case["run"]["main_ini"]["path"])
    ok &= check(checks, "EVID-MAIN-INI-SHA",
                ini.is_file() and sha256(ini) == case["run"]["main_ini"].get("sha256"),
                f"path={case['run']['main_ini'].get('path')}")
    ok &= check(checks, "EVID-PHYSICS-BLOCK-EM-ONLY",
                "em = " in ini.read_text(encoding="utf-8")
                and "reference = " not in ini.read_text(encoding="utf-8").replace("physics_reference", ""),
                f"main_ini={case['run']['main_ini'].get('path')}")
'''
text = text.replace(anchor2, extra2)

path.write_text(text, encoding="utf-8")
print("additional freeze/input/physics identity checks added")
