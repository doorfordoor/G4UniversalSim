from pathlib import Path

path = Path("out/collab/q2-reference-let-v2/compare.py")
text = path.read_text(encoding="utf-8")

anchor = '    hits = output / "hits_t0.csv"\n    ok &= check(checks, "EVID-NO-HITS-FOR-LET", not hits.exists(), str(hits))\n'
assert text.count(anchor) == 1
extra = anchor + '''    ok &= check(checks, "EVID-BACKEND-EXIT", case["run"].get("exit_code") == 0,
                f"backend_exit={case['run'].get('exit_code')}")
    ok &= check(checks, "EVID-PHYSICS-EM",
                summary.get("physics_em") == "G4EmStandardPhysics_option4",
                f"physics_em={summary.get('physics_em')}")
    ok &= check(checks, "EVID-PHYSICS-REFERENCE-EMPTY",
                (summary.get("physics_reference") or "").strip() == "",
                f"physics_reference={summary.get('physics_reference')!r}")
'''
text = text.replace(anchor, extra)

old_conclusion = '''            passed = all((checks_a, checks_b, checks_c, checks_d))
            conclusion = {
                "status": "pass" if passed else "fail",'''
new_conclusion = '''            primary_ok = bool(checks_a)
            auxiliary_ok = bool(checks_b and checks_c)
            passed = all((checks_a, checks_b, checks_c, checks_d))
            conclusion = {
                "status": "pass" if passed else "fail",
                "primary_let_t_status": "pass" if primary_ok else "fail",
                "auxiliary_let_d_relation_status": "pass" if auxiliary_ok else "fail",
                "primary_criterion": "REF-LET-T-ABS (0.015*reference + 3*sigma)",
                "auxiliary_criteria": ["REF-LET-D-GE-T", "REF-LET-D-REL (<=0.05)"],'''
assert text.count(old_conclusion) == 1
text = text.replace(old_conclusion, new_conclusion)

old_z = '''                "let_d_minus_t_significance_independent_z": (
                    difference / math.hypot(sigma, sigma_d) if math.hypot(sigma, sigma_d) else None
                ),
'''
new_z = '''                "let_d_minus_t_uncertainty_note": (
                    "no z test: the two ratios are correlated and the full covariance is not "
                    "available; the independent-sigma z is not a decision criterion"
                ),
'''
assert text.count(old_z) == 1
text = text.replace(old_z, new_z)

old_schema = '"schema": "g4usim_q2_ref_let_evaluation_v1",'
new_schema = '"schema": "g4usim_q2_ref_let_evaluation_v2",'
assert text.count(old_schema) == 1
text = text.replace(old_schema, new_schema)

old_out = '''        "failed_ids": failed,
        "cases": cases_out,'''
new_out = '''        "failed_ids": failed,
        "backend_exit_codes": {
            case_id: item["run"].get("exit_code") for case_id, item in results.get("cases", {}).items()
        },
        "comparison_exit_is_not_backend_exit": True,
        "cases": cases_out,'''
assert text.count(old_out) == 1
text = text.replace(old_out, new_out)

path.write_text(text, encoding="utf-8")
print("compare.py patched for v2")
