# Q2-3 REF-LET-01-EM：仅电磁 LET 受限对照（v2 作者交付）

2026-11-05。本目录是 `REF-LET-01-EM` 的完整交付，不是对 v1 的改写或重贴标签：

- v1（`out/collab/q2-reference-let-v1/`，冻结文件 `…freeze-v1.json`，FTFP_BERT_EMZ）观测到
  100 MeV `REF-LET-D-REL` 失败（`(LET_d−LET_t)/LET_t = 0.2106 > 0.05`），该失败按原样保留，
  不得改写为通过；独立复验见 `docs/collab/reviews/20261105-q2-let-reference-review-v1.md`。
- v2 是运行前另行冻结的**新前瞻实验**（`…freeze-v2.json`，schema `q2_reference_let_freeze_v2`），
  回到参考提案原定的**仅电磁 option4** 适用域；几何、源、cut、后端、PSTAR 表、参考算法与全部
  数值判据（含 5%）不变，只把种子在运行前固定为 `20261211`/`20261212`。

## 1. 身份与输入

| 项 | 值 |
| --- | --- |
| 冻结文件 | `docs/collab/decisions/20261105-q2-let-reference-freeze-v2.json`，sha256 `4a5ddbe1067589d8437fe604db79f47c68c61e30f9c69d7c86b9d8104166bf5b` |
| 冻结 schema / case | `q2_reference_let_freeze_v2` / `REF-LET-01-EM` |
| 冻结后端 | `out/collab/q2-backend-864bc036/G4UniversalSim.exe`，sha256 `f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f` |
| 后端 build / source fingerprint | `864bc036d6d7752475e52db4efd2b950cabfcc3d` / `e7de615d4e342114104f970688a7ea5f9789f7b70240b2562a388a50a45704e7` |
| Geant4 | 11.3.2（`1132`）；`--check-geant4-data` exit 0 |
| 参考数据 | `scenarios/benchmarks/shielding_range/nist/PSTAR_Si.txt`，sha256 `71cfaaf13545201276c24195d96a4fafd2341bf5fbd26ed52133cce0b42f2422` |
| 物理 | `[physics] em = option4`，**不写** `reference`（仅电磁；不得与 FTFP_BERT_EMZ 同时保留） |
| 几何/源 | Si 10×10×0.02 mm；点源 (0,0,−3) mm，方向 (0,0,1)；1 um cut；1 线程；每例 2000 事件 |

实际物理身份由运行产物核对，而不是只看输入：`run_summary.txt` 中
`physics_em = G4EmStandardPhysics_option4`、`physics_reference` 为空；比较器还核对输入文件
sha256、冻结文件 sha256/schema 与主 INI 的 `em`-only 物理块。

## 2. 参考重算（独立于冻结值）

`reference.py` 直接读取 PSTAR 原始字节（先校验 sha256、解析 132 行数值），按冻结方法重算：
E0 的 CSDA 射程 log-log 插值 → 减去 ρt/2 → 反插值得到 E_mid → 在 E_mid 处插值电子阻止本领
× ρ × 0.1 得到 keV/µm。两例与冻结值逐位一致（`mid_delta=0`、`let_delta=0`），结果在
`reference-recompute.json`；`--check` 在偏差时非零退出。

| 能量 (MeV) | E_mid (MeV) | 参考 LET (keV/µm) |
| --- | --- | --- |
| 10 | 9.918640484915057 | 8.10751145090545 |
| 100 | 99.98639444889122 | 1.3599232692852166 |

## 3. 执行

`setup_inputs.py` 生成输入并记录身份；`run_cases.py` 只执行已生成输入，逐例记录后端真实
`exit_code`、完成事件数、耗时、日志/摘要/metadata/宏/主 INI 的路径与 sha256；`compare.py`
在**后端完成事实之后**才做参考比较。

- 两例后端均 `exit=0`、`completed_events=2000`（约 1.4 s / 1.1 s）。
- 比较器共 **116 项检查，0 项失败**：身份 `ID-*` 12 项、运行证据 `EVID-*` 64 项（每例 32）、
  矩复算 `MOM-*` 8 项（每例 4）、统计 `STAT-*` 24 项（每例 12）、参考 `REF-*` 8 项（每例 4）。
- **比较驱动的退出码与后端退出码分开记录**：比较失败时驱动可以 exit 1，但那表示比较失败，
  不是后端崩溃；本次两例后端 exit 均为 0，比较驱动 exit 0。`results.json` 同时保存
  `evaluation.backend_exit_codes` 与 `comparison_exit_is_not_backend_exit=true`。

## 4. 结果

### 4.1 主判据：LET_t 对照 PSTAR 参考

`REF-LET-T-ABS`：`|LET_t − LET_ref| ≤ 0.015 × LET_ref + 3σ`。

| 能量 | LET_t (keV/µm) | 绝对差 | 允许值 | 相对差 | 结论 |
| --- | --- | --- | --- | --- | --- |
| 10 MeV | 8.10111615849 | −0.0063953 | 0.1221291 | −7.888e-4 | **pass** |
| 100 MeV | 1.36016812632 | +0.0002449 | 0.0204086 | +1.8005e-4 | **pass** |

### 4.2 辅助判据：LET_d 与 LET_t 的关系

`REF-LET-D-GE-T`（在印刷精度内非负）与 `REF-LET-D-REL`（相对差 ≤ 0.05）。

| 能量 | LET_d (keV/µm) | LET_d−LET_t | 相对差 | 结论 |
| --- | --- | --- | --- | --- |
| 10 MeV | 8.10123277098 | +1.1661e-4 | 1.43946e-5 | **pass** |
| 100 MeV | 1.36016814997 | +2.3650e-8 | 1.73876e-8 | **pass** |

两个比值的 δ 方法误差都由公开矩独立重算（`STAT-*` 与 `MOM-*` 检查）：

| 能量 | σ(LET_t) | σ(LET_d) | rel_error(LET_t) | rel_error(LET_d) |
| --- | --- | --- | --- | --- |
| 10 MeV | 1.7213e-4 | 1.7284e-4 | 2.1248e-5 | 2.1336e-5 |
| 100 MeV | 3.2643e-6 | 3.2670e-6 | 2.3999e-6 | 2.4019e-6 |

**整体：两例全部原判据通过。** 该结论只在仅电磁 option4 的受限适用域内成立。

## 5. 解释边界（必须与结果一起阅读）

1. **v1 失败保留**：v1 的 FTFP_BERT_EMZ 结果仍是失败（`REF-LET-D-REL 0.2106`），v2 不覆盖、
   不重分类、不作为 v1 的“通过复跑”。
2. **v2 只适用于仅电磁**：不能据此给强子混合谱的 `LET_d` 背书；完整强子病例的 `LET_d`
   适用范围限制继续保留。
3. **不能用无协方差的独立 z 宣布差值通过**：LET_d/LET_t 两个估计量相关，本次未提供完整
   协方差；本交付不用独立 σ 的 z 值做判据，也不声称“差值显著为零”。但 5% 辅助判据本身
   是冻结规则，v2 两个点估计均远低于 5%，因此按冻结规则通过。
4. **次级尾部原因仍未被证实**：v1 的“少数高 LET 步骤/次级主导”解释只是待检验假设；
   v2 的通过与该假设相容，但不构成证明（EM-only 下按构造几乎无强子次级）。
5. 未新增 scorer 字段、未做初级粒子过滤、未改 cut/N/种子/参考/容差、未调参；比较器是
   独立实现而不是调用产品内部结论。

## 6. 负例（只改拷贝，原件与冻结文件不动）

`tamper.py` 对 v2 交付构造 3 个有限反例，全部检出（3/3）：

| 反例 | 变异 | 预期检出 | 结果 |
| --- | --- | --- | --- |
| `REF-NUMERIC-SHIFT` | 冻结参考的拷贝中 10 MeV LET +6% | `REF-LET-T-ABS` | 检出，exit 1 |
| `REF-SOURCE-MAPPING` | 结果拷贝把 10 MeV 病例映射到 100 MeV 参考 | `REF-LET-T-ABS` | 检出，exit 1 |
| `REF-DATA-SHA` | PSTAR 拷贝改一位电子阻止本领 | `data_sha256` 不匹配 | 检出，exit 1 |

反例文件在 `tampered/`，可整体删除后重跑。

## 7. 复现

```bash
python -B out/collab/q2-reference-let-v2/setup_inputs.py
python -B out/collab/q2-reference-let-v2/reference.py --check
python -B out/collab/q2-reference-let-v2/run_cases.py     # 期望 exit 0（两例 pass）
python -B out/collab/q2-reference-let-v2/tamper.py        # 期望 3/3 检出
```

`results.json` 保存完整检查列表、逐例原始/重算矩与统计、身份与后端退出码；`identity.json`
保存后端、数据、冻结文件、输入文件与 Geant4 数据检查的身份。回执在
`docs/collab/outbox/20261105-q2-reference-let-v2.md`。

## 8. 限制与停止声明

- 单平台（Windows）、单线程、冻结两例（10/100 MeV，Si 20 µm，仅电磁 option4）、各 2000
  事件；其它能量/材料、MT、GUI、强子混合谱 `LET_d` 均不在本任务范围。
- 作者自测不是独立复验；本目录在交付后停止写入，等待主审独立复跑与签收。
- 若后续独立复验或主审给出不同判据/参考，必须以新的预注册实验处理，不能回改本目录。
