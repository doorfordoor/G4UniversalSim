"""Run the two frozen REF-LET-01 cases with the frozen backend.

This script only executes the frozen inputs created by setup_inputs.py.  It does
not touch the reference values or tolerances; those are applied by compare.py.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

import compare

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-let-v1"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-let-reference-freeze-v1.json"
BACKEND = ROOT / "out" / "collab" / "q2-backend-864bc036" / "G4UniversalSim.exe"
GEANT4_BIN = Path("D:/ProgramFiles/Geant4/bin")
GEANT4_DATA = Path("D:/ProgramFiles/Geant4/share/Geant4/data")


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def env() -> dict:
    merged = os.environ.copy()
    merged["PATH"] = str(GEANT4_BIN) + os.pathsep + merged.get("PATH", "")
    merged["GEANT4_DATA_DIR"] = str(GEANT4_DATA)
    merged.pop("QT_QPA_PLATFORM", None)
    return merged


def sha256(path: Path) -> str:
    return compare.sha256(path)


def clean_output(output: Path) -> None:
    if not output.exists():
        output.mkdir(parents=True)
        return
    for child in sorted(output.rglob("*"), reverse=True):
        if child.is_file():
            child.unlink()
        elif child.is_dir():
            child.rmdir()


def main() -> int:
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    identity = json.loads((BASE / "identity.json").read_text(encoding="utf-8"))
    cases: dict[str, dict] = {}
    for name, case in identity["cases"].items():
        energy = float(case["energy_MeV"])
        output = Path(case["output_dir"])
        clean_output(output)
        run_dir = Path(case["run_dir"])
        macro = run_dir / "run.mac"
        macro.write_text(
            f"# {freeze['case']} {energy:g} MeV: frozen batch wrapper\n"
            "/run/initialize\n"
            f"/run/beamOn {int(freeze['events_per_case'])}\n",
            encoding="utf-8",
        )
        command = [
            str(BACKEND),
            "--config", str(Path(case["main_ini"])),
            "--macro", str(macro),
            "--output", str(output),
            "--threads", str(int(case["threads"])),
            "--seed", str(int(case["seed"])),
        ]
        log_path = run_dir / "backend.log"
        started = time.time()
        with log_path.open("wb") as log:
            completed = subprocess.run(
                command, cwd=str(ROOT), env=env(),
                stdout=log, stderr=subprocess.STDOUT, timeout=3600,
            )
        duration = time.time() - started
        summary_path = output / "run_summary.txt"
        summary = compare.parse_run_summary(summary_path) if summary_path.is_file() else {}
        metadata_path = output / "run_metadata.json"
        record = {
            "case_id": name,
            "energy_MeV": energy,
            "seed": int(case["seed"]),
            "threads": int(case["threads"]),
            "planned_events": int(freeze["events_per_case"]),
            "completed_events": int(summary.get("actual_completed_event_count", -1)),
            "exit_code": completed.returncode,
            "duration_s": round(duration, 3),
            "output_dir": str(output),
            "run_summary_path": str(summary_path),
            "run_summary_sha256": sha256(summary_path) if summary_path.is_file() else None,
            "run_metadata_path": str(metadata_path),
            "run_metadata_sha256": sha256(metadata_path) if metadata_path.is_file() else None,
            "macro": {"path": str(macro), "sha256": sha256(macro)},
            "main_ini": {"path": str(Path(case["main_ini"])), "sha256": sha256(Path(case["main_ini"]))},
            "command": command,
            "backend_log": str(log_path),
            "started_at": now(),
        }
        (run_dir / "record.json").write_text(
            json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        cases[name] = {"run": record}
        print(f"{name}: exit={completed.returncode} {duration:.2f}s completed={record['completed_events']}")

    results = {
        "schema": "g4usim_q2_ref_let_run_results_v1",
        "case": freeze["case"],
        "freeze_sha256": sha256(FREEZE),
        "identity": identity,
        "cases": cases,
        "generated_at": now(),
    }
    evaluation = compare.evaluate(results, freeze, identity)
    results["evaluation"] = evaluation
    (BASE / "results.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    failed = [cid for cid, item in cases.items() if item["run"]["exit_code"] != 0]
    print("backend_failed:", failed)
    print("evaluation:", evaluation["status"], "checks", evaluation["checks_total"],
          "failed", evaluation["checks_failed"])
    return 0 if (not failed and evaluation["status"] == "pass") else 1


if __name__ == "__main__":
    raise SystemExit(main())
