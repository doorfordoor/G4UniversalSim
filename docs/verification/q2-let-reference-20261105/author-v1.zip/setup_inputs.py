"""Generate the frozen REF-LET-01 inputs and record the product/data identity.

Everything here is derived from `docs/collab/decisions/20261105-q2-let-reference-freeze-v1.json`
and `out/collab/q2-backend-864bc036/`.  The script refuses to continue when:
  * the frozen backend SHA-256 / build commit / source fingerprint disagrees;
  * the PSTAR Si data file no longer matches the frozen SHA-256;
  * Geant4 data reported by the backend is incomplete.
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-let-v1"
INPUTS = BASE / "inputs"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-let-reference-freeze-v1.json"
BACKEND = ROOT / "out" / "collab" / "q2-backend-864bc036" / "G4UniversalSim.exe"
BACKEND_ID = ROOT / "out" / "collab" / "q2-backend-864bc036" / "identity.json"
DATA = ROOT / "scenarios" / "benchmarks" / "shielding_range" / "nist" / "PSTAR_Si.txt"
GEANT4_PREFIX = Path("D:/ProgramFiles/Geant4")
GEANT4_DATA = GEANT4_PREFIX / "share" / "Geant4" / "data"
GEANT4_BIN = GEANT4_PREFIX / "bin"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def environment() -> dict:
    return {
        "GEANT4_DATA_DIR": str(GEANT4_DATA),
        "LD_LIBRARY_PATH": "",
        "PATH_prefix": str(GEANT4_BIN),
        "platform": "Windows",
        "cwd": str(ROOT),
    }


def env() -> dict:
    merged = os.environ.copy()
    merged["PATH"] = str(GEANT4_BIN) + os.pathsep + merged.get("PATH", "")
    merged["GEANT4_DATA_DIR"] = str(GEANT4_DATA)
    merged.pop("QT_QPA_PLATFORM", None)
    return merged


def run(command: list[str], timeout: int = 300) -> subprocess.CompletedProcess:
    return subprocess.run(
        command,
        cwd=str(ROOT),
        env=env(),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )


def render_materials() -> str:
    return """[galactic]
material = G4_Galactic

[silicon]
material = G4_Si
"""


def render_geometry(freeze: dict) -> str:
    dx, dy, dz = freeze["dimensions_mm"]
    return f"""[world]
shape = box
size = 20 mm, 20 mm, 20 mm
material = G4_Galactic

[volume.LetTarget]
parent = world
shape = box
size = {dx} mm, {dy} mm, {dz} mm
material = {freeze['material']}
position = 0 mm, 0 mm, 0 mm
sensitive = true
"""


def render_main(freeze: dict, energy: float, seed: int, output_dir: str) -> str:
    px, py, pz = freeze["source_position_mm"]
    dx, dy, dz = freeze["direction"]
    return f"""[run]
name = ref_let_{energy:g}
threads = {freeze['threads']}
seed = {seed}
interactive = false
verbose = 0
check_overlaps = false
dry_run = false

[output]
dir = {output_dir}
format = csv

[materials]
file = {INPUTS / 'materials.ini'}

[geometry]
template = hierarchical
config = {INPUTS / 'geometry_let.ini'}
default_world_material = G4_Galactic

[physics]
reference = {freeze['physics_reference']}
default_cut = {freeze['default_cut']}

[scoring]
enabled = true
hits = false
event_edep = false
edep = false
auto_create_default_scorers = true
let = true
[scoring.let]
particles = {freeze['particle']}

[source]
particle = {freeze['particle']}
energy = {energy:g} MeV
position_type = point
position = {px}, {py}, {pz} mm
direction = {dx}, {dy}, {dz}
"""


def main() -> int:
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    if freeze.get("schema") != "q2_reference_let_freeze_v1":
        raise SystemExit("unexpected freeze schema")
    if not BACKEND.is_file():
        raise SystemExit(f"frozen backend missing: {BACKEND}")
    if sha256(BACKEND) != "f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f":
        raise SystemExit("frozen backend sha256 mismatch")
    backend_identity = json.loads(BACKEND_ID.read_text(encoding="utf-8"))
    capabilities = json.loads(Path(backend_identity["capabilities_file"]).read_text(encoding="utf-8")) if "capabilities_file" in backend_identity else None
    if capabilities is None:
        capabilities = json.loads(run([str(BACKEND), "--capabilities"]).stdout.decode("utf-8"))
    if capabilities["build_git_commit"] != freeze["backend_build"]:
        raise SystemExit("backend build does not match the freeze")
    if sha256(DATA) != freeze["data_sha256"]:
        raise SystemExit("PSTAR_Si.txt sha256 does not match the freeze")
    check = run([str(BACKEND), "--check-geant4-data"])
    check_text = check.stdout.decode("utf-8", errors="replace")
    (BASE / "backend-data-check.txt").write_text(check_text, encoding="utf-8")
    if check.returncode != 0 or '"required_complete": true' not in check_text:
        raise SystemExit(f"--check-geant4-data not complete: exit={check.returncode}\n{check_text}")

    INPUTS.mkdir(parents=True, exist_ok=True)
    outputs = {}
    files = {
        "materials.ini": render_materials(),
        "geometry_let.ini": render_geometry(freeze),
    }
    for item in freeze["references"]:
        energy = float(item["energy"])
        seed = int(freeze["seeds"][freeze["references"].index(item)])
        run_dir = BASE / "runs" / f"ref_let_{energy:g}"
        output_dir = run_dir / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        name = f"main_ref_let_{energy:g}.ini"
        files[name] = render_main(freeze, energy, seed, output_dir.as_posix())
        outputs[f"ref_let_{energy:g}"] = {
            "energy_MeV": energy,
            "seed": seed,
            "threads": freeze["threads"],
            "events": freeze["events_per_case"],
            "main_ini": str((INPUTS / name).relative_to(ROOT)).replace("\\", "/"),
            "output_dir": str(output_dir.relative_to(ROOT)).replace("\\", "/"),
            "run_dir": str(run_dir.relative_to(ROOT)).replace("\\", "/"),
        }
    for name, content in files.items():
        (INPUTS / name).write_text(content, encoding="utf-8")

    identity = {
        "schema": "g4usim_q2_ref_let_identity_v1",
        "generated_at": now(),
        "case": freeze["case"],
        "workspace": str(ROOT).replace("\\", "/"),
        "freeze": {
            "path": str(FREEZE.relative_to(ROOT)).replace("\\", "/"),
            "sha256": sha256(FREEZE),
            "schema": freeze["schema"],
        },
        "backend": {
            "path": str(BACKEND.relative_to(ROOT)).replace("\\", "/"),
            "sha256": sha256(BACKEND),
            "bytes": BACKEND.stat().st_size,
            "build_git_commit": capabilities["build_git_commit"],
            "source_fingerprint": capabilities["source_fingerprint"],
            "geant4_version_number": capabilities["geant4_version_number"],
            "compiler_id": capabilities["compiler_id"],
        },
        "geant4": {
            "prefix": str(GEANT4_PREFIX),
            "data": str(GEANT4_DATA),
            "data_check_exit": check.returncode,
            "data_check_sha256": sha256(BASE / "backend-data-check.txt"),
        },
        "data_file": {
            "path": str(DATA.relative_to(ROOT)).replace("\\", "/"),
            "sha256": sha256(DATA),
            "bytes": DATA.stat().st_size,
            "matches_freeze": True,
        },
        "inputs": {
            name: {"path": str((INPUTS / name).relative_to(ROOT)).replace("\\", "/"), "sha256": sha256(INPUTS / name)}
            for name in files
        },
        "cases": outputs,
        "environment": environment(),
    }
    (BASE / "identity.json").write_text(json.dumps(identity, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(identity, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
