"""Negative controls for REF-LET-01.

Every mutation is applied to a *copy*; the frozen case directory, the frozen
reference file and the frozen table stay byte-identical.  Each case must be
detected with the expected check id (or, for the table copy, the frozen-data
SHA gate of reference.py).
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-let-v1"
TAMPERED = BASE / "tampered"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-let-reference-freeze-v1.json"
DATA = ROOT / "scenarios" / "benchmarks" / "shielding_range" / "nist" / "PSTAR_Si.txt"
PY = sys.executable


def run(command: list[str]) -> tuple[int, str]:
    completed = subprocess.run(command, cwd=str(ROOT), capture_output=True, text=True, timeout=600)
    return completed.returncode, (completed.stdout or "") + (completed.stderr or "")


def main() -> int:
    if TAMPERED.exists():
        shutil.rmtree(TAMPERED)
    TAMPERED.mkdir(parents=True)
    results = BASE / "results.json"
    identity = BASE / "identity.json"
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    tampers: list[dict] = []

    # 1) frozen reference value shifted by +6% -> absolute-error criterion must fail.
    shifted = json.loads(FREEZE.read_text(encoding="utf-8"))
    for item in shifted["references"]:
        if float(item["energy"]) == 10.0:
            item["let"] = float(item["let"]) * 1.06
    shifted_path = TAMPERED / "freeze-let-shifted.json"
    shifted_path.write_text(json.dumps(shifted, indent=2) + "\n", encoding="utf-8")
    code, text = run([PY, str(BASE / "compare.py"), "--results", str(results),
                      "--freeze", str(shifted_path), "--identity", str(identity)])
    tampers.append({
        "id": "REF-NUMERIC-SHIFT",
        "mutation": "copy of the frozen reference with 10 MeV LET +6%",
        "expected_check": "REF-LET-T-ABS",
        "exit_code": code,
        "detected": code != 0 and "REF-LET-T-ABS" in text,
        "evidence": str(shifted_path.relative_to(ROOT)).replace("\\", "/"),
    })

    # 2) wrong source-energy mapping: 10 MeV run compared against the 100 MeV reference.
    results_doc = json.loads(results.read_text(encoding="utf-8"))
    results_doc["cases"]["ref_let_10"]["run"]["energy_MeV"] = 100.0
    swapped_path = TAMPERED / "results-energy-swapped.json"
    swapped_path.write_text(json.dumps(results_doc, indent=2) + "\n", encoding="utf-8")
    code, text = run([PY, str(BASE / "compare.py"), "--results", str(swapped_path),
                      "--freeze", str(FREEZE), "--identity", str(identity)])
    tampers.append({
        "id": "REF-SOURCE-MAPPING",
        "mutation": "copy of results where the 10 MeV case claims the 100 MeV energy",
        "expected_check": "REF-LET-T-ABS",
        "exit_code": code,
        "detected": code != 0 and "REF-LET-T-ABS" in text,
        "evidence": str(swapped_path.relative_to(ROOT)).replace("\\", "/"),
    })

    # 3) frozen table byte changed -> reference.py must refuse via the frozen SHA.
    data_text = DATA.read_text(encoding="utf-8").splitlines()
    for index, line in enumerate(data_text):
        if line.strip().startswith("1.000E-03"):
            fields = line.split()
            fields[1] = "1.051E+02"
            data_text[index] = "  " + "  ".join(fields)
            break
    else:
        raise SystemExit("could not find the table row to mutate")
    modified_table = TAMPERED / "PSTAR_Si_modified.txt"
    modified_table.write_text("\n".join(data_text) + "\n", encoding="utf-8")
    code, text = run([PY, str(BASE / "reference.py"), "--check",
                      "--data", str(modified_table), "--freeze", str(FREEZE),
                      "--out", str(TAMPERED / "reference-recompute-modified.json")])
    tampers.append({
        "id": "REF-DATA-SHA",
        "mutation": "copy of PSTAR_Si.txt with one stopping-power digit changed",
        "expected_check": "data_sha256 mismatch",
        "exit_code": code,
        "detected": code != 0 and "sha256 mismatch" in text,
        "evidence": str(modified_table.relative_to(ROOT)).replace("\\", "/"),
    })

    payload = {
        "schema": "g4usim_q2_ref_let_tamper_v1",
        "case": freeze["case"],
        "total": len(tampers),
        "detected": sum(1 for item in tampers if item["detected"]),
        "tampers": tampers,
    }
    out = BASE / "tamper-results.json"
    out.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))
    return 0 if payload["detected"] == payload["total"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
