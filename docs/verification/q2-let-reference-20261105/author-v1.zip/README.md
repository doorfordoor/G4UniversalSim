# REF-LET-01 外部参考病例交付（Q2-3 首个冻结病例）

状态：**作者交付，待独立复验**。本交付只覆盖 `docs/collab/decisions/20261105-q2-let-reference-freeze-v1.json`
冻结的两个单能质子/20 µm 硅薄层病例；不扩展到重离子、厚靶、Dose/DDD 或统计覆盖率。

冻结身份（不重新定义）：

- 冻结后端 `out/collab/q2-backend-864bc036/G4UniversalSim.exe`
  sha256 `f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f`，
  build `864bc036d6d7752475e52db4efd2b950cabfcc3d`，source fingerprint `e7de615d…`，Geant4 11.3.2。
- 参考数据 `scenarios/benchmarks/shielding_range/nist/PSTAR_Si.txt`
  sha256 `71cfaaf13545201276c24195d96a4fafd2341bf5fbd26ed52133cce0b42f2422`。
- 参考数值来自冻结文件，不由本交付重新定义；本交付用独立 `reference.py` 从原始表字节重算并与冻结值核对。

## 1. 输入与运行

`setup_inputs.py` 从冻结文件生成：

| 病例 | 能量 | 事件 | 线程 | seed | 源 | 几何/材料 | 物理/cut |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ref_let_10 | 10 MeV 质子 | 2000 | 1 | 20261111 | 点源 (0,0,-3) mm → (0,0,1) | Si 10×10×0.02 mm，G4_Si（2.33 g/cm³），世界 20 mm G4_Galactic | FTFP_BERT_EMZ，1 um |
| ref_let_100 | 100 MeV 质子 | 2000 | 1 | 20261112 | 同上 | 同上 | 同上 |

运行命令（两例同一形式，参数取自冻结）：

```
G4UniversalSim.exe --config inputs/main_ref_let_<E>.ini \
  --macro runs/ref_let_<E>/run.mac --output runs/ref_let_<E>/output \
  --threads 1 --seed <frozen>
```

`run.mac` 只有 `/run/initialize` 与 `/run/beamOn 2000`，没有其它命令。输入文件、宏、摘要与
metadata 的 sha256 分别记录在 `identity.json`、`results.json` 与每例 `runs/*/record.json`。

实际执行（HEAD 与工作区见 §6）：两例均 `exit=0`、`completed_events=2000`、1 线程，
耗时约 1.9 s 与 1.4 s。

## 2. 先门禁、后参考比较

`compare.py` 的执行顺序固定，任何前序失败都不会产生物理结论：

1. **身份门禁**（`ID-*`）：冻结后端 sha256、build commit、source fingerprint 格式、
   Geant4 版本 1132、数据文件 sha256、`--check-geant4-data` 退出码 0。
2. **运行证据门禁**（`EVID-*`）：`run_summary.txt` 可解析且
   `status=completed`、`summary_write_status=completed`、`output_failure_status=none`、
   `macro_execution_status=completed`、`simulation_executed=true`、`program_exit_code=0`；
   `run_count=1`；planned/completed/actual 均为 2000；`run_metadata.json` 恰一条 run；
   `let_volume_summary_t0.csv` 与 `scorer_statistics.csv` 在 `generated_files` 声明、
   `integrity_status=hashed` 且磁盘 sha256/size 一致；scorer_statistics 每行 `n_events=2000`；
   `hits=false` 时不得出现 hits 文件。
3. **矩复算**（`MOM-*`）：由 `let_volume_summary_t0.csv` 的求和列独立重算
   `let_t=ΣwSl/Σwl`、`let_d=ΣwS²l/ΣwSl`，按 12 位有效数字打印精度与传播界比较。
4. **统计估计**（`STAT-*`）：`scorer_statistics.csv` 的 `let_t`/`let_d` 必须为
   `estimator=ratio` + `uncertainty_estimator=uncorrected_delta_ratio_v1`、有限且近似状态，
   `sigma = rel_error × |value|`。
5. **参考比较**（`REF-*`）：见 §3。

## 3. 参考重算与冻结值

`reference.py` 从 PSTAR_Si.txt 原始字节实现冻结方法：log-log 插值 CSDA 射程 → 扣 `ρt/2`
（`ρ=2.33 g/cm³`、`t=0.02 mm`）→ 反 log-log 插值得到 E_mid → 插值电子阻止本领
→ `×ρ×0.1` 得 keV/µm。结果与冻结值逐位一致（相对差 0.0），写入 `reference-recompute.json`；
同时校验数据 sha256 等于冻结值。

## 4. 结果（真实输出，未重跑或调参）

| 能量 | E_mid (MeV) | 参考 LET (keV/µm) | let_t (keV/µm) | 相对误差 | 允许误差 | let_d (keV/µm) | let_d−let_t | 相对 | 结论 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10 MeV | 9.918640484915057 | 8.10751145090545 | 8.1006542922 | −0.085 % | 0.1221 | 8.10076799456 | +1.137e-4 | 1.40e-5 | **pass** |
| 100 MeV | 99.98639444889122 | 1.3599232692852166 | 1.37634949516 | +1.21 % | 0.06889 | 1.66627194324 | +0.289922 | 0.2106 | **fail** |

- 两例 `let_t` 均满足 `|let_t − ref| ≤ 0.015·ref + 3σ`（10 MeV 用掉 5.6% 预算，100 MeV 用掉 23.8%）。
- `let_d ≥ let_t`（打印精度内）两例均成立。
- `relative(let_d−let_t) ≤ 0.05`：10 MeV 成立（1.4e-5），**100 MeV 不成立（0.2106）**。
  因此 REF-LET-01 冻结判据的总体结论为 **fail**，但失败项仅是这一个辅助判据；`let_t` 的物理对照通过。

## 5. 失败项分析与最小诊断提案（不改判据）

100 MeV 的 `let_d` 相对误差本身是 18.13 %（σ_d=0.3022 keV/µm），而 `let_t` 的相对误差只有
1.17 %（σ_t=0.01616）。差值 0.2899 与 σ_d 同量级：按两个估计量独立（未记录交叉矩）的保守上界，
`z = 0.2899 / sqrt(σ_t² + σ_d²) = 0.958`，即差异不足约 1σ_d。也就是说：

1. 该失败是“**点估计 + 5 % 固定阈**”与“`let_d` 在 2000 事件下的大统计不确定度”共同造成的
   判据不匹配；不能据此断言实现错误，也不能据此宣布物理通过。
2. `let_d` 的大误差说明少量高 LET 步骤/次级贡献主导了剂量平均 LET（10 MeV 的同几何病例
   在相同 2000 事件下 `let_d−let_t` 仅 1.4e-5，`sigma` 小两个量级，与此一致）。
3. 最小诊断提案（**需新的预注册冻结，不在本轮执行**）：
   - 增加 `let_d` 与 `let_t` 的交叉矩或逐事件矩输出，以便计算 `let_d−let_t` 自身的 delta 方法误差；
   - 或按 Q2-4 先预注册“`let_d` 方差与所需 N”，再用独立批次判定；
   - 或先冻结“仅初级质子/排除核反应次级”的 LET 口径，区分“实现错误”与“物理次级贡献”。
   上述任一方向都需要主审决定，**本轮不调 cut、不加事件、不改 5 % 判据**。

## 6. 负例（只作用于拷贝）

`tamper.py` 的三类反例全部被检出（`tamper-results.json`）：

| 反例 | 篡改 | 期望检出 | 结果 |
| --- | --- | --- | --- |
| REF-NUMERIC-SHIFT | 冻结参考拷贝中 10 MeV LET +6 % | `REF-LET-T-ABS` | 检出（exit 1） |
| REF-SOURCE-MAPPING | 结果拷贝把 10 MeV 病例映射到 100 MeV 参考 | `REF-LET-T-ABS` | 检出（exit 1） |
| REF-DATA-SHA | PSTAR 表拷贝改一位数值 | `data_sha256 mismatch` | 检出（exit 1） |

原件、冻结文件与参考表均未被修改；`tampered/` 可整体删除后重跑 `tamper.py` 重建。

## 7. 校验与复现

- `python -B setup_inputs.py` → `identity.json`（含输入/后端/数据 sha256）。
- `python -B reference.py --check` → 参考重算与冻结值一致。
- `python -B run_cases.py` → 两例真实运行 + `results.json`（含 101 项检查；1 项 fail 见 §4）。
- `python -B tamper.py` → 3/3 负例检出。
- `python -B compare.py` → 独立读取 `results.json` 重新评估（exit 1 = 判据未全过，非工具错误）。

## 8. 身份与限制

- 仓库 branch `roadmap/Q2-scientific-baselines`；病例运行与起草时 HEAD `9ed087f2`，生成回执时 HEAD 已由主审并行 docs 提交推进到 `c9c76e3b`（未修改工作区文件）；本次只新增
  `out/collab/q2-reference-let-v1/**` 与回执，未改产品源码/正式测试/正式基准/CI，未提交 Git。
- 仅 Windows、单线程、2000 事件、冻结两例；统计覆盖率、其它能量/材料、MT、GUI 入口均不在范围内。
- 参考表、冻结文件与后端均只读复用；冻结值未重新定义，失败未通过调参消除。
- 作者自测不是独立实窗/独立复验；等待主审独立复跑与签收。
