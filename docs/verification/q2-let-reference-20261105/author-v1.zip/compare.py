"""Evaluate REF-LET-01: run/product identity gate, then the frozen reference test.

The order matters.  The frozen case can only carry a physics conclusion when the
product really is the frozen backend, the run really completed at the frozen
sample size, and every compared number really comes from that run.  Only after
those gates pass does this module look at the reference comparison.

Checks emitted here are also reused by tamper.py: every tampered copy must make
at least one of them fail, with the expected id.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-let-v1"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-let-reference-freeze-v1.json"
FROZEN_BACKEND_SHA = "f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f"
FROZEN_GEANT4_VERSION = 1132
SIG_DIGITS = 12


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def half_width(value: float) -> float:
    """Half width of a decimal printed with 12 significant digits."""
    if value == 0.0 or not math.isfinite(value):
        return 0.0
    return 0.5 * 10.0 ** (math.floor(math.log10(abs(value))) - (SIG_DIGITS - 1))


def parse_run_summary(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        text = line.strip()
        if not text or text.startswith("[") or text.startswith("#"):
            continue
        if "=" not in text:
            continue
        key, value = text.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def check(checks: list[dict], cid: str, ok: bool, detail: str) -> bool:
    checks.append({"id": cid, "status": "pass" if ok else "fail", "detail": detail})
    return ok


def verify_identity(identity: dict, freeze: dict, checks: list[dict]) -> bool:
    backend = identity.get("backend", {})
    ok = True
    ok &= check(checks, "ID-BACKEND-SHA", backend.get("sha256") == FROZEN_BACKEND_SHA,
                f"sha256={backend.get('sha256')}")
    ok &= check(checks, "ID-BUILD-COMMIT",
                backend.get("build_git_commit") == freeze["backend_build"],
                f"build_git_commit={backend.get('build_git_commit')}")
    fingerprint = backend.get("source_fingerprint", "")
    ok &= check(checks, "ID-SOURCE-FINGERPRINT",
                isinstance(fingerprint, str) and len(fingerprint) == 64
                and all(ch in "0123456789abcdef" for ch in fingerprint),
                f"source_fingerprint={fingerprint}")
    ok &= check(checks, "ID-GEANT4-VERSION",
                backend.get("geant4_version_number") == FROZEN_GEANT4_VERSION,
                f"geant4_version_number={backend.get('geant4_version_number')}")
    data = identity.get("data_file", {})
    ok &= check(checks, "ID-DATA-SHA", data.get("sha256") == freeze["data_sha256"],
                f"sha256={data.get('sha256')}")
    ok &= check(checks, "ID-DATA-MATCHES-FREEZE", data.get("matches_freeze") is True,
                f"matches_freeze={data.get('matches_freeze')}")
    geant4 = identity.get("geant4", {})
    ok &= check(checks, "ID-GEANT4-DATA-CHECK", geant4.get("data_check_exit") == 0,
                f"exit={geant4.get('data_check_exit')} sha={geant4.get('data_check_sha256')}")
    return bool(ok)


def verify_case_evidence(case: dict, freeze: dict, checks: list[dict]) -> bool:
    n_expected = int(freeze["events_per_case"])
    output = Path(case["run"]["output_dir"])
    summary_path = output / "run_summary.txt"
    metadata_path = output / "run_metadata.json"
    ok = True
    ok &= check(checks, "EVID-SUMMARY-FILE", summary_path.is_file(), str(summary_path))
    ok &= check(checks, "EVID-METADATA-FILE", metadata_path.is_file(), str(metadata_path))
    if not summary_path.is_file() or not metadata_path.is_file():
        return False
    ok &= check(checks, "EVID-SUMMARY-SHA", sha256(summary_path) == case["run"]["run_summary_sha256"],
                case["run"]["run_summary_sha256"])
    summary = parse_run_summary(summary_path)
    expected = {
        "status": "completed",
        "summary_write_status": "completed",
        "output_failure_status": "none",
        "macro_execution_status": "completed",
        "simulation_executed": "true",
        "program_exit_code": "0",
        "run_count": "1",
    }
    for key, value in expected.items():
        ok &= check(checks, f"EVID-SUMMARY-{key.upper().replace('_', '-')}",
                    summary.get(key) == value, f"{key}={summary.get(key)}")
    for key in ("run_0_planned_events", "run_0_completed_events",
                "planned_event_count", "actual_completed_event_count"):
        ok &= check(checks, f"EVID-{key.upper().replace('_', '-')}",
                    summary.get(key) == str(n_expected), f"{key}={summary.get(key)}")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    runs = metadata.get("runs", [])
    ok &= check(checks, "EVID-METADATA-SCHEMA", metadata.get("schema") == "run_metadata_json_v1",
                str(metadata.get("schema")))
    ok &= check(checks, "EVID-METADATA-RUNS", len(runs) == 1, f"runs={len(runs)}")
    if len(runs) == 1:
        ok &= check(checks, "EVID-METADATA-PLANNED",
                    int(runs[0].get("planned_events", -1)) == n_expected,
                    f"planned={runs[0].get('planned_events')}")
        ok &= check(checks, "EVID-METADATA-COMPLETED",
                    int(runs[0].get("completed_events", -1)) == n_expected,
                    f"completed={runs[0].get('completed_events')}")
    declared = {
        Path(item.get("path", "")).name: item for item in metadata.get("generated_files", [])
    }
    for name in ("let_volume_summary_t0.csv", "scorer_statistics.csv"):
        item = declared.get(name)
        path = output / name
        ok &= check(checks, f"EVID-ASSET-DECLARED-{name}",
                    item is not None and item.get("integrity_status") == "hashed",
                    f"declared={item is not None}")
        if item is None or not path.is_file():
            ok &= check(checks, f"EVID-ASSET-FILE-{name}", False, str(path))
            continue
        ok &= check(checks, f"EVID-ASSET-FILE-{name}", True, str(path))
        ok &= check(checks, f"EVID-ASSET-SHA-{name}", sha256(path) == item.get("sha256"),
                    f"disk={sha256(path)} declared={item.get('sha256')}")
        ok &= check(checks, f"EVID-ASSET-SIZE-{name}", path.stat().st_size == item.get("size_bytes"),
                    f"disk={path.stat().st_size} declared={item.get('size_bytes')}")
    hits = output / "hits_t0.csv"
    ok &= check(checks, "EVID-NO-HITS-FOR-LET", not hits.exists(), str(hits))
    return bool(ok)


def let_products(output: Path, checks: list[dict]) -> dict:
    rows = read_csv(output / "let_volume_summary_t0.csv")
    row = next((item for item in rows if item.get("particles") == "proton"), None)
    if row is None:
        check(checks, "MOM-ROW-PRESENT", False, "no proton row")
        return {}
    check(checks, "MOM-ROW-PRESENT", True, row.get("volume_path", ""))
    values = {key: float(value) for key, value in row.items() if key not in {"runID", "volume_path", "volume_name", "particles"}}
    sum_wl = values["sum_wl_mm"]
    sum_wsl = values["sum_wSl_MeV"]
    sum_ws2l = values["sum_wS2l_MeV2_per_mm"]
    recomputed_t = sum_wsl / sum_wl
    recomputed_d = sum_ws2l / sum_wsl
    bound_t = 2.0 * (half_width(sum_wsl) / sum_wl + sum_wsl * half_width(sum_wl) / (sum_wl * sum_wl)) * recomputed_t
    bound_d = 2.0 * (half_width(sum_ws2l) / sum_wsl + sum_ws2l * half_width(sum_wsl) / (sum_wsl * sum_wsl)) * recomputed_d
    reported_t = values["let_t_keV_per_um"]
    reported_d = values["let_d_keV_per_um"]
    check(checks, "MOM-LET-T-RECOMPUTED", abs(reported_t - recomputed_t) <= bound_t + 1e-18,
          f"reported={reported_t!r} recomputed={recomputed_t!r} bound={bound_t:.3e}")
    check(checks, "MOM-LET-D-RECOMPUTED", abs(reported_d - recomputed_d) <= bound_d + 1e-18,
          f"reported={reported_d!r} recomputed={recomputed_d!r} bound={bound_d:.3e}")
    check(checks, "MOM-EVENTS", int(values["n_events"]) > 0,
          f"n_events={values['n_events']}")
    return {
        "reported": {"let_t": reported_t, "let_d": reported_d, "n_events": int(values["n_events"])},
        "recomputed": {"let_t": recomputed_t, "let_d": recomputed_d},
        "moments": values,
        "row": row,
    }


def statistics(output: Path, checks: list[dict]) -> dict:
    rows = read_csv(output / "scorer_statistics.csv")
    result: dict[str, dict] = {}
    for quantity in ("let_t", "let_d"):
        row = next((item for item in rows if item.get("quantity") == quantity), None)
        ok = row is not None
        check(checks, f"STAT-ROW-{quantity.upper()}", ok, "row present" if ok else "missing")
        if not ok:
            continue
        rel_error = float(row["rel_error"])
        value = float(row["value"])
        estimator = row["estimator"]
        uncertainty_estimator = row.get("uncertainty_estimator", "")
        status = row["uncertainty_status"]
        check(checks, f"STAT-ESTIMATOR-{quantity.upper()}",
              estimator == "ratio" and uncertainty_estimator == "uncorrected_delta_ratio_v1",
              f"estimator={estimator} uncertainty_estimator={uncertainty_estimator}")
        check(checks, f"STAT-STATUS-{quantity.upper()}", status == "approximate", status)
        check(checks, f"STAT-REL-ERROR-{quantity.upper()}",
              math.isfinite(rel_error) and rel_error >= 0.0, f"rel_error={rel_error!r}")
        check(checks, f"STAT-VALUE-{quantity.upper()}", math.isfinite(value), f"value={value!r}")
        check(checks, f"STAT-EVENTS-{quantity.upper()}",
              int(row["n_events"]) == int(values_events(output)), f"n_events={row['n_events']}")
        result[quantity] = {
            "value": value,
            "rel_error": rel_error,
            "sigma": rel_error * abs(value),
            "estimator": estimator,
            "uncertainty_estimator": uncertainty_estimator,
            "uncertainty_status": status,
            "n_events": int(row["n_events"]),
        }
    return result


def values_events(output: Path) -> int:
    rows = read_csv(output / "let_volume_summary_t0.csv")
    return int(rows[0]["n_events"]) if rows else -1


def evaluate(results: dict, freeze: dict, identity: dict | None = None) -> dict:
    checks: list[dict] = []
    identity = identity or results.get("identity", {})
    identity_ok = verify_identity(identity, freeze, checks)
    cases_out: dict[str, dict] = {}
    for case_id, case in results.get("cases", {}).items():
        energy = float(case["run"]["energy_MeV"])
        reference = next(item for item in freeze["references"] if float(item["energy"]) == energy)
        case_checks: list[dict] = []
        evidence_ok = verify_case_evidence(case, freeze, case_checks)
        products = let_products(Path(case["run"]["output_dir"]), case_checks) if evidence_ok else {}
        stats = statistics(Path(case["run"]["output_dir"]), case_checks) if evidence_ok else {}
        conclusion: dict = {"status": "inconclusive", "reason": "evidence gate failed"}
        if evidence_ok and products and stats:
            let_t = products["reported"]["let_t"]
            let_d = products["reported"]["let_d"]
            sigma = stats["let_t"]["sigma"]
            sigma_d = stats["let_d"]["sigma"]
            reference_let = float(reference["let"])
            abs_error = let_t - reference_let
            allowed = 0.015 * reference_let + 3.0 * sigma
            rel_error = abs_error / reference_let
            precision = half_width(let_t) + half_width(let_d)
            difference = let_d - let_t
            relative_difference = difference / let_t
            checks_a = check(case_checks, "REF-LET-T-ABS",
                             abs(abs_error) <= allowed,
                             f"|{abs_error:.9f}| <= {allowed:.9f} keV/um")
            checks_b = check(case_checks, "REF-LET-D-GE-T",
                             difference >= -precision,
                             f"let_d-let_t={difference:.9f} precision={precision:.3e}")
            checks_c = check(case_checks, "REF-LET-D-REL",
                             relative_difference <= 0.05,
                             f"{relative_difference:.6e} <= 0.05")
            status_ok = (case["run"]["completed_events"] == int(freeze["events_per_case"])
                         and all(math.isfinite(item) for item in (let_t, let_d, sigma))
                         and stats["let_t"]["uncertainty_estimator"] == "uncorrected_delta_ratio_v1"
                         and stats["let_d"]["uncertainty_estimator"] == "uncorrected_delta_ratio_v1"
                         and stats["let_t"]["sigma"] > 0.0 and stats["let_d"]["sigma"] > 0.0)
            checks_d = check(case_checks, "REF-STATUS", status_ok,
                             f"completed_events={case['run']['completed_events']}")
            passed = all((checks_a, checks_b, checks_c, checks_d))
            conclusion = {
                "status": "pass" if passed else "fail",
                "reference_let_keV_um": reference_let,
                "reference_mid_MeV": float(reference["mid"]),
                "let_t_keV_um": let_t,
                "let_d_keV_um": let_d,
                "sigma_let_t_keV_um": sigma,
                "allowed_abs_error_keV_um": allowed,
                "abs_error_keV_um": abs_error,
                "relative_error": rel_error,
                "let_d_minus_let_t_keV_um": difference,
                "relative_let_d_minus_t": relative_difference,
                "sigma_let_d_keV_um": sigma_d,
                "rel_error_let_t": stats["let_t"]["rel_error"],
                "rel_error_let_d": stats["let_d"]["rel_error"],
                "let_d_minus_t_significance_independent_z": (
                    difference / math.hypot(sigma, sigma_d) if math.hypot(sigma, sigma_d) else None
                ),
                "completed_events": case["run"]["completed_events"],
            }
        checks = checks + case_checks
        cases_out[case_id] = {
            "energy_MeV": energy,
            "checks": case_checks,
            "conclusion": conclusion,
            "products": {
                "reported": products.get("reported") if products else None,
                "recomputed": products.get("recomputed") if products else None,
                "statistics": stats,
            },
        }
    failed = [item["id"] for item in checks if item["status"] != "pass"]
    overall_pass = identity_ok and not failed and all(
        item["conclusion"]["status"] == "pass" for item in cases_out.values()
    )
    return {
        "schema": "g4usim_q2_ref_let_evaluation_v1",
        "case": freeze["case"],
        "status": "pass" if overall_pass else "fail",
        "identity_ok": bool(identity_ok),
        "checks_total": len(checks),
        "checks_failed": len(failed),
        "failed_ids": failed,
        "cases": cases_out,
        "checks": checks,
    }


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--results", default=str(BASE / "results.json"))
    parser.add_argument("--freeze", default=str(FREEZE))
    parser.add_argument("--identity", default=str(BASE / "identity.json"))
    args = parser.parse_args()
    results = json.loads(Path(args.results).read_text(encoding="utf-8"))
    freeze = json.loads(Path(args.freeze).read_text(encoding="utf-8"))
    identity = json.loads(Path(args.identity).read_text(encoding="utf-8"))
    evaluation = evaluate(results, freeze, identity)
    print(json.dumps(evaluation, indent=2, sort_keys=True))
    return 0 if evaluation["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
