"""Independent re-implementation of the frozen REF-LET-01 reference method.

The frozen file `docs/collab/decisions/20261105-q2-let-reference-freeze-v1.json`
defines the reference as:

    log-log interpolate CSDA range at E0, subtract rho*t/2 in g/cm2,
    inverse log-log interpolate energy, interpolate electronic stopping at
    mid and multiply rho*0.1

This module does that computation directly from the *bytes* of
`scenarios/benchmarks/shielding_range/nist/PSTAR_Si.txt` (SHA-256 is checked
against the frozen value) and never reads a simulation product.  It exists so
the delivery can show that the frozen numbers are reproducible from the public
table and the stated geometry, independently of the author who froze them.

Usage:
    python reference.py            # compute both cases and print JSON
    python reference.py --check    # exit 1 if the frozen values disagree
"""

from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-let-v1"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-let-reference-freeze-v1.json"
DATA = ROOT / "scenarios" / "benchmarks" / "shielding_range" / "nist" / "PSTAR_Si.txt"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_freeze() -> dict:
    return json.loads(FREEZE.read_text(encoding="utf-8"))


def parse_pstar(path: Path) -> list[tuple[float, float, float]]:
    """Return (T_MeV, STOP_e_MeV_cm2_g, CSDA_range_g_cm2) rows from the table."""
    rows: list[tuple[float, float, float]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if len(fields) != 7:
            continue
        try:
            values = [float(item) for item in fields]
        except ValueError:
            continue
        energy, stop_e, _stop_n, _stop_t, csda, _projected, _detour = values
        if energy <= 0.0 or stop_e <= 0.0 or csda <= 0.0:
            continue
        rows.append((energy, stop_e, csda))
    rows.sort(key=lambda item: item[0])
    if len(rows) < 2:
        raise SystemExit("PSTAR_Si.txt: not enough numeric rows")
    return rows


def _log_interp(x: float, points: list[tuple[float, float]]) -> float:
    """log-log interpolation of y(x) from a strictly increasing table."""
    if x <= points[0][0]:
        return points[0][1]
    if x >= points[-1][0]:
        return points[-1][1]
    for (x0, y0), (x1, y1) in zip(points, points[1:]):
        if x0 <= x <= x1:
            if x == x0:
                return y0
            if x == x1:
                return y1
            ratio = (math.log(x) - math.log(x0)) / (math.log(x1) - math.log(x0))
            return math.exp(math.log(y0) + ratio * (math.log(y1) - math.log(y0)))
    raise AssertionError("interpolation domain")


def _inverse_log_interp(y: float, points: list[tuple[float, float]]) -> float:
    """Invert a monotonically increasing log-log table: x such that y(x)=y."""
    if y <= points[0][1]:
        return points[0][0]
    if y >= points[-1][1]:
        return points[-1][0]
    for (x0, y0), (x1, y1) in zip(points, points[1:]):
        if y0 <= y <= y1:
            if y == y0:
                return x0
            if y == y1:
                return x1
            ratio = (math.log(y) - math.log(y0)) / (math.log(y1) - math.log(y0))
            return math.exp(math.log(x0) + ratio * (math.log(x1) - math.log(x0)))
    raise AssertionError("inverse interpolation domain")


def compute_reference(energy_mev: float, rows: list[tuple[float, float, float]], freeze: dict) -> dict:
    density = float(freeze["density_g_cm3"])
    thickness_cm = float(freeze["dimensions_mm"][2]) * 0.1  # 0.02 mm -> 0.002 cm
    areal_mass = density * thickness_cm  # g/cm2 of the slab
    range_at_e0 = _log_interp(energy_mev, [(row[0], row[2]) for row in rows])
    range_mid = range_at_e0 - areal_mass / 2.0
    if range_mid <= 0.0:
        raise SystemExit(f"energy {energy_mev} MeV: mid range is not positive")
    energy_mid = _inverse_log_interp(range_mid, [(row[0], row[2]) for row in rows])
    stop_e_mid = _log_interp(energy_mid, [(row[0], row[1]) for row in rows])
    # STOP(e) is MeV cm2/g; multiply by rho (g/cm3) and 0.1 (MeV/cm -> keV/um)
    let_kev_um = stop_e_mid * density * 0.1
    return {
        "energy_MeV": energy_mev,
        "range_at_E0_g_cm2": range_at_e0,
        "areal_mass_g_cm2": areal_mass,
        "range_mid_g_cm2": range_mid,
        "energy_mid_MeV": energy_mid,
        "stop_e_mid_MeV_cm2_g": stop_e_mid,
        "let_keV_um": let_kev_um,
    }


def build(data_path: Path | None = None, freeze_path: Path | None = None) -> dict:
    freeze_file = freeze_path or FREEZE
    data_file = data_path or DATA
    freeze = json.loads(freeze_file.read_text(encoding="utf-8"))
    data_sha = sha256(data_file)
    if data_sha != freeze["data_sha256"]:
        raise SystemExit(f"PSTAR_Si.txt sha256 mismatch: {data_sha} != {freeze['data_sha256']}")
    rows = parse_pstar(data_file)
    computed = [compute_reference(float(item["energy"]), rows, freeze) for item in freeze["references"]]
    comparison = []
    for expected, actual in zip(freeze["references"], computed):
        comparison.append(
            {
                "energy_MeV": expected["energy"],
                "frozen_mid_MeV": expected["mid"],
                "recomputed_mid_MeV": actual["energy_mid_MeV"],
                "mid_delta_MeV": actual["energy_mid_MeV"] - expected["mid"],
                "frozen_let_keV_um": expected["let"],
                "recomputed_let_keV_um": actual["let_keV_um"],
                "let_delta_keV_um": actual["let_keV_um"] - expected["let"],
                "let_relative_delta": (actual["let_keV_um"] - expected["let"]) / expected["let"],
            }
        )
    return {
        "schema": "g4usim_q2_ref_let_recompute_v1",
        "case": freeze["case"],
        "freeze_file": str(FREEZE.relative_to(ROOT)).replace("\\", "/"),
        "data_file": str(data_file),
        "data_sha256": data_sha,
        "data_matches_freeze": True,
        "method": freeze["reference_method"],
        "table_rows": len(rows),
        "computed": computed,
        "comparison": comparison,
    }


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default=str(DATA))
    parser.add_argument("--freeze", default=str(FREEZE))
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--out", default=str(BASE / "reference-recompute.json"))
    args = parser.parse_args()
    report = build(Path(args.data), Path(args.freeze))
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    if args.check:
        for item in report["comparison"]:
            if abs(item["let_relative_delta"]) > 1e-12:
                print(f"FAIL: {item['energy_MeV']} MeV reference disagrees", file=sys.stderr)
                return 1
            if abs(item["mid_delta_MeV"]) > 1e-9:
                print(f"FAIL: {item['energy_MeV']} MeV mid disagrees", file=sys.stderr)
                return 1
        print("reference recompute matches the frozen values", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
