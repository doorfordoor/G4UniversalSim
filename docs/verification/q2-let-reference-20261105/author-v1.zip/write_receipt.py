"""Generate the REF-LET-01 outbox receipt from the live delivery artefacts."""

from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-let-v1"
OUTBOX = ROOT / "docs" / "collab" / "outbox" / "20261105-q2-reference-let-v1.md"
FILES = [
    "README.md",
    "identity.json",
    "reference.py",
    "reference-recompute.json",
    "setup_inputs.py",
    "run_cases.py",
    "compare.py",
    "tamper.py",
    "results.json",
    "tamper-results.json",
    "backend-data-check.txt",
    "inputs/main_ref_let_10.ini",
    "inputs/main_ref_let_100.ini",
    "inputs/geometry_let.ini",
    "inputs/materials.ini",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def row(name: str) -> str:
    path = BASE / name
    return f"| `{name}` | `{sha256(path)[:16]}…` | {path.stat().st_size} |"


def main() -> int:
    identity = json.loads((BASE / "identity.json").read_text(encoding="utf-8"))
    results = json.loads((BASE / "results.json").read_text(encoding="utf-8"))
    evaluation = results["evaluation"]
    tamper = json.loads((BASE / "tamper-results.json").read_text(encoding="utf-8"))
    recompute = json.loads((BASE / "reference-recompute.json").read_text(encoding="utf-8"))
    cases = evaluation["cases"]
    head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip()
    text = f"""# Q2-3 REF-LET-01 外部参考病例回执

状态：**作者交付，待独立复验**（{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} 生成）。
本回执只覆盖 `docs/collab/decisions/20261105-q2-let-reference-freeze-v1.json` 冻结的两个病例；
未改产品源码、正式测试、正式基准、支持等级或 CI，未提交 Git。

## 1. 身份

- 仓库：`D:/Geant4/G4UniversalSim`，branch `roadmap/Q2-scientific-baselines`，生成时 HEAD `{head}`（病例运行于 `9ed087f2`）。
- 冻结后端：`{identity['backend']['path']}`，sha256 `{identity['backend']['sha256']}`，
  build `{identity['backend']['build_git_commit']}`，source fingerprint `{identity['backend']['source_fingerprint']}`，
  Geant4 `{identity['backend']['geant4_version_number']}`。
- 参考数据：`{identity['data_file']['path']}`，sha256 `{identity['data_file']['sha256']}`，
  与冻结值一致。
- 冻结文件：`{identity['freeze']['path']}`，sha256 `{identity['freeze']['sha256']}`。
- `--check-geant4-data`：exit {identity['geant4']['data_check_exit']}，输出 sha256
  `{identity['geant4']['data_check_sha256']}`。

## 2. 交付文件

| 文件 | sha256（前缀） | 字节 |
| --- | --- | --- |
{chr(10).join(row(name) for name in FILES)}

运行产物在 `runs/ref_let_10/`、`runs/ref_let_100/`（含 `run.mac`、`backend.log`、
`record.json` 与 `output/`）；完整执行原始文件保留，未复制覆盖。

## 3. 参考重算（独立于冻结值）

`reference.py` 从 PSTAR 原始字节按冻结方法重算：输入表 sha256 校验通过、132 行数据，
两例 E_mid/LET 与冻结值比较为 `mid_delta=0`、`let_delta=0`（相对差 0.0）。结果在
`reference-recompute.json`，失败时 `--check` 非零退出。

## 4. 运行与门禁

两例均真实运行（冻结后端、1 线程、2000 事件、seed 20261111/20261112），`exit=0`、
`completed_events=2000`。`results.json` 的 101 项检查中：

- 身份门禁 `ID-*`：全过；
- 运行证据门禁 `EVID-*`：全过（摘要/metadata 生命周期、冻结 N、资产 sha256/size、
  scorer_statistics 事件数、无 hits）；
- 矩复算 `MOM-*`：全过；
- 统计估计 `STAT-*`：全过（`estimator=ratio`、`uncertainty_estimator=uncorrected_delta_ratio_v1`、
  `approximate`、有限非负误差）；
- 参考比较 `REF-*`：10 MeV 全过；100 MeV `REF-LET-D-REL` 失败（唯一 fail）。

## 5. 结果

| 能量 | 参考 LET | let_t | 相对误差 | 允许 | let_d | let_d−let_t | 相对 | 结论 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10 MeV | {cases['ref_let_10']['conclusion']['reference_let_keV_um']} | {cases['ref_let_10']['conclusion']['let_t_keV_um']} | {cases['ref_let_10']['conclusion']['relative_error']:.6e} | {cases['ref_let_10']['conclusion']['allowed_abs_error_keV_um']:.6f} | {cases['ref_let_10']['conclusion']['let_d_keV_um']} | {cases['ref_let_10']['conclusion']['let_d_minus_let_t_keV_um']:.3e} | {cases['ref_let_10']['conclusion']['relative_let_d_minus_t']:.3e} | **pass** |
| 100 MeV | {cases['ref_let_100']['conclusion']['reference_let_keV_um']} | {cases['ref_let_100']['conclusion']['let_t_keV_um']} | {cases['ref_let_100']['conclusion']['relative_error']:.6e} | {cases['ref_let_100']['conclusion']['allowed_abs_error_keV_um']:.6f} | {cases['ref_let_100']['conclusion']['let_d_keV_um']} | {cases['ref_let_100']['conclusion']['let_d_minus_let_t_keV_um']:.6f} | {cases['ref_let_100']['conclusion']['relative_let_d_minus_t']:.4f} | **fail** |

`let_d−let_t` 的独立误差上界：10 MeV z={cases['ref_let_10']['conclusion']['let_d_minus_t_significance_independent_z']:.3f}，
100 MeV z={cases['ref_let_100']['conclusion']['let_d_minus_t_significance_independent_z']:.3f}
（σ_d={cases['ref_let_100']['conclusion']['sigma_let_d_keV_um']:.4f}，σ_t={cases['ref_let_100']['conclusion']['sigma_let_t_keV_um']:.6f}）。

## 6. 失败项、诊断提案与未通过范围

100 MeV 的 `relative(let_d−let_t)=21.06%` 超过冻结的 5% 辅助判据，因此 REF-LET-01 按冻结规则
**整体 fail**；`let_t` 与参考的对照本身通过（+1.21%，允许 5.07%）。失败项的关键数据：

- `let_d` 的 delta 方法相对误差为 {cases['ref_let_100']['conclusion']['rel_error_let_d']:.4%}，
  `let_t` 为 {cases['ref_let_100']['conclusion']['rel_error_let_t']:.4%}；
- 差值 0.2899 keV/µm 与 σ_d=0.3022 keV/µm 同量级（保守独立 z≈0.96）；
- 10 MeV 同几何在相同 2000 事件下差值仅 1.4e-5，说明 100 MeV 的 `let_d` 被少数高 LET 步骤/次级
  主导，而不是实现公式造成的一致偏移。

最小诊断提案（需新的预注册冻结，本轮**不执行、不调参**）：

1. 输出 `let_t` 与 `let_d` 的交叉矩，或逐事件矩，用于计算差值自身的 delta 方法误差；
2. 按 Q2-4 预注册 `let_d` 方差与所需 N，用独立批次判定而非单点 5% 阈；
3. 先冻结“是否只算初级质子”的 LET 口径，区分实现错误与核反应次级贡献。

在判据/参考/样本/物理被主审重新冻结前，不改变本病例输入、容差、cut 或事件数。

## 7. 负例

`tamper.py` 在**拷贝**上构造并全部检出（{tamper['detected']}/{tamper['total']}）：

{chr(10).join(f"- `{item['id']}`：{item['mutation']} → 期望 {item['expected_check']}，检出 exit {item['exit_code']}。" for item in tamper['tampers'])}

原件与冻结文件未被修改；`tampered/` 可整体删除后重跑 `tamper.py`。

## 8. 复现与校验

```
python -B out/collab/q2-reference-let-v1/setup_inputs.py
python -B out/collab/q2-reference-let-v1/reference.py --check
python -B out/collab/q2-reference-let-v1/run_cases.py     # overall fail：仅 REF-LET-D-REL
python -B out/collab/q2-reference-let-v1/tamper.py        # 3/3 检出
```

`compare.py` 可独立读取 `results.json` 重放判据；`check_doc_links` 对回执/README 的相对链接有效。
实际工具输出、事件数、退出码与哈希均见 `results.json`/`identity.json`/`tamper-results.json`。

## 9. 限制与停止声明

- 仅 Windows、单线程、2000 事件、冻结两例；统计覆盖率、其它能量/材料、MT、GUI 不在本任务。
- `let_d` 大误差的物理归因仍属未决；本交付不给“物理已通过”结论，也不以调参方式消除失败。
- 作者自测不是独立复验；已停写，等待主审独立复跑与签收。
"""
    OUTBOX.parent.mkdir(parents=True, exist_ok=True)
    OUTBOX.write_text(text, encoding="utf-8")
    print(f"wrote {OUTBOX} ({len(text.encode('utf-8'))} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
