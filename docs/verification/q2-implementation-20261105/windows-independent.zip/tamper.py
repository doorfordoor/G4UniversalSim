"""Tamper counterexamples for the Q2-2 independent comparator (repair R1).

Each counterexample copies a case's *products* (never the original) into a
scratch tree, applies one small mutation that would be invisible to a
field-by-field copier, and asserts that the independent comparator fails with
the expected check id.

Two families:

* arithmetic tampers (mass/volume/unit factor, missing column, missing event
  ledger, modified NIEL table) — the copy's run_metadata manifest entry for the
  mutated product is **refreshed** so the SHA check passes and only the
  independent arithmetic can catch the error.  This isolates "hash-consistent
  but numerically wrong", exactly as required by the review.
* run-evidence tampers (missing summary/metadata, failed summary, zero or fewer
  completed events, corrupt/stale products, undeclared or byte-mismatched
  assets) — these must fail the evidence checks even though every remaining CSV
  looks structurally valid.

The product code and the original run products are never modified.
"""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
from pathlib import Path

import comparator

BASE = Path(__file__).resolve().parent
RUNS = BASE / "runs"
INPUTS = BASE / "inputs"
TAMPERED = BASE / "tampered"

FILES = comparator.COMPARED_FILES
SUMMARY = "run_summary.txt"
METADATA = "run_metadata.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def copy_case(case: str, destination: Path) -> Path:
    root = destination / case / "output"
    root.mkdir(parents=True, exist_ok=True)
    for name in FILES[case] + [SUMMARY, METADATA]:
        shutil.copy2(RUNS / case / "output" / name, root / name)
    return root


def refresh_metadata(root: Path) -> None:
    """Rewrite declared hashes/sizes after a deliberate product mutation."""
    path = root / METADATA
    doc = json.loads(path.read_text(encoding="utf-8"))
    for entry in doc.get("generated_files", []):
        name = Path(str(entry.get("path", ""))).name
        product = root / name
        if product.is_file():
            entry["sha256"] = sha256(product)
            entry["size_bytes"] = product.stat().st_size
            entry["integrity_status"] = "hashed"
    path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def read_rows(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        return list(reader.fieldnames or []), list(reader)


def write_rows(path: Path, header: list[str], rows: list[dict[str, str]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=header)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in header})


def set_cell(root: Path, file: str, row_index: int, column: str, value: str) -> None:
    path = root / file
    header, rows = read_rows(path)
    rows[row_index][column] = value
    write_rows(path, header, rows)


def scale_cell(root: Path, file: str, row_index: int, column: str, factor: float) -> None:
    path = root / file
    header, rows = read_rows(path)
    rows[row_index][column] = repr(float(rows[row_index][column]) * factor)
    write_rows(path, header, rows)


def drop_column(root: Path, file: str, column: str) -> None:
    path = root / file
    header, rows = read_rows(path)
    write_rows(path, [name for name in header if name != column], rows)


def truncate_events(root: Path, limit: int) -> None:
    hits = root / "hits_t0.csv"
    header, rows = read_rows(hits)
    write_rows(hits, header, [row for row in rows if int(row["eventID"]) < limit])
    events = root / "event_edep_t0.csv"
    header, rows = read_rows(events)
    write_rows(events, header, rows[:limit])


def set_summary_facts(root: Path, values: dict[str, str]) -> None:
    path = root / SUMMARY
    lines = path.read_text(encoding="utf-8").splitlines()
    seen: set[str] = set()
    output: list[str] = []
    for line in lines:
        stripped = line.strip()
        if "=" in stripped and not stripped.startswith("-"):
            key = stripped.split("=", 1)[0].strip()
            if key in values:
                output.append(f"{key} = {values[key]}")
                seen.add(key)
                continue
        output.append(line)
    missing = [key for key in values if key not in seen]
    if missing:
        raise AssertionError(f"summary facts not found: {missing}")
    path.write_text("\n".join(output) + "\n", encoding="utf-8")


def set_metadata_runs(root: Path, planned: int, completed: int) -> None:
    path = root / METADATA
    doc = json.loads(path.read_text(encoding="utf-8"))
    runs = doc.get("runs") or []
    if not runs:
        raise AssertionError("metadata has no runs")
    runs[0]["planned_events"] = planned
    runs[0]["completed_events"] = completed
    path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def drop_metadata_asset(root: Path, name: str) -> None:
    path = root / METADATA
    doc = json.loads(path.read_text(encoding="utf-8"))
    doc["generated_files"] = [
        entry for entry in doc.get("generated_files", [])
        if Path(str(entry.get("path", ""))).name != name
    ]
    path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# Arithmetic tampers: refresh the manifest so only the arithmetic can fail.
# ---------------------------------------------------------------------------


def tamper_dose_mass(tmp: Path) -> None:
    root = copy_case("IMP-DOSE-01", tmp)
    set_cell(root, "dose_volume_summary_t0.csv", 0, "mass_kg", "0.000932")
    refresh_metadata(root)


def tamper_dose_unit(tmp: Path) -> None:
    root = copy_case("IMP-DOSE-01", tmp)
    scale_cell(root, "dose_volume_summary_t0.csv", 0, "raw_dose_Gy", 1000.0)
    scale_cell(root, "dose_volume_summary_t0.csv", 0, "weighted_dose_Gy", 1000.0)
    refresh_metadata(root)


def tamper_dose_missing_column(tmp: Path) -> None:
    root = copy_case("IMP-DOSE-01", tmp)
    drop_column(root, "dose_volume_summary_t0.csv", "raw_dose_Gy")
    refresh_metadata(root)


def tamper_dose_missing_events(tmp: Path) -> None:
    root = copy_case("IMP-DOSE-01", tmp)
    truncate_events(root, 1000)
    refresh_metadata(root)


def tamper_dose_missing_hits(tmp: Path) -> None:
    root = copy_case("IMP-DOSE-01", tmp)
    (root / "hits_t0.csv").unlink()


def tamper_fluence_volume(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    set_cell(root, "fluence_volume_summary_t0.csv", 0, "volume_mm3", "5")
    refresh_metadata(root)


def tamper_fluence_unit(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    scale_cell(root, "fluence_volume_summary_t0.csv", 0, "raw_fluence_mm-2", 10.0)
    refresh_metadata(root)


def tamper_fluence_missing_column(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    drop_column(root, "fluence_volume_summary_t0.csv", "n_events")
    refresh_metadata(root)


def tamper_let_cross(tmp: Path) -> None:
    root = copy_case("IMP-LET-01-10MeV", tmp)
    scale_cell(root, "let_volume_summary_t0.csv", 0, "sum_wl_x_wSl_MeV_mm", 1.01)
    refresh_metadata(root)


def tamper_let_value(tmp: Path) -> None:
    root = copy_case("IMP-LET-01-10MeV", tmp)
    set_cell(root, "let_volume_summary_t0.csv", 0, "let_t_keV_per_um", "8.2")
    refresh_metadata(root)


def tamper_let_missing_column(tmp: Path) -> None:
    root = copy_case("IMP-LET-01-10MeV", tmp)
    drop_column(root, "let_volume_summary_t0.csv", "sum_wS2l_MeV2_per_mm")
    refresh_metadata(root)


def tamper_ddd_volume(tmp: Path) -> None:
    root = copy_case("IMP-DDD-01", tmp)
    set_cell(root, "displacement_volume_summary_t0.csv", 0, "volume_mm3", "1")
    refresh_metadata(root)


def tamper_ddd_table(tmp: Path) -> None:
    root = copy_case("IMP-DDD-01", tmp)
    table = root / "tampered-niel.csv"
    table.write_text(
        "# tampered copy: value changed from 0.003 to 0.004\n"
        "energy_MeV,niel_MeV_cm2_g\n1e-12,0.004\n1000000,0.004\n",
        encoding="utf-8",
    )
    set_cell(root, "displacement_volume_summary_t0.csv", 0, "niel_table", str(table))
    refresh_metadata(root)


def tamper_ddd_value(tmp: Path) -> None:
    root = copy_case("IMP-DDD-01", tmp)
    scale_cell(root, "displacement_volume_summary_t0.csv", 0, "ddd_MeV_g", 10.0)
    refresh_metadata(root)


def tamper_ddd_missing_column(tmp: Path) -> None:
    root = copy_case("IMP-DDD-01", tmp)
    drop_column(root, "displacement_volume_summary_t0.csv", "out_of_range_track_length_mm")
    refresh_metadata(root)


# ---------------------------------------------------------------------------
# Run-evidence tampers.
# ---------------------------------------------------------------------------


def evidence_missing_summary(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    (root / SUMMARY).unlink()


def evidence_missing_metadata(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    (root / METADATA).unlink()


def evidence_failed_summary(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    set_summary_facts(root, {"status": "failed", "macro_execution_status": "failed"})


def evidence_zero_events(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    set_summary_facts(root, {"actual_completed_event_count": "0",
                             "run_0_completed_events": "0"})
    set_metadata_runs(root, 20000, 0)


def evidence_fewer_events(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    set_summary_facts(root, {"actual_completed_event_count": "19999",
                             "run_0_completed_events": "19999"})
    set_metadata_runs(root, 20000, 19999)


def evidence_corrupt_summary(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    (root / SUMMARY).write_text("Run Summary\n===========\n\n", encoding="utf-8")


def evidence_corrupt_metadata(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    (root / METADATA).write_text("{not json\n", encoding="utf-8")


def evidence_asset_not_declared(tmp: Path) -> None:
    root = copy_case("IMP-DOSE-01", tmp)
    drop_metadata_asset(root, "event_edep_t0.csv")


def evidence_asset_sha_mismatch(tmp: Path) -> None:
    root = copy_case("IMP-DOSE-01", tmp)
    with (root / "hits_t0.csv").open("a", encoding="utf-8") as handle:
        handle.write("\n")
    # metadata intentionally not refreshed: byte identity must fail


def evidence_stale_product(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    shutil.copy2(RUNS / "IMP-DOSE-01" / "output" / "dose_volume_summary_t0.csv",
                 root / "fluence_volume_summary_t0.csv")
    refresh_metadata(root)


def evidence_missing_both(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    (root / SUMMARY).unlink()
    (root / METADATA).unlink()


def evidence_wrong_exit(tmp: Path) -> None:
    root = copy_case("IMP-FLU-01", tmp)
    set_summary_facts(root, {"program_exit_code": "1"})


TAMPERS = [
    # arithmetic (hash refreshed -> only independent arithmetic can fail)
    ("dose-mass-double", "IMP-DOSE-01", tamper_dose_mass, "DOSE-MASS"),
    ("dose-unit-x1000", "IMP-DOSE-01", tamper_dose_unit, "DOSE-VALUE-HITS"),
    ("dose-missing-column", "IMP-DOSE-01", tamper_dose_missing_column, "DOSE-SUMMARY-COLUMNS"),
    ("dose-missing-events", "IMP-DOSE-01", tamper_dose_missing_events, "DOSE-EDEP-EVENTS"),
    ("dose-missing-hits", "IMP-DOSE-01", tamper_dose_missing_hits, "EVID-ASSET-FILE-hits_t0.csv"),
    ("fluence-volume-factor", "IMP-FLU-01", tamper_fluence_volume, "FLU-VOLUME"),
    ("fluence-unit-x10", "IMP-FLU-01", tamper_fluence_unit, "FLU-FLUENCE"),
    ("fluence-missing-column", "IMP-FLU-01", tamper_fluence_missing_column,
     "FLU-SUMMARY-COLUMNS"),
    ("let-cross-moment", "IMP-LET-01-10MeV", tamper_let_cross, "IMP-LET-01-10MeV-LET_T-REL"),
    ("let-value", "IMP-LET-01-10MeV", tamper_let_value, "IMP-LET-01-10MeV-LET-T"),
    ("let-missing-column", "IMP-LET-01-10MeV", tamper_let_missing_column,
     "IMP-LET-01-10MeV-SUMMARY-COLUMNS"),
    ("ddd-volume-factor", "IMP-DDD-01", tamper_ddd_volume, "DDD-VOLUME"),
    ("ddd-value-unit", "IMP-DDD-01", tamper_ddd_value, "DDD-VALUE"),
    ("ddd-table-modified", "IMP-DDD-01", tamper_ddd_table, "DDD-TABLE-SHA"),
    ("ddd-missing-column", "IMP-DDD-01", tamper_ddd_missing_column, "DDD-SUMMARY-COLUMNS"),
    # evidence
    ("evidence-missing-summary", "IMP-FLU-01", evidence_missing_summary, "EVID-SUMMARY-FILE"),
    ("evidence-missing-metadata", "IMP-FLU-01", evidence_missing_metadata,
     "EVID-METADATA-FILE"),
    ("evidence-failed-summary", "IMP-FLU-01", evidence_failed_summary,
     "EVID-SUMMARY-STATUS"),
    ("evidence-zero-events", "IMP-FLU-01", evidence_zero_events, "EVID-METADATA-RUNS"),
    ("evidence-fewer-events", "IMP-FLU-01", evidence_fewer_events, "EVID-COMPLETED-TOTAL"),
    ("evidence-corrupt-summary", "IMP-FLU-01", evidence_corrupt_summary,
     "EVID-SUMMARY-PARSE"),
    ("evidence-corrupt-metadata", "IMP-FLU-01", evidence_corrupt_metadata,
     "EVID-METADATA-PARSE"),
    ("evidence-asset-not-declared", "IMP-DOSE-01", evidence_asset_not_declared,
     "EVID-ASSET-DECLARED-event_edep_t0.csv"),
    ("evidence-asset-sha-mismatch", "IMP-DOSE-01", evidence_asset_sha_mismatch,
     "EVID-ASSET-SHA-hits_t0.csv"),
    ("evidence-stale-product", "IMP-FLU-01", evidence_stale_product, "FLU-SUMMARY-COLUMNS"),
    ("evidence-missing-both", "IMP-FLU-01", evidence_missing_both, "EVID-SUMMARY-FILE"),
    ("evidence-wrong-exit", "IMP-FLU-01", evidence_wrong_exit, "EVID-PROGRAM-EXIT"),
]


def main() -> int:
    if TAMPERED.exists():
        shutil.rmtree(TAMPERED)
    TAMPERED.mkdir(parents=True)
    results = []
    for name, case, mutate, expected_id in TAMPERS:
        tmp = TAMPERED / name
        mutate(tmp)
        result = comparator.compare_one(case, tmp, INPUTS)
        detected = result["status"] == "fail"
        expected_hit = any(expected_id in (item or "") for item in result["failed_ids"])
        record = {
            "tamper": name,
            "case": case,
            "mutation": mutate.__name__,
            "expected_check": expected_id,
            "detected": detected,
            "expected_check_hit": expected_hit,
            "failed_ids": result["failed_ids"],
            "status": "pass" if detected and expected_hit else "fail",
        }
        results.append(record)
        print(f"{name}: detected={detected} expected_hit={expected_hit} "
              f"failed={result['failed_ids'][:4]}")
    (BASE / "tamper-results.json").write_text(
        json.dumps({
            "schema": "g4usim_q2_2_tamper_v1",
            "tampers": results,
            "status": "pass" if all(r["status"] == "pass" for r in results) else "fail",
        }, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return 0 if all(r["status"] == "pass" for r in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
