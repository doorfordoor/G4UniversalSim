"""Create the frozen Q2-2 implementation-case inputs (IMP-* cases).

Inputs are generated from the frozen decision file
docs/collab/decisions/20261105-q2-implementation-freeze-v1.md.
No random choices: every number below is copied from that file.
"""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-implementation-v1"
INPUTS = BASE / "inputs"


def w(rel: str, text: str) -> Path:
    path = INPUTS / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


def main_ini(
    name: str,
    seed: int,
    geometry: str,
    scoring_lines: list[str],
    source_lines: list[str],
    physics: str = "FTFP_BERT_EMZ",
    cut: str = "1 um",
    hits: bool = False,
    event_edep: bool = False,
) -> str:
    lines = [
        "[run]",
        f"name = {name}",
        "threads = 1",
        f"seed = {seed}",
        "interactive = false",
        "verbose = 0",
        "check_overlaps = false",
        "dry_run = false",
        "",
        "[output]",
        f"dir = {(BASE / 'runs' / name / 'output').as_posix()}",
        "format = csv",
        "",
        "[materials]",
        f"file = {(INPUTS / 'materials.ini').as_posix()}",
        "",
        "[geometry]",
        "template = hierarchical",
        f"config = {(INPUTS / geometry).as_posix()}",
        "default_world_material = G4_Galactic",
        "",
        "[physics]",
        f"reference = {physics}",
        f"default_cut = {cut}",
        "",
        "[scoring]",
        "enabled = true",
        f"hits = {'true' if hits else 'false'}",
        f"event_edep = {'true' if event_edep else 'false'}",
        "edep = false",
        "auto_create_default_scorers = true",
    ]
    lines.extend(scoring_lines)
    lines.append("")
    lines.append("[source]")
    lines.extend(source_lines)
    return "\n".join(lines) + "\n"


def main() -> int:
    INPUTS.mkdir(parents=True, exist_ok=True)

    w(
        "materials.ini",
        "[galactic]\nmaterial = G4_Galactic\n\n[silicon]\nmaterial = G4_Si\n",
    )

    # IMP-DOSE-01: G4_Si 10x10x2 mm, proton 10 MeV normal incidence, N=20000
    w(
        "geometry_dose.ini",
        "[world]\nshape = box\nsize = 20 mm, 20 mm, 20 mm\nmaterial = G4_Galactic\n\n"
        "[volume.SiTarget]\nparent = world\nshape = box\nsize = 10 mm, 10 mm, 2 mm\n"
        "material = G4_Si\nposition = 0 mm, 0 mm, 0 mm\nsensitive = true\n",
    )
    w(
        "main_imp_dose.ini",
        main_ini(
            "imp_dose",
            20261120,
            "geometry_dose.ini",
            ["dose = true"],
            ["particle = proton", "energy = 10 MeV", "position_type = point",
             "position = 0, 0, -3 mm", "direction = 0, 0, 1"],
            # 10 mm production cut: no secondary electrons are produced, so the
            # per-step hits evidence stays bounded (~7.5 rows/event).  Dose is
            # total deposited energy / mass, so the normalisation is unchanged;
            # the cut is an implementation choice, not a frozen physics parameter.
            cut="10 mm",
            hits=True,
            event_edep=True,
        ),
    )

    # IMP-FLU-01 / IMP-DDD-01: 10x10x0.1 mm G4_Galactic slab, point source at (0,0,-2)
    w(
        "geometry_fluence.ini",
        "[world]\nshape = box\nsize = 20 mm, 20 mm, 20 mm\nmaterial = G4_Galactic\n\n"
        "[volume.Slab]\nparent = world\nshape = box\nsize = 10 mm, 10 mm, 0.1 mm\n"
        "material = G4_Galactic\nposition = 0 mm, 0 mm, 0 mm\nsensitive = true\n",
    )
    w(
        "main_imp_fluence.ini",
        main_ini(
            "imp_fluence",
            20261121,
            "geometry_fluence.ini",
            ["fluence = true"],
            ["particle = geantino", "energy = 1 MeV", "position_type = point",
             "position = 0, 0, -2 mm", "direction = 0, 0, 1"],
        ),
    )

    # IMP-LET-01: G4_Si 10x10x0.02 mm, protons 10/100 MeV
    w(
        "geometry_let.ini",
        "[world]\nshape = box\nsize = 20 mm, 20 mm, 20 mm\nmaterial = G4_Galactic\n\n"
        "[volume.LetTarget]\nparent = world\nshape = box\nsize = 10 mm, 10 mm, 0.02 mm\n"
        "material = G4_Si\nposition = 0 mm, 0 mm, 0 mm\nsensitive = true\n",
    )
    for energy, seed in (("10", 20261122), ("100", 20261123)):
        w(
            f"main_imp_let_{energy}.ini",
            main_ini(
                f"imp_let_{energy}",
                seed,
                "geometry_let.ini",
                ["let = true", "[scoring.let]", "particles = proton"],
                ["particle = proton", f"energy = {energy} MeV", "position_type = point",
                 "position = 0, 0, -3 mm", "direction = 0, 0, 1"],
                cut="1 um",
            ),
        )

    # IMP-DDD-01: same geometry/source as IMP-FLU, constant synthetic NIEL table
    w(
        "niel_constant_0p003.csv",
        "# synthetic constant NIEL table for IMP-DDD-01 (unit/volume factor test only)\n"
        "energy_MeV,niel_MeV_cm2_g\n1e-12,0.003\n1000000,0.003\n",
    )
    w(
        "main_imp_ddd.ini",
        main_ini(
            "imp_ddd",
            20261124,
            "geometry_fluence.ini",
            ["fluence = true", "displacement = true", "[scoring.displacement]",
             f"geantino = {(INPUTS / 'niel_constant_0p003.csv').as_posix()}"],
            ["particle = geantino", "energy = 1 MeV", "position_type = point",
             "position = 0, 0, -2 mm", "direction = 0, 0, 1"],
        ),
    )

    inputs = {
        "IMP-DOSE-01": "main_imp_dose.ini",
        "IMP-FLU-01": "main_imp_fluence.ini",
        "IMP-LET-01-10MeV": "main_imp_let_10.ini",
        "IMP-LET-01-100MeV": "main_imp_let_100.ini",
        "IMP-DDD-01": "main_imp_ddd.ini",
    }
    (INPUTS / "inputs.json").write_text(
        json.dumps(
            {
                "note": "generated by setup_inputs.py from docs/collab/decisions/20261105-q2-implementation-freeze-v1.md",
                "inputs_dir": str(INPUTS),
                "cases": inputs,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    print("inputs written to", INPUTS)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
