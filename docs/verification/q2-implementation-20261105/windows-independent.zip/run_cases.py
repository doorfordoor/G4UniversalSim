"""Run the frozen Q2-2 implementation cases with the frozen backend.

Every case reuses the same input files created by setup_inputs.py; the only
per-case addition is a minimal batch macro with /run/initialize + /run/beamOn N.
No physics decision is made here: beamOn counts are copied from the freeze file.
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-implementation-v1"
BACKEND = ROOT / "out" / "collab" / "q2-backend-864bc036" / "G4UniversalSim.exe"
GEANT4_BIN = Path("D:/ProgramFiles/Geant4/bin")
GEANT4_DATA = Path("D:/ProgramFiles/Geant4/share/Geant4/data")

CASES = {
    # case id: (main ini, seed, threads, beam_on)
    "IMP-DOSE-01": ("main_imp_dose.ini", 20261120, 1, 20000),
    "IMP-FLU-01": ("main_imp_fluence.ini", 20261121, 1, 20000),
    "IMP-LET-01-10MeV": ("main_imp_let_10.ini", 20261122, 1, 2000),
    "IMP-LET-01-100MeV": ("main_imp_let_100.ini", 20261123, 1, 2000),
    "IMP-DDD-01": ("main_imp_ddd.ini", 20261124, 1, 20000),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def environment() -> dict:
    return {
        "GEANT4_DATA_DIR": str(GEANT4_DATA),
        "PATH_prefix": str(GEANT4_BIN),
        "platform": os.name,
        "python": "venv (not used by backend)",
        "cwd": str(ROOT),
    }


def run(command: list[str], log_path: Path, timeout: int = 3600) -> tuple[int, float, str]:
    started = time.time()
    with log_path.open("wb") as log:
        completed = subprocess.run(
            command,
            cwd=str(ROOT),
            env=env(),
            stdout=log,
            stderr=subprocess.STDOUT,
            timeout=timeout,
        )
    duration = time.time() - started
    return completed.returncode, duration, log_path.read_text(encoding="utf-8", errors="replace")


def env() -> dict:
    merged = os.environ.copy()
    merged["PATH"] = str(GEANT4_BIN) + os.pathsep + merged.get("PATH", "")
    merged["GEANT4_DATA_DIR"] = str(GEANT4_DATA)
    merged.pop("QT_QPA_PLATFORM", None)
    return merged


def main() -> int:
    if not BACKEND.is_file():
        raise SystemExit(f"frozen backend missing: {BACKEND}")
    BASE.mkdir(parents=True, exist_ok=True)
    inputs = BASE / "inputs"

    identity = {
        "backend": {
            "path": str(BACKEND),
            "sha256": sha256(BACKEND),
            "bytes": BACKEND.stat().st_size,
            "copied_from": "C:/.../f2-independent-build (see out/collab/q2-backend-864bc036/identity.json)",
        },
        "geant4": {"prefix": "D:/ProgramFiles/Geant4", "data": str(GEANT4_DATA)},
        "generated_at": now(),
        "workspace": "D:/Geant4/G4UniversalSim",
    }
    caps = subprocess.run(
        [str(BACKEND), "--capabilities"], cwd=str(ROOT), env=env(),
        capture_output=True, text=True, timeout=120,
    )
    (BASE / "backend_capabilities.json").write_text(caps.stdout, encoding="utf-8")
    identity["capabilities"] = json.loads(caps.stdout) if caps.stdout.strip() else {}
    check = subprocess.run(
        [str(BACKEND), "--check-geant4-data"], cwd=str(ROOT), env=env(),
        capture_output=True, text=True, timeout=300,
    )
    (BASE / "backend_geant4_data.json").write_text(check.stdout, encoding="utf-8")
    identity["geant4_data_required_complete"] = json.loads(check.stdout).get("required_complete")
    (BASE / "identity.json").write_text(
        json.dumps(identity, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    results = {}
    for case, (ini_name, seed, threads, beam_on) in CASES.items():
        run_dir = BASE / "runs" / case
        output = run_dir / "output"
        if output.exists():
            for child in sorted(output.rglob("*"), reverse=True):
                if child.is_file():
                    child.unlink()
                elif child.is_dir():
                    child.rmdir()
        output.mkdir(parents=True, exist_ok=True)
        macro = run_dir / "run.mac"
        macro.write_text(
            f"# {case}: minimal batch wrapper, /run/beamOn from the frozen decision file\n"
            "/run/initialize\n"
            f"/run/beamOn {beam_on}\n",
            encoding="utf-8",
        )
        ini = inputs / ini_name
        command = [
            str(BACKEND),
            "--config", str(ini),
            "--macro", str(macro),
            "--output", str(output),
            "--threads", str(threads),
            "--seed", str(seed),
        ]
        record = {
            "case": case,
            "main_ini": {"path": str(ini), "sha256": sha256(ini)},
            "macro": {"path": str(macro), "sha256": sha256(macro), "beam_on": beam_on},
            "command": command,
            "environment": environment(),
            "started_at": now(),
        }
        code, duration, text = run(command, run_dir / "backend.log")
        record.update(
            {
                "finished_at": now(),
                "duration_s": round(duration, 3),
                "exit_code": code,
                "backend_log": str(run_dir / "backend.log"),
            }
        )
        summary_path = output / "run_summary.txt"
        record["run_summary_present"] = summary_path.is_file()
        if summary_path.is_file():
            record["run_summary_sha256"] = sha256(summary_path)
            record["run_summary_excerpt"] = summary_path.read_text(
                encoding="utf-8", errors="replace"
            )[:4000]
        record["outputs"] = sorted(
            str(path.relative_to(output)) for path in output.rglob("*") if path.is_file()
        ) if output.is_dir() else []
        record["console_tail"] = text[-2000:]
        (run_dir / "record.json").write_text(
            json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        results[case] = record
        print(f"{case}: exit={code} {duration:.2f}s outputs={len(record['outputs'])}")

    (BASE / "raw_runs.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    failed = [case for case, record in results.items() if record["exit_code"] != 0]
    print("failed cases:", failed)
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
