# REF-FLU-01：均匀方束穿过薄层气体的解析注量参考

本目录是一个**冻结的外部参考病例**的一次真实运行、独立参考重算、六层证据比较与有限反例的完整交付。
它回答的问题只有一个：在冻结的均匀 12×12 mm、100 MeV 质子束垂直穿过 10×10×0.1 mm
G4_Galactic 灵敏片时，产品 Fluence 计分器给出的面积注量（mm⁻²）是否与解析期望
`N/面积` 一致，且误差口径与由本轮 hits 独立重算的结果、以及冻结的 Bernoulli 统计模型一致。

范围声明见第 10 节：**只**验证上述仅电磁、近似空介质、均匀孔径模型；不是散射材料注量验证，
不是剂量、NIEL、强子输运或产品缺陷证明。

## 1. 冻结身份

| 项目 | 值 |
| --- | --- |
| 冻结文件 | `docs/collab/decisions/20261105-q2-fluence-reference-freeze-v1.json` |
| 冻结 SHA-256 | `d9ceb71f9cb6a3bcf4029010eb2bf2212c6b014dca9967b40277e01379b077b3` |
| schema | `q2_reference_fluence_freeze_v1` |
| case | `REF-FLU-01` |
| 后端构建 | `864bc036d6d7752475e52db4efd2b950cabfcc3d` |
| 后端 exe SHA-256 | `f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f`（2,786,304 B） |
| 后端源码指纹 | `e7de615d4e342114104f970688a7ea5f9789f7b70240b2562a388a50a45704e7` |
| Geant4 | 11.3.2（`G4VERSION_NUMBER=1132`，`--check-geant4-data` exit 0 / `required_complete=true`） |
| 物理 | 仅电磁 `G4EmStandardPhysics_option4`（配置里**没有** `reference`） |
| 线程 / 事件 / 种子 | 1 / 20000 / `20261110` |
| 默认 cut | 0.7 mm |

身份全文在 `identity.json`；输入 SHA 在 `identity.json.inputs`：`geometry.ini` =
`cc7d1819f14627a6…`、`main.ini` = `5571b5ee62461a0b…`。

## 2. 几何与源（坐标口径）

几何按冻结合同：世界为 3000×3000×3000 mm `G4_Galactic`；灵敏片是世界的子体
`volume.Slab`，10×10×0.1 mm、`G4_Galactic`、`position = 0,0,0`、`sensitive = true`、
**无 daughter**（Fluence 计分器要求 sensitive solid 无 daughter 才按径迹长度计分）。
片体积 10 mm³、迎束面积 100 mm²。

源位于片外 2 mm：`position_type = plane`、`shape = square`、`halfx = 6 mm`（后端方形平面源
只接受 `halfx`，写 `halfy` 会被拒绝）、`center = 0,0,-2 mm`、`direction = 0,0,1`、100 MeV 质子。
束面积 = `(12 mm)² = 144 mm²`。

## 3. 独立解析参考（`reference.py`）

不是从产品输出反推，而是从冻结几何/源直接计算：

- 命中概率：`p = 片面积 / 束面积 = 100/144 = 0.6944444444444444`
- 期望命中事件数：`E[K] = N·p = 20000·100/144 = 13888.888888888889`
- 单次穿越径迹长度：片厚 0.1 mm（垂直入射）
- 期望总径迹长度：`E[ΣL] = N·p·0.1 = 1388.888888888889 mm`
- 期望注量：`E[Φ] = E[ΣL]/V = 1388.888888888889/10 = 138.88888888888889 mm⁻²`
- 单位权重下的观测标准差：`sd(Φ) = 0.1·sqrt(N·p(1−p))/V = 0.6514466333088097 mm⁻²`
- 单位换算：`1 cm⁻² = 0.01 mm⁻²`

`python reference.py --check` 的输出 `reference-recompute.json` 与冻结值**逐项双精度相等**
（`all_match = true`，6 项绝对差均为 0）。

## 4. 真实运行（`run_cases.py`）

命令（完整命令记录在 `results.json` 的 `command` 字段）：

```
out/collab/q2-backend-864bc036/G4UniversalSim.exe \
  --config out/collab/q2-reference-fluence-v1/inputs/main.ini \
  --macro  out/collab/q2-reference-fluence-v1/runs/ref_fluence_01/run.mac \
  --output out/collab/q2-reference-fluence-v1/runs/ref_fluence_01/output \
  --threads 1 --seed 20261110
```

`run.mac` 只有 `/run/initialize` 与 `/run/beamOn 20000`。环境：Geant4 `bin` 前缀进 `PATH`、
`GEANT4_DATA_DIR` 指向本机 11.3.2 数据。

结果：后端 **exit 0**、`completed_events = 20000`、耗时 1.636 s、`status = completed`、
`actual_threads = 1`、`physics_em = G4EmStandardPhysics_option4`、`output_failure_status = none`、
`scoring_fluence_enabled/scoring_hits_enabled = true`、`scoring_dose_enabled = false`。
产物：`run_summary.txt`、`run_metadata.json`、`hits_t0.csv`、`fluence_volume_summary_t0.csv`、
`scorer_statistics.csv`，另有 6 个 `effective_config_*.json`；全部 SHA 记录在 `results.json`。

**复用规则**：冻结文件、后端 exe、生成输入四类 SHA 与上次记录一致，且每个产物按记录 SHA/大小
仍存在、完成事件数一致时，`run_cases.py` 直接复用已记录的真实运行，不重跑同一模拟；
`--force` 才会重跑。本次交付记录 `reused = true`（此前唯一一次真实运行被完整保留）。

## 5. 六层证据比较（`compare.py`，122 项检查）

`compare.py` 只读原始输出与身份，不重新推理物理事实，按六层逐项检查并输出 `checks`：

- **ID（身份）**：冻结 SHA/schema/case、后端 build/exe SHA/源码指纹、Geant4 版本、数据检查、
  两个输入 SHA、后端字节重哈希。
- **IN（输入）**：仅电磁且无 `reference`、cut、scoring 开关、线程/种子、源 plane+square+halfx+
  无 halfy+center+direction+energy、世界尺寸/材料、片尺寸/位置/材料/sensitive/无 daughter、
  独立体积与束面积。
- **EVID（完成与证据）**：run_summary 必备字段、`status=completed`、`program_exit_code=0`、
  `output_failure_status=none`、macro/仿真完成、**实际完成 N=20000**、run_count=1、线程、物理/
  cut/scoring 字段；run_metadata 的 runs 与 `generated_files` 哈希（`run_metadata.json` 自身为
  `self_reference_excluded`，不参与自哈希）；记录的后端 exit、日志、五类产物 SHA。
- **MOM（原始矩）**：hits 表头精确匹配、仅 proton、仅 `Slab_PV`、单位权重、正步长、
  **按事件合并的穿越长度 = 0.1 mm**（不是把每步当完整厚度）、hits 行数≠事件数、
  Fluence CSV 表头/单行/体积/n_events/长度/体积除法/raw=weighted，以及**独立实现**
  `Σ(stepLength)/10 mm³` 与产品 Fluence 的 1e-9 及印刷精度比较。
- **STAT（统计）**：raw/weighted 两行：`unit=mm-2`、`estimator=total`、`n_events=20000`、
  `entries=13851`（有命中事件数）、`mean=value/N`、`rel_error` 与 `sqrt(1/K−1/N)` 一致、
  `std_error=rel_error·|value|`、`uncertainty_estimator=uncorrected_event_moments_v1`、
  `uncertainty_status=approximate`。
- **REF（冻结判据）**：`|Φ−N/面积| ≤ 1e-6·(N/面积) + 3σ_obs`，`σ_obs=|Φ|·rel_error`；
  K 的期望与 z 值**只作诊断输出，不设门槛**（K 是随机量，不要求 K=Np）。

结果：**status = pass，checks_total = 122，checks_failed = 0**。

## 6. 结果与判定

| 量 | 数值 |
| --- | --- |
| 命中事件 K | 13851（期望 13888.8889，sd 65.1447，z = −0.5816，仅诊断） |
| ΣL（产品 Fluence CSV） | 1385.1 mm |
| Φ（产品） | **138.51 mm⁻²**（raw = weighted） |
| Φ 独立重算（hits） | 1385.0999999998357/10 = 138.50999999998356 mm⁻² |
| 解析期望 N/面积 | 138.88888888888889 mm⁻² |
| 绝对偏差 | 0.3788888888888948（相对 0.002728） |
| σ_obs（本轮有效误差） | 0.6525710650958741 mm⁻²（rel_error 0.00471136427042 = sqrt(1/13851−1/20000)） |
| 允许误差 | 1.9578520841765115 = 1e-6·138.8889 + 3·0.652571… |
| 判定 | **通过**（0.3789 ≤ 1.9579） |

产品 Fluence 与 hits 按事件合并的独立复算差约 1e-14（远小于 1e-9 口径与印刷精度）。

## 7. 有限反例（`tamper.py`，7/7 检出）

所有反例只操作 `tampered/` 下的副本；原运行目录、`results.json`、冻结输入全程不改，
结束后原件 SHA 逐个复核一致（`tamper-results.json.originals_unchanged = true`）。

| 反例 | 缺陷 | 被检出检查（节选） |
| --- | --- | --- |
| `missing_metadata` | 删除 run_metadata.json | `EVID-METADATA-FILE` |
| `cm2_factor` | Fluence CSV 按 cm⁻²×100 误写 | `REF-DPHI-ABS`、`MOM-FLUENCE-RAW-DIVISION` |
| `volume_factor` | 体积因子重复（10→20 mm³） | `MOM-FLUENCE-VOLUME` |
| `reference_number` | 冻结参考 Φ 改为 148.8889 | `REF-DPHI-ABS` |
| `artifact_sha` | 改 hits 产物但记录 SHA 未变 | `EVID-ASSET-SHA-hits_t0.csv` |
| `path_per_event` | hits 步长 0.1→0.2 并同步记录 | `MOM-PATH-PER-EVENT` |
| `completed_events` | run_summary 完成数 20000→15000 | `EVID-COMPLETED` |

## 8. 复现命令

```bash
cd out/collab/q2-reference-fluence-v1
python -B setup_inputs.py --write        # 校验冻结/后端/数据身份，生成 inputs/ 与 identity.json
python -B reference.py --check --write   # 独立重算参考，写 reference-recompute.json
python -B run_cases.py                   # 真实运行；输入未变时复用记录，--force 才重跑
python -B compare.py --update            # 重算 122 项检查并写回 results.json
python -B tamper.py                      # 7 个副本反例 + 原件 SHA 复核
```

上述脚本均为标准库实现，无第三方依赖；`setup_inputs.py` 与 `run_cases.py` 需要冻结后端与
本机 Geant4 11.3.2 数据。

## 9. 文件清单（SHA-256 前 16 位）

| 文件 | 字节 | SHA-256 |
| --- | --- | --- |
| `setup_inputs.py` | 9413 | `bb835077c7a93511` |
| `reference.py` | 4858 | `2e49da92c615b3c7` |
| `run_cases.py` | 9064 | `848d21edf1b802fa` |
| `compare.py` | 33746 | `1bd545064adae519` |
| `tamper.py` | 9786 | `e01102e40186904d` |
| `identity.json` | 2197 | `7f7bb842c8b39707` |
| `reference-recompute.json` | 2069 | `50b1f6a1c6442ec0` |
| `results.json` | 28807 | `9e92a062196ea6b7` |
| `tamper-results.json` | 2747 | `d3fa430c13e62301` |
| `backend-data-check.txt` | 2240 | `ec86b695aebaa3a7` |
| `inputs/geometry.ini` | 226 | `cc7d1819f14627a6` |
| `inputs/main.ini` | 758 | `5571b5ee62461a0b` |
| `runs/ref_fluence_01/run.mac` | 72 | `440097d32e48fd45` |
| `runs/ref_fluence_01/backend.log` | 27887 | `857bf9f0864efcdd` |
| `runs/ref_fluence_01/output/hits_t0.csv` | 2145351 | `11268cef2edbdcd4` |
| `runs/ref_fluence_01/output/fluence_volume_summary_t0.csv` | 280 | `80e9cbe873192c3a` |
| `runs/ref_fluence_01/output/scorer_statistics.csv` | 596 | `8fd975951bc73344` |
| `runs/ref_fluence_01/output/run_summary.txt` | 12026 | `28e3f21b46b3e6a6` |
| `runs/ref_fluence_01/output/run_metadata.json` | 16726 | `d101fc97ea4202ea` |

## 10. 边界与非声明

- **仅电磁**：`G4EmStandardPhysics_option4`，不含任何强子/核物理过程；不涉及强子剂量。
- **仅均匀孔径模型**：世界与灵敏片均为 `G4_Galactic`，近似无散射、无衰减；本轮不验证
  有材料散射/衰减下的注量，也不验证非均匀束或非垂直入射。
- **注量定义**：产品 Fluence 是 `Σ(stepLength·weight)/volume` 的面积注量（mm⁻²），
  本病例中权重恒为 1；不是通量率、不是剂量、不是 NIEL。
- **统计口径**：K 是随机量，不要求 K=Np；`rel_error = sqrt(1/K−1/N)` 是本模型下的
  Bernoulli 观测误差，`uncertainty_status=approximate` 如实标注为未修正事件矩。
- **未改动产品/测试/正式基准/冻结合同/ROADMAP/STATUS**，未提交 Git；本目录位于被
  gitignore 的 `out/` 下。本交付**等待监督端独立复验**，不构成产品缺陷结论。
