"""Limited negative controls for the frozen REF-FLU-01 result.

Every counterexample works on a *copy* under ``tampered/``; the original run
directory, the recorded results and the frozen inputs are never modified.  Each
case must make the comparator fail on a check that is specific to the defect,
and the original output hashes must be byte-identical afterwards.
"""

from __future__ import annotations

import hashlib
import json
import shutil
import sys
from pathlib import Path

import compare

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-fluence-reference-freeze-v1.json"
CASE = "ref_fluence_01"
OUTPUTS = ("run_summary.txt", "run_metadata.json", "hits_t0.csv",
           "fluence_volume_summary_t0.csv", "scorer_statistics.csv")


def sha(path: Path) -> str:
    return compare.sha256(path)


def copy_tree(source: Path, target: Path) -> None:
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    for item in source.iterdir():
        if item.is_dir():
            shutil.copytree(item, target / item.name)
        else:
            shutil.copy2(item, target / item.name)


def rewrite_record(record: dict, output: Path, run_dir: Path) -> dict:
    record = json.loads(json.dumps(record))
    record["output_dir"] = compare.rel(output)
    record["run_dir"] = compare.rel(run_dir)
    record["run_summary_path"] = compare.rel(output / "run_summary.txt")
    record["run_metadata_path"] = compare.rel(output / "run_metadata.json")
    record["backend_log"] = compare.rel(run_dir / "backend.log")
    record["macro"]["path"] = compare.rel(run_dir / "run.mac")
    artifacts = {}
    for name in OUTPUTS:
        path = output / name
        artifacts[name] = {"path": compare.rel(path), "sha256": sha(path),
                           "size_bytes": path.stat().st_size}
    record["artifacts"] = artifacts
    return record


def refresh_metadata(output: Path) -> None:
    metadata_path = output / "run_metadata.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    for item in metadata.get("generated_files", []):
        name = Path(item.get("path", "")).name
        path = output / name
        if path.is_file() and item.get("sha256") is not None:
            item["sha256"] = sha(path)
            item["size_bytes"] = path.stat().st_size
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
                             encoding="utf-8")


def run_case(name: str, mutation, expected_ids: list[str]) -> dict:
    case_dir = BASE / "tampered" / name
    output = case_dir / "output"
    run_dir = case_dir / "run"
    copy_tree(ROOT / f"out/collab/q2-reference-fluence-v1/runs/{CASE}/output", output)
    copy_tree(ROOT / f"out/collab/q2-reference-fluence-v1/runs/{CASE}", run_dir)
    results = json.loads((BASE / "results.json").read_text(encoding="utf-8"))
    identity = json.loads(json.dumps(results["identity"]))
    record = rewrite_record(results["cases"][CASE], output, run_dir)
    identity["case"]["output_dir"] = compare.rel(output)
    identity["case"]["run_dir"] = compare.rel(run_dir)
    freeze_path = FREEZE
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    freeze_path = mutation(name, output, record, freeze, run_dir) or freeze_path
    if freeze_path != FREEZE:
        freeze = json.loads(Path(freeze_path).read_text(encoding="utf-8"))
    refreshed = refresh_metadata_candidate(output)
    if refreshed:
        record["artifacts"] = artifacts_of(output)
    results["cases"][CASE] = record
    results["identity"] = identity
    evaluation = compare.evaluate(results, freeze, identity)
    failed = evaluation["failed_ids"]
    detected = [cid for cid in expected_ids if cid in failed]
    return {
        "case": name,
        "expected_ids": expected_ids,
        "status": "pass" if evaluation["status"] == "fail" and detected else "fail",
        "evaluation_status": evaluation["status"],
        "failed_ids": failed,
        "detected": detected,
    }


def refresh_metadata_candidate(output: Path) -> bool:
    """Refresh metadata hashes after a mutation that rewrites an output file."""
    return (output / "run_metadata.json").is_file()


def artifacts_of(output: Path) -> dict:
    artifacts = {}
    for filename in OUTPUTS:
        path = output / filename
        artifacts[filename] = {"path": compare.rel(path), "sha256": sha(path),
                               "size_bytes": path.stat().st_size}
    return artifacts


def mutate_missing_metadata(name: str, output: Path, record: dict, freeze: dict, run_dir: Path):
    (output / "run_metadata.json").unlink()
    return None


def mutate_cm2_factor(name: str, output: Path, record: dict, freeze: dict, run_dir: Path):
    path = output / "fluence_volume_summary_t0.csv"
    lines = path.read_text(encoding="utf-8").splitlines()
    header = lines[0].split(",")
    values = lines[1].split(",")
    for column in ("raw_fluence_mm-2", "weighted_fluence_mm-2"):
        index = header.index(column)
        values[index] = f"{float(values[index]) * 100.0:g}"
    path.write_text("\n".join([lines[0], ",".join(values)]) + "\n", encoding="utf-8")
    refresh_metadata(output)
    return None


def mutate_volume_double(name: str, output: Path, record: dict, freeze: dict, run_dir: Path):
    path = output / "fluence_volume_summary_t0.csv"
    lines = path.read_text(encoding="utf-8").splitlines()
    header = lines[0].split(",")
    values = lines[1].split(",")
    values[header.index("volume_mm3")] = "20"
    path.write_text("\n".join([lines[0], ",".join(values)]) + "\n", encoding="utf-8")
    refresh_metadata(output)
    return None


def mutate_reference_number(name: str, output: Path, record: dict, freeze: dict, run_dir: Path):
    tampered = json.loads(json.dumps(freeze))
    tampered["reference"]["expected_fluence_mm_minus2"] = 148.88888888888889
    path = BASE / "tampered" / "reference_tampered.json"
    path.write_text(json.dumps(tampered, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return str(path)


def mutate_artifact_sha(name: str, output: Path, record: dict, freeze: dict, run_dir: Path):
    path = output / "hits_t0.csv"
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    header = lines[0].split(",")
    values = lines[2].split(",")
    values[header.index("edep_MeV")] = "1.0"
    lines[2] = ",".join(values)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return None


def mutate_path_per_event(name: str, output: Path, record: dict, freeze: dict, run_dir: Path):
    path = output / "hits_t0.csv"
    lines = path.read_text(encoding="utf-8").splitlines()
    header = lines[0].split(",")
    index = header.index("stepLength_mm")
    for row in range(1, len(lines)):
        values = lines[row].split(",")
        if row <= 10:
            values[index] = "0.2"
        lines[row] = ",".join(values)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    refresh_metadata(output)
    return None


def mutate_completed_events(name: str, output: Path, record: dict, freeze: dict, run_dir: Path):
    path = output / "run_summary.txt"
    text = path.read_text(encoding="utf-8")
    text = text.replace("actual_completed_event_count = 20000", "actual_completed_event_count = 15000")
    path.write_text(text, encoding="utf-8")
    record["completed_events"] = 15000
    record["artifacts"] = artifacts_of(output)
    return None


def main() -> int:
    original_results = (BASE / "results.json").read_bytes()
    original_record = json.loads((BASE / "results.json").read_text(encoding="utf-8"))["cases"][CASE]
    original_shas = {name: item["sha256"] for name, item in original_record["artifacts"].items()}
    cases = [
        ("missing_metadata", mutate_missing_metadata, ["EVID-METADATA-FILE"]),
        ("cm2_factor", mutate_cm2_factor,
         ["REF-DPHI-ABS", "MOM-FLUENCE-RAW-DIVISION"]),
        ("volume_factor", mutate_volume_double,
         ["MOM-FLUENCE-VOLUME", "MOM-FLUENCE-RAW-DIVISION"]),
        ("reference_number", mutate_reference_number, ["REF-DPHI-ABS"]),
        ("artifact_sha", mutate_artifact_sha,
         ["EVID-ASSET-SHA-hits_t0.csv", "EVID-RECORDED-hits_t0.csv"]),
        ("path_per_event", mutate_path_per_event, ["MOM-PATH-PER-EVENT"]),
        ("completed_events", mutate_completed_events, ["EVID-COMPLETED"]),
    ]
    results = []
    all_pass = True
    for name, mutation, expected in cases:
        outcome = run_case(name, mutation, expected)
        all_pass &= outcome["status"] == "pass"
        results.append(outcome)
        print(f"{name}: {outcome['status']} expected={expected} "
              f"detected={outcome['detected']} failed={outcome['failed_ids']}")
    # Originals must be untouched.
    after = json.loads((BASE / "results.json").read_text(encoding="utf-8"))["cases"][CASE]
    originals_ok = (BASE / "results.json").read_bytes() == original_results
    originals_ok &= all(sha(ROOT / item["path"]) == original_shas[name]
                        for name, item in original_record["artifacts"].items()
                        if (ROOT / item["path"]).is_file())
    report = {
        "schema": "g4usim_q2_ref_fluence_tamper_v1",
        "case": "REF-FLU-01",
        "status": "pass" if all_pass and originals_ok else "fail",
        "originals_unchanged": originals_ok,
        "cases": results,
    }
    (BASE / "tamper-results.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("tamper:", report["status"], "originals_unchanged:", originals_ok)
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
