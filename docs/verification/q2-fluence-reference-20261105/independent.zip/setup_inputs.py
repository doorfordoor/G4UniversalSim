"""Generate the single frozen REF-FLU-01 input set and record its identity.

Derived from
`docs/collab/decisions/20261105-q2-fluence-reference-freeze-v1.{md,json}` and the
frozen backend tree under `out/collab/q2-backend-864bc036/`.  The script refuses
to continue when the backend SHA-256 / build / source fingerprint or the Geant4
data completeness disagree with the frozen contract.  It writes inputs only: no
simulation is executed here.
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-fluence-v1"
INPUTS = BASE / "inputs"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-fluence-reference-freeze-v1.json"
BACKEND = ROOT / "out" / "collab" / "q2-backend-864bc036" / "G4UniversalSim.exe"
BACKEND_ID = ROOT / "out" / "collab" / "q2-backend-864bc036" / "identity.json"
GEANT4_PREFIX = Path("D:/ProgramFiles/Geant4")
GEANT4_DATA = GEANT4_PREFIX / "share" / "Geant4" / "data"
GEANT4_BIN = GEANT4_PREFIX / "bin"

FROZEN_BACKEND_SHA = "f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f"
FROZEN_GEANT4_VERSION = 1132
FROZEN_FREEZE_SHA = "d9ceb71f9cb6a3bcf4029010eb2bf2212c6b014dca9967b40277e01379b077b3"
CASE = "ref_fluence_01"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def env() -> dict:
    merged = os.environ.copy()
    merged["PATH"] = str(GEANT4_BIN) + os.pathsep + merged.get("PATH", "")
    merged["GEANT4_DATA_DIR"] = str(GEANT4_DATA)
    merged.pop("QT_QPA_PLATFORM", None)
    return merged


def run(command: list[str], timeout: int = 300) -> subprocess.CompletedProcess:
    return subprocess.run(
        command,
        cwd=str(ROOT),
        env=env(),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )


def render_geometry(freeze: dict) -> str:
    world_x, world_y, world_z = freeze["world_size_mm"]
    slab_x, slab_y, slab_z = freeze["sensitive_dimensions_mm"]
    px, py, pz = freeze["sensitive_position_mm"]
    return f"""[world]
shape = box
size = {world_x} mm, {world_y} mm, {world_z} mm
material = {freeze['world_material']}

[volume.Slab]
parent = world
shape = box
size = {slab_x:g} mm, {slab_y:g} mm, {slab_z:g} mm
material = {freeze['sensitive_material']}
position = {px:g} mm, {py:g} mm, {pz:g} mm
sensitive = true
"""


def render_main(freeze: dict, output_dir: Path) -> str:
    source = freeze["source"]
    center = ", ".join(f"{item:g}" for item in source["center_mm"])
    direction = ", ".join(f"{item:g}" for item in source["direction"])
    return f"""[run]
name = {CASE}
threads = {int(freeze['threads'])}
seed = {int(freeze['seed'])}
interactive = false
verbose = 0
check_overlaps = false
dry_run = false

[output]
dir = {output_dir.as_posix()}
format = csv

[geometry]
template = hierarchical
config = {(INPUTS / 'geometry.ini').as_posix()}
default_world_material = {freeze['world_material']}

[physics]
em = {freeze['physics_em']}
default_cut = {freeze['default_cut']}

[scoring]
enabled = true
hits = {str(bool(freeze['scoring']['hits'])).lower()}
event_edep = false
edep = false
dose = false
fluence = {str(bool(freeze['scoring']['fluence'])).lower()}
auto_create_default_scorers = true

[source]
particle = {source['particle']}
energy = {float(source['energy_MeV']):g} MeV
position_type = {source['position_type']}
shape = {source['shape']}
halfx = {float(source['halfx_mm']):g} mm
center = {center} mm
direction = {direction}
"""


def main() -> int:
    freeze_text = FREEZE.read_text(encoding="utf-8")
    freeze_sha = hashlib.sha256(freeze_text.encode("utf-8")).hexdigest()
    freeze = json.loads(freeze_text)
    if freeze.get("schema") != "q2_reference_fluence_freeze_v1":
        raise SystemExit("unexpected freeze schema")
    if freeze.get("case") != "REF-FLU-01":
        raise SystemExit("unexpected freeze case")
    if freeze_sha != FROZEN_FREEZE_SHA:
        raise SystemExit("frozen decision file sha256 mismatch")
    if not BACKEND.is_file():
        raise SystemExit(f"frozen backend missing: {BACKEND}")
    if sha256(BACKEND) != FROZEN_BACKEND_SHA:
        raise SystemExit("frozen backend sha256 mismatch")
    backend_identity = json.loads(BACKEND_ID.read_text(encoding="utf-8"))
    capabilities = json.loads(run([str(BACKEND), "--capabilities"]).stdout.decode("utf-8"))
    if capabilities["build_git_commit"] != freeze["backend_build"]:
        raise SystemExit("backend build does not match the freeze")
    if capabilities["source_fingerprint"] != backend_identity["source_fingerprint"]:
        raise SystemExit("backend fingerprint changed since the frozen recording")
    if int(capabilities["geant4_version_number"]) != FROZEN_GEANT4_VERSION:
        raise SystemExit("Geant4 version does not match the frozen evidence level")
    check = run([str(BACKEND), "--check-geant4-data"])
    check_text = check.stdout.decode("utf-8", errors="replace")
    (BASE / "backend-data-check.txt").write_text(check_text, encoding="utf-8")
    if check.returncode != 0 or '"required_complete": true' not in check_text:
        raise SystemExit(f"--check-geant4-data not complete: exit={check.returncode}\n{check_text}")

    slab_x, slab_y, slab_z = (float(item) for item in freeze["sensitive_dimensions_mm"])
    volume_mm3 = slab_x * slab_y * slab_z
    area_mm2 = slab_x * slab_y
    beam_area_mm2 = float(freeze["source"]["area_mm2"])
    halfx = float(freeze["source"]["halfx_mm"])
    if abs(volume_mm3 - float(freeze["sensitive_volume_mm3"])) > 1e-12:
        raise SystemExit("sensitive volume does not match the freeze")
    if abs(area_mm2 - float(freeze["sensitive_area_mm2"])) > 1e-12:
        raise SystemExit("sensitive area does not match the freeze")
    if abs(beam_area_mm2 - (2.0 * halfx) ** 2) > 1e-12:
        raise SystemExit("square beam area does not match (2*halfx)^2")
    p = area_mm2 / beam_area_mm2
    if abs(p - float(freeze["reference"]["hit_probability"])) > 1e-15:
        raise SystemExit("hit probability does not match the freeze")

    INPUTS.mkdir(parents=True, exist_ok=True)
    run_dir = BASE / "runs" / CASE
    output_dir = run_dir / "output"
    output_dir.mkdir(parents=True, exist_ok=True)
    files = {
        "geometry.ini": render_geometry(freeze),
        "main.ini": render_main(freeze, output_dir),
    }
    for name, content in files.items():
        (INPUTS / name).write_text(content, encoding="utf-8")

    identity = {
        "schema": "g4usim_q2_ref_fluence_identity_v1",
        "generated_at": now(),
        "freeze_case": freeze["case"],
        "workspace": str(ROOT).replace("\\", "/"),
        "freeze": {
            "path": str(FREEZE.relative_to(ROOT)).replace("\\", "/"),
            "sha256": freeze_sha,
            "schema": freeze["schema"],
        },
        "backend": {
            "path": str(BACKEND.relative_to(ROOT)).replace("\\", "/"),
            "sha256": sha256(BACKEND),
            "bytes": BACKEND.stat().st_size,
            "build_git_commit": capabilities["build_git_commit"],
            "source_fingerprint": capabilities["source_fingerprint"],
            "geant4_version_number": capabilities["geant4_version_number"],
            "compiler_id": capabilities["compiler_id"],
        },
        "geant4": {
            "prefix": str(GEANT4_PREFIX),
            "data": str(GEANT4_DATA),
            "data_check_exit": check.returncode,
            "data_check_sha256": sha256(BASE / "backend-data-check.txt"),
        },
        "inputs": {
            name: {
                "path": str((INPUTS / name).relative_to(ROOT)).replace("\\", "/"),
                "sha256": sha256(INPUTS / name),
            }
            for name in files
        },
        "geometry_volume_mm3": volume_mm3,
        "sensitive_area_mm2": area_mm2,
        "beam_area_mm2": beam_area_mm2,
        "case": {
            "case": CASE,
            "seed": int(freeze["seed"]),
            "threads": int(freeze["threads"]),
            "events": int(freeze["events"]),
            "main_ini": str((INPUTS / "main.ini").relative_to(ROOT)).replace("\\", "/"),
            "geometry_ini": str((INPUTS / "geometry.ini").relative_to(ROOT)).replace("\\", "/"),
            "output_dir": str(output_dir.relative_to(ROOT)).replace("\\", "/"),
            "run_dir": str(run_dir.relative_to(ROOT)).replace("\\", "/"),
        },
        "environment": {
            "GEANT4_DATA_DIR": str(GEANT4_DATA),
            "PATH_prefix": str(GEANT4_BIN),
            "platform": "Windows",
            "cwd": str(ROOT),
        },
    }
    (BASE / "identity.json").write_text(
        json.dumps(identity, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(identity, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
