"""Fixed aperture-case verification from hits, without product imports."""
from collections import defaultdict
from pathlib import Path
import csv
import hashlib
import json
import math

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
checks = []


def require(name, valid):
    checks.append({"id": name, "status": "pass" if valid else "fail"})
    assert valid, name


def close(a, b):
    return math.isfinite(a) and math.isfinite(b) and abs(a - b) <= 1e-9 * max(abs(a), abs(b), 1e-300)


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def main():
    path = ROOT / "docs/collab/decisions/20261105-q2-fluence-reference-freeze-v1.json"
    require("freeze-sha", hashlib.sha256(path.read_bytes()).hexdigest() == "d9ceb71f9cb6a3bcf4029010eb2bf2212c6b014dca9967b40277e01379b077b3")
    f = json.loads(path.read_text(encoding="utf-8-sig"))
    n = f["events"]
    volume = math.prod(f["sensitive_dimensions_mm"])
    thickness = f["sensitive_dimensions_mm"][2]
    target_area = math.prod(f["sensitive_dimensions_mm"][:2])
    beam_area = (2 * f["source"]["halfx_mm"])**2
    probability = target_area / beam_area
    expected = n / beam_area
    require("reference-volume", close(volume, f["sensitive_volume_mm3"]))
    require("reference-probability", close(probability, f["reference"]["hit_probability"]))
    require("reference-mean", close(expected, f["reference"]["expected_fluence_mm_minus2"]))
    require("reference-cm-to-mm", f["reference"]["cm_minus2_to_mm_minus2"] == 0.01)
    output = BASE / "runs/ref_fluence_01/output"
    hits = rows(output / "hits_t0.csv")
    require("hits-scope", bool(hits) and all(row["volume"] == "Slab_PV" and row["particle"] == "proton" for row in hits))
    require("unit-weights", all(float(row["weight"]) == 1 for row in hits))
    event_lengths, event_precision = defaultdict(list), defaultdict(list)
    for row in hits:
        event, length = int(row["eventID"]), float(row["stepLength_mm"])
        assert 0 <= event < n and math.isfinite(length) and length > 0
        event_lengths[event].append(length)
        event_precision[event].append(0.5 * 10**(math.floor(math.log10(length)) - 11))
    per_event = {event: math.fsum(values) for event, values in event_lengths.items()}
    require("straight-event-traversals", all(abs(length - thickness) <= math.fsum(event_precision[event]) + 1e-15 for event, length in per_event.items()))
    k = len(per_event)
    total = math.fsum(per_event.values())
    squares = math.fsum(length**2 for length in per_event.values())
    observed = total / volume
    relative_error = math.sqrt(squares / total**2 - 1 / n)
    require("bernoulli-event-error", close(relative_error, math.sqrt(1 / k - 1 / n)))
    summary = next(row for row in rows(output / "fluence_volume_summary_t0.csv") if row["volume_name"] == "Slab_PV")
    require("summary-volume", close(float(summary["volume_mm3"]), volume))
    require("summary-N", int(summary["n_events"]) == n)
    for prefix in ["raw", "weighted"]:
        require(prefix + ":length", close(float(summary[prefix + "_track_length_mm"]), total))
        require(prefix + ":length-squares", close(float(summary[prefix + "_track_length_sum_sq_mm2"]), squares))
        require(prefix + ":fluence", close(float(summary[prefix + "_fluence_mm-2"]), observed))
        stat = next(row for row in rows(output / "scorer_statistics.csv") if row["scorer"] == "fluence" and row["quantity"] == prefix + "_fluence")
        require(prefix + ":N-and-entries", int(stat["n_events"]) == n and int(stat["entries"]) == k)
        require(prefix + ":stat-value", close(float(stat["value"]), observed))
        require(prefix + ":stat-event-squares", close(float(stat["sum_sq"]), squares / volume**2))
        require(prefix + ":stat-rel-error", close(float(stat["rel_error"]), relative_error))
        require(prefix + ":stat-standard-error", close(float(stat["std_error"]), observed * relative_error))
    sigma = observed * relative_error
    threshold = 1e-6 * expected + 3 * sigma
    require("physical-reference", abs(observed - expected) <= threshold)
    theoretical_sigma = math.sqrt(n * probability * (1 - probability)) / target_area
    require("reference-theoretical-sigma", close(theoretical_sigma, f["reference"]["theoretical_sd_fluence_mm_minus2"]))
    report = {"schema": "q2_fluence_independent_hit_math_v1", "status": "pass", "scope": "one fixed Galactic aperture case; no confidence-coverage claim", "checks": checks, "N": n, "K": k, "expected_K": n * probability, "volume_mm3": volume, "total_path_mm": total, "fluence_mm_minus2": observed, "expected_fluence_mm_minus2": expected, "observed_sigma": sigma, "theoretical_sigma": theoretical_sigma, "relative_error": relative_error, "threshold": threshold}
    (BASE / "independent-math-results.json").write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print("independent math passed", len(checks), "checks; K", k, "of", n, "fluence", observed)


if __name__ == "__main__":
    main()
