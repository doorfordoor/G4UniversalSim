"""Recompute the REF-FLU-01 analytic reference from the frozen geometry only.

There is no measured table and no fit here: a uniform 12 mm x 12 mm proton beam
covers a 10 mm x 10 mm slab, so the hit probability and the track-length
fluence expectation follow from geometry.  The script reproduces every frozen
reference number from the dimensions and compares it with the decision file; it
never runs the simulation.  ``--check`` exits non-zero when the recomputation
and the frozen values disagree.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-fluence-v1"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-fluence-reference-freeze-v1.json"


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def recompute(freeze: dict) -> dict:
    slab_x, slab_y, slab_z = (float(item) for item in freeze["sensitive_dimensions_mm"])
    halfx = float(freeze["source"]["halfx_mm"])
    events = int(freeze["events"])
    volume_mm3 = slab_x * slab_y * slab_z
    area_mm2 = slab_x * slab_y
    beam_area_mm2 = (2.0 * halfx) ** 2
    p = area_mm2 / beam_area_mm2
    expected_path_mm = events * p * slab_z
    expected_fluence = expected_path_mm / volume_mm3
    theoretical_sd = math.sqrt(events * p * (1.0 - p)) / area_mm2
    return {
        "sensitive_volume_mm3": volume_mm3,
        "sensitive_area_mm2": area_mm2,
        "beam_area_mm2": beam_area_mm2,
        "hit_probability": p,
        "expected_hits": events * p,
        "expected_total_path_mm": expected_path_mm,
        "expected_fluence_mm_minus2": expected_fluence,
        "theoretical_sd_fluence_mm_minus2": theoretical_sd,
        "cm_minus2_to_mm_minus2": 1.0 / 100.0,
        "events": events,
    }


def close(reported: float, recomputed: float) -> bool:
    # The frozen JSON carries the exact doubles produced by the same arithmetic;
    # compare bit-for-bit on the decimal text so no tolerance can hide a change.
    return float(reported) == float(recomputed)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="exit non-zero when the recomputation disagrees")
    args = parser.parse_args(argv)
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    recomputed = recompute(freeze)
    frozen = freeze["reference"]
    pairs = {
        "hit_probability": (frozen["hit_probability"], recomputed["hit_probability"]),
        "expected_hits": (frozen["expected_hits"], recomputed["expected_hits"]),
        "expected_total_path_mm": (frozen["expected_total_path_mm"], recomputed["expected_total_path_mm"]),
        "expected_fluence_mm_minus2": (
            frozen["expected_fluence_mm_minus2"], recomputed["expected_fluence_mm_minus2"]),
        "theoretical_sd_fluence_mm_minus2": (
            frozen["theoretical_sd_fluence_mm_minus2"], recomputed["theoretical_sd_fluence_mm_minus2"]),
        "cm_minus2_to_mm_minus2": (
            frozen["cm_minus2_to_mm_minus2"], recomputed["cm_minus2_to_mm_minus2"]),
    }
    deltas = {}
    matches = True
    for key, (mine, frozen_value) in pairs.items():
        matches = matches and close(frozen_value, mine)
        deltas[key] = {
            "frozen": float(frozen_value),
            "recomputed": float(mine),
            "absolute_delta": float(mine) - float(frozen_value),
            "matches": close(frozen_value, mine),
        }
    report = {
        "schema": "g4usim_q2_ref_fluence_recompute_v1",
        "case": freeze["case"],
        "generated_at": now(),
        "reference_path": str(FREEZE.relative_to(ROOT)).replace("\\", "/"),
        "reference_sha256": __import__("hashlib").sha256(FREEZE.read_bytes()).hexdigest(),
        "inputs_used": {
            "sensitive_dimensions_mm": [float(item) for item in freeze["sensitive_dimensions_mm"]],
            "halfx_mm": float(freeze["source"]["halfx_mm"]),
            "events": int(freeze["events"]),
            "sensitive_volume_mm3_from_freeze": float(freeze["sensitive_volume_mm3"]),
            "sensitive_area_mm2_from_freeze": float(freeze["sensitive_area_mm2"]),
            "source_area_mm2_from_freeze": float(freeze["source"]["area_mm2"]),
        },
        "recomputed": recomputed,
        "comparison": deltas,
        "all_match": matches,
    }
    (BASE / "reference-recompute.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps({"all_match": matches, "recomputed": recomputed, "deltas": deltas}, indent=2))
    return 0 if (matches or not args.check) else 1


if __name__ == "__main__":
    raise SystemExit(main())
