"""Evaluate REF-FLU-01: identity gate, run evidence, implementation, then physics.

Order matters.  The analytic reference may only be compared after the frozen
backend/inputs are identified, the run really completed at the frozen sample
size, and every compared number comes from that run.  The random hit count K is
a diagnostic (binomial): it is reported but never required to equal N*p.

The independent implementation check recomputes the track-length fluence as
``sum(stepLength over hits) / volume`` (the volume is taken from the frozen
geometry, not from the output CSV) and also checks that every crossing event
contributes one straight 0.1 mm traversal, not "every step is a full thickness".
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-fluence-v1"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-fluence-reference-freeze-v1.json"
FROZEN_BACKEND_SHA = "f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f"
FROZEN_GEANT4_VERSION = 1132
SIG_DIGITS = 12
RELATIVE_TOLERANCE = 1e-6
IMPLEMENTATION_TOLERANCE = 1e-9
EXPECTED_OUTPUTS = (
    "run_summary.txt",
    "run_metadata.json",
    "hits_t0.csv",
    "fluence_volume_summary_t0.csv",
    "scorer_statistics.csv",
)

HITS_HEADER = [
    "runID", "eventID", "trackID", "parentID", "particle", "edep_MeV", "ndep_MeV",
    "stepLength_mm", "x0_mm", "y0_mm", "z0_mm", "x1_mm", "y1_mm", "z1_mm",
    "px", "py", "pz", "kineticEnergy_MeV", "process", "volume", "weight",
]
FLUENCE_HEADER = [
    "runID", "volume_path", "volume_name", "volume_mm3", "raw_track_length_mm",
    "weighted_track_length_mm", "raw_fluence_mm-2", "weighted_fluence_mm-2",
    "raw_track_length_sum_sq_mm2", "weighted_track_length_sum_sq_mm2", "n_events",
]
STAT_HEADER = [
    "runID", "scorer", "quantity", "key", "name", "unit", "estimator", "n_events",
    "entries", "value", "mean_per_event", "std_error", "rel_error", "fom_per_s",
    "run_wall_time_s", "sum", "sum_sq", "uncertainty_estimator", "uncertainty_status",
]
REQUIRED_SUMMARY_FIELDS = [
    "status", "summary_write_status", "output_failure_status", "macro_execution_status",
    "simulation_executed", "program_exit_code", "run_count", "actual_completed_event_count",
    "actual_threads", "physics_em", "physics_default_cut", "scoring_fluence_enabled",
    "scoring_hits_enabled", "scoring_dose_enabled", "effective_scoring_enabled",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def numbers(text: str) -> list[float]:
    """Numbers from a generated field such as ``0, 0, -2 mm``."""
    cleaned = [token.replace("mm", "").replace("MeV", "").strip()
               for token in str(text).replace(",", " ").split()]
    return [float(token) for token in cleaned if token]


def half_width(value: float) -> float:
    """Half width of a decimal printed with 12 significant digits."""
    if value == 0.0 or not math.isfinite(value):
        return 0.0
    return 0.5 * 10.0 ** (math.floor(math.log10(abs(value))) - (SIG_DIGITS - 1))


def close_enough(reported: str | float, recomputed: float,
                 *, relative: float = IMPLEMENTATION_TOLERANCE) -> tuple[bool, float]:
    value = float(reported)
    bound = relative * max(abs(value), abs(recomputed)) + half_width(value) + half_width(recomputed)
    delta = abs(value - recomputed)
    return delta <= bound, delta


def parse_run_summary(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        text = line.strip()
        if not text or text.startswith("[") or text.startswith("#") or "=" not in text:
            continue
        key, value = text.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        return list(reader.fieldnames or []), list(reader)


def parse_simple_ini(path: Path) -> dict[str, dict[str, str]]:
    sections: dict[str, dict[str, str]] = {}
    current = ""
    for line in path.read_text(encoding="utf-8").splitlines():
        text = line.strip()
        if not text or text.startswith("#"):
            continue
        if text.startswith("[") and text.endswith("]"):
            current = text[1:-1].strip()
            sections.setdefault(current, {})
            continue
        if "=" in text and current:
            key, value = text.split("=", 1)
            sections[current][key.strip()] = value.strip()
    return sections


def check(checks: list[dict], cid: str, ok: bool, detail: str) -> bool:
    checks.append({"id": cid, "status": "pass" if ok else "fail", "detail": detail})
    return ok


def rel(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(ROOT.resolve())).replace("\\", "/")
    except ValueError:
        return str(path)


def verify_identity(identity: dict, freeze: dict, checks: list[dict]) -> bool:
    ok = True
    backend = identity.get("backend", {})
    expected_sha = backend.get("sha256")
    ok &= check(checks, "ID-BACKEND-SHA", expected_sha == FROZEN_BACKEND_SHA,
                f"sha256={expected_sha}")
    ok &= check(checks, "ID-BUILD-COMMIT", backend.get("build_git_commit") == freeze["backend_build"],
                f"build_git_commit={backend.get('build_git_commit')}")
    ok &= check(checks, "ID-SOURCE-FINGERPRINT",
                isinstance(backend.get("source_fingerprint"), str)
                and len(backend["source_fingerprint"]) == 64,
                f"source_fingerprint={backend.get('source_fingerprint')}")
    ok &= check(checks, "ID-GEANT4-VERSION",
                int(backend.get("geant4_version_number", -1)) == FROZEN_GEANT4_VERSION,
                f"geant4_version_number={backend.get('geant4_version_number')}")
    freeze_info = identity.get("freeze", {})
    actual_freeze_sha = sha256(FREEZE)
    ok &= check(checks, "ID-FREEZE-SHA", freeze_info.get("sha256") == actual_freeze_sha,
                f"identity={freeze_info.get('sha256')} actual={actual_freeze_sha}")
    ok &= check(checks, "ID-FREEZE-SCHEMA", freeze_info.get("schema") == freeze["schema"],
                f"schema={freeze_info.get('schema')}")
    ok &= check(checks, "ID-FREEZE-CASE", freeze.get("case") == "REF-FLU-01",
                f"case={freeze.get('case')}")
    geant4 = identity.get("geant4", {})
    backend_sha = sha256(ROOT / backend["path"]) if backend.get("path") else None
    ok &= check(checks, "ID-BACKEND-BYTES", backend_sha == FROZEN_BACKEND_SHA,
                f"recomputed={backend_sha}")
    ok &= check(checks, "ID-DATA-CHECK", int(geant4.get("data_check_exit", 1)) == 0,
                f"data_check_exit={geant4.get('data_check_exit')}")
    for name, item in sorted(identity.get("inputs", {}).items()):
        path = ROOT / item["path"]
        actual = sha256(path) if path.is_file() else None
        ok &= check(checks, f"ID-INPUT-{name}", actual == item.get("sha256"),
                    f"path={item['path']} recorded={item.get('sha256')} actual={actual}")
    return bool(ok)


def verify_inputs(identity: dict, freeze: dict, checks: list[dict]) -> bool:
    ok = True
    case = identity["case"]
    main = parse_simple_ini(ROOT / case["main_ini"])
    geometry = parse_simple_ini(ROOT / case["geometry_ini"])
    run = main.get("run", {})
    physics = main.get("physics", {})
    scoring = main.get("scoring", {})
    source = main.get("source", {})
    source_freeze = freeze["source"]
    ok &= check(checks, "IN-PHYSICS-EM-ONLY",
                physics.get("em") == freeze["physics_em"] and "reference" not in physics,
                f"em={physics.get('em')} reference={physics.get('reference')}")
    ok &= check(checks, "IN-CUT", physics.get("default_cut") == freeze["default_cut"],
                f"default_cut={physics.get('default_cut')}")
    ok &= check(checks, "IN-SCORING",
                scoring.get("enabled") == "true"
                and scoring.get("fluence") == "true"
                and scoring.get("hits") == "true"
                and scoring.get("dose") == "false"
                and scoring.get("edep") == "false"
                and scoring.get("event_edep") == "false"
                and scoring.get("auto_create_default_scorers") == "true",
                f"scoring={scoring}")
    ok &= check(checks, "IN-THREADS", int(run.get("threads", -1)) == int(freeze["threads"]),
                f"threads={run.get('threads')}")
    ok &= check(checks, "IN-SEED", int(run.get("seed", -1)) == int(freeze["seed"]),
                f"seed={run.get('seed')}")
    ok &= check(checks, "IN-SOURCE-PLANE",
                source.get("position_type") == source_freeze["position_type"]
                and source.get("shape") == source_freeze["shape"]
                and source.get("particle") == source_freeze["particle"],
                f"particle={source.get('particle')} position_type={source.get('position_type')} "
                f"shape={source.get('shape')}")
    halfx = numbers(source.get("halfx", ""))
    ok &= check(checks, "IN-SOURCE-HALFX",
                len(halfx) == 1 and abs(halfx[0] - float(source_freeze["halfx_mm"])) <= 1e-12,
                f"halfx={source.get('halfx')}")
    ok &= check(checks, "IN-SOURCE-NO-HALFY", "halfy" not in source,
                "square source must not carry halfy (backend rejects it)")
    center = numbers(source.get("center", ""))
    ok &= check(checks, "IN-SOURCE-CENTER",
                center == [float(item) for item in source_freeze["center_mm"]],
                f"center={center} expected={source_freeze['center_mm']}")
    direction = numbers(source.get("direction", ""))
    ok &= check(checks, "IN-SOURCE-DIRECTION",
                direction == [float(item) for item in source_freeze["direction"]],
                f"direction={direction}")
    energy = numbers(source.get("energy", ""))
    ok &= check(checks, "IN-SOURCE-ENERGY",
                len(energy) == 1 and abs(energy[0] - float(source_freeze["energy_MeV"])) <= 1e-12,
                f"energy={source.get('energy')}")
    world = geometry.get("world", {})
    ok &= check(checks, "IN-WORLD-SIZE",
                numbers(world.get("size", "")) == [float(item) for item in freeze["world_size_mm"]],
                f"world size={world.get('size')}")
    ok &= check(checks, "IN-WORLD-MATERIAL", world.get("material") == freeze["world_material"],
                f"world material={world.get('material')}")
    slab = geometry.get("volume.Slab", {})
    ok &= check(checks, "IN-SLAB-SIZE",
                numbers(slab.get("size", ""))
                == [float(item) for item in freeze["sensitive_dimensions_mm"]],
                f"slab size={slab.get('size')}")
    ok &= check(checks, "IN-SLAB-POSITION",
                numbers(slab.get("position", ""))
                == [float(item) for item in freeze["sensitive_position_mm"]],
                f"slab position={slab.get('position')}")
    ok &= check(checks, "IN-SLAB-MATERIAL", slab.get("material") == freeze["sensitive_material"],
                f"slab material={slab.get('material')}")
    ok &= check(checks, "IN-SLAB-SENSITIVE", slab.get("sensitive", "").lower() == "true",
                f"sensitive={slab.get('sensitive')}")
    ok &= check(checks, "IN-SLAB-NO-CHILDREN",
                not any(key.startswith("volume.") and key != "volume.Slab" for key in geometry),
                "the fluence scorer requires a daughter-free sensitive solid")
    ok &= check(checks, "IN-VOLUME", abs(float(identity["geometry_volume_mm3"])
                                         - float(freeze["sensitive_volume_mm3"])) <= 1e-12,
                f"geometry_volume_mm3={identity['geometry_volume_mm3']}")
    ok &= check(checks, "IN-BEAM-AREA", abs(float(identity["beam_area_mm2"])
                                            - float(source_freeze["area_mm2"])) <= 1e-12,
                f"beam_area_mm2={identity['beam_area_mm2']}")
    return bool(ok)


def verify_case_evidence(case: dict, freeze: dict, checks: list[dict]) -> bool:
    ok = True
    output = ROOT / case["output_dir"]
    n_events = int(freeze["events"])
    summary_path = output / "run_summary.txt"
    metadata_path = output / "run_metadata.json"
    ok &= check(checks, "EVID-SUMMARY-FILE", summary_path.is_file(),
                f"path={rel(summary_path)}")
    ok &= check(checks, "EVID-METADATA-FILE", metadata_path.is_file(),
                f"path={rel(metadata_path)}")
    summary = parse_run_summary(summary_path) if summary_path.is_file() else {}
    for field in REQUIRED_SUMMARY_FIELDS:
        ok &= check(checks, f"EVID-SUMMARY-{field}",
                    field in summary and summary[field] not in ("", "unknown"),
                    f"{field}={summary.get(field)}")
    ok &= check(checks, "EVID-STATUS", summary.get("status") == "completed",
                f"status={summary.get('status')}")
    ok &= check(checks, "EVID-EXIT", summary.get("program_exit_code") == "0",
                f"program_exit_code={summary.get('program_exit_code')}")
    ok &= check(checks, "EVID-OUTPUT-FAILURE", summary.get("output_failure_status") == "none",
                f"output_failure_status={summary.get('output_failure_status')}")
    ok &= check(checks, "EVID-MACRO", summary.get("macro_execution_status") == "completed",
                f"macro_execution_status={summary.get('macro_execution_status')}")
    ok &= check(checks, "EVID-SIMULATION", summary.get("simulation_executed") == "true",
                f"simulation_executed={summary.get('simulation_executed')}")
    ok &= check(checks, "EVID-COMPLETED", summary.get("actual_completed_event_count") == str(n_events),
                f"actual_completed_event_count={summary.get('actual_completed_event_count')}")
    ok &= check(checks, "EVID-RUN-COUNT", summary.get("run_count") == "1",
                f"run_count={summary.get('run_count')}")
    ok &= check(checks, "EVID-THREADS", summary.get("actual_threads") == str(int(freeze["threads"])),
                f"actual_threads={summary.get('actual_threads')}")
    ok &= check(checks, "EVID-PHYSICS-EM", summary.get("physics_em") == "G4EmStandardPhysics_option4",
                f"physics_em={summary.get('physics_em')}")
    cut_mm = float(str(summary.get("physics_default_cut", "nan")))
    expected_cut_mm = float(str(freeze["default_cut"]).split()[0])
    ok &= check(checks, "EVID-CUT", abs(cut_mm - expected_cut_mm) <= 1e-12,
                f"physics_default_cut={cut_mm} expected={expected_cut_mm} mm")
    ok &= check(checks, "EVID-SCORING",
                summary.get("scoring_fluence_enabled") == "true"
                and summary.get("scoring_hits_enabled") == "true"
                and summary.get("scoring_dose_enabled") == "false",
                f"fluence={summary.get('scoring_fluence_enabled')} "
                f"hits={summary.get('scoring_hits_enabled')} dose={summary.get('scoring_dose_enabled')}")
    metadata_ok = False
    if metadata_path.is_file():
        try:
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            runs = metadata.get("runs", [])
            ok_runs = (len(runs) == 1
                       and int(runs[0].get("planned_events", -1)) == n_events
                       and int(runs[0].get("completed_events", -1)) == n_events)
            generated = metadata.get("generated_files", [])
            recorded = {Path(item.get("path", "")).name: item for item in generated}
            ok_artifacts = True
            for name in EXPECTED_OUTPUTS:
                item = recorded.get(name)
                path = output / name
                if item is None or not path.is_file():
                    ok_artifacts = False
                    ok &= check(checks, f"EVID-ASSET-FILE-{name}", False,
                                f"metadata/files missing for {name}")
                    continue
                if name == "run_metadata.json":
                    # The metadata file cannot hash itself; it declares that exclusion.
                    ok_artifacts &= check(
                        checks, "EVID-ASSET-run_metadata.json",
                        item.get("integrity_status") == "self_reference_excluded"
                        and item.get("sha256") is None,
                        f"integrity_status={item.get('integrity_status')} sha={item.get('sha256')}")
                    continue
                actual = sha256(path)
                ok_artifacts &= check(checks, f"EVID-ASSET-SHA-{name}",
                                      item.get("sha256") == actual
                                      and int(item.get("size_bytes", -1)) == path.stat().st_size,
                                      f"recorded={item.get('sha256')} actual={actual} "
                                      f"size={item.get('size_bytes')}/{path.stat().st_size}")
            metadata_ok = ok_runs and ok_artifacts
            ok &= check(checks, "EVID-METADATA-RUNS", ok_runs,
                        f"runs={[(r.get('run_id'), r.get('planned_events'), r.get('completed_events')) for r in runs]}")
        except (json.JSONDecodeError, KeyError, TypeError) as exc:
            ok &= check(checks, "EVID-METADATA-PARSE", False, f"metadata unreadable: {exc}")
    for name in EXPECTED_OUTPUTS:
        path = output / name
        ok &= check(checks, f"EVID-FILE-{name}", path.is_file(),
                    f"path={rel(path)} size={path.stat().st_size if path.is_file() else 'missing'}")
    record = case
    ok &= check(checks, "EVID-BACKEND-EXIT", int(record.get("exit_code", -1)) == 0,
                f"exit_code={record.get('exit_code')}")
    log_path = ROOT / record.get("backend_log", "")
    ok &= check(checks, "EVID-BACKEND-LOG", log_path.is_file(),
                f"path={record.get('backend_log')}")
    for name in EXPECTED_OUTPUTS:
        item = record.get("artifacts", {}).get(name)
        path = output / name
        if item is None or not path.is_file():
            ok &= check(checks, f"EVID-RECORDED-{name}", False, f"record missing {name}")
            continue
        ok &= check(checks, f"EVID-RECORDED-{name}",
                    item.get("sha256") == sha256(path),
                    f"recorded={item.get('sha256')} actual={sha256(path)}")
    return bool(ok)


def read_hits(output: Path, freeze: dict, checks: list[dict]) -> dict:
    ok = True
    path = output / "hits_t0.csv"
    header: list[str] = []
    rows: list[dict[str, str]] = []
    if path.is_file():
        header, rows = read_csv(path)
    ok &= check(checks, "MOM-HITS-HEADER", header == HITS_HEADER, f"header={header}")
    slab = freeze["sensitive_dimensions_mm"]
    thickness = float(slab[2])
    per_event: dict[int, float] = {}
    events: set[int] = set()
    total_path = 0.0
    weights_unit = True
    particles: set[str] = set()
    volumes: set[str] = set()
    finite = True
    step_positive = True
    rows_ok = 0
    for row in rows:
        try:
            event_id = int(row["eventID"])
            length = float(row["stepLength_mm"])
            weight = float(row["weight"])
            edep = float(row["edep_MeV"])
            ndep = float(row["ndep_MeV"])
        except (ValueError, TypeError, KeyError):
            finite = False
            continue
        if not all(math.isfinite(item) for item in (length, weight, edep, ndep)) or length < 0.0:
            finite = False
            continue
        if event_id < 0:
            finite = False
            continue
        rows_ok += 1
        particles.add(row["particle"])
        volumes.add(row["volume"])
        step_positive &= length > 0.0
        weights_unit &= abs(weight - 1.0) <= 1e-12
        total_path += length
        per_event[event_id] = per_event.get(event_id, 0.0) + length
        events.add(event_id)
    ok &= check(checks, "MOM-HITS-PARSE", finite and rows_ok == len(rows),
                f"rows={len(rows)} parsed={rows_ok}")
    ok &= check(checks, "MOM-HITS-PROTON", particles == {"proton"}, f"particles={sorted(particles)}")
    ok &= check(checks, "MOM-HITS-VOLUME", volumes == {"Slab_PV"}, f"volumes={sorted(volumes)}")
    ok &= check(checks, "MOM-HITS-UNIT-WEIGHT", weights_unit, "all track weights are 1")
    ok &= check(checks, "MOM-HITS-POSITIVE-STEPS", step_positive, "all stepLength_mm > 0")
    events_with_hits = len(events)
    ok &= check(checks, "MOM-HITS-EVENTS", 0 < events_with_hits <= int(freeze["events"]),
                f"distinct events with hits={events_with_hits} N={freeze['events']}")
    ok &= check(checks, "MOM-HITS-ROWS-VS-EVENTS", len(rows) >= events_with_hits,
                f"hit rows={len(rows)} events={events_with_hits} (rows are steps, not events)")
    wrong = []
    for event_id, value in sorted(per_event.items()):
        within, delta = close_enough(f"{value:.12g}", thickness)
        if not within:
            wrong.append((event_id, value, delta))
    ok &= check(checks, "MOM-PATH-PER-EVENT", not wrong,
                f"each crossing event sums to one {thickness:g} mm traversal; "
                f"violations={wrong[:5]} of {len(per_event)}")
    return {
        "header": header,
        "rows": len(rows),
        "events_with_hits": events_with_hits,
        "total_path_mm": total_path,
        "per_event": per_event,
        "computed_fluence_mm_minus2": total_path / float(freeze["sensitive_volume_mm3"]),
    }


def read_fluence(output: Path, freeze: dict, checks: list[dict]) -> dict:
    ok = True
    path = output / "fluence_volume_summary_t0.csv"
    header: list[str] = []
    rows: list[dict[str, str]] = []
    if path.is_file():
        header, rows = read_csv(path)
    ok &= check(checks, "MOM-FLUENCE-HEADER", header == FLUENCE_HEADER, f"header={header}")
    ok &= check(checks, "MOM-FLUENCE-ROWS", len(rows) == 1, f"rows={len(rows)}")
    row = rows[0] if rows else {}
    volume = float(row.get("volume_mm3", "nan")) if row else float("nan")
    raw_length = float(row.get("raw_track_length_mm", "nan")) if row else float("nan")
    weighted_length = float(row.get("weighted_track_length_mm", "nan")) if row else float("nan")
    raw_fluence = float(row.get("raw_fluence_mm-2", "nan")) if row else float("nan")
    weighted_fluence = float(row.get("weighted_fluence_mm-2", "nan")) if row else float("nan")
    n_events = int(row.get("n_events", "-1")) if row else -1
    volume_mm3 = float(freeze["sensitive_volume_mm3"])
    ok &= check(checks, "MOM-FLUENCE-VOLUME", abs(volume - volume_mm3) <= 1e-12,
                f"volume_mm3={volume} expected={volume_mm3}")
    ok &= check(checks, "MOM-FLUENCE-N-EVENTS", n_events == int(freeze["events"]),
                f"n_events={n_events}")
    within, delta = close_enough(raw_fluence, raw_length / volume_mm3)
    ok &= check(checks, "MOM-FLUENCE-RAW-DIVISION", within,
                f"fluence={raw_fluence} length/volume={raw_length / volume_mm3} delta={delta}")
    within, delta = close_enough(weighted_fluence, weighted_length / volume_mm3)
    ok &= check(checks, "MOM-FLUENCE-WEIGHTED-DIVISION", within,
                f"weighted_fluence={weighted_fluence} "
                f"weighted_length/volume={weighted_length / volume_mm3} delta={delta}")
    ok &= check(checks, "MOM-FLUENCE-UNIT-WEIGHTS",
                abs(weighted_length - raw_length) <= 1e-9 * max(abs(raw_length), 1.0),
                f"raw={raw_length} weighted={weighted_length}")
    return {
        "header": header,
        "volume_mm3": volume,
        "raw_length_mm": raw_length,
        "weighted_length_mm": weighted_length,
        "raw_fluence": raw_fluence,
        "weighted_fluence": weighted_fluence,
        "n_events": n_events,
        "row": row,
    }


def statistics(output: Path, freeze: dict, hits: dict, checks: list[dict]) -> dict:
    ok = True
    path = output / "scorer_statistics.csv"
    header: list[str] = []
    rows: list[dict[str, str]] = []
    if path.is_file():
        header, rows = read_csv(path)
    ok &= check(checks, "STAT-HEADER", header == STAT_HEADER, f"header={header}")
    fluence_rows = [row for row in rows if row.get("scorer") == "fluence"]
    ok &= check(checks, "STAT-FLUENCE-ROWS", len(fluence_rows) == 2,
                f"rows={[(r.get('quantity'), r.get('key')) for r in fluence_rows]}")
    n_events = int(freeze["events"])
    events_with_hits = hits["events_with_hits"]
    expected_error = math.sqrt(1.0 / events_with_hits - 1.0 / n_events) if events_with_hits else 0.0
    result = {"rows": {}}
    for row in fluence_rows:
        quantity = row.get("quantity", "")
        prefix = quantity.upper().replace("_", "-")
        ok &= check(checks, f"STAT-{prefix}-ESTIMATOR", row.get("estimator") == "total",
                    f"estimator={row.get('estimator')}")
        ok &= check(checks, f"STAT-{prefix}-UNIT", row.get("unit") == "mm-2",
                    f"unit={row.get('unit')}")
        ok &= check(checks, f"STAT-{prefix}-N", int(row.get("n_events", "-1")) == n_events,
                    f"n_events={row.get('n_events')}")
        ok &= check(checks, f"STAT-{prefix}-ENTRIES",
                    int(row.get("entries", "-1")) == events_with_hits,
                    f"entries={row.get('entries')} events_with_hits={events_with_hits}")
        value = float(row.get("value", "nan"))
        mean = float(row.get("mean_per_event", "nan"))
        rel_error = float(row.get("rel_error", "nan"))
        std_error = float(row.get("std_error", "nan"))
        sum_value = float(row.get("sum", "nan"))
        ok &= check(checks, f"STAT-{prefix}-VALUE", math.isfinite(value) and math.isfinite(sum_value),
                    f"value={value} sum={sum_value}")
        within, delta = close_enough(mean, value / n_events)
        ok &= check(checks, f"STAT-{prefix}-MEAN", within,
                    f"mean_per_event={mean} value/N={value / n_events} delta={delta}")
        within, delta = close_enough(rel_error, expected_error)
        ok &= check(checks, f"STAT-{prefix}-REL-ERROR", within,
                    f"rel_error={rel_error} sqrt(1/K-1/N)={expected_error} delta={delta}")
        within, delta = close_enough(std_error, rel_error * abs(value))
        ok &= check(checks, f"STAT-{prefix}-STD-ERROR", within,
                    f"std_error={std_error} rel*|value|={rel_error * abs(value)} delta={delta}")
        ok &= check(checks, f"STAT-{prefix}-UNCERTAINTY-ESTIMATOR",
                    row.get("uncertainty_estimator") == "uncorrected_event_moments_v1",
                    f"uncertainty_estimator={row.get('uncertainty_estimator')}")
        ok &= check(checks, f"STAT-{prefix}-UNCERTAINTY-STATUS",
                    row.get("uncertainty_status") == "approximate",
                    f"uncertainty_status={row.get('uncertainty_status')}")
        result["rows"][quantity] = {
            "value": value, "mean_per_event": mean, "rel_error": rel_error,
            "std_error": std_error, "entries": int(row.get("entries", -1)),
            "n_events": int(row.get("n_events", -1)),
        }
    missing = [quantity for quantity in ("raw_fluence", "weighted_fluence")
               if quantity not in result["rows"]]
    ok &= check(checks, "STAT-REQUIRED-QUANTITIES", not missing, f"missing={missing}")
    return result


def verify_implementation(fluence: dict, hits: dict, freeze: dict, checks: list[dict]) -> bool:
    ok = True
    volume = float(freeze["sensitive_volume_mm3"])
    computed = hits["total_path_mm"] / volume
    within, delta = close_enough(fluence["raw_fluence"], computed)
    ok &= check(checks, "MOM-IMPLEMENTATION-RAW", within,
                f"product={fluence['raw_fluence']} hits/volume={computed} delta={delta}")
    within, delta = close_enough(fluence["weighted_fluence"], computed)
    ok &= check(checks, "MOM-IMPLEMENTATION-WEIGHTED", within,
                f"product={fluence['weighted_fluence']} hits/volume={computed} delta={delta}")
    within, delta = close_enough(fluence["raw_length_mm"], hits["total_path_mm"])
    ok &= check(checks, "MOM-IMPLEMENTATION-LENGTH", within,
                f"product_length={fluence['raw_length_mm']} hits_sum={hits['total_path_mm']}")
    return bool(ok)


def verify_reference(fluence: dict, stats: dict, hits: dict, freeze: dict, checks: list[dict]) -> dict:
    reference = freeze["reference"]
    expected = float(reference["expected_fluence_mm_minus2"])
    observed = float(fluence["weighted_fluence"])
    rel_error = float(stats["rows"].get("weighted_fluence", {}).get("rel_error", float("nan")))
    sigma_observed = abs(observed) * rel_error
    allowed = RELATIVE_TOLERANCE * expected + 3.0 * sigma_observed
    delta = abs(observed - expected)
    ok = check(checks, "REF-DPHI-ABS", delta <= allowed,
               f"|{observed} - {expected}|={delta} allowed={allowed} "
               f"(1e-6*ref={RELATIVE_TOLERANCE * expected}, 3*sigma_obs={3.0 * sigma_observed})")
    p = float(reference["hit_probability"])
    n_events = int(freeze["events"])
    expected_hits = n_events * p
    diagnostics = {
        "observed_fluence_mm_minus2": observed,
        "expected_fluence_mm_minus2": expected,
        "absolute_delta": delta,
        "relative_delta": delta / expected if expected else None,
        "sigma_observed": sigma_observed,
        "allowed": allowed,
        "hits_observed": hits["events_with_hits"],
        "hits_expected": expected_hits,
        "hits_standard_deviation": math.sqrt(n_events * p * (1.0 - p)),
        "hits_z": ((hits["events_with_hits"] - expected_hits)
                   / math.sqrt(n_events * p * (1.0 - p)) if n_events * p * (1.0 - p) > 0 else None),
        "statistical_error_formula": "sqrt(1/K-1/N) for the unit-weight aperture model",
    }
    return {"ok": bool(ok), "diagnostics": diagnostics}


def evaluate(results: dict, freeze: dict, identity: dict | None = None) -> dict:
    checks: list[dict] = []
    identity = identity or results.get("identity", {})
    ok = True
    ok &= verify_identity(identity, freeze, checks)
    case = identity.get("case", {})
    ok &= check(checks, "ID-CASE-SEED", int(case.get("seed", -1)) == int(freeze["seed"]),
                f"seed={case.get('seed')}")
    ok &= check(checks, "ID-CASE-EVENTS", int(case.get("events", -1)) == int(freeze["events"]),
                f"events={case.get('events')}")
    ok &= verify_inputs(identity, freeze, checks)
    run = results.get("cases", {}).get("ref_fluence_01", {})
    ok &= verify_case_evidence(run, freeze, checks)
    output = ROOT / case["output_dir"]
    hits = read_hits(output, freeze, checks)
    fluence = read_fluence(output, freeze, checks)
    if hits["rows"] == 0:
        ok &= check(checks, "MOM-HITS-EMPTY", False, "no hits rows: cannot recompute track lengths")
    else:
        ok &= verify_implementation(fluence, hits, freeze, checks)
    stats = statistics(output, freeze, hits, checks)
    reference = verify_reference(fluence, stats, hits, freeze, checks)
    ok &= reference["ok"]
    failed_ids = [item["id"] for item in checks if item["status"] == "fail"]
    return {
        "schema": "g4usim_q2_ref_fluence_evaluation_v1",
        "case": freeze["case"],
        "status": "pass" if not failed_ids else "fail",
        "checks_total": len(checks),
        "checks_failed": len(failed_ids),
        "failed_ids": failed_ids,
        "checks": checks,
        "diagnostics": reference["diagnostics"],
        "read_hits": {key: value for key, value in hits.items() if key != "per_event"},
        "read_fluence": {key: value for key, value in fluence.items() if key != "row"},
        "statistics": stats,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", default=str(BASE / "results.json"))
    parser.add_argument("--update", action="store_true", help="write the evaluation back into results.json")
    parser.add_argument("--freeze", default=str(FREEZE))
    args = parser.parse_args(argv)
    freeze = json.loads(Path(args.freeze).read_text(encoding="utf-8"))
    results_path = Path(args.results)
    results = json.loads(results_path.read_text(encoding="utf-8"))
    identity = results.get("identity")
    evaluation = evaluate(results, freeze, identity)
    results["evaluation"] = evaluation
    if args.update:
        results_path.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: evaluation[key] for key in
                      ("status", "checks_total", "checks_failed", "failed_ids", "diagnostics")},
                     indent=2, ensure_ascii=False))
    return 0 if evaluation["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
