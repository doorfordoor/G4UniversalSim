# Q2-3 REF-DOSE-01：四个冻结参考病例（仅电磁平衡薄层）

本候选实现冻结合同
`docs/collab/decisions/20261105-q2-dose-reference-freeze-v1.{md,json}`
（case `REF-DOSE-01`），用同一冻结后端真实运行四例，先独立重算 PSTAR 参考，再做
身份/证据/统计/参考四层比较，并在副本上完成有限反例。四例比较全部通过；四例真实运行
均 `exit_code = 0`、完成 20000 事件。

- 候选目录：`out/collab/q2-reference-dose-v1/`
- 回执：`docs/collab/outbox/20261105-q2-reference-dose-v1.md`
- 本轮**未修改**产品、正式测试/基准、冻结合同、其它候选、`ROADMAP.md`/`STATUS.md`；
  未提交 Git。监督端对 `docs/ROADMAP.md` 的既有改动保持原样。

## 1. 冻结身份（先验身份，再谈物理）

| 项目 | 值 |
| --- | --- |
| 冻结文件 SHA-256 | `a2a799e90bd941b4969beab62be408013420dfbd684c4e8e52f07775308e498d` |
| 冻结 schema / case | `q2_reference_dose_freeze_v1` / `REF-DOSE-01` |
| 后端 exe SHA-256 | `f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f` |
| 后端 build commit | `864bc036d6d7752475e52db4efd2b950cabfcc3d` |
| 后端 source fingerprint | `e7de615d4e342114104f970688a7ea5f9789f7b70240b2562a388a50a45704e7` |
| Geant4 | `G4VERSION_NUMBER = 1132`（11.3.2） |
| PSTAR 表 | `scenarios/benchmarks/shielding_range/nist/PSTAR_Si.txt`，SHA-256 `71cfaaf13545201276c24195d96a4fafd2341bf5fbd26ed52133cce0b42f2422`，10507 B，132 行，能量域 0.001–10000 MeV |
| Geant4 数据自检 | `--check-geant4-data` 退出码 0，`required_complete = true`（`backend-data-check.txt`） |

生成输入（`inputs/`，均由 `setup_inputs.py` 生成并记录 SHA-256）：

| 文件 | SHA-256 |
| --- | --- |
| `materials.ini` | `fb05cfd6f448f12805a15c3b423cb16889fc34e64bbbc1a1a7bce45a6d0ef858` |
| `geometry_ref_dose_10.ini` | `68812cef753f32c3171d4180a90860db57fad79cc474e01d39c9c6862ca26964` |
| `geometry_ref_dose_50.ini` | `921ad20843239b90f57e9ad2896cbe68cc9da0300330b596338ff7a983c03064` |
| `geometry_ref_dose_100.ini` | `33005980bcc481bf7cc3bbb2b2540c321ae18636b92db4f5dbd569e05ff0bcb7` |
| `geometry_ref_dose_200.ini` | `b85ca00e0b216a6c3f003b111e70511819cf92052842fdb2ca833ac3705e513f` |
| `main_ref_dose_10.ini` | `1fb99ef0f698d4ebc7f4c674865ffa3eea855e58955442487ac9618c36bcd5bf` |
| `main_ref_dose_50.ini` | `cb6920def3ee70e276890ae7d52852d8e38f6f2ca361a27567f71d47e9855b98` |
| `main_ref_dose_100.ini` | `5248255687efa9ee5787dda90ce9875adaa3032f455357dfa36e171959e9cddb` |
| `main_ref_dose_200.ini` | `9a2d3c8058ec826e100dcb786c2616004b2dc3908b9c6fad481c5f34bb998bbb` |

## 2. 几何、体积与质量的复算依据

坐标规则按冻结合同与 `scripts/run_benchmarks.py` 的基准布置：

* 硅块前表面位于 `z = 0`，块中心在 `z = (2b + t)/2`；
* 敏感片放在块的**局部中心**，即块中心深度处，深度 = `b + t/2`；
* 点平面源位于 `z = -1 mm`（块外），束流沿 `+z`。

敏感性薄片体积的复算依据是**生成的几何定义 + 冻结密度**，不是输出 CSV 的某个体积列：

* 片横向 10 mm × 10 mm = 1.0 cm²，厚度 `t`（0.02 / 0.1 / 0.1 / 0.2 mm = 0.002 / 0.01 / 0.01 / 0.02 cm）；
* 体积 = 1.0 cm² × t = 0.002 / 0.01 / 0.01 / 0.02 cm³；
* 质量 = ρ·V = 2.33 g/cm³ × V = 4.66e-6 / 2.33e-5 / 2.33e-5 / 4.66e-5 kg。

需要明确的字段边界：`dose_volume_summary_t0.csv` **没有** `volume_mm3` 列，它只给出
`mass_kg`、能量沉积与剂量等产品输出。上面的体积/质量是依据几何定义和密度**独立推算**的，
再与 CSV 的 `mass_kg` 做一致性比较（`MOM-MASS-INDEPENDENT`，1e-9 相对容差内）；
不能把推算值说成 CSV 原字段，也不能说 CSV 自带体积列。

入射注量归一化使用平面方束面积，**不是**片面积：方源边长 = 2 × halfx = 12 mm × 12 mm =
1.44 cm²（冻结 `source.area_cm2`），片横向只有 1.0 cm²，这是合同规定的名义注量面积。

## 3. 参考值的独立重算

`reference.py` 只读 PSTAR 原始字节：按冻结方法对 E→CSDA range 做 log-log 插值得
`R(E0)`，减去到片中心的面积质量 `ρ·(b + t/2)/10` g/cm²，再反演 range→E_mid，在 E_mid
插值电子阻止本领，`D/Φ = Se(E_mid) × 1.602176634e-10`。敏感性质量同时由几何独立推算。

结果：四例 `dose_per_fluence_relative_delta = 0`、`energy_mid_delta = 0`、
`sensitive_mass_delta = 0`，插值区间均为内部区间；PSTAR 字节 SHA 与冻结一致。
完整数据在 `reference-recompute.json`（schema `g4usim_q2_ref_dose_recompute_v1`）。

| 病例 | E0 (MeV) | E_mid (MeV) | Se (MeV cm²/g) | 冻结 D/Φ (Gy cm²) |
| --- | --- | --- | --- | --- |
| ref_dose_10 | 10 | 9.50433541620899 | 35.94748529368706 | 5.759422098860403e-09 |
| ref_dose_50 | 50 | 49.19041512400653 | 9.977400889717448 | 1.5985558573556106e-09 |
| ref_dose_100 | 100 | 99.11269531665732 | 5.874150333423087 | 9.41142640881378e-10 |
| ref_dose_200 | 200 | 198.65003216203812 | 3.642867996985731 | 5.836517985516922e-10 |

## 4. 真实运行

每例：冻结后端 + `main_ref_dose_<E>.ini` + 生成的 `run.mac`（`/run/initialize`、
`/run/beamOn 20000`），1 线程、冻结种子、仅电磁 option4、`10 um` cut、`dose` 与 `hits`
开启、`event_edep` 关闭。后端实际退出码、完成事件数、产物 SHA 与大小均记入
`results.json` 的 `cases[*]`。

| 病例 | 种子 | 后端 exit | 完成事件 | 用时 (s) | 运行记录 |
| --- | --- | --- | --- | --- | --- |
| ref_dose_10 | 20261106 | 0 | 20000 | 1.781 | 复用已验证记录 |
| ref_dose_50 | 20261107 | 0 | 20000 | 3.385 | 复用已验证记录 |
| ref_dose_100 | 20261108 | 0 | 20000 | 3.15 | 复用已验证记录 |
| ref_dose_200 | 20261109 | 0 | 20000 | 3.419 | 复用已验证记录 |

复用规则：冻结文件 SHA、后端 SHA、生成输入 SHA、记录产物 SHA/大小、`run_summary.txt`
完成事件数全部一致时直接复用已记录运行（本次最终状态四例均为 `reused: true`，未再次模拟）；
`--force` 才重跑。首次执行驱动曾多写方源 `halfy` 被后端拒绝，属于**驱动输入问题**而非物理
比较失败，记录见 `driver-notes.md`。

每个输出目录同时包含 `run_summary.txt`、`run_metadata.json`、`hits_t0.csv`、
`dose_volume_summary_t0.csv`、`scorer_statistics.csv` 与若干 `effective_config_*.json`。
完成事实以 `run_summary.txt` / `run_metadata.json` 为准，不以 hits 行数当事件总数。

## 5. 比较口径（证据在物理之前）

`compare.py` 的检查按层执行，任何一层缺失即 fail closed：

1. **ID**：冻结 SHA/schema、后端 build/SHA/指纹/Geant4 版本、PSTAR SHA、Geant4 数据自检、
   9 个生成输入 SHA；
2. **IN**：实际输入是仅电磁 option4、10 um、dose+hits、1 线程、冻结种子、方束
   halfx/中心 z=-1/方向、块前表面 z=0、块厚、片在块局部中心、片尺寸/敏感/材料、
   片中心深度 = b + t/2、源在块外、注量面积 1.44 cm²；
3. **EVID**：summary/metadata/hits/dose/statistics 文件存在、SHA 与大小、后端真实退出码、
   summary 状态/后台状态/宏状态/物理/计分/线程/种子/能量、计划=完成=20000、
   metadata runs 与 generated_files（含 hashed 完整性）、记录中的产物 SHA/大小、
   实际输出目录、后端日志、主/几何 INI 的 SHA；
4. **MOM**：hits 表头精确匹配、能量列带 `_MeV`、权重、按 eventID 独立重算 raw/weighted
   沉积能与平方和、零贡献事件保留（hits 事件数 < N）、dose 汇总 CSV 与 hits 对账、
   独立几何质量与冻结质量对账；
5. **STAT**：`raw_dose`/`weighted_dose` 两行的 estimator、`uncorrected_event_moments_v1`、
   `approximate`、`n_events = 20000`、`entries = 非零贡献事件数`、均值 = 总和/N、
   `rel_error = sqrt(sum_sq/sum² − 1/N)`、`std_error = rel_error × value`；
6. **REF**：`D/Φ = weighted_dose × 1.44 / 实际完成 N`，
   `σ = D/Φ × weighted_dose rel_error`，判据 `|D/Φ − ref| ≤ 0.02·ref + 3σ`；
   另用 hits 与独立几何质量从零重算 `D/Φ` 做实现交叉核对（1e-9 相对）。

统计量使用真实 N = 20000（含零贡献事件）：Dose 计分器只对非零沉积事件累计矩，但相对误差
分母是 run 总事件数，因此 `scorer_statistics.csv` 的 `entries`（非零事件数，13834/13894/
13884/13854）小于 `n_events`，这与“漏靶事件按零贡献保留”的合同口径一致；hits 文件只有
命中行，行数（13838/83486/75085/78553）不能当作事件数。

## 6. 四例结果

`results.json` 中 `evaluation` 状态 `pass`，共 494 项检查、0 失败。

| 病例 | 参考 D/Φ | 模拟 D/Φ | 绝对差 | 相对差 | σ | 允许误差 | 结论 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ref_dose_10 | 5.759422098860403e-09 | 5.7375158097023994e-09 | −2.1906289158003958e-11 | −3.804e-03 | 2.756847456982235e-11 | 1.9789386568667512e-10 | pass |
| ref_dose_50 | 1.5985558573556106e-09 | 1.5936261401015997e-09 | −4.929717254010895e-12 | −3.084e-03 | 7.878024735804674e-12 | 5.5605191354526236e-11 | pass |
| ref_dose_100 | 9.41142640881378e-10 | 9.367205891472e-10 | −4.422051734178057e-12 | −4.699e-03 | 5.02734376149564e-12 | 3.390488410211448e-11 | pass |
| ref_dose_200 | 5.836517985516922e-10 | 5.7873788827704e-10 | −4.913910274652172e-12 | −8.419e-03 | 3.230626399903765e-12 | 2.136491517074514e-11 | pass |

（D/Φ 单位 Gy cm²；允许误差 = 0.02·参考 + 3σ，以参考为主项。）

实现自洽：四例的 raw 与 weighted 剂量相同（权重恒为 1）；`raw_dose_Gy` =
7.96877195792e-05 / 2.21336963903e-05 / 1.30100081826e-05 / 8.03802622607e-06，
与 hits 重算及 `D/Φ` 交叉核对差值在 1e-21 量级。

## 7. 有限反例（只在副本，正例不被覆盖）

`tamper.py` 在 `tampered/` 下使用 JSON 副本与硬链接影子输出目录构造变异，绝不写回
`runs/` 或 `results.json`；脚本末尾复核原件 SHA 未变化（`originals_unchanged: true`）。
每个变异都必须使评估 fail closed，`tamper-results.json` 记录实际失败检查。

| 反例 | 变异 | 检测到的检查 | 状态 |
| --- | --- | --- | --- |
| missing_metadata | 影子输出删掉 `run_metadata.json` | `EVID-METADATA-FILE` | 检出 |
| reference_plus_6pct | 冻结副本参考值 ×1.06 | `REF-DPHI-ABS`（四例） | 检出 |
| energy_mapping_swapped | 副本中 10 MeV 与 100 MeV 的输入映射互换 | `IN-SOURCE-ENERGY`、`IN-SEED` | 检出 |
| mass_unit_factor | 影子 `dose_volume_summary` 的 `mass_kg` ×1000 | `EVID-ASSET-SHA-dose_volume_summary_t0.csv`、`EVID-OUTPUT-DIR`（证据层拒绝） | 检出 |
| fluence_area_factor_100 | 冻结副本注量面积 1.44→144 cm² | `IN-SOURCE-AREA`（四例） | 检出 |
| artifact_sha_tampered | 结果副本篡改 hits 声明 SHA | `EVID-RECORDED-hits_t0.csv` | 检出 |
| freeze_mass_unit_factor | 冻结副本敏感质量 ×1000 | `MOM-MASS-MATCHES-FREEZE`（算术层） | 检出 |

质量单位因子在输出文件层被“声明 SHA 与实际内容不一致”的证据门禁先行拒绝；其算术层的
独立质量对账由 `freeze_mass_unit_factor` 反例与正例的 `MOM-MASS-INDEPENDENT` 覆盖。

## 8. 驱动输入问题记录

初次生成的方源多写了 `halfy`，后端在运行前拒绝：
`G4UniversalSim fatal error: SourceManager plane square uses halfx only.`。这是驱动输入
不符合字段契约，不是物理比较失败；修正为方源只写 `halfx` 后四例正常完成。详见
`driver-notes.md`（其中同时记录了复用判断曾误报“freeze changed”的驱动缺陷；冻结文件
字节 SHA 始终未变，最终不再重跑模拟）。

## 9. 复现命令

```powershell
cd D:\Geant4\G4UniversalSim\out\collab\q2-reference-dose-v1
python setup_inputs.py          # 生成 inputs/ 与 identity.json（先验证后端/数据/冻结身份）
python reference.py --check     # 独立重算四例参考并与冻结值比对，写 reference-recompute.json
python run_cases.py             # 真实运行四例；冻结输入与会话输出未变时复用已记录运行
python compare.py --results results.json --update   # 重新评估并写回 evaluation
python tamper.py                # 在副本上构造 7 个反例并复核原件未变
```

## 10. 边界与未声明事项

* 参考与判据仅适用于**仅电磁**质子、以及碰撞平衡的薄层 TID 近似；不适用于强子输运、
  次级粒子不平衡或厚靶剂量；
* 只覆盖冻结合同列出的四个能量点与本后端/本 PSTAR 表；
* `D/Φ` 判据是“外部电子阻止本领数据 + 冻结插值方法”的对照，不是实验测量验证；
* 未声明完整强子剂量、NIEL、活化或 GEANT4 全物理列表的能力；
* 本轮未提交 Git；一旦独立复验完成，是否需要提交由监督端决定。

## 11. 文件清单

* `setup_inputs.py` — 身份门禁 + 生成几何/材料/主 INI 与 `identity.json`
* `reference.py` — PSTAR 独立重算与冻结比对
* `run_cases.py` — 真实运行、复用判断、记录产物与 `results.json`
* `compare.py` — ID/IN/EVID/MOM/STAT/REF 六层比较器
* `tamper.py` — 七个副本反例与原件不变复核
* `identity.json`、`reference-recompute.json`、`results.json`、`tamper-results.json`
* `inputs/`、`runs/`、`tampered/`、`backend-data-check.txt`、`driver-notes.md`
