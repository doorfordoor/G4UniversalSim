"""Run the four frozen REF-DOSE-01 cases with the frozen backend.

Reuse rule (frozen inputs unchanged => never re-run the same simulation):

* the frozen decision file, the backend executable and every generated input
  keep the same SHA-256 they had when a recorded run was produced, and
* every output file recorded for that run still exists with its recorded
  SHA-256 and size.

Only then the previous record is reused.  ``--force`` re-runs anyway.  A failed
run is never overwritten by this script on its own; the record of a failed case
is kept so that a later human decision can inspect it.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

import compare

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-dose-v1"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-dose-reference-freeze-v1.json"
BACKEND = ROOT / "out" / "collab" / "q2-backend-864bc036" / "G4UniversalSim.exe"
GEANT4_BIN = Path("D:/ProgramFiles/Geant4/bin")
GEANT4_DATA = Path("D:/ProgramFiles/Geant4/share/Geant4/data")
EXPECTED_OUTPUTS = (
    "run_summary.txt",
    "run_metadata.json",
    "hits_t0.csv",
    "dose_volume_summary_t0.csv",
    "scorer_statistics.csv",
)


def rel(path: Path) -> str:
    """Store paths relative to the repository root so the record is portable."""
    try:
        return str(path.resolve().relative_to(ROOT.resolve())).replace("\\", "/")
    except ValueError:
        return str(path)


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def env() -> dict:
    merged = os.environ.copy()
    merged["PATH"] = str(GEANT4_BIN) + os.pathsep + merged.get("PATH", "")
    merged["GEANT4_DATA_DIR"] = str(GEANT4_DATA)
    merged.pop("QT_QPA_PLATFORM", None)
    return merged


def clean_output(output: Path) -> None:
    if not output.exists():
        output.mkdir(parents=True)
        return
    for child in sorted(output.rglob("*"), reverse=True):
        if child.is_file():
            child.unlink()
        elif child.is_dir():
            child.rmdir()


def case_meta(identity: dict, name: str) -> dict:
    case = dict(identity["cases"][name])
    inputs = identity["inputs"]
    main_name = Path(case["main_ini"]).name
    geometry_name = Path(case["geometry_ini"]).name
    case["main_ini_sha256"] = inputs[main_name]["sha256"]
    case["geometry_ini_sha256"] = inputs[geometry_name]["sha256"]
    return case


def record_is_reusable(record: dict, previous: dict | None, identity: dict,
                       freeze_sha: str) -> tuple[bool, str]:
    if not record or not previous:
        return False, "no previous result set"
    if previous.get("freeze_sha256") != freeze_sha:
        return False, "freeze changed"
    previous_identity = previous.get("identity", {})
    if previous_identity.get("backend", {}).get("sha256") != identity["backend"]["sha256"]:
        return False, "backend changed"
    if previous_identity.get("inputs", {}) != identity["inputs"]:
        return False, "frozen inputs changed"
    if record.get("exit_code") != 0:
        return False, "previous backend run failed; not overwriting its record"
    run = record
    output = ROOT / run.get("output_dir", "")
    for name in EXPECTED_OUTPUTS:
        item = run.get("artifacts", {}).get(name)
        path = ROOT / item.get("path", "") if item else None
        if item is None or path is None or not path.is_file():
            return False, f"recorded output missing: {name}"
        if compare.sha256(path) != item.get("sha256"):
            return False, f"recorded output changed: {name}"
        if path.stat().st_size != item.get("size_bytes"):
            return False, f"recorded output size changed: {name}"
    summary = compare.parse_run_summary(output / "run_summary.txt")
    if int(summary.get("actual_completed_event_count", -1)) != int(run.get("completed_events", -2)):
        return False, "completed events changed"
    return True, "frozen inputs, backend and outputs all verified"


def run_case(name: str, case: dict, freeze: dict) -> dict:
    energy = float(case["energy_MeV"])
    output = ROOT / case["output_dir"]
    run_dir = ROOT / case["run_dir"]
    run_dir.mkdir(parents=True, exist_ok=True)
    clean_output(output)
    macro = run_dir / "run.mac"
    macro.write_text(
        f"# {freeze['case']} {energy:g} MeV: frozen batch wrapper\n"
        "/run/initialize\n"
        f"/run/beamOn {int(freeze['events_per_case'])}\n",
        encoding="utf-8",
    )
    command = [
        str(BACKEND),
        "--config", str(ROOT / case["main_ini"]),
        "--macro", str(macro),
        "--output", str(output),
        "--threads", str(int(case["threads"])),
        "--seed", str(int(case["seed"])),
    ]
    log_path = run_dir / "backend.log"
    started = time.time()
    with log_path.open("wb") as log:
        completed = subprocess.run(
            command, cwd=str(ROOT), env=env(),
            stdout=log, stderr=subprocess.STDOUT, timeout=3600,
        )
    duration = time.time() - started
    summary_path = output / "run_summary.txt"
    summary = compare.parse_run_summary(summary_path) if summary_path.is_file() else {}
    metadata_path = output / "run_metadata.json"
    artifacts = {}
    for filename in EXPECTED_OUTPUTS:
        path = output / filename
        if path.is_file():
            artifacts[filename] = {
                "path": rel(path),
                "sha256": compare.sha256(path),
                "size_bytes": path.stat().st_size,
            }
    record = {
        "case_id": name,
        "energy_MeV": energy,
        "seed": int(case["seed"]),
        "threads": int(case["threads"]),
        "planned_events": int(freeze["events_per_case"]),
        "completed_events": int(summary.get("actual_completed_event_count", -1)),
        "exit_code": completed.returncode,
        "duration_s": round(duration, 3),
        "output_dir": rel(output),
        "run_dir": rel(run_dir),
        "run_summary_path": rel(summary_path),
        "run_summary_sha256": compare.sha256(summary_path) if summary_path.is_file() else None,
        "run_metadata_path": rel(metadata_path),
        "run_metadata_sha256": compare.sha256(metadata_path) if metadata_path.is_file() else None,
        "macro": {"path": rel(macro), "sha256": compare.sha256(macro)},
        "command": command,
        "backend_log": rel(log_path),
        "backend_log_sha256": compare.sha256(log_path),
        "artifacts": artifacts,
        "value_states": {
            "run_summary": "actual_run" if summary_path.is_file() else "not_written",
            "run_metadata": "actual_run" if metadata_path.is_file() else "not_written",
            "hits": "actual_run" if (output / "hits_t0.csv").is_file() else "not_written",
            "dose_summary": "actual_run" if (output / "dose_volume_summary_t0.csv").is_file() else "not_written",
            "scorer_statistics": "actual_run" if (output / "scorer_statistics.csv").is_file() else "not_written",
        },
        "started_at": now(),
    }
    (run_dir / "record.json").write_text(
        json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return record


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--force", action="store_true", help="re-run even when a verified record exists")
    args = parser.parse_args(argv)
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    freeze_sha = compare.sha256(FREEZE)
    identity = json.loads((BASE / "identity.json").read_text(encoding="utf-8"))
    results_path = BASE / "results.json"
    previous = json.loads(results_path.read_text(encoding="utf-8")) if results_path.is_file() else None
    records = (previous or {}).get("cases", {})
    cases: dict[str, dict] = {}
    for name in sorted(identity["cases"]):
        case = case_meta(identity, name)
        existing = dict(records.get(name, {}))
        if existing and not args.force:
            reusable, reason = record_is_reusable(existing, previous, identity, freeze_sha)
            if reusable:
                existing["reused"] = True
                existing["reuse_reason"] = reason
                cases[name] = {"case": case, "run": existing}
                print(f"{name}: reused verified record ({reason})")
                continue
            print(f"{name}: not reusable ({reason}); re-running")
        record = run_case(name, case, freeze)
        record["reused"] = False
        record["reuse_reason"] = "fresh run"
        cases[name] = {"case": case, "run": record}
        print(f"{name}: exit={record['exit_code']} {record['duration_s']:.2f}s "
              f"completed={record['completed_events']}")
    merged = {name: item["run"] for name, item in cases.items()}
    results = {
        "schema": "g4usim_q2_ref_dose_run_results_v1",
        "case": freeze["case"],
        "freeze_sha256": freeze_sha,
        "identity": identity,
        "cases": merged,
        "generated_at": now(),
    }
    evaluation = compare.evaluate(results, freeze, identity)
    results["evaluation"] = evaluation
    results_path.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    failed = [name for name, item in merged.items() if item["exit_code"] != 0]
    print("backend_failed:", failed)
    print("evaluation:", evaluation["status"], "checks", evaluation["checks_total"],
          "failed", evaluation["checks_failed"])
    return 0 if (not failed and evaluation["status"] == "pass") else 1


if __name__ == "__main__":
    raise SystemExit(main())
