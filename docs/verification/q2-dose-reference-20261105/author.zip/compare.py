"""Evaluate REF-DOSE-01: identity gate, run evidence, dose implementation, then physics.

The order matters.  The frozen reference numbers may only be compared after the
identity of the frozen backend/data/inputs is verified, the run really completed
at the frozen sample size, and every compared number comes from that run.  The
product's own dose/statistics output is cross-checked against an independent
recomputation from the raw hits and the daughter-free slab mass.

Checks emitted here are reused by tamper.py: every tampered copy must make at
least one expected check fail.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-dose-v1"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-dose-reference-freeze-v1.json"
FROZEN_BACKEND_SHA = "f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f"
FROZEN_GEANT4_VERSION = 1132
SIG_DIGITS = 12
MEV_TO_J = 1.602176634e-13
ELEMENTARY_CHARGE_SCALE = 1.602176634e-10

HITS_HEADER = [
    "runID", "eventID", "trackID", "parentID", "particle", "edep_MeV", "ndep_MeV",
    "stepLength_mm", "x0_mm", "y0_mm", "z0_mm", "x1_mm", "y1_mm", "z1_mm",
    "px", "py", "pz", "kineticEnergy_MeV", "process", "volume", "weight",
]
DOSE_HEADER = [
    "runID", "volume_path", "volume_name", "mass_kg", "raw_edep_MeV",
    "weighted_edep_MeV", "raw_dose_Gy", "weighted_dose_Gy",
    "raw_edep_sum_sq_MeV2", "weighted_edep_sum_sq_MeV2", "n_events",
]
STAT_HEADER = [
    "runID", "scorer", "quantity", "key", "name", "unit", "estimator", "n_events",
    "entries", "value", "mean_per_event", "std_error", "rel_error", "fom_per_s",
    "run_wall_time_s", "sum", "sum_sq", "uncertainty_estimator", "uncertainty_status",
]
REQUIRED_SUMMARY_FIELDS = [
    "status", "summary_write_status", "output_failure_status", "macro_execution_status",
    "simulation_executed", "program_exit_code", "run_count",
]
FROZEN_TOLERANCE = 0.02


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def numbers(text: str) -> list[float]:
    """Numbers from a generated field such as ``0, 0, -1 mm``."""
    return [float(token.replace("mm", "")) for token in str(text).replace(",", " ").split()
            if token.replace("mm", "").strip()]


def half_width(value: float) -> float:
    """Half width of a decimal printed with 12 significant digits."""
    if value == 0.0 or not math.isfinite(value):
        return 0.0
    return 0.5 * 10.0 ** (math.floor(math.log10(abs(value))) - (SIG_DIGITS - 1))


def parse_run_summary(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith("[") or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        return list(reader.fieldnames or []), list(reader)


def parse_simple_ini(path: Path) -> dict[str, dict[str, str]]:
    """Parse the small, generated INIs (no escapes, one '=' per line)."""
    sections: dict[str, dict[str, str]] = {}
    current = ""
    for line in path.read_text(encoding="utf-8").splitlines():
        text = line.strip()
        if not text or text.startswith("#"):
            continue
        if text.startswith("[") and text.endswith("]"):
            current = text[1:-1].strip()
            sections.setdefault(current, {})
            continue
        if "=" in text and current:
            key, value = text.split("=", 1)
            sections[current][key.strip()] = value.strip()
    return sections


def check(checks: list[dict], cid: str, ok: bool, detail: str) -> bool:
    checks.append({"id": cid, "status": "pass" if ok else "fail", "detail": detail})
    return ok


def close_enough(reported: str | float, recomputed: float, *, relative: float = 1e-9) -> tuple[bool, float]:
    """Compare a 12-significant-digit printed value with an independent recomputation."""
    value = float(reported)
    bound = relative * max(abs(value), abs(recomputed)) + half_width(value) + half_width(recomputed)
    delta = abs(value - recomputed)
    return delta <= bound + 1e-300, delta


def verify_identity(identity: dict, freeze: dict, checks: list[dict]) -> bool:
    backend = identity.get("backend", {})
    ok = True
    ok &= check(checks, "ID-BACKEND-SHA", backend.get("sha256") == FROZEN_BACKEND_SHA,
                f"sha256={backend.get('sha256')}")
    ok &= check(checks, "ID-BUILD-COMMIT",
                backend.get("build_git_commit") == freeze["backend_build"],
                f"build_git_commit={backend.get('build_git_commit')}")
    fingerprint = backend.get("source_fingerprint", "")
    ok &= check(checks, "ID-SOURCE-FINGERPRINT",
                isinstance(fingerprint, str) and len(fingerprint) == 64
                and all(ch in "0123456789abcdef" for ch in fingerprint),
                f"source_fingerprint={fingerprint}")
    ok &= check(checks, "ID-GEANT4-VERSION",
                int(backend.get("geant4_version_number", -1)) == FROZEN_GEANT4_VERSION,
                f"geant4_version_number={backend.get('geant4_version_number')}")
    data = identity.get("data_file", {})
    ok &= check(checks, "ID-DATA-SHA", data.get("sha256") == freeze["data_sha256"],
                f"sha256={data.get('sha256')}")
    ok &= check(checks, "ID-DATA-MATCHES-FREEZE", data.get("matches_freeze") is True,
                f"matches_freeze={data.get('matches_freeze')}")
    geant4 = identity.get("geant4", {})
    check_path = ROOT / identity.get("data_file", {}).get("path", "")
    ok &= check(checks, "ID-GEANT4-DATA-CHECK",
                geant4.get("data_check_exit") == 0
                and check_path.is_file()
                and sha256(BASE / "backend-data-check.txt") == geant4.get("data_check_sha256")
                and '"required_complete": true' in (BASE / "backend-data-check.txt").read_text(encoding="utf-8"),
                f"data_check_exit={geant4.get('data_check_exit')}")
    freeze_info = identity.get("freeze", {})
    freeze_path = ROOT / freeze_info.get("path", "")
    ok &= check(checks, "ID-FREEZE-SHA",
                freeze_path.is_file() and sha256(freeze_path) == freeze_info.get("sha256"),
                f"path={freeze_info.get('path')} recorded={freeze_info.get('sha256')}")
    ok &= check(checks, "ID-FREEZE-SCHEMA",
                freeze_info.get("schema") == freeze.get("schema"),
                f"identity={freeze_info.get('schema')} freeze={freeze.get('schema')}")
    inputs = identity.get("inputs", {})
    for name, item in sorted(inputs.items()):
        input_path = ROOT / item.get("path", "")
        ok &= check(checks, f"ID-INPUT-SHA-{name.upper().replace('.', '-').replace('_', '-')}",
                    input_path.is_file() and sha256(input_path) == item.get("sha256"),
                    f"path={item.get('path')}")
    return bool(ok)


def verify_inputs(case: dict, freeze: dict, freeze_case: dict, checks: list[dict]) -> bool:
    """The frozen coordinates and source really are in the generated inputs."""
    ok = True
    main = parse_simple_ini(ROOT / case["main_ini"])
    geometry = parse_simple_ini(ROOT / case["geometry_ini"])
    source = main.get("source", {})
    physics = main.get("physics", {})
    scoring = main.get("scoring", {})
    run = main.get("run", {})
    ok &= check(checks, "IN-EM-ONLY", "em" in physics and "reference" not in physics,
                f"physics keys={sorted(physics)}")
    ok &= check(checks, "IN-EM-VALUE", physics.get("em") == freeze["physics_em"],
                f"em={physics.get('em')}")
    ok &= check(checks, "IN-CUT", physics.get("default_cut") == freeze["default_cut"],
                f"default_cut={physics.get('default_cut')}")
    ok &= check(checks, "IN-SCORING-DOSE", scoring.get("dose") == "true",
                f"dose={scoring.get('dose')}")
    ok &= check(checks, "IN-SCORING-HITS", scoring.get("hits") == "true",
                f"hits={scoring.get('hits')}")
    ok &= check(checks, "IN-SCORING-NO-EVENT-EDEP", scoring.get("event_edep") == "false",
                f"event_edep={scoring.get('event_edep')}")
    ok &= check(checks, "IN-THREADS", run.get("threads") == str(int(freeze["threads"])),
                f"threads={run.get('threads')}")
    ok &= check(checks, "IN-SEED", run.get("seed") == str(int(freeze_case["seed"])),
                f"seed={run.get('seed')}")
    ok &= check(checks, "IN-SOURCE-PARTICLE", source.get("particle") == freeze["particle"],
                f"particle={source.get('particle')}")
    ok &= check(checks, "IN-SOURCE-ENERGY",
                abs(float(str(source.get("energy", "nan")).split()[0]) - float(freeze_case["energy_MeV"])) <= 1e-12,
                f"energy={source.get('energy')}")
    ok &= check(checks, "IN-SOURCE-PLANE",
                source.get("position_type") == "plane" and source.get("shape") == "square",
                f"position_type={source.get('position_type')} shape={source.get('shape')}")
    ok &= check(checks, "IN-SOURCE-HALFX",
                abs(float(str(source.get("halfx", "nan")).split()[0]) - float(freeze["source"]["halfx_mm"])) <= 1e-12,
                f"halfx={source.get('halfx')}")
    center = numbers(source.get("center"))
    ok &= check(checks, "IN-SOURCE-CENTER",
                len(center) == 3 and abs(center[0]) <= 1e-12 and abs(center[1]) <= 1e-12
                and abs(center[2] - float(freeze["source"]["center_mm"][2])) <= 1e-12,
                f"center={center}")
    direction = numbers(source.get("direction"))
    ok &= check(checks, "IN-SOURCE-DIRECTION", direction == [0.0, 0.0, 1.0],
                f"direction={direction}")
    block = geometry.get("volume.Block", {})
    slab = geometry.get("volume.Slab", {})
    block_position = numbers(block.get("position"))
    block_size = numbers(block.get("size"))
    slab_position = numbers(slab.get("position"))
    slab_size = numbers(slab.get("size"))
    ok &= check(checks, "IN-GEOMETRY-TEMPLATE", main.get("geometry", {}).get("template") == "hierarchical",
                f"template={main.get('geometry', {}).get('template')}")
    ok &= check(checks, "IN-BLOCK-FRONT-AT-ZERO",
                abs(block_position[2] - 0.5 * block_size[2]) <= 1e-12,
                f"center_z={block_position[2]} half_thickness={0.5 * block_size[2]}")
    ok &= check(checks, "IN-BLOCK-THICKNESS",
                abs(block_size[2] - float(freeze_case["block_z_mm"])) <= 1e-12,
                f"block_z={block_size[2]} frozen={freeze_case['block_z_mm']}")
    ok &= check(checks, "IN-SLAB-AT-BLOCK-CENTER",
                slab_position == [0.0, 0.0, 0.0],
                f"slab_position={slab_position}")
    ok &= check(checks, "IN-SLAB-SIZE",
                abs(slab_size[0] - float(freeze["slab_xy_mm"][0])) <= 1e-12
                and abs(slab_size[1] - float(freeze["slab_xy_mm"][1])) <= 1e-12
                and abs(slab_size[2] - float(freeze_case["slab_mm"])) <= 1e-12,
                f"slab_size={slab_size}")
    ok &= check(checks, "IN-SLAB-SENSITIVE", slab.get("sensitive") == "true",
                f"sensitive={slab.get('sensitive')}")
    ok &= check(checks, "IN-SLAB-MATERIAL", slab.get("material") == freeze["material"],
                f"material={slab.get('material')}")
    slab_mid_depth = block_position[2] + slab_position[2]
    beam_area_cm2 = (2.0 * float(freeze["source"]["halfx_mm"]) * 0.1) ** 2
    source_area_cm2 = float(freeze["source"]["area_cm2"])
    ok &= check(checks, "IN-SOURCE-AREA",
                abs(source_area_cm2 - beam_area_cm2) <= 1e-12,
                f"source_area_cm2={source_area_cm2} beam_area_cm2={beam_area_cm2}")
    ok &= check(checks, "IN-SLAB-MID-DEPTH",
                abs(slab_mid_depth - (float(freeze_case["buildup_mm"])
                                      + 0.5 * float(freeze_case["slab_mm"]))) <= 1e-12,
                f"slab_mid_depth={slab_mid_depth} expected="
                f"{float(freeze_case['buildup_mm']) + 0.5 * float(freeze_case['slab_mm'])}")
    ok &= check(checks, "IN-SOURCE-OUTSIDE-BLOCK",
                center[2] < (block_position[2] - 0.5 * block_size[2]),
                f"source_z={center[2]} front_z={block_position[2] - 0.5 * block_size[2]}")
    return bool(ok)


def verify_case_evidence(case: dict, freeze: dict, freeze_case: dict, checks: list[dict]) -> bool:
    n_expected = int(freeze["events_per_case"])
    output = ROOT / case["run"]["output_dir"]
    run = case["run"]
    summary_path = output / "run_summary.txt"
    metadata_path = output / "run_metadata.json"
    hits_path = output / "hits_t0.csv"
    dose_path = output / "dose_volume_summary_t0.csv"
    stats_path = output / "scorer_statistics.csv"
    ok = True
    ok &= check(checks, "EVID-SUMMARY-FILE", summary_path.is_file(), str(summary_path))
    ok &= check(checks, "EVID-METADATA-FILE", metadata_path.is_file(), str(metadata_path))
    ok &= check(checks, "EVID-HITS-FILE", hits_path.is_file(), str(hits_path))
    ok &= check(checks, "EVID-DOSE-FILE", dose_path.is_file(), str(dose_path))
    ok &= check(checks, "EVID-STATISTICS-FILE", stats_path.is_file(), str(stats_path))
    ok &= check(checks, "EVID-BACKEND-EXIT", run.get("exit_code") == 0,
                f"backend_exit={run.get('exit_code')}")
    if not (summary_path.is_file() and metadata_path.is_file() and hits_path.is_file()
            and dose_path.is_file() and stats_path.is_file()):
        return False
    ok &= check(checks, "EVID-SUMMARY-SHA", sha256(summary_path) == run.get("run_summary_sha256"),
                str(run.get("run_summary_sha256")))
    ok &= check(checks, "EVID-METADATA-SHA", sha256(metadata_path) == run.get("run_metadata_sha256"),
                str(run.get("run_metadata_sha256")))
    summary = parse_run_summary(summary_path)
    expected = {
        "status": "completed",
        "summary_write_status": "completed",
        "output_failure_status": "none",
        "macro_execution_status": "completed",
        "simulation_executed": "true",
        "program_exit_code": "0",
        "run_count": "1",
        "actual_threads": str(int(freeze["threads"])),
        "source_particle": freeze["particle"],
        "physics_em": "G4EmStandardPhysics_option4",
        "scoring_dose_enabled": "true",
        "scoring_hits_enabled": "true",
    }
    for key, value in expected.items():
        ok &= check(checks, f"EVID-SUMMARY-{key.upper().replace('_', '-')}",
                    summary.get(key) == value, f"{key}={summary.get(key)}")
    ok &= check(checks, "EVID-SUMMARY-PHYSICS-REFERENCE-EMPTY",
                (summary.get("physics_reference") or "").strip() == "",
                f"physics_reference={summary.get('physics_reference')!r}")
    for key in ("run_0_planned_events", "run_0_completed_events", "planned_event_count",
                "actual_completed_event_count"):
        ok &= check(checks, f"EVID-{key.upper().replace('_', '-')}",
                    summary.get(key) == str(n_expected), f"{key}={summary.get(key)}")
    ok &= check(checks, "EVID-CONFIGURED-SEED",
                summary.get("configured_seed") == str(int(freeze_case["seed"])),
                f"configured_seed={summary.get('configured_seed')}")
    ok &= check(checks, "EVID-SOURCE-ENERGY",
                abs(float(summary.get("effective_source_energy_MeV", "nan"))
                    - float(freeze_case["energy_MeV"])) <= 1e-12,
                f"effective_source_energy_MeV={summary.get('effective_source_energy_MeV')}")

    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    runs = metadata.get("runs", [])
    ok &= check(checks, "EVID-METADATA-SCHEMA", metadata.get("schema") == "run_metadata_json_v1",
                str(metadata.get("schema")))
    ok &= check(checks, "EVID-METADATA-RUNS", len(runs) == 1, f"runs={len(runs)}")
    if len(runs) == 1:
        ok &= check(checks, "EVID-METADATA-PLANNED",
                    int(runs[0].get("planned_events", -1)) == n_expected,
                    f"planned={runs[0].get('planned_events')}")
        ok &= check(checks, "EVID-METADATA-COMPLETED",
                    int(runs[0].get("completed_events", -1)) == n_expected,
                    f"completed={runs[0].get('completed_events')}")
    declared = {Path(item.get("path", "")).name: item for item in metadata.get("generated_files", [])}
    for name in ("hits_t0.csv", "dose_volume_summary_t0.csv", "scorer_statistics.csv"):
        item = declared.get(name)
        path = output / name
        ok &= check(checks, f"EVID-ASSET-DECLARED-{name}",
                    item is not None and item.get("integrity_status") == "hashed",
                    f"declared={item is not None}")
        if item is None or not path.is_file():
            ok &= check(checks, f"EVID-ASSET-FILE-{name}", False, str(path))
            continue
        ok &= check(checks, f"EVID-ASSET-FILE-{name}", True, str(path))
        ok &= check(checks, f"EVID-ASSET-SHA-{name}", sha256(path) == item.get("sha256"),
                    f"disk={sha256(path)} declared={item.get('sha256')}")
        ok &= check(checks, f"EVID-ASSET-SIZE-{name}", path.stat().st_size == item.get("size_bytes"),
                    f"disk={path.stat().st_size} declared={item.get('size_bytes')}")
    recorded = run.get("artifacts", {})
    for name in ("hits_t0.csv", "dose_volume_summary_t0.csv", "scorer_statistics.csv",
                 "run_summary.txt", "run_metadata.json"):
        item = recorded.get(name)
        path = ROOT / item.get("path", "") if item else None
        ok &= check(checks, f"EVID-RECORDED-{name}",
                    item is not None and path is not None and path.is_file()
                    and sha256(path) == item.get("sha256") and path.stat().st_size == item.get("size_bytes"),
                    f"recorded={item.get('sha256') if item else None}")
    ok &= check(checks, "EVID-OUTPUT-DIR",
                Path(summary.get("actual_output_dir", "").replace("\\", "/")).resolve()
                == output.resolve(),
                f"summary={summary.get('actual_output_dir')} expected={output}")
    ok &= check(checks, "EVID-BACKEND-LOG",
                (ROOT / run.get("backend_log", "")).is_file(),
                str(run.get("backend_log")))
    main_ini = ROOT / case["main_ini"]
    ok &= check(checks, "EVID-MAIN-INI-SHA",
                main_ini.is_file() and sha256(main_ini) == case["main_ini_sha256"],
                f"path={case['main_ini']}")
    geometry_ini = ROOT / case["geometry_ini"]
    ok &= check(checks, "EVID-GEOMETRY-INI-SHA",
                geometry_ini.is_file() and sha256(geometry_ini) == case["geometry_ini_sha256"],
                f"path={case['geometry_ini']}")
    return bool(ok)


def read_hits(output: Path, n_events: int, checks: list[dict]) -> dict:
    header, rows = read_csv(output / "hits_t0.csv")
    check(checks, "MOM-HITS-HEADER", header == HITS_HEADER, f"header={header}")
    per_event: dict[int, list[float]] = {}
    weights: list[float] = []
    rows_ok = True
    for row in rows:
        try:
            event = int(row["eventID"])
            edep = float(row["edep_MeV"])
            weight = float(row["weight"])
        except (KeyError, TypeError, ValueError):
            rows_ok = False
            continue
        if not (math.isfinite(edep) and math.isfinite(weight)):
            rows_ok = False
            continue
        per_event.setdefault(event, []).append(edep)
        weights.append(weight)
    check(checks, "MOM-HITS-ROWS", rows_ok and len(rows) > 0, f"rows={len(rows)}")
    event_values = {event: sum(items) for event, items in per_event.items()}
    weighted_values = {event: sum(items) for event, items in per_event.items()}
    # weight is uniform in this frozen case (no biasing); assert each hit weight
    weight_ok = all(abs(item - 1.0) <= 1e-12 for item in weights)
    check(checks, "MOM-HITS-UNIT-WEIGHT", weight_ok,
          f"distinct_weights={sorted({round(item, 12) for item in weights})[:5]}")
    weighted_event_values = {}
    for row in rows:
        event = int(row["eventID"])
        edep = float(row["edep_MeV"])
        weight = float(row["weight"])
        weighted_event_values[event] = weighted_event_values.get(event, 0.0) + edep * weight
    check(checks, "MOM-HITS-EDEP-UNIT",
          "edep_MeV" in header and "kineticEnergy_MeV" in header,
          "energy columns carry the _MeV suffix")
    check(checks, "MOM-HITS-EVENTS-WITHIN-N",
          all(0 <= event < n_events for event in per_event),
          f"events={len(per_event)} n={n_events}")
    check(checks, "MOM-HITS-ZERO-EVENTS-RETAINED",
          len(per_event) < n_events,
          f"events_with_hits={len(per_event)} completed_events={n_events}")
    raw_sum = sum(event_values.values())
    raw_sum_sq = sum(value * value for value in event_values.values())
    weighted_sum = sum(weighted_event_values.values())
    weighted_sum_sq = sum(value * value for value in weighted_event_values.values())
    return {
        "header": header,
        "rows": len(rows),
        "events_with_hits": len(per_event),
        "raw_sum_MeV": raw_sum,
        "raw_sum_sq_MeV2": raw_sum_sq,
        "weighted_sum_MeV": weighted_sum,
        "weighted_sum_sq_MeV2": weighted_sum_sq,
        "unit_weight": weight_ok,
    }


def read_dose(output: Path, freeze_case: dict, n_events: int, checks: list[dict]) -> dict:
    header, rows = read_csv(output / "dose_volume_summary_t0.csv")
    check(checks, "MOM-DOSE-HEADER", header == DOSE_HEADER, f"header={header}")
    ok_rows = len(rows) == 1
    check(checks, "MOM-DOSE-ROWS", ok_rows, f"rows={len(rows)}")
    if not ok_rows:
        return {}
    row = rows[0]
    values = {
        "volume_path": row["volume_path"],
        "volume_name": row["volume_name"],
        "mass_kg": float(row["mass_kg"]),
        "raw_edep_MeV": float(row["raw_edep_MeV"]),
        "weighted_edep_MeV": float(row["weighted_edep_MeV"]),
        "raw_dose_Gy": float(row["raw_dose_Gy"]),
        "weighted_dose_Gy": float(row["weighted_dose_Gy"]),
        "raw_edep_sum_sq_MeV2": float(row["raw_edep_sum_sq_MeV2"]),
        "weighted_edep_sum_sq_MeV2": float(row["weighted_edep_sum_sq_MeV2"]),
        "n_events": int(row["n_events"]),
    }
    check(checks, "MOM-DOSE-VOLUME",
          values["volume_name"] == "Slab_PV" and values["volume_path"].endswith("/Slab_PV#0"),
          f"volume_name={values['volume_name']} path={values['volume_path']}")
    check(checks, "MOM-DOSE-N-EVENTS", values["n_events"] == n_events,
          f"n_events={values['n_events']} frozen={n_events}")
    check(checks, "MOM-DOSE-FINITE",
          all(math.isfinite(item) for key, item in values.items() if isinstance(item, float) and key != "volume_name"),
          "all numeric fields finite")
    return values


def independent_mass(freeze: dict, freeze_case: dict) -> float:
    density = float(freeze["density_g_cm3"])
    area_cm2 = float(freeze["slab_xy_mm"][0]) * 0.1 * float(freeze["slab_xy_mm"][1]) * 0.1
    thickness_cm = float(freeze_case["slab_mm"]) * 0.1
    return density * area_cm2 * thickness_cm / 1000.0


def verify_implementation(dose: dict, hits: dict, freeze: dict, freeze_case: dict,
                         freeze_area_cm2: float, checks: list[dict]) -> dict:
    n_events = int(freeze["events_per_case"])
    result: dict = {}
    mass_independent = independent_mass(freeze, freeze_case)
    ok, delta = close_enough(dose["mass_kg"], mass_independent)
    check(checks, "MOM-MASS-INDEPENDENT", ok, f"reported={dose['mass_kg']!r} independent={mass_independent!r} delta={delta:.3e}")
    ok, delta = close_enough(dose["mass_kg"], float(freeze_case["sensitive_mass_kg"]))
    check(checks, "MOM-MASS-MATCHES-FREEZE", ok,
          f"frozen={freeze_case['sensitive_mass_kg']!r} delta={delta:.3e}")
    # raw / weighted sums recomputed from the hits
    raw_sum = hits["raw_sum_MeV"]
    weighted_sum = hits["weighted_sum_MeV"]
    ok, delta = close_enough(dose["raw_edep_MeV"], raw_sum)
    check(checks, "MOM-RAW-EDEP-VS-HITS", ok, f"delta={delta:.3e}")
    ok, delta = close_enough(dose["weighted_edep_MeV"], weighted_sum)
    check(checks, "MOM-WEIGHTED-EDEP-VS-HITS", ok, f"delta={delta:.3e}")
    ok, delta = close_enough(dose["raw_edep_sum_sq_MeV2"], hits["raw_sum_sq_MeV2"])
    check(checks, "MOM-RAW-SUM-SQ-VS-HITS", ok, f"delta={delta:.3e}")
    ok, delta = close_enough(dose["weighted_edep_sum_sq_MeV2"], hits["weighted_sum_sq_MeV2"])
    check(checks, "MOM-WEIGHTED-SUM-SQ-VS-HITS", ok, f"delta={delta:.3e}")
    # raw / weighted dose from the printed mass and the recomputed sums
    raw_dose = raw_sum * MEV_TO_J / dose["mass_kg"]
    weighted_dose = weighted_sum * MEV_TO_J / dose["mass_kg"]
    ok, delta = close_enough(dose["raw_dose_Gy"], raw_dose)
    check(checks, "MOM-RAW-DOSE-VS-HITS", ok, f"delta={delta:.3e}")
    ok, delta = close_enough(dose["weighted_dose_Gy"], weighted_dose)
    check(checks, "MOM-WEIGHTED-DOSE-VS-HITS", ok, f"delta={delta:.3e}")
    # implementation-independent Dose/Phi from hits and the independent mass
    dose_per_fluence_impl = weighted_sum * MEV_TO_J / mass_independent * freeze_area_cm2 / n_events
    result = {
        "independent_mass_kg": mass_independent,
        "raw_dose_Gy": raw_dose,
        "weighted_dose_Gy": weighted_dose,
        "dose_per_fluence_from_hits_Gy_cm2": dose_per_fluence_impl,
        "reported_mass_kg": dose["mass_kg"],
        "reported_raw_dose_Gy": dose["raw_dose_Gy"],
        "reported_weighted_dose_Gy": dose["weighted_dose_Gy"],
        "hits": hits,
    }
    return result


def statistics(output: Path, n_events: int, events_with_hits: int, checks: list[dict]) -> dict:
    header, rows = read_csv(output / "scorer_statistics.csv")
    check(checks, "STAT-HEADER", header == STAT_HEADER, f"header={header}")
    result: dict[str, dict] = {}
    for quantity in ("raw_dose", "weighted_dose"):
        row = next((item for item in rows
                    if item.get("scorer") == "dose" and item.get("quantity") == quantity), None)
        ok = row is not None
        check(checks, f"STAT-ROW-{quantity.upper()}", ok, "row present" if ok else "missing")
        if not ok:
            continue
        value = float(row["value"])
        sum_sq = float(row["sum_sq"])
        sum_value = float(row["sum"])
        rel_error = float(row["rel_error"])
        recomputed = math.sqrt(max(sum_sq / sum_value / sum_value - 1.0 / n_events, 0.0))
        checks_ok = True
        checks_ok &= check(checks, f"STAT-ESTIMATOR-{quantity.upper()}",
                           row["estimator"] == "total"
                           and row["uncertainty_estimator"] == "uncorrected_event_moments_v1",
                           f"estimator={row['estimator']} uncertainty_estimator={row['uncertainty_estimator']}")
        checks_ok &= check(checks, f"STAT-STATUS-{quantity.upper()}",
                           row["uncertainty_status"] == "approximate", row["uncertainty_status"])
        checks_ok &= check(checks, f"STAT-N-EVENTS-{quantity.upper()}",
                           int(row["n_events"]) == n_events, f"n_events={row['n_events']}")
        checks_ok &= check(checks, f"STAT-ENTRIES-{quantity.upper()}",
                           int(row["entries"]) == events_with_hits,
                           f"entries={row['entries']} hits_events={events_with_hits}")
        checks_ok &= check(checks, f"STAT-VALUE-FINITE-{quantity.upper()}",
                           math.isfinite(value) and value > 0.0, f"value={value!r}")
        checks_ok &= check(checks, f"STAT-SUM-VS-VALUE-{quantity.upper()}",
                           abs(sum_value - value) <= half_width(value) + 1e-30,
                           f"sum={sum_value!r} value={value!r}")
        ok_mean, delta = close_enough(row["mean_per_event"], value / n_events)
        checks_ok &= check(checks, f"STAT-MEAN-{quantity.upper()}", ok_mean, f"delta={delta:.3e}")
        ok_rel, delta = close_enough(rel_error, recomputed)
        checks_ok &= check(checks, f"STAT-REL-ERROR-{quantity.upper()}", ok_rel,
                           f"reported={rel_error!r} recomputed={recomputed!r} delta={delta:.3e}")
        ok_std, delta = close_enough(row["std_error"], rel_error * abs(value))
        checks_ok &= check(checks, f"STAT-STD-ERROR-{quantity.upper()}", ok_std, f"delta={delta:.3e}")
        result[quantity] = {
            "value": value,
            "rel_error": rel_error,
            "rel_error_recomputed": recomputed,
            "sum": sum_value,
            "sum_sq": sum_sq,
            "sigma": rel_error * abs(value),
            "entries": int(row["entries"]),
            "n_events": int(row["n_events"]),
            "uncertainty_status": row["uncertainty_status"],
            "uncertainty_estimator": row["uncertainty_estimator"],
        }
    return result


def evaluate(results: dict, freeze: dict, identity: dict | None = None) -> dict:
    checks: list[dict] = []
    identity = identity or results.get("identity", {})
    identity_ok = verify_identity(identity, freeze, checks)
    freeze_cases = {item["case"]: item for item in freeze["cases"]}
    n_events = int(freeze["events_per_case"])
    identity_cases = identity.get("cases", {})
    identity_inputs = identity.get("inputs", {})
    cases_out: dict[str, dict] = {}
    for case_id, run_record in results.get("cases", {}).items():
        freeze_case = freeze_cases[case_id]
        case = dict(identity_cases.get(case_id, {}))
        case["run"] = run_record
        case.setdefault("main_ini", run_record.get("main_ini", {}).get("path", ""))
        case.setdefault("geometry_ini", "")
        for filename, item in identity_inputs.items():
            if Path(filename).name == Path(case.get("main_ini", "")).name:
                case["main_ini_sha256"] = item["sha256"]
            if Path(filename).name == Path(case.get("geometry_ini", "")).name:
                case["geometry_ini_sha256"] = item["sha256"]
        case_checks: list[dict] = []
        input_ok = verify_inputs(case, freeze, freeze_case, case_checks)
        evidence_ok = verify_case_evidence(case, freeze, freeze_case, case_checks)
        products: dict = {}
        stats: dict = {}
        conclusion: dict = {"status": "inconclusive", "reason": "evidence gate failed"}
        if input_ok and evidence_ok:
            output = ROOT / case["run"]["output_dir"]
            hits = read_hits(output, n_events, case_checks)
            dose = read_dose(output, freeze_case, n_events, case_checks)
            if hits and dose:
                products = verify_implementation(dose, hits, freeze, freeze_case,
                                                 float(freeze["source"]["area_cm2"]), case_checks)
                stats = statistics(output, n_events, hits["events_with_hits"], case_checks)
        if products and stats and all("raw_dose" in stats and "weighted_dose" in stats for _ in [0]):
            freeze_area_cm2 = float(freeze["source"]["area_cm2"])
            dose_per_fluence = products["reported_weighted_dose_Gy"] * freeze_area_cm2 / n_events
            sigma = dose_per_fluence * stats["weighted_dose"]["rel_error"]
            reference = float(freeze_case["reference_dose_per_fluence_Gy_cm2"])
            abs_error = dose_per_fluence - reference
            allowed = FROZEN_TOLERANCE * reference + 3.0 * sigma
            rel_error = abs_error / reference
            impl_delta = dose_per_fluence - products["dose_per_fluence_from_hits_Gy_cm2"]
            impl_bound = 1e-9 * max(abs(dose_per_fluence), abs(products["dose_per_fluence_from_hits_Gy_cm2"]))
            checks_a = check(case_checks, "REF-DPHI-ABS",
                             abs(abs_error) <= allowed,
                             f"|{abs_error:.6e}| <= {allowed:.6e} Gy cm2")
            checks_b = check(case_checks, "REF-IMPLEMENTATION-CROSSCHECK",
                             abs(impl_delta) <= impl_bound + 2e-30,
                             f"delta={impl_delta:.3e} bound={impl_bound:.3e}")
            status_ok = (
                int(case["run"]["completed_events"]) == n_events
                and stats["weighted_dose"]["uncertainty_status"] == "approximate"
                and stats["weighted_dose"]["entries"] == products["hits"]["events_with_hits"]
                and stats["weighted_dose"]["entries"] < n_events
                and stats["weighted_dose"]["sigma"] > 0.0
                and all(math.isfinite(item) for item in (dose_per_fluence, sigma, reference))
            )
            checks_c = check(case_checks, "REF-STATUS", status_ok,
                             f"completed={case['run']['completed_events']} entries={stats['weighted_dose']['entries']}")
            passed = bool(checks_a and checks_b and checks_c)
            conclusion = {
                "status": "pass" if passed else "fail",
                "criterion": "abs(Dose/Phi - reference) <= 0.02*reference + 3*sigma",
                "reference_dose_per_fluence_Gy_cm2": reference,
                "simulated_dose_per_fluence_Gy_cm2": dose_per_fluence,
                "simulated_from_hits_Gy_cm2": products["dose_per_fluence_from_hits_Gy_cm2"],
                "abs_error_Gy_cm2": abs_error,
                "relative_error": rel_error,
                "sigma_dose_per_fluence_Gy_cm2": sigma,
                "allowed_abs_error_Gy_cm2": allowed,
                "weighted_dose_relative_error": stats["weighted_dose"]["rel_error"],
                "completed_events": int(case["run"]["completed_events"]),
                "events_with_hits": products["hits"]["events_with_hits"],
                "zero_contribution_events": n_events - products["hits"]["events_with_hits"],
                "raw_dose_Gy": products["reported_raw_dose_Gy"],
                "weighted_dose_Gy": products["reported_weighted_dose_Gy"],
                "reference_mid_energy_MeV": float(freeze_case["reference_mid_energy_MeV"]),
                "electronic_stopping_MeV_cm2_g": float(freeze_case["electronic_stopping_MeV_cm2_g"]),
                "implementation_crosscheck_delta_Gy_cm2": impl_delta,
            }
        checks = checks + case_checks
        cases_out[case_id] = {
            "energy_MeV": float(freeze_case["energy_MeV"]),
            "checks": case_checks,
            "conclusion": conclusion,
            "products": {
                "dose": {key: value for key, value in products.items() if key != "hits"} if products else None,
                "statistics": stats or None,
                "hits": {
                    "rows": products["hits"]["rows"],
                    "events_with_hits": products["hits"]["events_with_hits"],
                    "raw_sum_MeV": products["hits"]["raw_sum_MeV"],
                    "weighted_sum_MeV": products["hits"]["weighted_sum_MeV"],
                } if products else None,
            },
        }
    failed = [item["id"] for item in checks if item["status"] != "pass"]
    overall_pass = identity_ok and not failed and all(
        item["conclusion"]["status"] == "pass" for item in cases_out.values()
    )
    return {
        "schema": "g4usim_q2_ref_dose_evaluation_v1",
        "case": freeze["case"],
        "status": "pass" if overall_pass else "fail",
        "identity_ok": bool(identity_ok),
        "checks_total": len(checks),
        "checks_failed": len(failed),
        "failed_ids": failed,
        "backend_exit_codes": {
            case_id: item.get("exit_code") for case_id, item in results.get("cases", {}).items()
        },
        "comparison_exit_is_not_backend_exit": True,
        "cases": cases_out,
        "checks": checks,
    }


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--results", default=str(BASE / "results.json"))
    parser.add_argument("--freeze", default=str(FREEZE))
    parser.add_argument("--identity", default=str(BASE / "identity.json"))
    parser.add_argument("--update", action="store_true",
                        help="write the evaluation into the results file")
    args = parser.parse_args()
    results = json.loads(Path(args.results).read_text(encoding="utf-8"))
    freeze = json.loads(Path(args.freeze).read_text(encoding="utf-8"))
    identity = json.loads(Path(args.identity).read_text(encoding="utf-8"))
    evaluation = evaluate(results, freeze, identity)
    if args.update:
        results["evaluation"] = evaluation
        Path(args.results).write_text(
            json.dumps(results, ensure_ascii=False, indent=2) + chr(10), encoding="utf-8")
    print(json.dumps(evaluation, indent=2, sort_keys=True))
    return 0 if evaluation["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
