# REF-DOSE-01 执行驱动记录（输入问题与复用）

本文件记录候选驱动在开发过程中出现的输入问题与运行复用问题。它们属于**执行驱动**问题，
不是物理比较失败；四例真实运行本身均成功完成 20000 事件，物理判据见 `README.md`。

## 1. 方源多写 `halfy` 被后端拒绝（输入问题）

初次生成的 `[source]` 同时写入 `halfx` 与 `halfy`：

```ini
shape = square
halfx = 6 mm
halfy = 6 mm
```

真实后端在运行前拒绝，未产生任何运行输出：

```text
G4UniversalSim fatal error: SourceManager plane square uses halfx only.
```

后端的方源语义是 `square` 只接受 `halfx`（边长 = 2 × halfx），`halfy` 只能用于矩形
（`shape = rectangle`）。`setup_inputs.py` 随后改为方源只写 `halfx`，四例运行方才开始。

说明与证据边界：

* 这是**驱动输入**不符合后端字段契约，不是物理比较失败，也不影响任何物理数值；
* 初次失败的原始后端日志已被后续成功运行覆盖，本文件只保留当时的原始错误文本与修正方式，
  不声称保留了那条失败日志的原文件；
* 该拒绝反而证明了后端在 Geant4 对象创建前做字段校验，与 M0 的 fail-fast 契约一致。

## 2. 复用判断曾错误报告“freeze changed”（驱动缺陷，非冻结变更）

`run_cases.py` 的复用判断最初把“结果记录里缺少后来新增的身份字段”误判为冻结文件变化，
因而重复执行了模拟。实际情况：

* 冻结文件字节 SHA-256 始终为 `a2a799e90bd941b4969beab62be408013420dfbd684c4e8e52f07775308e498d`，
  未发生任何变更；
* 修正后的复用判断只比较：冻结文件 SHA、后端 SHA、生成输入 SHA、记录中产物 SHA/大小、
  以及 `run_summary.txt` 的完成事件数；全部一致即复用，不再重跑；
* 最终 `results.json` 中四例记录均为 `reused: true`，复用时只重算评估，不重新模拟。

按监督要求，本条作为驱动问题保留，不写成冻结参数变化。
