"""Independent re-implementation of the frozen REF-DOSE-01 reference method.

The frozen file
`docs/collab/decisions/20261105-q2-dose-reference-freeze-v1.md` defines

    R(E_mid) = R(E0) - rho*(b + t/2)/10        [g/cm2]
    D/Phi    = S_e(E_mid) * 1.602176634e-10    [Gy cm2]

with bisection/log-log interpolation of the PSTAR Si table for
E -> CSDA range, and log-log interpolation of the electronic stopping power at
E_mid.  This module does the computation directly from the *bytes* of
`scenarios/benchmarks/shielding_range/nist/PSTAR_Si.txt` (SHA-256 checked
against the frozen value) and never reads a simulation product.  It refuses
values that would require extrapolating or clamping the table.

Usage:
    python reference.py            # compute all four cases and print JSON
    python reference.py --check    # exit 1 if frozen values disagree or the
                                   # mid-point falls outside the table interior
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-dose-v1"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-dose-reference-freeze-v1.json"
DATA = ROOT / "scenarios" / "benchmarks" / "shielding_range" / "nist" / "PSTAR_Si.txt"
MEV_TO_J = 1.602176634e-13
ELEMENTARY_CHARGE_SCALE = 1.602176634e-10  # (MeV cm2/g) -> (Gy cm2) for stopping power


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_pstar(path: Path) -> list[tuple[float, float, float]]:
    """Return (T_MeV, STOP_e_MeV_cm2_g, CSDA_range_g_cm2) rows from the table."""
    rows: list[tuple[float, float, float]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if len(fields) != 7:
            continue
        try:
            values = [float(item) for item in fields]
        except ValueError:
            continue
        energy, stop_e, _stop_n, _stop_t, csda, _projected, _detour = values
        if energy <= 0.0 or stop_e <= 0.0 or csda <= 0.0:
            continue
        rows.append((energy, stop_e, csda))
    rows.sort(key=lambda item: item[0])
    if len(rows) < 2:
        raise SystemExit("PSTAR_Si.txt: not enough numeric rows")
    energies = [row[0] for row in rows]
    if any(b <= a for a, b in zip(energies, energies[1:])):
        raise SystemExit("PSTAR_Si.txt: energies are not strictly increasing")
    ranges = [row[2] for row in rows]
    if any(b <= a for a, b in zip(ranges, ranges[1:])):
        raise SystemExit("PSTAR_Si.txt: CSDA ranges are not strictly increasing")
    return rows


def _bracket(x: float, points: list[tuple[float, float]], label: str) -> tuple[float, float]:
    """Return the two table abscissae bracketing x; refuse extrapolation."""
    if not (points[0][0] < x < points[-1][0]):
        raise SystemExit(f"{label}={x!r} is outside the table interior [{points[0][0]}, {points[-1][0]}]")
    for (x0, _), (x1, _) in zip(points, points[1:]):
        if x0 <= x <= x1:
            return x0, x1
    raise AssertionError("bracket")


def _log_interp(x: float, points: list[tuple[float, float]]) -> tuple[float, tuple[float, float]]:
    x0, x1 = _bracket(x, points, "interpolation x")
    if x == x0:
        return points[[px for px, _ in points].index(x0)][1], (x0, x1)
    if x == x1:
        return points[[px for px, _ in points].index(x1)][1], (x0, x1)
    y0 = dict(points)[x0]
    y1 = dict(points)[x1]
    ratio = (math.log(x) - math.log(x0)) / (math.log(x1) - math.log(x0))
    return math.exp(math.log(y0) + ratio * (math.log(y1) - math.log(y0))), (x0, x1)


def _inverse_log_interp(y: float, points: list[tuple[float, float]]) -> tuple[float, tuple[float, float]]:
    ys = [item[1] for item in points]
    if not (ys[0] < y < ys[-1]):
        raise SystemExit(f"inverse interpolation target {y!r} is outside the table interior")
    for (x0, y0), (x1, y1) in zip(points, points[1:]):
        if y0 <= y <= y1:
            if y == y0:
                return x0, (x0, x1)
            if y == y1:
                return x1, (x0, x1)
            ratio = (math.log(y) - math.log(y0)) / (math.log(y1) - math.log(y0))
            energy = math.exp(math.log(x0) + ratio * (math.log(x1) - math.log(x0)))
            return energy, (x0, x1)
    raise AssertionError("inverse interpolation domain")


def compute_case(case: dict, rows: list[tuple[float, float, float]], freeze: dict) -> dict:
    density = float(freeze["density_g_cm3"])
    energy0 = float(case["energy_MeV"])
    buildup_mm = float(case["buildup_mm"])
    slab_mm = float(case["slab_mm"])
    depth_mm = buildup_mm + 0.5 * slab_mm
    areal_mass = density * depth_mm * 0.1  # g/cm2 (mm -> cm factor 0.1)

    range_points = [(row[0], row[2]) for row in rows]
    stop_points = [(row[0], row[1]) for row in rows]
    range_at_e0, range_bracket = _log_interp(energy0, range_points)
    range_mid = range_at_e0 - areal_mass
    energy_mid, mid_bracket = _inverse_log_interp(range_mid, range_points)
    stop_mid, stop_bracket = _log_interp(energy_mid, stop_points)
    dose_per_fluence = stop_mid * ELEMENTARY_CHARGE_SCALE
    expected_mass = density * float(freeze["slab_xy_mm"][0]) * float(freeze["slab_xy_mm"][1]) * slab_mm * 1e-3 / 1000.0
    depth_from_center = float(case["block_center_z_mm"])
    return {
        "case": case["case"],
        "energy_MeV": energy0,
        "buildup_mm": buildup_mm,
        "slab_mm": slab_mm,
        "depth_to_slab_mid_mm": depth_mm,
        "areal_mass_up_to_mid_g_cm2": areal_mass,
        "range_at_E0_g_cm2": range_at_e0,
        "range_at_E0_bracket_MeV": list(range_bracket),
        "range_mid_g_cm2": range_mid,
        "energy_mid_MeV": energy_mid,
        "energy_mid_bracket_MeV": list(mid_bracket),
        "stop_e_mid_MeV_cm2_g": stop_mid,
        "stop_e_mid_bracket_MeV": list(stop_bracket),
        "dose_per_fluence_Gy_cm2": dose_per_fluence,
        "sensitive_mass_kg": expected_mass,
        "slab_mid_matches_block_center": abs(depth_mm - depth_from_center) < 1e-12,
    }


def build(data_path: Path | None = None, freeze_path: Path | None = None) -> dict:
    freeze_file = freeze_path or FREEZE
    data_file = data_path or DATA
    freeze = json.loads(freeze_file.read_text(encoding="utf-8"))
    data_sha = sha256(data_file)
    if data_sha != freeze["data_sha256"]:
        raise SystemExit(f"PSTAR_Si.txt sha256 mismatch: {data_sha} != {freeze['data_sha256']}")
    rows = parse_pstar(data_file)
    computed = [compute_case(case, rows, freeze) for case in freeze["cases"]]
    comparison = []
    for case, actual in zip(freeze["cases"], computed):
        comparison.append(
            {
                "case": case["case"],
                "energy_MeV": case["energy_MeV"],
                "frozen_energy_mid_MeV": case["reference_mid_energy_MeV"],
                "recomputed_energy_mid_MeV": actual["energy_mid_MeV"],
                "energy_mid_delta_MeV": actual["energy_mid_MeV"] - case["reference_mid_energy_MeV"],
                "frozen_stop_e_MeV_cm2_g": case["electronic_stopping_MeV_cm2_g"],
                "recomputed_stop_e_MeV_cm2_g": actual["stop_e_mid_MeV_cm2_g"],
                "stop_e_relative_delta": (actual["stop_e_mid_MeV_cm2_g"] - case["electronic_stopping_MeV_cm2_g"]) / case["electronic_stopping_MeV_cm2_g"],
                "frozen_dose_per_fluence_Gy_cm2": case["reference_dose_per_fluence_Gy_cm2"],
                "recomputed_dose_per_fluence_Gy_cm2": actual["dose_per_fluence_Gy_cm2"],
                "dose_per_fluence_relative_delta": (actual["dose_per_fluence_Gy_cm2"] - case["reference_dose_per_fluence_Gy_cm2"]) / case["reference_dose_per_fluence_Gy_cm2"],
                "frozen_sensitive_mass_kg": case["sensitive_mass_kg"],
                "recomputed_sensitive_mass_kg": actual["sensitive_mass_kg"],
                "sensitive_mass_delta_kg": actual["sensitive_mass_kg"] - case["sensitive_mass_kg"],
                "slab_mid_bracket_interior": not (
                    actual["energy_mid_MeV"] <= rows[0][0] or actual["energy_mid_MeV"] >= rows[-1][0]
                ),
            }
        )
    return {
        "schema": "g4usim_q2_ref_dose_recompute_v1",
        "case": freeze["case"],
        "freeze_file": str(freeze_file.relative_to(ROOT)).replace("\\", "/"),
        "data_file": str(data_file.relative_to(ROOT)).replace("\\", "/"),
        "data_sha256": data_sha,
        "data_matches_freeze": True,
        "method": freeze["reference_method"],
        "table_rows": len(rows),
        "table_energy_range_MeV": [rows[0][0], rows[-1][0]],
        "computed": computed,
        "comparison": comparison,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default=str(DATA))
    parser.add_argument("--freeze", default=str(FREEZE))
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--out", default=str(BASE / "reference-recompute.json"))
    args = parser.parse_args()
    report = build(Path(args.data), Path(args.freeze))
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    if args.check:
        failed = False
        for item in report["comparison"]:
            if abs(item["dose_per_fluence_relative_delta"]) > 1e-12:
                print(f"FAIL: {item['case']} frozen D/Phi disagrees", file=sys.stderr)
                failed = True
            if abs(item["energy_mid_delta_MeV"]) > 1e-9:
                print(f"FAIL: {item['case']} frozen E_mid disagrees", file=sys.stderr)
                failed = True
            if abs(item["sensitive_mass_delta_kg"]) > 1e-15:
                print(f"FAIL: {item['case']} frozen sensitive mass disagrees", file=sys.stderr)
                failed = True
            if not item["slab_mid_bracket_interior"]:
                print(f"FAIL: {item['case']} E_mid is at the table boundary", file=sys.stderr)
                failed = True
        if failed:
            return 1
        print("dose reference recompute matches the frozen values", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
