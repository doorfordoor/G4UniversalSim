"""Limited mutation counterexamples for REF-DOSE-01.

Every mutation happens on a copy: copied results/freeze/identity JSON documents
and, where an output file must be corrupted, a shadow output directory whose
unchanged files are hard links to the original run outputs.  The original
`runs/` outputs and `results.json` are never written.  Each counterexample must
make the evaluation fail closed with at least one expected check.

Counterexamples (deliberately limited, no new cases are invented):

* missing run metadata in the compared outputs;
* frozen reference value increased by 6 %;
* swapped energy->input mapping for two cases;
* sensitive mass unit factor (kg read as g) in the dose summary;
* incident fluence area factor of 100 (1.44 cm2 read as 144 cm2);
* tampered declared SHA-256 of a recorded output artifact;
* sensitive mass unit factor inside a copy of the frozen decision (arithmetic-level).
"""

from __future__ import annotations

import csv
import json
import os
from copy import deepcopy
from pathlib import Path

import compare

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-dose-v1"
TAMPERED = BASE / "tampered"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-dose-reference-freeze-v1.json"


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def shadow_output(case_name: str) -> Path:
    """Hard-link the original outputs into a writable shadow directory."""
    original = BASE / "runs" / case_name / "output"
    shadow = TAMPERED / case_name / "output"
    if shadow.exists():
        for child in sorted(shadow.rglob("*"), reverse=True):
            child.unlink()
        shadow.rmdir()
    shadow.mkdir(parents=True)
    for source in sorted(original.iterdir()):
        if source.is_file():
            os.link(source, shadow / source.name)
    return shadow


def rel(path: Path) -> str:
    return str(path.resolve().relative_to(ROOT.resolve())).replace("\\", "/")


def reference_case(freeze: dict, case_id: str) -> dict:
    return next(item for item in freeze["cases"] if item["case"] == case_id)


def evaluate(results: dict, freeze: dict, identity: dict) -> dict:
    return compare.evaluate(results, freeze, identity)


def failed_ids(evaluation: dict) -> list[str]:
    return [item["id"] for item in evaluation["checks"] if item["status"] != "pass"]


def main() -> int:
    TAMPERED.mkdir(parents=True, exist_ok=True)
    freeze = load(FREEZE)
    results = load(BASE / "results.json")
    identity = load(BASE / "identity.json")
    original_hashes = {
        "freeze": compare.sha256(FREEZE),
        "results": compare.sha256(BASE / "results.json"),
        "identity": compare.sha256(BASE / "identity.json"),
        "runs": {
            name: {filename: compare.sha256(BASE / "runs" / name / "output" / filename)
                   for filename in ("run_summary.txt", "run_metadata.json", "hits_t0.csv",
                                    "dose_volume_summary_t0.csv", "scorer_statistics.csv")
                   if (BASE / "runs" / name / "output" / filename).is_file()}
            for name in ("ref_dose_10", "ref_dose_50", "ref_dose_100", "ref_dose_200")
        },
    }
    cases: list[dict] = []

    def record(name: str, description: str, evaluation: dict, expected: list[str]) -> None:
        observed = failed_ids(evaluation)
        missing = [item for item in expected if item not in observed]
        cases.append({
            "name": name,
            "description": description,
            "evaluation_status": evaluation["status"],
            "expected_failing_checks": expected,
            "observed_failing_checks": observed,
            "expected_observed": not missing,
            "missing_expected_checks": missing,
            "checks_total": evaluation["checks_total"],
            "checks_failed": evaluation["checks_failed"],
        })
        print(f"{name}: status={evaluation['status']} failed={observed[:6]}"
              f"{' ...' if len(observed) > 6 else ''} expected_ok={not missing}")

    # 1) missing run metadata in the compared output directory
    shadow = shadow_output("ref_dose_10")
    (shadow / "run_metadata.json").unlink()
    mutated = deepcopy(results)
    mutated["cases"]["ref_dose_10"]["output_dir"] = rel(shadow)
    record("missing_metadata", "run_metadata.json removed from the compared output directory",
           evaluate(mutated, freeze, identity), ["EVID-METADATA-FILE"])

    # 2) frozen reference dose per fluence increased by 6 %
    mutated_freeze = deepcopy(freeze)
    for item in mutated_freeze["cases"]:
        item["reference_dose_per_fluence_Gy_cm2"] = float(item["reference_dose_per_fluence_Gy_cm2"]) * 1.06
    record("reference_plus_6pct", "frozen reference value multiplied by 1.06 (copy of the freeze)",
           evaluate(results, mutated_freeze, identity),
           ["REF-DPHI-ABS"])

    # 3) energy -> input mapping swapped between 10 MeV and 100 MeV
    mutated_identity = deepcopy(identity)
    a = mutated_identity["cases"]["ref_dose_10"]["main_ini"]
    b = mutated_identity["cases"]["ref_dose_100"]["main_ini"]
    mutated_identity["cases"]["ref_dose_10"]["main_ini"] = b
    mutated_identity["cases"]["ref_dose_100"]["main_ini"] = a
    record("energy_mapping_swapped", "10 MeV and 100 MeV case inputs are exchanged in a copy of the identity",
           evaluate(deepcopy(results), freeze, mutated_identity),
           ["IN-SOURCE-ENERGY"])

    # 4) mass unit factor (kg read as g) in the dose summary
    shadow = shadow_output("ref_dose_50")
    dose_path = shadow / "dose_volume_summary_t0.csv"
    header, rows = compare.read_csv(dose_path)
    rows[0]["mass_kg"] = f"{float(rows[0]['mass_kg']) * 1000.0:.12g}"
    dose_path.unlink()  # break the hard link; never modify the original run output
    with dose_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=header)
        writer.writeheader()
        writer.writerow(rows[0])
    mutated = deepcopy(results)
    mutated["cases"]["ref_dose_50"]["output_dir"] = rel(shadow)
    record("mass_unit_factor", "dose summary mass_kg multiplied by 1000 in a shadow output copy",
           evaluate(mutated, freeze, identity),
           ["EVID-ASSET-SHA-dose_volume_summary_t0.csv", "EVID-OUTPUT-DIR"])

    # 5) incident fluence area factor of 100 (1.44 cm2 read as 144 cm2)
    mutated_freeze = deepcopy(freeze)
    mutated_freeze["source"]["area_cm2"] = 144.0
    record("fluence_area_factor_100", "frozen incident area read as 144 cm2 instead of 1.44 cm2",
           evaluate(results, mutated_freeze, identity),
           ["IN-SOURCE-AREA"])

    # 6) tampered declared SHA-256 of a recorded artifact
    mutated = deepcopy(results)
    artifact = mutated["cases"]["ref_dose_200"]["artifacts"]["hits_t0.csv"]
    artifact["sha256"] = "0" * 64
    record("artifact_sha_tampered", "declared hits SHA-256 replaced by zeros in a results copy",
           evaluate(mutated, freeze, identity),
           ["EVID-RECORDED-hits_t0.csv"])

    # 7) sensitive mass unit factor in a copy of the freeze (arithmetic-level check)
    mutated_freeze = deepcopy(freeze)
    reference_case(mutated_freeze, "ref_dose_200")["sensitive_mass_kg"] = (
        float(reference_case(mutated_freeze, "ref_dose_200")["sensitive_mass_kg"]) * 1000.0)
    record("freeze_mass_unit_factor", "frozen sensitive mass multiplied by 1000 (copy of the freeze)",
           evaluate(results, mutated_freeze, identity),
           ["MOM-MASS-MATCHES-FREEZE"])

    # originals must be untouched
    now_hashes = {
        "freeze": compare.sha256(FREEZE),
        "results": compare.sha256(BASE / "results.json"),
        "identity": compare.sha256(BASE / "identity.json"),
        "runs": {
            name: {filename: compare.sha256(BASE / "runs" / name / "output" / filename)
                   for filename in ("run_summary.txt", "run_metadata.json", "hits_t0.csv",
                                    "dose_volume_summary_t0.csv", "scorer_statistics.csv")
                   if (BASE / "runs" / name / "output" / filename).is_file()}
            for name in ("ref_dose_10", "ref_dose_50", "ref_dose_100", "ref_dose_200")
        },
    }
    originals_unchanged = now_hashes == original_hashes
    report = {
        "schema": "g4usim_q2_ref_dose_tamper_results_v1",
        "case": freeze["case"],
        "tamper_cases": cases,
        "originals_unchanged": originals_unchanged,
        "original_hashes": original_hashes,
        "observed_hashes": now_hashes,
        "status": "pass" if originals_unchanged and all(item["expected_observed"] for item in cases) else "fail",
    }
    (BASE / "tamper-results.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + chr(10), encoding="utf-8")
    print("originals_unchanged:", originals_unchanged)
    print("tamper_status:", report["status"])
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
