"""One-candidate independent hit/event arithmetic; no product imports."""
from pathlib import Path
from collections import defaultdict
import bisect
import csv
import hashlib
import json
import math

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
checks = []


def require(label, condition):
    checks.append({"id": label, "status": "pass" if condition else "fail"})
    assert condition, label


def close(a, b):
    return math.isfinite(a) and math.isfinite(b) and abs(a - b) <= 1e-9 * max(abs(a), abs(b), 1e-300)


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def interp(x, xs, ys):
    i = max(0, min(len(xs) - 2, bisect.bisect_right(xs, x) - 1))
    assert xs[i] <= x <= xs[i + 1]
    return math.exp(math.log(ys[i]) + math.log(x / xs[i]) / math.log(xs[i + 1] / xs[i]) * math.log(ys[i + 1] / ys[i]))


def main():
    path = ROOT / "docs/collab/decisions/20261105-q2-dose-reference-freeze-v1.json"
    require("freeze-sha", hashlib.sha256(path.read_bytes()).hexdigest() == "a2a799e90bd941b4969beab62be408013420dfbd684c4e8e52f07775308e498d")
    freeze = json.loads(path.read_text(encoding="utf-8-sig"))
    data = ROOT / freeze["data_file"]
    require("pstar-sha", hashlib.sha256(data.read_bytes()).hexdigest() == freeze["data_sha256"])
    table = []
    for line in data.read_text(encoding="ascii").splitlines():
        try:
            values = list(map(float, line.split()))
        except ValueError:
            continue
        if len(values) == 7:
            table.append(values)
    energies, stopping, ranges = ([row[i] for row in table] for i in (0, 1, 4))
    summaries = []
    for case in freeze["cases"]:
        name = case["case"]
        output = BASE / "runs" / name / "output"
        dose = next(row for row in rows(output / "dose_volume_summary_t0.csv") if row["volume_name"] == "Slab_PV")
        stat = next(row for row in rows(output / "scorer_statistics.csv") if row["scorer"] == "dose" and row["quantity"] == "weighted_dose" and row["name"] == "Slab_PV")
        n = freeze["events_per_case"]
        mass = freeze["density_g_cm3"] * math.prod(freeze["slab_xy_mm"]) * case["slab_mm"] * 1e-6
        require(name + ":mass", close(float(dose["mass_kg"]), mass))
        raw_hits, weighted_hits = [], []
        event_terms = defaultdict(list)
        hit_rows = rows(output / "hits_t0.csv")
        require(name + ":hit-volume", bool(hit_rows) and all(row["volume"] == "Slab_PV" for row in hit_rows))
        for row in hit_rows:
            event = int(row["eventID"])
            assert 0 <= event < n
            edep, weight = float(row["edep_MeV"]), float(row["weight"])
            assert math.isfinite(edep) and math.isfinite(weight) and edep >= 0 and weight >= 0
            raw_hits.append(edep)
            weighted_hits.append(edep * weight)
            event_terms[event].append(edep * weight)
        raw, weighted = math.fsum(raw_hits), math.fsum(weighted_hits)
        per_event = [math.fsum(x) for x in event_terms.values()]
        squared = math.fsum(x * x for x in per_event)
        require(name + ":raw-energy", close(raw, float(dose["raw_edep_MeV"])))
        require(name + ":weighted-energy", close(weighted, float(dose["weighted_edep_MeV"])))
        require(name + ":event-squares", close(squared, float(dose["weighted_edep_sum_sq_MeV2"])))
        require(name + ":n", int(dose["n_events"]) == int(stat["n_events"]) == n)
        require(name + ":nonzero-entries", int(stat["entries"]) == sum(x > 0 for x in per_event))
        reconstructed_dose = weighted * 1.602176634e-13 / mass
        require(name + ":raw-dose", close(raw * 1.602176634e-13 / mass, float(dose["raw_dose_Gy"])))
        require(name + ":weighted-dose", close(reconstructed_dose, float(dose["weighted_dose_Gy"])))
        require(name + ":stat-dose", close(reconstructed_dose, float(stat["value"])))
        variance = squared / weighted**2 - 1 / n
        assert variance > 0
        rel_error = math.sqrt(variance)
        require(name + ":event-relative-error", close(rel_error, float(stat["rel_error"])))
        mid = interp(interp(case["energy_MeV"], energies, ranges) - freeze["density_g_cm3"] * (case["buildup_mm"] + case["slab_mm"] / 2) / 10, ranges, energies)
        reference = interp(mid, energies, stopping) * 1.602176634e-10
        require(name + ":reference", close(reference, case["reference_dose_per_fluence_Gy_cm2"]))
        observed = reconstructed_dose * freeze["source"]["area_cm2"] / n
        sigma = observed * rel_error
        threshold = 0.02 * reference + 3 * sigma
        require(name + ":physical", abs(observed - reference) <= threshold)
        summaries.append({"case": name, "N": n, "nonzero_events": sum(x > 0 for x in per_event), "mass_kg": mass, "dose_Gy": reconstructed_dose, "event_rel_error": rel_error, "reference": reference, "observed_per_fluence": observed, "sigma": sigma, "threshold": threshold})
    report = {"schema": "q2_dose_independent_hit_math_v1", "scope": "fixed four cases, all depositing species; no product imports; zero events included in N", "status": "pass", "checks": checks, "cases": summaries}
    (BASE / "independent-math-results.json").write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print("independent math passed", len(checks), "checks", len(summaries), "cases")


if __name__ == "__main__":
    main()
