#!/usr/bin/env python3
"""Evaluate the frozen Q2-4 uncertainty experiment from its public outputs.

The evaluator is independent of the runner: it re-reads the frozen contract,
the identity file, every raw output and every printed scalar, and recomputes
each quantity with pre-registered half-unit interval propagation.  It never
runs Geant4, never changes inputs and never touches product code.

Exit code: 0 when every check passes, 1 otherwise.  This is a comparison
result, not a backend exit code; the recorded backend exit codes are reported
separately.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from datetime import datetime, timezone
from decimal import Decimal, localcontext
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-uncertainty-v1"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-uncertainty-freeze-v1.json"
IDENTITY = BASE / "identity.json"
RESULTS = BASE / "results.json"
BACKEND = ROOT / "out" / "collab" / "q2-backend-864bc036" / "G4UniversalSim.exe"

FROZEN_BACKEND_SHA = "f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f"
FROZEN_FREEZE_SHA = "5768cc413d7e05b586fdbe8074342e52ec14cdbf27fbc037163604775e0381b6"
REFERENCE_DOCS = {
    "docs/collab/decisions/20261105-q2-uncertainty-coverage-design-v1.json":
        "f179a241d77ef483a143c086c31c2e14fd5c63a84422071298d6ae83251a3af3",
    "docs/collab/reviews/20261105-q2-uncertainty-preregister-review.md":
        "55b73bc7ad8817f6adec67c249bf270dfa3b0ff2a8746db9d4f709efbda9e9db",
    "docs/collab/decisions/20261105-q2-dose-reference-freeze-v1.json":
        "a2a799e90bd941b4969beab62be408013420dfbd684c4e8e52f07775308e498d",
    "docs/collab/decisions/20261105-q2-fluence-reference-freeze-v1.json":
        "d9ceb71f9cb6a3bcf4029010eb2bf2212c6b014dca9967b40277e01379b077b3",
    "docs/collab/decisions/20261105-q2-let-reference-freeze-v1.json":
        "b22b7d6535d226f632719f759003b391d2153f28802a348ae4b071a178136af1",
}
HALF_UNIT_EXPONENT = -11
EVENT_EDEP_HEADER = ["runID", "eventID", "raw_edep_MeV", "weighted_edep_MeV"]
DOSE_HEADER = ["runID", "volume_path", "volume_name", "mass_kg", "raw_edep_MeV",
               "weighted_edep_MeV", "raw_dose_Gy", "weighted_dose_Gy",
               "raw_edep_sum_sq_MeV2", "weighted_edep_sum_sq_MeV2", "n_events"]
LET_HEADER = ["runID", "volume_path", "volume_name", "particles", "steps",
              "sum_wl_mm", "sum_wSl_MeV", "sum_wS2l_MeV2_per_mm",
              "let_t_keV_per_um", "let_d_keV_per_um", "sum_sq_wl_mm2",
              "sum_sq_wSl_MeV2", "sum_sq_wS2l_MeV4_per_mm2",
              "sum_wl_x_wSl_MeV_mm", "sum_wSl_x_wS2l_MeV3_per_mm", "n_events"]
FLUENCE_HEADER = ["runID", "volume_path", "volume_name", "volume_mm3",
                  "raw_track_length_mm", "weighted_track_length_mm",
                  "raw_fluence_mm-2", "weighted_fluence_mm-2",
                  "raw_track_length_sum_sq_mm2", "weighted_track_length_sum_sq_mm2",
                  "n_events"]
STATS_HEADER = ["runID", "scorer", "quantity", "key", "name", "unit", "estimator",
                "n_events", "entries", "value", "mean_per_event", "std_error",
                "rel_error", "fom_per_s", "run_wall_time_s", "sum", "sum_sq",
                "uncertainty_estimator", "uncertainty_status"]

TOT_MASS_KG = Decimal("4.66e-06")
N1_MASS_KG = Decimal("4.66e-04")
MEV_TO_J = Decimal("1.602176634e-13")
COVERAGE_N = 2000
COVERAGE_AREA = Decimal(144)
TWO = Decimal(2)
EXPECTED = {
    "UNC-TOT": {"events": 20, "threads": 1, "seed": 20261120, "cut": Decimal("0.01"),
                "physics_reference": None},
    "UNC-N1": {"events": 1, "threads": 1, "seed": 20261121, "cut": Decimal("0.01"),
               "physics_reference": None},
    "UNC-ZERO": {"events": 100, "threads": 1, "seed": 20261122, "cut": Decimal("0.01"),
                 "physics_reference": None},
    "UNC-LET-COV": {"events": 2000, "threads": 1, "seed": 20261123,
                    "cut": Decimal("0.01"),
                    "physics_reference": "FTFP_BERT_EMZ"},
    "UNC-MT-SPARSE": {"events": 2, "threads": 4, "seed": 20261124, "cut": Decimal("0.01"),
                      "physics_reference": None},
    "UNC-COVERAGE": {"events": 2000, "threads": 1, "seed": None, "cut": Decimal("0.7"),
                     "physics_reference": None},
}
COVERAGE_SEEDS = list(range(220001, 220065))
FROZEN_COMPONENT_SOURCES = {
    "src/Scoring/HistoryStatistics.cc":
        "91fdcc6421507286ffddc1a021e716acac6d2bb43f4ac4a841ac8001b7b4eaaa",
    "include/Scoring/HistoryStatistics.hh":
        "abad43750bb5403683a9da638e375a936ebdab76526b4c18790cba4815056643",
    "include/Scoring/NumericChecks.hh":
        "dae1399a57fee4a04bd949acef9b8dfd9a1a1b60ce44ab6d6b8b5d5b6d70f448",
}


# --------------------------------------------------------------------------
# utilities
# --------------------------------------------------------------------------
def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_csv_rows(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    if not path.is_file():
        return [], []
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    if not lines:
        return [], []
    header = [item.strip() for item in lines[0].split(",")]
    rows = []
    for line in lines[1:]:
        if line.strip():
            rows.append(dict(zip(header, [item.strip() for item in line.split(",")])))
    return header, rows


def parse_run_summary(path: Path) -> dict[str, str]:
    values = {}
    if not path.is_file():
        return values
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if " = " in line:
            key, _, value = line.partition(" = ")
            values[key.strip()] = value.strip()
    return values


def read_json(path: Path) -> dict:
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def thread_rows(output: Path, prefix: str) -> list[dict[str, str]]:
    rows = []
    for path in sorted(output.glob(prefix + "_t*.csv")):
        _, part = read_csv_rows(path)
        rows.extend(part)
    return rows


def thread_paths(output: Path, prefix: str) -> list[Path]:
    return sorted(output.glob(prefix + "_t*.csv"))


def as_decimal(text: str) -> Decimal:
    return Decimal(str(text).strip())


def finite(text: str) -> bool:
    try:
        return math.isfinite(float(text))
    except (TypeError, ValueError):
        return False


def half_unit(value: Decimal) -> Decimal:
    if value == 0:
        return Decimal(0)
    with localcontext() as ctx:
        ctx.prec = 60
        return Decimal(1).scaleb(value.copy_abs().adjusted() + HALF_UNIT_EXPONENT) / TWO


class Interval:
    """Closed Decimal interval with interval arithmetic."""

    __slots__ = ("low", "high")

    def __init__(self, low: Decimal, high: Decimal) -> None:
        self.low = min(low, high)
        self.high = max(low, high)

    @classmethod
    def printed(cls, text: str) -> "Interval":
        value = as_decimal(text)
        if value == 0:
            return cls(Decimal(0), Decimal(0))
        tolerance = half_unit(value)
        return cls(value - tolerance, value + tolerance)

    @classmethod
    def exact(cls, value) -> "Interval":
        number = Decimal(value)
        return cls(number, number)

    def __add__(self, other: "Interval") -> "Interval":
        return Interval(self.low + other.low, self.high + other.high)

    def __sub__(self, other: "Interval") -> "Interval":
        return Interval(self.low - other.high, self.high - other.low)

    def __mul__(self, other: "Interval") -> "Interval":
        values = (self.low * other.low, self.low * other.high,
                  self.high * other.low, self.high * other.high)
        return Interval(min(values), max(values))

    def __truediv__(self, other: "Interval") -> "Interval":
        if other.low <= 0 <= other.high:
            raise ZeroDivisionError("division by an interval containing zero")
        values = (self.low / other.low, self.low / other.high,
                  self.high / other.low, self.high / other.high)
        return Interval(min(values), max(values))

    def sqrt(self) -> "Interval":
        if self.low < 0:
            raise ValueError("sqrt of a negative interval")
        return Interval(self.low.sqrt(), self.high.sqrt())

    def overlaps(self, other: "Interval") -> bool:
        return self.low <= other.high and other.low <= self.high

    def __repr__(self) -> str:
        return f"[{self.low}, {self.high}]"


def isum(intervals) -> Interval:
    total = Interval.exact(0)
    for item in intervals:
        total = total + item
    return total


def equals_printed(computed: Interval, printed: str) -> bool:
    return computed.overlaps(Interval.printed(printed))


def overlap_printed_squared(computed_squared: Interval, printed_relerror: str) -> bool:
    printed = Interval.printed(printed_relerror)
    return (printed * printed).overlaps(computed_squared)


# --------------------------------------------------------------------------
# check bookkeeping
# --------------------------------------------------------------------------
def add(checks: list[dict], check_id: str, ok: bool, detail: str) -> bool:
    checks.append({"id": check_id, "status": "pass" if ok else "fail",
                   "ok": bool(ok), "detail": detail})
    return bool(ok)


def output_dir_of(record: dict) -> Path:
    text = str(record.get("output_dir", "")).replace("\\", "/")
    path = Path(text)
    if not path.is_absolute():
        path = ROOT / path
    return path


def resolve(relative: str) -> Path:
    path = Path(str(relative).replace("\\", "/"))
    return path if path.is_absolute() else ROOT / path


def repo_relative(path: Path) -> str:
    return Path(path).resolve().relative_to(ROOT).as_posix()


# --------------------------------------------------------------------------
# identity
# --------------------------------------------------------------------------
def identity_checks(checks: list[dict], identity: dict) -> None:
    actual = sha256(FREEZE)
    add(checks, "ID-FREEZE-SHA",
        actual == identity["freeze"]["sha256"] == FROZEN_FREEZE_SHA,
        f"freeze sha256 {actual}")
    backend_sha = sha256(BACKEND)
    add(checks, "ID-BACKEND-SHA",
        backend_sha == identity["backend"]["sha256"] == FROZEN_BACKEND_SHA,
        f"backend sha256 {backend_sha}")
    log_text = (BASE / identity["backend"]["data_check_log"]).read_text(
        encoding="utf-8", errors="replace")
    position = log_text.find("{")
    report = json.loads(log_text[position:]) if position >= 0 else {}
    add(checks, "ID-GEANT4-DATA",
        identity["backend"]["geant4_version_number"] == 1132
        and identity["backend"]["data_check_exit_code"] == 0
        and report.get("required_complete") is True,
        f"Geant4 {identity['backend']['geant4_version_number']} "
        f"required_complete={report.get('required_complete')}")
    inputs_ok = all(resolve(item["path"]).is_file()
                    and sha256(resolve(item["path"])) == item["sha256"]
                    for item in identity["inputs"].values())
    manifest = read_json(BASE / "inputs_manifest.json")
    add(checks, "ID-INPUTS",
        inputs_ok and len(identity["inputs"]) == 17
        and manifest.get("files") == {name: item["sha256"]
                                      for name, item in identity["inputs"].items()},
        f"{len(identity['inputs'])} frozen inputs re-hashed")
    docs_ok = True
    for relative, expected in REFERENCE_DOCS.items():
        path = ROOT / relative
        docs_ok &= path.is_file() and sha256(path) == expected
    add(checks, "ID-REFERENCE-DOCS", docs_ok,
        f"{len(REFERENCE_DOCS)} reference documents re-hashed")


# --------------------------------------------------------------------------
# per-run evidence
# --------------------------------------------------------------------------
def required_artifacts(case_name: str, output: Path) -> list[str]:
    if case_name == "UNC-MT-SPARSE":
        names = ["run_summary.txt", "run_metadata.json", "scorer_statistics.csv"]
        for prefix in ("dose_volume_summary", "let_volume_summary", "event_edep"):
            paths = thread_paths(output, prefix)
            names.extend(path.name for path in paths)
        return names
    mapping = {
        "UNC-TOT": ["run_summary.txt", "run_metadata.json", "event_edep_t0.csv",
                    "dose_volume_summary_t0.csv", "scorer_statistics.csv"],
        "UNC-N1": ["run_summary.txt", "run_metadata.json",
                   "dose_volume_summary_t0.csv", "let_volume_summary_t0.csv",
                   "scorer_statistics.csv"],
        "UNC-ZERO": ["run_summary.txt", "run_metadata.json",
                     "dose_volume_summary_t0.csv", "let_volume_summary_t0.csv"],
        "UNC-LET-COV": ["run_summary.txt", "run_metadata.json",
                        "let_volume_summary_t0.csv", "scorer_statistics.csv"],
        "UNC-COVERAGE": ["run_summary.txt", "run_metadata.json",
                         "fluence_volume_summary_t0.csv", "scorer_statistics.csv"],
    }
    return mapping[case_name]


def expected_output_dir(identity: dict, key: str, case_name: str) -> Path:
    if case_name == "UNC-COVERAGE":
        index = int(key.replace("BATCH", ""))
        return resolve(identity["cases"]["UNC-COVERAGE"]["batches"][index]["output_dir"])
    return resolve(identity["cases"][case_name]["output_dir"])


def evidence_checks(checks: list[dict], key: str, case_name: str, record: dict,
                    identity: dict) -> None:
    spec = EXPECTED[case_name]
    output = output_dir_of(record)
    summary = parse_run_summary(output / "run_summary.txt")
    metadata = read_json(output / "run_metadata.json")
    values = metadata.get("values") or {}
    runs = metadata.get("runs") or [{}]
    files = {Path(item.get("path", "")).name: item
             for item in metadata.get("generated_files", [])}
    completed = int(summary.get("actual_completed_event_count", -1))

    add(checks, f"EVID-COMPLETED-{key}",
        summary.get("status") == "completed"
        and int(summary.get("program_exit_code", -1)) == 0
        and completed == spec["events"]
        and int(summary.get("run_count", -1)) == 1
        and int(summary.get("run_0_planned_events", -1)) == spec["events"]
        and int(summary.get("run_0_completed_events", -1)) == spec["events"]
        and summary.get("output_failure_status") == "none",
        f"status={summary.get('status')} completed={completed}/{spec['events']} "
        f"exit={summary.get('program_exit_code')}")

    required = required_artifacts(case_name, output)
    missing = [name for name in required if name not in files]
    assets_ok = not missing
    for name, item in files.items():
        path = output / name
        if name == "run_metadata.json":
            assets_ok &= (item.get("integrity_status") == "self_reference_excluded"
                          and item.get("sha256") is None)
            continue
        if not path.is_file() or item.get("sha256") != sha256(path) \
                or item.get("size_bytes") != path.stat().st_size:
            assets_ok = False
            break
    add(checks, f"EVID-METADATA-{key}",
        metadata.get("schema") == "run_metadata_json_v1"
        and int(values.get("actual_completed_event_count", -1)) == spec["events"]
        and int(values.get("actual_threads", -1)) == spec["threads"]
        and int(runs[0].get("completed_events", -1)) == spec["events"]
        and int(runs[0].get("planned_events", -1)) == spec["events"]
        and assets_ok,
        f"threads={values.get('actual_threads')} "
        f"listed={len(required)-len(missing)}/{len(required)}")

    expected_seed = spec["seed"]
    if expected_seed is None:
        index = int(key.replace("BATCH", ""))
        seed = COVERAGE_SEEDS[index]
        seed_ok = (summary.get("effective_seed_origin_kind") == "cli"
                   and int(summary.get("effective_configured_seed", -1)) == seed
                   and int(summary.get("seed", -2)) == seed
                   and int(summary.get("planned_seed", -3)) == seed)
    else:
        seed_ok = (int(summary.get("seed", -1)) == expected_seed
                   and int(summary.get("planned_seed", -1)) == expected_seed)
    add(checks, f"EVID-SEED-{key}", seed_ok,
        f"seed={summary.get('seed')} origin={summary.get('effective_seed_origin_kind')}")

    cut_ok = False
    try:
        cut_ok = equals_printed(Interval.exact(spec["cut"]),
                                summary.get("physics_default_cut", ""))
    except Exception:
        cut_ok = False
    expected_reference = spec["physics_reference"]
    if expected_reference is None:
        physics_ok = (
            summary.get("physics_em") == "G4EmStandardPhysics_option4"
            and summary.get("physics_reference", "") in ("", "not_applicable")
            and summary.get("physics_extra_modules", "") == "")
    else:
        physics_ok = (
            summary.get("physics_reference") == expected_reference
            and summary.get("physics_extra_modules", "") == "")
    add(checks, f"EVID-PHYSICS-{key}", physics_ok and cut_ok,
        f"em={summary.get('physics_em')} "
        f"reference={summary.get('physics_reference')} "
        f"cut={summary.get('physics_default_cut')} "
        f"modules={summary.get('physics_extra_modules')}")

    add(checks, f"EVID-OUTPUT-{key}", output == expected_output_dir(identity, key, case_name),
        f"output={output}")

    record_ok = int(record.get("exit_code", -1)) == 0
    for item in record.get("artifacts", {}).values():
        path = resolve(item["path"])
        if not path.is_file() or sha256(path) != item["sha256"]:
            record_ok = False
            break
    command = record.get("command") or []
    command_ok = (str(BACKEND) in command and "--config" in command
                  and "--macro" in command and "--output" in command
                  and "--threads" in command
                  and (spec["seed"] is not None or "--seed" in command))
    add(checks, f"EVID-RECORD-{key}", record_ok and command_ok,
        f"exit={record.get('exit_code')} artifacts={len(record.get('artifacts', {}))}")
    add(checks, f"EVID-INPUTS-{key}",
        record.get("identity_sha256") == sha256(IDENTITY),
        "identity file unchanged")


# --------------------------------------------------------------------------
# main case checks
# --------------------------------------------------------------------------
def tot_checks(checks: list[dict], output: Path) -> None:
    n = 20
    header, rows = read_csv_rows(output / "event_edep_t0.csv")
    ids = [int(row["eventID"]) for row in rows]
    add(checks, "TOT-EVENT-ROWS",
        header == EVENT_EDEP_HEADER and len(rows) == n
        and len(set(ids)) == n and sorted(ids) == list(range(n)),
        f"rows={len(rows)} distinct={len(set(ids))}")

    zero_count = sum(1 for row in rows
                     if as_decimal(row["raw_edep_MeV"]) == 0)
    _, stats_early = read_csv_rows(output / "scorer_statistics.csv")
    dose_entries = [int(row.get("entries", -1)) for row in stats_early
                    if row.get("scorer") == "dose"
                    and row.get("quantity") in ("raw_dose", "weighted_dose")]
    add(checks, "TOT-ZERO-ROWS-KEPT",
        len(rows) == n and all(int(row["eventID"]) < n for row in rows)
        and bool(dose_entries)
        and all(entries + zero_count == n for entries in dose_entries),
        f"rows={len(rows)} zero_rows={zero_count} dose_entries={dose_entries}")

    _, dose_rows = read_csv_rows(output / "dose_volume_summary_t0.csv")
    dose = dose_rows[0] if dose_rows else {}
    raw = isum([Interval.printed(row["raw_edep_MeV"]) for row in rows])
    weighted = isum([Interval.printed(row["weighted_edep_MeV"]) for row in rows])
    mass = Interval.printed(dose.get("mass_kg", "0"))
    add(checks, "TOT-EDEP-EQ-DOSE",
        equals_printed(raw * Interval.exact(MEV_TO_J) / mass,
                       dose.get("raw_dose_Gy", "0"))
        and equals_printed(weighted * Interval.exact(MEV_TO_J) / mass,
                           dose.get("weighted_dose_Gy", "0")),
        f"raw={raw} dose={dose.get('raw_dose_Gy')}")

    squared = isum([(Interval.printed(row["raw_edep_MeV"]) *
                     Interval.printed(row["raw_edep_MeV"])) for row in rows])
    variance = squared / (raw * raw) - Interval.exact(1) / Interval.exact(n)
    if variance.low < 0:  # interval rounding only: a variance cannot be negative
        variance = Interval(Decimal(0), max(variance.high, Decimal(0)))
    r = variance.sqrt()
    positive = sum(1 for row in rows if as_decimal(row["raw_edep_MeV"]) > 0)
    _, stats = read_csv_rows(output / "scorer_statistics.csv")
    dose_stats = [row for row in stats if row.get("scorer") == "dose"
                  and row.get("quantity") in ("raw_dose", "weighted_dose")]
    add(checks, "TOT-MOMENTS",
        len(dose_stats) == 2 and all(
            equals_printed(r, row.get("rel_error", "0"))
            and int(row.get("entries", -1)) == positive
            and int(row.get("n_events", -1)) == n
            and row.get("uncertainty_status") == "approximate"
            for row in dose_stats),
        f"R={r} entries={positive}")

    summary = parse_run_summary(output / "run_summary.txt")
    add(checks, "TOT-NOT-HITS-ROWS",
        len(rows) == int(summary.get("actual_completed_event_count", -1))
        and len(set(ids)) == len(rows),
        f"rows={len(rows)} summary_N={summary.get('actual_completed_event_count')}")
    add(checks, "TOT-MASS",
        equals_printed(Interval.exact(TOT_MASS_KG), dose.get("mass_kg", "0")),
        f"mass={dose.get('mass_kg')}")


def n1_checks(checks: list[dict], output: Path) -> None:
    _, dose_rows = read_csv_rows(output / "dose_volume_summary_t0.csv")
    dose = dose_rows[0] if dose_rows else {}
    add(checks, "N1-DOSE-ROW",
        len(dose_rows) == 1 and finite(dose.get("raw_dose_Gy", ""))
        and as_decimal(dose.get("raw_dose_Gy", "0")) > 0
        and equals_printed(Interval.exact(N1_MASS_KG), dose.get("mass_kg", "0"))
        and int(dose.get("n_events", -1)) == 1,
        f"rows={len(dose_rows)} dose={dose.get('raw_dose_Gy')}")
    _, let_rows = read_csv_rows(output / "let_volume_summary_t0.csv")
    let = let_rows[0] if let_rows else {}
    add(checks, "N1-LET-ROW",
        len(let_rows) == 1 and finite(let.get("let_t_keV_per_um", ""))
        and finite(let.get("let_d_keV_per_um", ""))
        and as_decimal(let.get("let_t_keV_per_um", "0")) > 0
        and as_decimal(let.get("let_d_keV_per_um", "0")) > 0
        and int(let.get("n_events", -1)) == 1,
        f"rows={len(let_rows)} let_t={let.get('let_t_keV_per_um')}")
    _, stats = read_csv_rows(output / "scorer_statistics.csv")
    add(checks, "N1-STATUS",
        len(stats) == 4
        and all(int(row.get("n_events", -1)) == 1 for row in stats)
        and all(row.get("uncertainty_status") == "insufficient_events"
                for row in stats),
        f"statuses={[row.get('uncertainty_status') for row in stats]}")
    add(checks, "N1-NO-ZERO-FABRICATION",
        all(row.get("uncertainty_status") != "approximate" for row in stats),
        "no fabricated approximate row")


def zero_checks(checks: list[dict], output: Path) -> None:
    dose_header, dose_rows = read_csv_rows(output / "dose_volume_summary_t0.csv")
    let_header, let_rows = read_csv_rows(output / "let_volume_summary_t0.csv")
    add(checks, "ZERO-DOSE-HEADER-ONLY",
        dose_header == DOSE_HEADER and not dose_rows,
        f"header_ok={dose_header == DOSE_HEADER} rows={len(dose_rows)}")
    add(checks, "ZERO-LET-HEADER-ONLY",
        let_header == LET_HEADER and not let_rows,
        f"header_ok={let_header == LET_HEADER} rows={len(let_rows)}")
    stats_path = output / "scorer_statistics.csv"
    add(checks, "ZERO-STATS-ABSENT", not stats_path.is_file(),
        f"exists={stats_path.is_file()}")
    _, stats = read_csv_rows(stats_path)
    add(checks, "ZERO-NO-FABRICATION",
        all(row.get("uncertainty_status") not in ("zero_total", "undefined_ratio")
            for row in stats),
        f"stats_rows={len(stats)}")
    metadata = read_json(output / "run_metadata.json")
    files = {Path(item["path"]).name: item
             for item in metadata.get("generated_files", [])}
    listed = all(name in files and files[name].get("sha256") == sha256(output / name)
                 for name in ("dose_volume_summary_t0.csv",
                              "let_volume_summary_t0.csv"))
    add(checks, "ZERO-METADATA",
        listed and int((metadata.get("runs") or [{}])[0].get("completed_events", -1)) == 100,
        f"listed={listed}")


def lev_cov_values(row: dict) -> dict:
    a = Interval.printed(row["sum_wl_mm"])
    b = Interval.printed(row["sum_wSl_MeV"])
    c = Interval.printed(row["sum_wS2l_MeV2_per_mm"])
    ba = Interval.printed(row["sum_wl_x_wSl_MeV_mm"])
    ac = Interval.printed(row["sum_wSl_x_wS2l_MeV3_per_mm"])
    sq_a = Interval.printed(row["sum_sq_wl_mm2"])
    sq_b = Interval.printed(row["sum_sq_wSl_MeV2"])
    sq_c = Interval.printed(row["sum_sq_wS2l_MeV4_per_mm2"])
    rt2 = sq_b / (b * b) + sq_a / (a * a) - Interval.exact(2) * ba / (a * b)
    rd2 = sq_c / (c * c) + sq_b / (b * b) - Interval.exact(2) * ac / (b * c)
    return {"a": a, "b": b, "c": c, "ba": ba, "ac": ac, "sq_a": sq_a,
            "sq_b": sq_b, "sq_c": sq_c, "rt2": rt2, "rd2": rd2}


def let_checks(checks: list[dict], output: Path) -> None:
    header, rows = read_csv_rows(output / "let_volume_summary_t0.csv")
    row = rows[0] if rows else {}
    add(checks, "LET-COV-ROWS",
        header == LET_HEADER and len(rows) == 1
        and int(row.get("n_events", -1)) == 2000
        and row.get("particles") == "proton" and int(row.get("steps", 0)) > 0,
        f"rows={len(rows)} steps={row.get('steps')}")
    values = lev_cov_values(row) if row else None
    add(checks, "LET-COV-LET-VALUES",
        values is not None
        and equals_printed(values["b"] / values["a"], row.get("let_t_keV_per_um", "0"))
        and equals_printed(values["c"] / values["b"], row.get("let_d_keV_per_um", "0")),
        f"let_t={row.get('let_t_keV_per_um')} let_d={row.get('let_d_keV_per_um')}")
    _, stats = read_csv_rows(output / "scorer_statistics.csv")
    let_t_row = next((item for item in stats if item.get("quantity") == "let_t"), {})
    let_d_row = next((item for item in stats if item.get("quantity") == "let_d"), {})
    add(checks, "LET-COV-RT",
        values is not None
        and overlap_printed_squared(values["rt2"], let_t_row.get("rel_error", "0")),
        f"R_t2={values['rt2'] if values else None} printed={let_t_row.get('rel_error')}")
    add(checks, "LET-COV-RD",
        values is not None
        and overlap_printed_squared(values["rd2"], let_d_row.get("rel_error", "0")),
        f"R_d2={values['rd2'] if values else None} printed={let_d_row.get('rel_error')}")
    cross_ok = False
    if values is not None:
        zero_t = (values["sq_b"] / (values["b"] * values["b"])
                  + values["sq_a"] / (values["a"] * values["a"]))
        zero_d = (values["sq_c"] / (values["c"] * values["c"])
                  + values["sq_b"] / (values["b"] * values["b"]))
        cross_ok = (values["ba"].low > 0 and values["ac"].low > 0
                    and not overlap_printed_squared(zero_t,
                                                    let_t_row.get("rel_error", "0"))
                    and not overlap_printed_squared(zero_d,
                                                    let_d_row.get("rel_error", "0")))
    add(checks, "LET-COV-CROSS-MOMENTS", cross_ok,
        "cross moments present; recomputing with BA=AC=0 changes both rel errors")
    add(checks, "LET-COV-NO-PHYSICAL-BOUND", True,
        "only the statistical identity is checked; no 0.05 bound")


def mt_checks(checks: list[dict], output: Path) -> dict:
    summary = parse_run_summary(output / "run_summary.txt")
    metadata = read_json(output / "run_metadata.json")
    add(checks, "MT-METADATA",
        int(summary.get("actual_threads", -1)) == 4
        and int(summary.get("actual_completed_event_count", -1)) == 2
        and int((metadata.get("runs") or [{}])[0].get("completed_events", -1)) == 2,
        f"threads={summary.get('actual_threads')} "
        f"completed={summary.get('actual_completed_event_count')}")

    rows = thread_rows(output, "event_edep")
    ids = [int(row["eventID"]) for row in rows]
    add(checks, "MT-EVENT-IDS",
        len(rows) == 2 and len(set(ids)) == 2, f"rows={len(rows)} ids={sorted(ids)}")

    raw = isum([Interval.printed(row["raw_edep_MeV"]) for row in rows])
    weighted = isum([Interval.printed(row["weighted_edep_MeV"]) for row in rows])
    dose_rows = thread_rows(output, "dose_volume_summary")
    mass = Interval.printed(dose_rows[0]["mass_kg"]) if dose_rows else Interval.exact(0)
    raw_dose = isum([Interval.printed(row["raw_dose_Gy"]) for row in dose_rows])
    weighted_dose = isum([Interval.printed(row["weighted_dose_Gy"]) for row in dose_rows])
    add(checks, "MT-EDEP-MERGE",
        (raw_dose * mass / Interval.exact(MEV_TO_J)).overlaps(raw)
        and (weighted_dose * mass / Interval.exact(MEV_TO_J)).overlaps(weighted),
        f"raw={raw}")

    squared = isum([(Interval.printed(row["raw_edep_MeV"]) *
                     Interval.printed(row["raw_edep_MeV"])) for row in rows])
    variance = squared / (raw * raw) - Interval.exact(1) / Interval.exact(2)
    if variance.low < 0:  # interval rounding only: a variance cannot be negative
        variance = Interval(Decimal(0), max(variance.high, Decimal(0)))
    r = variance.sqrt()
    positive = sum(1 for row in rows if as_decimal(row["raw_edep_MeV"]) > 0)
    _, stats = read_csv_rows(output / "scorer_statistics.csv")
    dose_stats = [row for row in stats if row.get("scorer") == "dose"]
    add(checks, "MT-DOSE-STATS",
        len(dose_stats) == 2 and all(
            int(row.get("n_events", -1)) == 2
            and int(row.get("entries", -1)) == positive
            and equals_printed(r, row.get("rel_error", "0"))
            for row in dose_stats),
        f"R={r} entries={positive}")

    let_rows = thread_rows(output, "let_volume_summary")
    let_t_row = next((item for item in stats if item.get("quantity") == "let_t"), {})
    let_d_row = next((item for item in stats if item.get("quantity") == "let_d"), {})
    merged = None
    if let_rows:
        total = {name: isum([Interval.printed(row[name]) for row in let_rows])
                 for name in ("sum_wl_mm", "sum_wSl_MeV", "sum_wS2l_MeV2_per_mm",
                              "sum_wl_x_wSl_MeV_mm", "sum_wSl_x_wS2l_MeV3_per_mm",
                              "sum_sq_wl_mm2", "sum_sq_wSl_MeV2",
                              "sum_sq_wS2l_MeV4_per_mm2")}
        a, b, c = total["sum_wl_mm"], total["sum_wSl_MeV"], total["sum_wS2l_MeV2_per_mm"]
        ba, ac = total["sum_wl_x_wSl_MeV_mm"], total["sum_wSl_x_wS2l_MeV3_per_mm"]
        rt2 = (total["sum_sq_wSl_MeV2"] / (b * b)
               + total["sum_sq_wl_mm2"] / (a * a) - Interval.exact(2) * ba / (a * b))
        rd2 = (total["sum_sq_wS2l_MeV4_per_mm2"] / (c * c)
               + total["sum_sq_wSl_MeV2"] / (b * b) - Interval.exact(2) * ac / (b * c))
        merged = {"rt2": rt2, "rd2": rd2, "let_t": b / a, "let_d": c / b,
                  "a": a, "b": b, "c": c}
    let_ok = (merged is not None
              and overlap_printed_squared(merged["rt2"], let_t_row.get("rel_error", "0"))
              and overlap_printed_squared(merged["rd2"], let_d_row.get("rel_error", "0")))
    add(checks, "MT-LET-MERGE", let_ok,
        f"merged let_t={merged['let_t'] if merged else None}")

    non_empty = 0
    for path in thread_paths(output, "event_edep"):
        _, part = read_csv_rows(path)
        if part:
            non_empty += 1
    worker_errors = []
    for path in thread_paths(output, "let_volume_summary"):
        _, part = read_csv_rows(path)
        if not part:
            continue
        values = lev_cov_values(part[0])
        if values["rt2"].low >= 0:
            worker_errors.append(values["rt2"].sqrt())
    average_note = "not_computed"
    if len(worker_errors) >= 2:
        average_note = str(sum(worker_errors, Interval.exact(0)) /
                           Interval.exact(len(worker_errors)))
    add(checks, "MT-NO-WORKER-AVERAGE",
        let_ok and non_empty <= 4 and (4 - non_empty) >= 2,
        f"non_empty_event_workers={non_empty} empty>={4-non_empty} "
        f"merged_relerr={let_t_row.get('rel_error')} worker_average={average_note}; "
        "the frozen sparse run is not forced to make the wrong average distinguishable")
    return {"non_empty_event_workers": non_empty,
            "worker_average_note": average_note}


# --------------------------------------------------------------------------
# component probe
# --------------------------------------------------------------------------
def component_checks(checks: list[dict]) -> None:
    probe = read_json(BASE / "probe" / "probe_results.json")
    if not probe:
        for check_id in ("CMP-BUILD", "CMP-FIXTURES", "CMP-COVARIANCE", "CMP-NO-MIRROR"):
            add(checks, check_id, False, "probe_results.json missing")
        return
    build = probe.get("build", {})
    build_command = str(build.get("command", "")).replace("\\", "/")
    add(checks, "CMP-BUILD",
        build.get("exit_code") == 0
        and "src/Scoring/HistoryStatistics.cc" in build_command
        and build.get("source_sha256")
        == FROZEN_COMPONENT_SOURCES["src/Scoring/HistoryStatistics.cc"]
        and all(build.get("sources", {}).get(name) == value
                for name, value in FROZEN_COMPONENT_SOURCES.items()),
        f"probe build exit={build.get('exit_code')} sources_ok="
        f"{all(build.get('sources', {}).get(name) == value for name, value in FROZEN_COMPONENT_SOURCES.items())}")
    expected = {
        "N=0,num=1,total": "insufficient_events",
        "N=1,num=0,ratio,den=0": "insufficient_events",
        "N=2,num=1,ratio,den=0": "undefined_ratio",
        "N=2,num=0,total": "zero_total",
        "N=2,num=0,ratio,den=1": "zero_total",
        "N=2,num=1,total": "approximate",
        "N=2,num=1,ratio,den=1": "approximate",
    }
    actual = {item.get("fixture"): item.get("status")
              for item in probe.get("fixtures", [])}
    add(checks, "CMP-FIXTURES", actual == expected, f"{len(actual)} fixtures")
    cov = probe.get("covariance", {})
    add(checks, "CMP-COVARIANCE",
        cov.get("A") == 3 and cov.get("B") == 3
        and cov.get("sum_sq_A") == 5 and cov.get("sum_sq_B") == 5
        and cov.get("cross") == 4
        and abs(cov.get("ratio", 0) - 1) < 1e-15
        and abs(cov.get("relative_error", 0) - math.sqrt(2) / 3) < 1e-12,
        f"R={cov.get('relative_error')}")
    add(checks, "CMP-NO-MIRROR",
        "src/Scoring/HistoryStatistics.cc" in build_command,
        "the probe links the real shared implementation")


# --------------------------------------------------------------------------
# coverage
# --------------------------------------------------------------------------
def exact_covered(k: int, n: int = COVERAGE_N) -> bool:
    if k < 0 or k > n:
        return False
    return n * (144 * k - 100 * n) ** 2 <= 4 * 144 * 144 * k * (n - k)


def single_batch_probability() -> Decimal:
    n = COVERAGE_N
    covered = [k for k in range(n + 1) if exact_covered(k)]
    total = sum(math.comb(n, k) * 25 ** k * 11 ** (n - k) for k in covered)
    with localcontext() as ctx:
        ctx.prec = 60
        return Decimal(total) / Decimal(36 ** n)


def lower_tail_count(probability: Decimal, batches: int, threshold: int) -> Decimal:
    with localcontext() as ctx:
        ctx.prec = 60
        total = Decimal(0)
        for k in range(threshold):
            total += (Decimal(math.comb(batches, k))
                      * probability ** k
                      * (Decimal(1) - probability) ** (batches - k))
        return total


def coverage_checks(checks: list[dict], identity: dict, records: dict) -> dict:
    names = [f"UNC-COVERAGE/batch_{index:03d}" for index in range(64)]
    present = [name for name in names if name in records]
    extra = [name for name in records if name.startswith("UNC-COVERAGE/")
             and name not in names]
    seeds_ok = all(
        int(records[name]["summary"].get("seed", -1)) == COVERAGE_SEEDS[index]
        for index, name in enumerate(names) if name in records)
    completed_ok = all(
        int(records[name]["summary"].get("actual_completed_event_count", -1))
        == COVERAGE_N for name in present)
    add(checks, "COV-BATCHES",
        len(records) >= 64 and len(present) == 64 and seeds_ok and completed_ok
        and not extra,
        f"present={len(present)}/64 seeds_ok={seeds_ok} completed_ok={completed_ok} "
        f"extra={extra}")

    ks: list[int] = []
    path_ok = True
    covered = 0
    for index, name in enumerate(names):
        if name not in records:
            path_ok = False
            continue
        output = output_dir_of(records[name])
        header, rows = read_csv_rows(output / "fluence_volume_summary_t0.csv")
        _, stats = read_csv_rows(output / "scorer_statistics.csv")
        stat = next((item for item in stats if item.get("quantity") == "raw_fluence"),
                    {})
        if header != FLUENCE_HEADER or len(rows) != 1:
            path_ok = False
            continue
        row = rows[0]
        length = as_decimal(row["raw_track_length_mm"])
        k = int((length / Decimal("0.1")).to_integral_value())
        ks.append(k)
        model_ok = (
            equals_printed(Interval.exact(Decimal(k) / Decimal(10)),
                           row["raw_track_length_mm"])
            and equals_printed(Interval.exact(Decimal(k) / Decimal(100)),
                               row["raw_fluence_mm-2"])
            and equals_printed(Interval.exact(Decimal(k) / Decimal(100)),
                               row["raw_track_length_sum_sq_mm2"])
            and equals_printed(Interval.exact(Decimal(k) / Decimal(10000)),
                               stat.get("sum_sq", "0")))
        if not model_ok:
            path_ok = False
        integer_ok = exact_covered(k)
        phi = as_decimal(row["raw_fluence_mm-2"])
        rel = as_decimal(stat.get("rel_error", "0"))
        n144 = Decimal(COVERAGE_N) / COVERAGE_AREA
        tolerance = (half_unit(phi) + 2 * phi * half_unit(rel)
                     + 2 * half_unit(phi) * rel + Decimal("1e-30"))
        printed_ok = abs(phi - n144) <= 2 * phi * rel + tolerance
        if printed_ok != integer_ok:
            path_ok = False
        if integer_ok:
            covered += 1
    add(checks, "COV-PATH", path_ok,
        f"64 batches; printed/analytic consistency={path_ok}; covered={covered}")

    range_ok = bool(ks) and all((1347 <= k <= 1429) == exact_covered(k) for k in ks)
    add(checks, "COV-K-RANGE", range_ok,
        f"K range {min(ks) if ks else None}..{max(ks) if ks else None}; "
        f"covered K range [1347,1429]")

    probability = single_batch_probability()
    tail = lower_tail_count(probability, 64, 57)
    add(checks, "COV-MODEL-PROB",
        abs(probability - Decimal("0.9559137115315595")) < Decimal("1e-13")
        and abs(tail - Decimal("0.006980515323982699")) < Decimal("1e-12"),
        f"p_covered={probability} P(C<57)={tail}")

    add(checks, "COV-COUNT", covered >= 57, f"covered={covered}/64 (minimum 57)")
    total_k = sum(ks)
    add(checks, "COV-AGGREGATE", 88464 <= total_k <= 89313,
        f"sum(K)={total_k} expected 88888.888... in [88464,89313]")
    add(checks, "COV-SCOPE", True,
        "conclusion limited to this frozen model, seeds and 64-sample distribution")
    return {"ks": ks, "covered": covered, "sum_k": total_k,
            "p_covered": str(probability), "p_count_below_57": str(tail)}


# --------------------------------------------------------------------------
# entry point
# --------------------------------------------------------------------------
def evaluate(identity: dict, results: dict) -> dict:
    checks: list[dict] = []
    identity_checks(checks, identity)
    records = results.get("runs", {})
    for name, record in records.items():
        if name.startswith("UNC-COVERAGE/"):
            key = "BATCH" + name.rsplit("_", 1)[1]
            case_name = "UNC-COVERAGE"
        else:
            key = name
            case_name = name
        if case_name in EXPECTED:
            evidence_checks(checks, key, case_name, record, identity)
    diagnostics = {}
    if "UNC-TOT" in records:
        tot_checks(checks, output_dir_of(records["UNC-TOT"]))
    if "UNC-N1" in records:
        n1_checks(checks, output_dir_of(records["UNC-N1"]))
    if "UNC-ZERO" in records:
        zero_checks(checks, output_dir_of(records["UNC-ZERO"]))
    if "UNC-LET-COV" in records:
        let_checks(checks, output_dir_of(records["UNC-LET-COV"]))
    if "UNC-MT-SPARSE" in records:
        diagnostics["mt"] = mt_checks(checks, output_dir_of(records["UNC-MT-SPARSE"]))
    component_checks(checks)
    diagnostics["coverage"] = coverage_checks(checks, identity, records)
    failed = [item["id"] for item in checks if item["status"] == "fail"]
    order = ["ID", "EVID", "TOT", "N1", "ZERO", "LET", "MT", "CMP", "COV"]

    def sort_key(item: dict):
        prefix = item["id"].split("-")[0]
        return (order.index(prefix) if prefix in order else len(order), item["id"])

    checks.sort(key=sort_key)
    return {
        "schema": "g4usim_q2_uncertainty_evaluation_v1",
        "evaluated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "status": "pass" if not failed else "fail",
        "checks_total": len(checks),
        "checks_pass": sum(1 for item in checks if item["status"] == "pass"),
        "checks_failed": len(failed),
        "failed_ids": failed,
        "checks": checks,
        "diagnostics": diagnostics,
        "backend_exit_codes": {name: record.get("exit_code")
                               for name, record in records.items()},
        "comparison_exit_is_not_backend_exit": True,
        "note": "a fail here is a comparison result; backend exit codes are "
                "reported separately",
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true",
                        help="store the evaluation into results.json")
    args = parser.parse_args(argv)
    identity = read_json(IDENTITY)
    results = read_json(RESULTS)
    evaluation = evaluate(identity, results)
    if args.write:
        results["evaluation"] = evaluation
        RESULTS.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n",
                           encoding="utf-8")
    print(f"status={evaluation['status']} checks={evaluation['checks_total']} "
          f"pass={evaluation['checks_pass']} fail={evaluation['checks_failed']}")
    print(f"coverage: K={evaluation['diagnostics']['coverage']['ks']}")
    if evaluation["failed_ids"]:
        print("failed ids: " + ", ".join(evaluation["failed_ids"]))
    return 0 if evaluation["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
