// One-off component probe for the frozen Q2-4 uncertainty experiment.
//
// This program links the repository's real shared implementation
// (src/Scoring/HistoryStatistics.cc) instead of a Python re-implementation and
// evaluates the pre-registered component fixtures:
//   * uncertainty-status priority table,
//   * delta-method covariance fixture A=[1,2,0], B=[2,1,0],
//   * tally accumulation over per-event values (zero events included).
//
// It is a candidate-local artifact, not a product interface.

#include "Scoring/HistoryStatistics.hh"

#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace {

struct Fixture {
    const char* name;
    long long events;
    double numerator;
    bool ratio;
    double denominator;
    const char* expected;
};

const Fixture kFixtures[] = {
    {"N=0,num=1,total", 0, 1.0, false, 0.0, "insufficient_events"},
    {"N=1,num=0,ratio,den=0", 1, 0.0, true, 0.0, "insufficient_events"},
    {"N=2,num=1,ratio,den=0", 2, 1.0, true, 0.0, "undefined_ratio"},
    {"N=2,num=0,total", 2, 0.0, false, 0.0, "zero_total"},
    {"N=2,num=0,ratio,den=1", 2, 0.0, true, 1.0, "zero_total"},
    {"N=2,num=1,total", 2, 1.0, false, 0.0, "approximate"},
    {"N=2,num=1,ratio,den=1", 2, 1.0, true, 1.0, "approximate"},
};

std::string Quote(const std::string& value)
{
    std::string out = "\"";
    for (char c : value) {
        if (c == '\\' || c == '"') out += '\\';
        out += c;
    }
    out += '"';
    return out;
}

}  // namespace

int main()
{
    std::printf("{\n");
    std::printf("  \"schema\": \"g4usim_q2_uncertainty_history_probe_v1\",\n");

    std::printf("  \"fixtures\": [\n");
    for (std::size_t index = 0; index < sizeof(kFixtures) / sizeof(kFixtures[0]); ++index) {
        const Fixture& fixture = kFixtures[index];
        const char* status = HistoryStatistics::UncertaintyStatus(
            fixture.events, fixture.numerator, fixture.ratio, fixture.denominator);
        if (std::string(status) != fixture.expected) {
            std::fprintf(stderr, "fixture %s: got %s expected %s\n",
                         fixture.name, status, fixture.expected);
            return 1;
        }
        std::printf("    {\"fixture\": %s, \"events\": %lld, \"numerator\": %.17g, "
                    "\"ratio\": %s, \"denominator\": %.17g, \"status\": %s}%s\n",
                    Quote(fixture.name).c_str(), fixture.events, fixture.numerator,
                    fixture.ratio ? "true" : "false", fixture.denominator,
                    Quote(status).c_str(),
                    index + 1 == sizeof(kFixtures) / sizeof(kFixtures[0]) ? "" : ",");
    }
    std::printf("  ],\n");

    // Delta-method covariance fixture A=[1,2,0], B=[2,1,0].
    const double valuesA[] = {1.0, 2.0, 0.0};
    const double valuesB[] = {2.0, 1.0, 0.0};
    HistoryTally tallyA;
    HistoryTally tallyB;
    HistoryTallySet set;
    double cross = 0.0;
    for (int index = 0; index < 3; ++index) {
        set.Add(tallyA, valuesA[index]);
        set.Add(tallyB, valuesB[index]);
        set.EndEvent();
        cross += valuesA[index] * valuesB[index];
    }
    if (tallyA.sum != 3.0 || tallyB.sum != 3.0 || tallyA.sumSq != 5.0 || tallyB.sumSq != 5.0
        || tallyA.entries != 2 || tallyB.entries != 2 || cross != 4.0) {
        std::fprintf(stderr, "tally fixture mismatch\n");
        return 1;
    }
    const double ratio = tallyB.sum != 0.0 ? tallyB.sum / tallyA.sum : 0.0;
    const double relative = HistoryStatistics::RatioRelativeError(
        tallyB.sum, tallyB.sumSq, tallyA.sum, tallyA.sumSq, cross);
    const double expected = std::sqrt(2.0) / 3.0;
    if (std::fabs(ratio - 1.0) > 1e-15 || std::fabs(relative - expected) > 1e-15) {
        std::fprintf(stderr, "covariance fixture mismatch: %g vs %g\n", relative, expected);
        return 1;
    }
    std::printf("  \"covariance\": {\"A\": %.17g, \"B\": %.17g, \"sum_sq_A\": %.17g, "
                "\"sum_sq_B\": %.17g, \"cross\": %.17g, \"entries_A\": %lld, "
                "\"entries_B\": %lld, \"ratio\": %.17g, \"relative_error\": %.17g,\n",
                tallyA.sum, tallyB.sum, tallyA.sumSq, tallyB.sumSq, cross,
                tallyA.entries, tallyB.entries, ratio, relative);
    std::printf("    \"tally_source\": \"HistoryTallySet per-event accumulation\", "
                "\"expected_relative_error\": %.17g},\n", expected);

    // Total-estimator relative error fixture: values [2,0,2] on N=3.
    HistoryTally total;
    HistoryTallySet totals;
    for (double value : {2.0, 0.0, 2.0}) {
        totals.Add(total, value);
        totals.EndEvent();
    }
    const double totalRelative = HistoryStatistics::RelativeError(total.sum, total.sumSq, 3);
    const double expectedTotal = std::sqrt(8.0 / 16.0 - 1.0 / 3.0);
    if (total.entries != 2 || total.sum != 4.0 || total.sumSq != 8.0
        || std::fabs(totalRelative - expectedTotal) > 1e-15) {
        std::fprintf(stderr, "total fixture mismatch\n");
        return 1;
    }
    std::printf("  \"total_moments\": {\"sum\": %.17g, \"sum_sq\": %.17g, \"entries\": %lld, "
                "\"relative_error\": %.17g, \"expected_relative_error\": %.17g},\n",
                total.sum, total.sumSq, total.entries, totalRelative, expectedTotal);

    std::printf("  \"ok\": true\n}\n");
    return 0;
}
