#!/usr/bin/env python3
"""Build and run the one-off HistoryStatistics component probe.

The probe compiles against the repository's real shared implementation
(src/Scoring/HistoryStatistics.cc) and records the compiler command and the
SHA-256 of every linked project source.  It is a candidate-local artifact, not
a product interface or test framework.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
BASE = Path(__file__).resolve().parent
PROBE = BASE / "history_statistics_probe.cc"
OUTPUT = BASE / "history_statistics_probe.exe"
SOURCES = {
    "src/Scoring/HistoryStatistics.cc": ROOT / "src" / "Scoring" / "HistoryStatistics.cc",
    "include/Scoring/HistoryStatistics.hh": ROOT / "include" / "Scoring" / "HistoryStatistics.hh",
    "include/Scoring/NumericChecks.hh": ROOT / "include" / "Scoring" / "NumericChecks.hh",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def find_compiler() -> str:
    candidates = [
        "D:/msys64/ucrt64/bin/g++.exe",
        shutil.which("g++") or "",
        shutil.which("c++") or "",
        "cl.exe",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return candidate
    raise SystemExit("no C++ compiler found (g++ or cl.exe required)")


def main() -> int:
    compiler = find_compiler()
    command = [
        compiler, "-std=c++17", "-O2", "-Wall", "-Wextra",
        "-I", str(ROOT / "include"),
        str(PROBE),
        str(SOURCES["src/Scoring/HistoryStatistics.cc"]),
        "-o", str(OUTPUT),
    ]
    completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    (BASE / "build_stdout.log").write_text(completed.stdout, encoding="utf-8")
    (BASE / "build_stderr.log").write_text(completed.stderr, encoding="utf-8")
    build = {
        "command": " ".join(str(item) for item in command),
        "exit_code": completed.returncode,
        "compiler": compiler,
        "sources": {name: sha256(path) for name, path in SOURCES.items()},
        "source_sha256": sha256(SOURCES["src/Scoring/HistoryStatistics.cc"]),
        "probe_sha256": sha256(PROBE),
        "stdout_log": "build_stdout.log",
        "stderr_log": "build_stderr.log",
    }
    if completed.returncode != 0:
        result = {"schema": "g4usim_q2_uncertainty_history_probe_v1",
                  "ok": False, "build": build}
        (BASE / "probe_results.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("compilation failed; see build logs", file=sys.stderr)
        return 1

    environment = os.environ.copy()
    environment["PATH"] = str(Path(compiler).parent) + os.pathsep + environment.get("PATH", "")
    run = subprocess.run([str(OUTPUT)], cwd=BASE, capture_output=True, text=True,
                         env=environment, timeout=120)
    (BASE / "probe_stdout.log").write_text(run.stdout, encoding="utf-8")
    (BASE / "probe_stderr.log").write_text(run.stderr, encoding="utf-8")
    try:
        probe = json.loads(run.stdout)
    except json.JSONDecodeError as error:
        print(f"probe output is not JSON: {error}", file=sys.stderr)
        return 1
    probe["build"] = build
    probe["run_exit_code"] = run.returncode
    probe["binary_sha256"] = sha256(OUTPUT)
    (BASE / "probe_results.json").write_text(
        json.dumps(probe, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"probe: compile exit {completed.returncode}, run exit {run.returncode}, "
          f"ok={probe.get('ok')}")
    return 0 if run.returncode == 0 and probe.get("ok") is True else 1


if __name__ == "__main__":
    raise SystemExit(main())
