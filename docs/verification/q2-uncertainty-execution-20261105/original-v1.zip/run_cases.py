#!/usr/bin/env python3
"""Execute the frozen Q2-4 uncertainty experiment with the frozen backend.

69 runs = 5 main cases (UNC-TOT, UNC-N1, UNC-ZERO, UNC-LET-COV,
UNC-MT-SPARSE) + 64 coverage batches.  Every run keeps its own output
directory, its own record.json (command, environment, exit code, log,
artifact SHA-256) and its own raw outputs.

Reuse rule: a previous record is reused only when the frozen contract,
backend executable, frozen inputs and every recorded artifact still carry
their recorded SHA-256/size and the recorded completed-event count is the
expected one.  ``--force`` re-runs anyway.

A failed real execution is kept and stops the whole run sequence: the frozen
contract forbids changing the seed, adding batches or retrying a failed case.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-uncertainty-v1"
IDENTITY = BASE / "identity.json"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-uncertainty-freeze-v1.json"
BACKEND = ROOT / "out" / "collab" / "q2-backend-864bc036" / "G4UniversalSim.exe"
GEANT4_BIN = Path("D:/ProgramFiles/Geant4/bin")
GEANT4_DATA = Path("D:/ProgramFiles/Geant4/share/Geant4/data")

REQUIRED_OUTPUTS = {
    "UNC-TOT": ("run_summary.txt", "run_metadata.json",
                "event_edep_t0.csv", "dose_volume_summary_t0.csv",
                "scorer_statistics.csv"),
    "UNC-N1": ("run_summary.txt", "run_metadata.json",
               "dose_volume_summary_t0.csv", "let_volume_summary_t0.csv",
               "scorer_statistics.csv"),
    "UNC-ZERO": ("run_summary.txt", "run_metadata.json",
                 "dose_volume_summary_t0.csv", "let_volume_summary_t0.csv"),
    "UNC-LET-COV": ("run_summary.txt", "run_metadata.json",
                    "let_volume_summary_t0.csv", "scorer_statistics.csv"),
    "UNC-MT-SPARSE": ("run_summary.txt", "run_metadata.json",
                      "dose_volume_summary_t0.csv", "let_volume_summary_t0.csv",
                      "scorer_statistics.csv"),
    "UNC-COVERAGE": ("run_summary.txt", "run_metadata.json",
                     "fluence_volume_summary_t0.csv", "scorer_statistics.csv"),
}


def rel(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(ROOT.resolve())).replace("\\", "/")
    except ValueError:
        return str(path)


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def env() -> dict:
    merged = os.environ.copy()
    merged["PATH"] = str(GEANT4_BIN) + os.pathsep + merged.get("PATH", "")
    merged["GEANT4_DATA_DIR"] = str(GEANT4_DATA)
    merged.pop("QT_QPA_PLATFORM", None)
    return merged


def parse_run_summary(path: Path) -> dict:
    values = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if " = " in line:
            key, _, value = line.partition(" = ")
            values[key.strip()] = value.strip()
    return values


def clean_dir(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True)


def artifact_table(output_dir: Path) -> dict:
    artifacts = {}
    for path in sorted(output_dir.rglob("*")):
        if path.is_file():
            artifacts[rel(path)] = {
                "path": rel(path),
                "sha256": sha256(path),
                "size_bytes": path.stat().st_size,
            }
    return artifacts


def record_is_reusable(record: dict, identity: dict, expected_events: int) -> tuple[bool, str]:
    if not record:
        return False, "no previous record"
    if record.get("exit_code") != 0:
        return False, "previous run failed; record kept"
    if record.get("identity_sha256") != identity["_identity_sha256"]:
        return False, "identity changed"
    summary = record.get("summary", {})
    if int(summary.get("actual_completed_event_count", -1)) != expected_events:
        return False, "completed events changed"
    for item in record.get("artifacts", {}).values():
        path = ROOT / item["path"]
        if not path.is_file():
            return False, f"recorded artifact missing: {item['path']}"
        if sha256(path) != item["sha256"] or path.stat().st_size != item["size_bytes"]:
            return False, f"recorded artifact changed: {item['path']}"
    return True, "record and artifacts verified"


def run_one(name: str, run_dir: Path, output_dir: Path, config: Path, macro: Path,
            threads: int, seed: int | None, expected_events: int,
            identity: dict, force: bool) -> dict:
    record_path = run_dir / "record.json"
    previous = None
    if record_path.is_file():
        try:
            previous = json.loads(record_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            previous = None
    if not force and previous is not None:
        reusable, reason = record_is_reusable(previous, identity, expected_events)
        if reusable:
            print(f"[reuse] {name}: {reason}")
            return previous
        print(f"[run]   {name}: {reason}")

    clean_dir(output_dir)
    stdout_path = run_dir / "stdout.log"
    stderr_path = run_dir / "stderr.log"
    log_path = run_dir / "backend.log"
    command = [str(BACKEND), "--config", str(config), "--macro", str(macro),
               "--output", str(output_dir), "--threads", str(threads)]
    if seed is not None:
        command += ["--seed", str(seed)]

    started = now()
    start_clock = time.perf_counter()
    completed = subprocess.run(command, cwd=ROOT, env=env(),
                               capture_output=True)
    elapsed = time.perf_counter() - start_clock
    finished = now()
    stdout_text = completed.stdout.decode("utf-8", "replace")
    stderr_text = completed.stderr.decode("utf-8", "replace")
    stdout_path.write_text(stdout_text, encoding="utf-8")
    stderr_path.write_text(stderr_text, encoding="utf-8")
    log_path.write_text(
        "$ " + " ".join(command) + "\n"
        + f"[cwd] {ROOT}\n[exit_code] {completed.returncode}\n"
        + "[stdout]\n" + stdout_text
        + "\n[stderr]\n" + stderr_text, encoding="utf-8")

    summary = {}
    summary_path = output_dir / "run_summary.txt"
    if summary_path.is_file():
        summary = parse_run_summary(summary_path)
    record = {
        "schema": "g4usim_q2_uncertainty_run_record_v1",
        "case": name,
        "identity_sha256": identity["_identity_sha256"],
        "freeze_sha256": identity["freeze"]["sha256"],
        "backend_sha256": identity["backend"]["sha256"],
        "command": command,
        "command_display": " ".join(command),
        "cwd": str(ROOT),
        "environment": {
            "PATH_first": env()["PATH"].split(os.pathsep)[0],
            "GEANT4_DATA_DIR": str(GEANT4_DATA),
        },
        "config": rel(config),
        "macro": rel(macro),
        "expected_events": expected_events,
        "threads": threads,
        "seed_override": seed,
        "started_at": started,
        "finished_at": finished,
        "elapsed_seconds": round(elapsed, 3),
        "exit_code": completed.returncode,
        "stdout": rel(stdout_path),
        "stderr": rel(stderr_path),
        "log": rel(log_path),
        "output_dir": rel(output_dir),
        "summary": summary,
        "artifacts": artifact_table(output_dir),
    }
    record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n",
                           encoding="utf-8")
    problems = []
    if completed.returncode != 0:
        problems.append(f"backend exit code {completed.returncode}")
    if summary.get("status") != "completed":
        problems.append(f"run status {summary.get('status')!r}")
    if int(summary.get("program_exit_code", -1)) != 0:
        problems.append(f"program exit code {summary.get('program_exit_code')!r}")
    if int(summary.get("actual_completed_event_count", -1)) != expected_events:
        problems.append(
            f"completed events {summary.get('actual_completed_event_count')!r}, "
            f"expected {expected_events}")
    required = REQUIRED_OUTPUTS[name_of(name)]
    present = {Path(key).name for key in record["artifacts"]}
    missing = [item for item in required if item not in present]
    if missing:
        problems.append("required output missing: " + ", ".join(missing))
    if problems:
        record["problems"] = problems
        record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n",
                               encoding="utf-8")
        print(f"[fail]  {name}: {'; '.join(problems)}")
    else:
        print(f"[done]  {name}: exit {completed.returncode}, "
              f"{summary.get('actual_completed_event_count')} events, {elapsed:.2f} s")
    return record


def name_of(case_name: str) -> str:
    return case_name if not case_name.startswith("UNC-COVERAGE") else "UNC-COVERAGE"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", action="append", default=[],
                        help="case or batch name to run, repeatable")
    parser.add_argument("--force", action="store_true",
                        help="re-run even when a verified record exists")
    args = parser.parse_args(argv)

    if not IDENTITY.is_file():
        print("identity.json missing: run setup_inputs.py first", file=sys.stderr)
        return 2
    identity = json.loads(IDENTITY.read_text(encoding="utf-8"))
    identity_sha = sha256(IDENTITY)
    identity["_identity_sha256"] = identity_sha
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    if sha256(FREEZE) != identity["freeze"]["sha256"]:
        print("frozen contract changed since setup; refusing to run", file=sys.stderr)
        return 2
    if freeze["status"] != "frozen" or freeze["execution_authorized"] is not True:
        print("contract not frozen/authorized", file=sys.stderr)
        return 2

    results_path = BASE / "results.json"
    results = {
        "schema": "g4usim_q2_uncertainty_run_results_v1",
        "generated_at": now(),
        "identity_sha256": identity_sha,
        "identity": rel(IDENTITY),
        "freeze_sha256": identity["freeze"]["sha256"],
        "backend_sha256": identity["backend"]["sha256"],
        "runs": {},
        "status": "running",
    }

    order = []
    for case_name in ("UNC-TOT", "UNC-N1", "UNC-ZERO", "UNC-LET-COV",
                      "UNC-MT-SPARSE"):
        order.append(case_name)
    for batch in identity["cases"]["UNC-COVERAGE"]["batches"]:
        order.append(f"UNC-COVERAGE/batch_{batch['batch_id']:03d}")
    selected = [item for item in order if not args.only or item in args.only]
    if args.only:
        missing = {item for item in args.only if item not in order}
        if missing:
            print("unknown --only value(s): " + ", ".join(sorted(missing)),
                  file=sys.stderr)
            return 2

    failed = None
    for name in selected:
        if name.startswith("UNC-COVERAGE/"):
            case_name = "UNC-COVERAGE"
            batch_id = int(name.rsplit("_", 1)[1])
            batch = identity["cases"]["UNC-COVERAGE"]["batches"][batch_id]
            case = identity["cases"]["UNC-COVERAGE"]
            run_dir = ROOT / batch["run_dir"]
            output_dir = ROOT / batch["output_dir"]
            run_dir.mkdir(parents=True, exist_ok=True)
            record = run_one(
                name, run_dir, output_dir,
                ROOT / case["main_ini"], ROOT / case["macro"],
                case["threads"], batch["seed"], case["events"],
                identity, args.force)
        else:
            case = identity["cases"][name]
            run_dir = ROOT / case["run_dir"]
            output_dir = ROOT / case["output_dir"]
            run_dir.mkdir(parents=True, exist_ok=True)
            record = run_one(
                name, run_dir, output_dir, ROOT / case["main_ini"],
                ROOT / case["macro"], case["threads"], None, case["events"],
                identity, args.force)
        results["runs"][name] = record
        results["generated_at"] = now()
        if record.get("problems"):
            failed = name
            results["status"] = "failed"
            results_path.write_text(
                json.dumps(results, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8")
            print(f"stopping after failed run {name} (frozen contract forbids "
                  "changing seeds, batches or tolerances)", file=sys.stderr)
            break
        # write incrementally so a later crash never loses a finished run
        results_path.write_text(
            json.dumps(results, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8")

    if failed is None:
        results["status"] = "completed"
    results["generated_at"] = now()
    results["summary"] = {
        "runs_completed": sum(1 for run in results["runs"].values()
                              if not run.get("problems")),
        "runs_total": len(results["runs"]),
        "events_completed": sum(int(run["summary"].get("actual_completed_event_count", 0))
                                for run in results["runs"].values()),
    }
    results_path.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n",
                            encoding="utf-8")
    print(f"results: {rel(results_path)} status={results['status']} "
          f"runs={results['summary']['runs_completed']}/{results['summary']['runs_total']} "
          f"events={results['summary']['events_completed']}")
    return 0 if failed is None else 1


if __name__ == "__main__":
    raise SystemExit(main())
