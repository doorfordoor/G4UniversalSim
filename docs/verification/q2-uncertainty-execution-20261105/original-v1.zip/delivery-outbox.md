# Q2-4 冻结统计实验执行回执（REF-UNC-01）

- 日期：2026-11-04/05
- 任务：`q2-uncertainty-execute-v1-20261105`（用户 m16615）
- 冻结预注册：`docs/collab/decisions/20261105-q2-uncertainty-freeze-v1.json`
  - SHA-256：`5768cc413d7e05b586fdbe8074342e52ec14cdbf27fbc037163604775e0381b6`
  - schema：`q2_uncertainty_freeze_v1`；status `frozen`；`execution_authorized: true`
- 候选目录：`out/collab/q2-uncertainty-v1/`（gitignored `out/` 下，未提交 Git）
- 结论：**执行与比较通过**；1–6 节为结果，7 节为反例，8 节为边界，9 节为复核入口。

## 1. 身份与输入

- 后端：`out/collab/q2-backend-864bc036/G4UniversalSim.exe`，
  SHA-256 `f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f`，
  build `864bc036d6d7752475e52db4efd2b950cabfcc3d`，
  源指纹 `e7de615d4e342114104f970688a7ea5f9789f7b70240b2562a388a50a45704e7`，
  Geant4 11.3.2（`--check-geant4-data` `required_complete: true`）。
- 17 个冻结草案输入逐字节复制到 `inputs/` 并按 `inputs_manifest.json` 逐个校验，
  全部 `relocated: false`；`identity.json` 记录冻结、参考文档、输入、主病例、
  64 个覆盖批次、组件源码与计划计数。
- 计划 69 次运行、130123 事件；实际 69/69 运行、130123/130123 完成事件，全部 exit 0。

## 2. 运行

| 病例 | 事件 | 线程 | seed | exit | 完成 | 关键观测 |
| --- | --- | --- | --- | --- | --- | --- |
| UNC-TOT | 20 | 1 | 20261120 | 0 | 20 | 20 行 event_edep（5 个零沉积行保留），dose entries=15，剂量 8.67866495335e-08 Gy，R=0.131457123022… |
| UNC-N1 | 1 | 1 | 20261121 | 0 | 1 | dose 3.43814728326e-09 Gy、let_t 14.021046061 keV/µm；4 行统计均 insufficient_events |
| UNC-ZERO | 100 | 1 | 20261122 | 0 | 100 | dose/LET 仅表头，无 scorer_statistics；metadata 登记两个 header-only 文件 |
| UNC-LET-COV | 2000 | 1 | 20261123 | 0 | 2000 | let_t=1.46108573803、let_d=3.37461108049 keV/µm；R_t²=0.004724488639…、R_d²=0.305772026375…（公开矩重算） |
| UNC-MT-SPARSE | 2 | 4 | 20261124 | 0 | 2 | 4 线程、3 个空 worker、1 个非空；事件 ID {0,1}；dose/let 按线程合并；R=[0, 3.16e-06] |
| UNC-COVERAGE×64 | 2000 | 1 | 220001…220064 | 0 | 各 2000 | K 1351…1436，covered 63/64，ΣK=88809 |

## 3. 比较结果（`results.json.evaluation`）

- status `pass`；526 项检查全部 pass、0 fail。
- 分层：ID 5、EVID 483、TOT 6、N1 4、ZERO 5、LET 6、MT 6、CMP 4、COV 7。
- 半单位规则：非零 12 位 general 打印值 `h = 0.5×10^(floor(log10|d|)−11)`；
  打印的精确零是精确 0；所有和/平方和/质量/体积/面积/rel_error/sigma/差值同规则传播。
- 比较器退出码与后端 exit 分开记录：`backend_exit_codes` 全 0，
  `comparison_exit_is_not_backend_exit: true`。

## 4. 组件 probe（真实共享实现）

- `probe/history_statistics_probe.cc` 直接编译真实 `src/Scoring/HistoryStatistics.cc`，
  记录编译命令与源码 SHA（与冻结合同一致：`91fdcc6421507286…`、`abad43750bb54036…`、
  `dae1399a57fee4a0…`）。
- 7 状态 fixture 全通过；协方差 fixture `A=[1,2,0]`、`B=[2,1,0]` →
  A=B=3、sumSq=5、cross=4、ratio=1、`R=√2/3`；总矩 fixture `[2,0,2]` →
  sum=4、sumSq=8、entries=2。
- 编译器：`D:/msys64/ucrt64/bin/g++.exe`（C++17），probe 编译/运行 exit 0。

## 5. 覆盖批次

- 64/64 批次存在、种子一致、各 2000 完成事件。
- K 范围 1351…1436 ⊂ 冻结覆盖区间 [1347,1429]；covered 63/64（最少 57）。
- ΣK=88809 ∈ 冻结中央 99% 区间 [88464,89313]。
- 单批覆盖概率 `0.955913711531559450…`（与设计一致）；
  `P(C<57)=0.00698051532398270997…`（与设计 0.006980515324 一致）。
- 覆盖判据采用精确整数形式，结论仅适用于本冻结模型、种子与 64 样本分布
  （不用“普适 95% 区间”）。

## 6. 反例（8/8 检出，原件未变）

`tamper-results.json`：`status=pass`、`detected=8/8`、`originals_unchanged=true`。

| 反例 | 预期失败检查 | 结果 |
| --- | --- | --- |
| ce-drop-zero-row | TOT-EVENT-ROWS | 检出（连带 TOT-ZERO-ROWS-KEPT、TOT-NOT-HITS-ROWS） |
| ce-hits-as-n | TOT-NOT-HITS-ROWS | 检出（连带 TOT-EVENT-ROWS/TOT-MOMENTS 等） |
| ce-zero-error | ZERO-STATS-ABSENT | 检出（连带 ZERO-NO-FABRICATION） |
| ce-unknown-covariance-zero | LET-COV-CROSS-MOMENTS | 检出（连带 LET-COV-RT/RD） |
| ce-worker-average | MT-NO-WORKER-AVERAGE | 检出（连带 MT-EVENT-IDS/MT-EDEP-MERGE/MT-DOSE-STATS） |
| ce-missing-metadata | EVID-METADATA-UNC-TOT | 检出（唯一失败） |
| ce-resample | COV-BATCHES | 检出（连带 COV-PATH/COV-AGGREGATE） |
| ce-mass-unit | TOT-EDEP-EQ-DOSE | 检出（连带 TOT-MASS） |

每个反例只写 `tampered/` 副本；副本的 metadata/artifact 在改动后重新密封，
只留下预期语义检查失败。运行前后 `runs/**`、`identity.json`、`results.json`
的 SHA 全部不变。

## 7. 已声明的观测限制（不构成失败，也不是宽松容差）

- UNC-MT-SPARSE 稀疏运行不能区分“错误 worker 平均”；可区分性由预指定组件 fixture 提供。
- `hits=false` 的覆盖批次没有逐事件路径观测，只校验打印矩一致性。
- header-only 文件是合法的“无有效贡献”表示；`scorer_statistics.csv` 无 entry 时不存在。
- 结论仅限冻结合同内的仅电磁/明确参考物理、固定几何、源、cut、N、种子与样本。

## 8. 复现命令

```text
cd out/collab/q2-uncertainty-v1
python -B setup_inputs.py
python -B run_cases.py
python -B compare.py --write
python -B probe/build_probe.py
python -B tamper.py
```

## 9. 校验与边界

- 未修改产品、正式测试/基准、冻结合同、参考/NIEL 表、预注册目录、ROADMAP/STATUS；
  未提交 Git。
- 候选目录与全部原始产物位于 gitignore 的 `out/` 下；回执为新增未跟踪文件。
- 交付后停写，等待独立复验；不重跑、不换种子、不补采样、不调容差。
