#!/usr/bin/env python3
"""Prepare the Q2-4 uncertainty execution candidate.

* verify the frozen contract, backend, Geant4 data and reference documents,
* copy the 17 pre-registered input files byte for byte and verify every SHA
  against the frozen inputs_manifest.json (no path rebinding is needed because
  the draft inputs already point at this candidate directory),
* write the identity file used by the prompt's required identity checks.

Only files under out/collab/q2-uncertainty-v1/ are written.
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-uncertainty-v1"
PROPOSAL = ROOT / "out" / "collab" / "q2-uncertainty-proposal-v1"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-uncertainty-freeze-v1.json"
BACKEND = ROOT / "out" / "collab" / "q2-backend-864bc036" / "G4UniversalSim.exe"
GEANT4_BIN = Path("D:/ProgramFiles/Geant4/bin")
GEANT4_DATA = Path("D:/ProgramFiles/Geant4/share/Geant4/data")

FREEZE_SHA = "5768cc413d7e05b586fdbe8074342e52ec14cdbf27fbc037163604775e0381b6"
BACKEND_SHA = "f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f"
BACKEND_BUILD = "864bc036d6d7752475e52db4efd2b950cabfcc3d"
MANIFEST_SHA = "048bec9bd7582c2ced7ace5654056b4c20ca9c6d6db1b0d1122bcaf53f0009e4"
REFERENCE_DOCS = {
    "docs/collab/decisions/20261105-q2-uncertainty-coverage-design-v1.json":
        "f179a241d77ef483a143c086c31c2e14fd5c63a84422071298d6ae83251a3af3",
    "docs/collab/reviews/20261105-q2-uncertainty-preregister-review.md":
        "55b73bc7ad8817f6adec67c249bf270dfa3b0ff2a8746db9d4f709efbda9e9db",
    "docs/collab/decisions/20261105-q2-dose-reference-freeze-v1.json":
        "a2a799e90bd941b4969beab62be408013420dfbd684c4e8e52f07775308e498d",
    "docs/collab/decisions/20261105-q2-fluence-reference-freeze-v1.json":
        "d9ceb71f9cb6a3bcf4029010eb2bf2212c6b014dca9967b40277e01379b077b3",
    "docs/collab/decisions/20261105-q2-let-reference-freeze-v1.json":
        "b22b7d6535d226f632719f759003b391d2153f28802a348ae4b071a178136af1",
}

CASES = {
    "UNC-TOT": {
        "main_ini": "main_unc_tot.ini",
        "geometry": "geometry_unc_tot.ini",
        "macro": "run_unc_tot.mac",
        "seed": 20261120,
        "threads": 1,
        "events": 20,
        "case_dir": "unc_tot",
    },
    "UNC-N1": {
        "main_ini": "main_unc_n1.ini",
        "geometry": "geometry_unc_n1.ini",
        "macro": "run_unc_n1.mac",
        "seed": 20261121,
        "threads": 1,
        "events": 1,
        "case_dir": "unc_n1",
    },
    "UNC-ZERO": {
        "main_ini": "main_unc_zero.ini",
        "geometry": "geometry_unc_n1.ini",
        "macro": "run_unc_zero.mac",
        "seed": 20261122,
        "threads": 1,
        "events": 100,
        "case_dir": "unc_zero",
    },
    "UNC-LET-COV": {
        "main_ini": "main_unc_let_cov.ini",
        "geometry": "geometry_unc_let_cov.ini",
        "macro": "run_unc_let_cov.mac",
        "seed": 20261123,
        "threads": 1,
        "events": 2000,
        "case_dir": "unc_let_cov",
    },
    "UNC-MT-SPARSE": {
        "main_ini": "main_unc_mt_sparse.ini",
        "geometry": "geometry_unc_n1.ini",
        "macro": "run_unc_mt_sparse.mac",
        "seed": 20261124,
        "threads": 4,
        "events": 2,
        "case_dir": "unc_mt_sparse",
    },
}

COVERAGE = {
    "main_ini": "main_unc_coverage.ini",
    "geometry": "geometry_unc_coverage.ini",
    "macro": "run_unc_coverage.mac",
    "events": 2000,
    "threads": 1,
    "seeds": list(range(220001, 220065)),
    "case_dir": "unc_coverage",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def rel(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(ROOT.resolve())).replace("\\", "/")
    except ValueError:
        return str(path)


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def env() -> dict:
    merged = os.environ.copy()
    merged["PATH"] = str(GEANT4_BIN) + os.pathsep + merged.get("PATH", "")
    merged["GEANT4_DATA_DIR"] = str(GEANT4_DATA)
    return merged


def copy_inputs(freeze: dict) -> dict:
    source = ROOT / freeze["inputs"]["draft_root"]
    manifest_path = ROOT / freeze["inputs"]["manifest"]
    assert sha256(manifest_path) == MANIFEST_SHA, "inputs manifest SHA mismatch"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    target = BASE / "inputs"
    target.mkdir(parents=True, exist_ok=True)
    inputs = {}
    for name, expected in sorted(manifest["files"].items()):
        original = source / name
        assert original.is_file(), f"pre-registered input missing: {name}"
        assert sha256(original) == expected, f"pre-registered input SHA mismatch: {name}"
        (target / name).write_bytes(original.read_bytes())
        copied = target / name
        copied_sha = sha256(copied)
        assert copied_sha == expected, f"copied input SHA mismatch: {name}"
        assert copied.stat().st_size == original.stat().st_size, f"copied size mismatch: {name}"
        inputs[name] = {
            "sha256": copied_sha,
            "size_bytes": copied.stat().st_size,
            "original_path": rel(original),
            "original_sha256": expected,
            "path": rel(copied),
            "relocated": rel(original) != rel(copied),
        }
    assert len(inputs) == 17, f"expected 17 inputs, got {len(inputs)}"
    (BASE / "inputs_manifest.json").write_text(
        json.dumps({"schema": "g4usim_q2_uncertainty_inputs_manifest_v1",
                    "files": {name: item["sha256"] for name, item in inputs.items()}},
                   ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return inputs


def verify_backend() -> dict:
    assert BACKEND.is_file(), "frozen backend executable missing"
    exe_sha = sha256(BACKEND)
    assert exe_sha == BACKEND_SHA, f"backend executable SHA mismatch: {exe_sha}"
    capabilities = json.loads(subprocess.run(
        [str(BACKEND), "--capabilities"], capture_output=True, text=True, check=True,
        env=env()).stdout)
    assert capabilities["build_git_commit"] == BACKEND_BUILD, "backend build mismatch"
    assert capabilities["geant4_version_number"] == 1132, "Geant4 version mismatch"
    data = subprocess.run([str(BACKEND), "--check-geant4-data"], capture_output=True,
                          text=True, env=env())
    (BASE / "backend-data-check.txt").write_text(
        data.stdout + data.stderr, encoding="utf-8")
    assert data.returncode == 0, f"--check-geant4-data failed: {data.returncode}"
    text = data.stdout + data.stderr
    start = text.find("{")
    assert start >= 0, "--check-geant4-data produced no JSON"
    data_report = json.loads(text[start:])
    assert data_report.get("required_complete") is True, "--check-geant4-data not required_complete"
    return {
        "path": rel(BACKEND),
        "sha256": exe_sha,
        "build": capabilities["build_git_commit"],
        "source_fingerprint": capabilities["source_fingerprint"],
        "source_state": capabilities["build_git_source_state"],
        "geant4_version_number": capabilities["geant4_version_number"],
        "multithreaded": capabilities["multithreaded"],
        "data_check_exit_code": data.returncode,
        "data_check_log": "backend-data-check.txt",
        "data_check_command": "--check-geant4-data",
    }


def verify_references() -> dict:
    result = {}
    for path, expected in REFERENCE_DOCS.items():
        full = ROOT / path
        assert full.is_file(), f"reference document missing: {path}"
        actual = sha256(full)
        assert actual == expected, f"reference document SHA mismatch: {path}"
        result[path] = {"sha256": actual, "size_bytes": full.stat().st_size}
    return result


def build_identity(freeze: dict, inputs: dict, backend: dict, references: dict) -> dict:
    cases = {}
    for name, spec in CASES.items():
        cases[name] = {
            "main_ini": rel(BASE / "inputs" / spec["main_ini"]),
            "main_ini_sha256": inputs[spec["main_ini"]]["sha256"],
            "geometry": rel(BASE / "inputs" / spec["geometry"]),
            "geometry_sha256": inputs[spec["geometry"]]["sha256"],
            "materials": rel(BASE / "inputs" / "materials.ini"),
            "macro": rel(BASE / "inputs" / spec["macro"]),
            "macro_sha256": inputs[spec["macro"]]["sha256"],
            "seed": spec["seed"],
            "threads": spec["threads"],
            "events": spec["events"],
            "output_dir": rel(BASE / "runs" / spec["case_dir"] / "output"),
            "run_dir": rel(BASE / "runs" / spec["case_dir"]),
        }
    batches = []
    for index, seed in enumerate(COVERAGE["seeds"]):
        batches.append({
            "batch_id": index,
            "seed": seed,
            "output_dir": rel(BASE / "runs" / COVERAGE["case_dir"] / f"batch_{index:03d}" / "output"),
            "run_dir": rel(BASE / "runs" / COVERAGE["case_dir"] / f"batch_{index:03d}"),
        })
    cases["UNC-COVERAGE"] = {
        "main_ini": rel(BASE / "inputs" / COVERAGE["main_ini"]),
        "main_ini_sha256": inputs[COVERAGE["main_ini"]]["sha256"],
        "geometry": rel(BASE / "inputs" / COVERAGE["geometry"]),
        "geometry_sha256": inputs[COVERAGE["geometry"]]["sha256"],
        "materials": rel(BASE / "inputs" / "materials.ini"),
        "macro": rel(BASE / "inputs" / COVERAGE["macro"]),
        "macro_sha256": inputs[COVERAGE["macro"]]["sha256"],
        "events": COVERAGE["events"],
        "threads": COVERAGE["threads"],
        "seeds": COVERAGE["seeds"],
        "batches": batches,
        "case_dir": rel(BASE / "runs" / COVERAGE["case_dir"]),
    }
    return {
        "schema": "g4usim_q2_uncertainty_identity_v1",
        "created": now(),
        "freeze": {
            "path": rel(FREEZE),
            "sha256": FREEZE_SHA,
            "schema": freeze["schema"],
            "status": freeze["status"],
            "execution_authorized": freeze["execution_authorized"],
            "source_proposal_sha256": freeze["freeze"]["source_proposal_sha256"],
            "review": freeze["freeze"]["review"],
        },
        "backend": backend,
        "geant4": {"version_number": 1132, "version": "11.3.2"},
        "reference_documents": references,
        "inputs_manifest_sha256": MANIFEST_SHA,
        "inputs_draft_root": freeze["inputs"]["draft_root"],
        "inputs": inputs,
        "cases": cases,
        "component_production_sources": freeze["freeze"]["component_production_sources"],
        "planned_runs": 69,
        "planned_events": 130123,
    }


def main() -> int:
    BASE.mkdir(parents=True, exist_ok=True)
    assert sha256(FREEZE) == FREEZE_SHA, "frozen contract SHA mismatch"
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    assert freeze["status"] == "frozen" and freeze["execution_authorized"] is True
    backend = verify_backend()
    references = verify_references()
    inputs = copy_inputs(freeze)
    identity = build_identity(freeze, inputs, backend, references)
    (BASE / "identity.json").write_text(
        json.dumps(identity, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    planned = sum(case["events"] for name, case in CASES.items()) + 64 * COVERAGE["events"]
    print("inputs:", len(inputs), "all SHA verified")
    print("backend:", backend["sha256"][:16], "build", backend["build"],
          "Geant4", backend["geant4_version_number"])
    print("runs planned:", 5 + 64, "events planned:", planned)
    assert planned == 130123, f"planned event total mismatch: {planned}"
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
