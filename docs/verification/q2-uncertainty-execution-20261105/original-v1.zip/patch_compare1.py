from pathlib import Path
p = Path('compare.py')
t = p.read_text(encoding='utf-8')

# 1. frozen component source SHAs
anchor = 'COVERAGE_SEEDS = list(range(220001, 220065))'
addition = '''COVERAGE_SEEDS = list(range(220001, 220065))
FROZEN_COMPONENT_SOURCES = {
    "src/Scoring/HistoryStatistics.cc":
        "91fdcc6421507286ffddc1a021e716acac6d2bb43f4ac4a841ac8001b7b4eaaa",
    "include/Scoring/HistoryStatistics.hh":
        "abad43750bb5403683a9da638e375a936ebdab76526b4c18790cba4815056643",
    "include/Scoring/NumericChecks.hh":
        "dae1399a57fee4a04bd949acef9b8dfd9a1a1b60ce44ab6d6b8b5d5b6d70f448",
}'''
assert anchor in t
t = t.replace(anchor, addition, 1)

# 2. clean CMP-BUILD
old = '''    build = probe.get("build", {})
    add(checks, "CMP-BUILD",
        build.get("exit_code") == 0
        and "src/Scoring/HistoryStatistics.cc" in build.get("command", "")
        and build.get("source_sha256") ==
        "91fdcc64fc4e6bf21d04e0b7a5cd6a4d45b4d773a1ce0f5b0c8e0c6c0b8d2e9e"
        if False else build.get("exit_code") == 0
        and "src/Scoring/HistoryStatistics.cc" in build.get("command", ""),
        f"probe build exit={build.get('exit_code')}")'''
new = '''    build = probe.get("build", {})
    add(checks, "CMP-BUILD",
        build.get("exit_code") == 0
        and "src/Scoring/HistoryStatistics.cc" in build.get("command", "")
        and build.get("source_sha256")
        == FROZEN_COMPONENT_SOURCES["src/Scoring/HistoryStatistics.cc"]
        and all(build.get("sources", {}).get(name) == value
                for name, value in FROZEN_COMPONENT_SOURCES.items()),
        f"probe build exit={build.get('exit_code')} sources_ok="
        f"{all(build.get('sources', {}).get(name) == value for name, value in FROZEN_COMPONENT_SOURCES.items())}")'''
assert old in t
t = t.replace(old, new, 1)

# 3. coverage completed_ok simplification
old = '''    completed_ok = all(
        int(records[name]["summary"].get("completed_events", -1)) == COVERAGE_N
        if "completed_events" in records[name]["summary"] else
        int(records[name]["summary"].get("actual_completed_event_count", -1))
        == COVERAGE_N for name in present)'''
new = '''    completed_ok = all(
        int(records[name]["summary"].get("actual_completed_event_count", -1))
        == COVERAGE_N for name in present)'''
assert old in t
t = t.replace(old, new, 1)

# 4. remove dead expected_dir lines
old = '''    expected_dir = expected_output_dir(identity, key, case_name)
    command = record.get("command") or []'''
new = '''    command = record.get("command") or []'''
assert old in t
t = t.replace(old, new, 1)
old = '''    add(checks, f"EVID-INPUTS-{key}",
        record.get("identity_sha256") == sha256(IDENTITY),
        "identity file unchanged")

    del expected_dir
'''
new = '''    add(checks, f"EVID-INPUTS-{key}",
        record.get("identity_sha256") == sha256(IDENTITY),
        "identity file unchanged")
'''
assert old in t
t = t.replace(old, new, 1)

# 5. TOT zero-row check cross-checked against statistics entries
old = '''    zero_ids = {int(row["eventID"]) for row in rows
                if as_decimal(row["raw_edep_MeV"]) == 0}
    expected_zero_ids = {int(row["eventID"]) for row in rows
                         if as_decimal(row["raw_edep_MeV"]) == 0}
    add(checks, "TOT-ZERO-ROWS-KEPT",
        zero_ids == expected_zero_ids and len(rows) == n
        and all(int(row["eventID"]) < n for row in rows),
        f"row_ids={sorted(ids)[:3]}... zero_rows={len(zero_ids)}")
'''
new = '''    zero_count = sum(1 for row in rows
                     if as_decimal(row["raw_edep_MeV"]) == 0)
    _, stats_early = read_csv_rows(output / "scorer_statistics.csv")
    dose_entries = [int(row.get("entries", -1)) for row in stats_early
                    if row.get("scorer") == "dose"
                    and row.get("quantity") in ("raw_dose", "weighted_dose")]
    add(checks, "TOT-ZERO-ROWS-KEPT",
        len(rows) == n and all(int(row["eventID"]) < n for row in rows)
        and bool(dose_entries)
        and all(entries + zero_count == n for entries in dose_entries),
        f"rows={len(rows)} zero_rows={zero_count} dose_entries={dose_entries}")
'''
assert old in t
t = t.replace(old, new, 1)

p.write_text(t, encoding='utf-8')
print('patched compare.py')
