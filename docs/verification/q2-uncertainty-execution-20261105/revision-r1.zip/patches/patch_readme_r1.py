# -*- coding: utf-8 -*-
"""Apply the R1 revision to README.md (deterministic, asserted anchors)."""
from pathlib import Path

readme = Path("README.md")
text = readme.read_text(encoding="utf-8")


def replace(old: str, new: str) -> None:
    global text
    assert old in text, f"anchor missing: {old[:60]!r}"
    assert text.count(old) == 1, f"anchor not unique: {old[:60]!r}"
    text = text.replace(old, new)


replace(
    "# Q2-4 冻结统计实验：执行候选 v1（REF-UNC-01）\n",
    "# Q2-4 冻结统计实验：执行候选 v1 + R1 修复（REF-UNC-01）\n"
)
replace(
    "本目录位于 gitignore 的 `out/` 下。执行后停写，等待独立复验。\n",
    "本目录位于 gitignore 的 `out/` 下。执行后停写，等待独立复验。\n\n"
    "本目录另有 R1 修复（2026-11-05）：按独立审查 `docs/collab/reviews/"
    "20261105-q2-uncertainty-execution-review-v1.md` 的三条定位，只修比较器、"
    "组件 probe、副本反例和报告，**没有重跑任何模拟**。69 次运行、输入、"
    "identity 与冻结合同字节保持不变；R1 之前的 v1 报告保存在 `preserved/`，"
    "原件指纹保存在 `originals-manifest.json`。详见第 11 节。\n"
)
replace(
    "## 3. 比较器与 526 项检查\n",
    "## 3. 比较器与 527 项检查（R1 后）\n"
)
replace(
    "`results.json.evaluation`：**status `pass`，526 项检查，526 pass，0 fail**。\n"
    "分层：ID 5、EVID 483、TOT 6、N1 4、ZERO 5、LET 6、MT 6、CMP 4、COV 7。\n",
    "`results.json.evaluation`：**status `pass`，527 项检查，527 pass，0 fail**。\n"
    "分层：ID 5、EVID 483、TOT 6、N1 4、ZERO 5、LET 6、MT 6、CMP 5、COV 7。\n"
    "R1 增加的 `CMP-WORKER-MERGE` 对账真实组件合并（见第 5 节）。\n"
)
replace(
    "  dose/let 的 raw/weighted 长度由各线程 CSV 合并；`R=[0, 3.16e-06]`（2 个相等值）；\n"
    "  let_t 合并 `13.9334540571…`；没有把 worker 误差平均；冻结的稀疏运行不强制让“错误平均”\n"
    "  可区分（可区分性由预指定组件 fixture 提供）。\n",
    "  dose/let 的 raw/weighted 长度由各线程 CSV 合并；`R=[0, 3.16e-06]`（2 个相等值）；\n"
    "  公开 master `let_t=13.9334540571`、`let_d=17.3914931468` 与合并矩比值\n"
    "  `S1/S0`、`S2/S1` 一致（单位 `keV/µm`，与 `MeV/mm` 数值相同；R1 修复前只比 R，\n"
    "  不核公开值）；没有把 worker 误差平均。稀疏运行本身不能区分“错误 worker 平均”，\n"
    "  可区分性由真实组件 probe 的两 worker fixture 提供：合并贡献 `[1,1]`、`[0,4]` 得到\n"
    "  N=4、S=6、S2=18、entries=3、`R=0.5`，而错误平均 `(0+√0.5)/2=0.353553390593…`。\n"
)
replace(
    "- 总矩 fixture `[2,0,2]`：sum=4、sumSq=8、entries=2、`R=√(1/2−1/3)`。\n",
    "- 总矩 fixture `[2,0,2]`：sum=4、sumSq=8、entries=2、`R=√(1/2−1/3)`。\n"
    "- 两 worker 合并 fixture（R1 新增）：用真实 `HistoryTallySet` 逐事件累计 worker A\n"
    "  `[1,1]` 与 worker B `[0,4]`，真实 `Submit`/`Take` 合并得 sum=6、sum_sq=18、\n"
    "  entries=3、`R=0.5`；per-worker R 为 `[0, 0.7071067811865476]`，错误平均为\n"
    "  `0.3535533905932738`。该 fixture 是合成组件，不冒充 N=2 的真实 worker 分配。\n"
)
replace(
    "- K 范围 1351…1436，冻结覆盖区间 [1347,1429]；`covered=63/64`（最少 57）。\n",
    "- K 范围 1351…1436。冻结的覆盖整数区间是 [1347,1429]，64 批中恰好 63 批落在\n"
    "  该区间内、1 批 `K=1436` 落在区间外；因此 `covered=63/64` 是正常结果（不是失败），\n"
    "  冻结下限是 57。\n"
)
replace(
    "| ce-worker-average | MT-NO-WORKER-AVERAGE | 检出（连带 MT-EVENT-IDS/MT-EDEP-MERGE/MT-DOSE-STATS） |\n",
    "| ce-worker-average | MT-DOSE-STATS | 检出（R1 后只替换 master 统计的 `rel_error` 为错误\n平均 `0.353553390593`，由 MT-DOSE-STATS 拒绝；审查允许 MT-NO-WORKER-AVERAGE 或\nMT-DOSE-STATS 之一） |\n"
)
replace(
    "`tamper-results.json`：`status=pass`、`detected=8/8`、`originals_unchanged=true`；\n"
    "运行前后 `runs/**`、`identity.json`、`results.json` 的 SHA 全部不变。\n",
    "`tamper-results.json`：`status=pass`、`detected=8/8`、`originals_unchanged=true`；\n"
    "运行前后 `runs/**`、`identity.json`、`results.json` 的 SHA 全部不变。\n\n"
    "### 7.1 R1 附加最小副本检查（2/2 检出）\n\n"
    "审查要求确认修复后的检查确实覆盖被改字段，因此额外做两个最小副本检查（不新增\n"
    "科学病例，结果单独记录在 `additional_minimal_checks`）：\n\n"
    "| 副本检查 | 只改字段 | 预期失败检查 | 结果 |\n"
    "| --- | --- | --- | --- |\n"
    "| ce-let-master-value | 副本中 master `let_t` 值 ×1.01 | MT-LET-MERGE | 检出（连带 MT-NO-WORKER-AVERAGE，因共享合并值一致性） |\n"
    "| ce-coverage-entries | 副本 batch_000 的 raw/weighted fluence `entries` 各 +1 | COV-PATH | 检出（唯一失败） |\n\n"
    "两个附加检查都要求预先声明的检查出现真实 `fail`；baseline 仍为 0 fail。\n"
)
replace(
    "| 文件 | 字节 | SHA-256 |\n"
    "| --- | --- | --- |\n"
    "| setup_inputs.py | 12256 | `10dafa2e9e2a139dd7242ce2e35341690b775e3996226194edf38ad4b8e842e6` |\n"
    "| run_cases.py | 14423 | `88feaa8280fe0ba75d31281cb8307077214adc66548fbcd25807f6fdd9927b04` |\n"
    "| compare.py | 44741 | `2726f5c7c0fbd4290b008e21454157526cec1eefc6e1f7325bd187dc3c4ea85f` |\n"
    "| tamper.py | 10582 | `f21138ce8f4f430cf7d38f24152df2db57b5f2534a74ec080b8b8f98d26fe705` |\n"
    "| identity.json | 32131 | `35796e2e5143b98b0865bf94195ecd5599790e294aa8ba9395d0c22b0361728d` |\n"
    "| inputs_manifest.json | 1707 | `d191f86888db8b230b6f2ac7aa0d0688d3873b0909823246a5d42c9488f9823b` |\n"
    "| results.json | 1446174 | `3529cb987b687d29d47e42636d38be061dd3fff6c0f6c4cac8d9caa6b9042cc8` |\n"
    "| tamper-results.json | 2993 | `f8b26cf32ab7d3e963cacde5eef69e4641853e68878396c2f1b9782f6bca8318` |\n"
    "| probe/build_probe.py | 4067 | `c7ee67097a6d22a3d6b8240ade11f4a5c703f662eb44b1f78b4e5fb8255b05ea` |\n"
    "| probe/history_statistics_probe.cc | 5324 | `b7baf70d34f7ab079d26faa63e49cef9747b34abf270f910f0c85bbd26265e36` |\n"
    "| probe/probe_results.json | 3042 | `c9e4c2c419f37c258b0ecff96edfed8ddb1585e0dc0aed1ede60d1f1a44f1f54` |\n",
    "| 文件 | 字节 | SHA-256 |\n"
    "| --- | --- | --- |\n"
    "| setup_inputs.py | 12256 | `10dafa2e9e2a139dd7242ce2e35341690b775e3996226194edf38ad4b8e842e6` |\n"
    "| run_cases.py | 14423 | `88feaa8280fe0ba75d31281cb8307077214adc66548fbcd25807f6fdd9927b04` |\n"
    "| compare.py | 50633 | `b6a8bb4b3fc79fc687370524fab31cca643b8c9deec96b32dacc010ea3db831c` |\n"
    "| tamper.py | 15586 | `df9ae1e2d8111a9397605ae4e1122cdee1ee8fb326ea59c6a550bebe6f115b51` |\n"
    "| snapshot_originals.py | 7295 | `6cac9e47e68d812c5cd15f254f1433342a10e2805169ecdcbee3f36bc6846762` |\n"
    "| identity.json | 32131 | `35796e2e5143b98b0865bf94195ecd5599790e294aa8ba9395d0c22b0361728d` |\n"
    "| inputs_manifest.json | 1707 | `d191f86888db8b230b6f2ac7aa0d0688d3873b0909823246a5d42c9488f9823b` |\n"
    "| results.json | 1446968 | `f0a8e9f950ce2a63fe64616b3d3b9dcb2913ebba8b730816839ae0e849d0c4a0` |\n"
    "| tamper-results.json | 3789 | `264470b5ce28e15f9ee36d47d97f1ea9dec7eab9f5de5ec9fefddc1008abffd2` |\n"
    "| originals-manifest.json | 186783 | `f7df0f9d37f644e1690680d41cdd1b7020a8189fcc8d4f4a1ebe133a482b9594` |\n"
    "| probe/build_probe.py | 4067 | `c7ee67097a6d22a3d6b8240ade11f4a5c703f662eb44b1f78b4e5fb8255b05ea` |\n"
    "| probe/history_statistics_probe.cc | 8405 | `b34e492e67038ef68f7d82f500a6ca9fcc46de6e47d002c95fb1e6dc0304a6e7` |\n"
    "| probe/probe_results.json | 3611 | `03bc66163da02d1e20f7ed0fa4e87b0ba85a742335442d03654899ec5e0d06b0` |\n\n"
    "`preserved/` 保存 R1 之前的 v1 报告：`results-v1.json` 1446174 B\n"
    "`3529cb987b687d29…`、`tamper-results-v1.json` 2993 B `f8b26cf32ab7d3e9…`、\n"
    "`probe-results-v1.json` 3042 B `c9e4c2c419f37c25…`、`README-v1.md` 10287 B\n"
    "`5946cd53961b6d39…`。`originals-manifest.json` 记录 982 个 runs 文件与 17 个输入的\n"
    "SHA-256 清单（`runs_manifest_sha256=efa84ba51f5c66c6…`、\n"
    "`inputs_manifest_sha256=36f0f3952c9500e7…`）。\n"
)
replace(
    "- 未修改产品、测试、基准、冻结、表数据、ROADMAP/STATUS；未提交 Git；未提交任何\n"
    "  预注册目录改动。\n",
    "- R1 未重跑任何模拟：`runs/**`（982 文件、64,853,211 B）、`inputs/**`、\n"
    "  `identity.json`、冻结合同与后端 exe 的字节均未变；`snapshot_originals.py`\n"
    "  的 `--verify` 在修复前后都通过。\n"
    "- 未修改产品、测试、基准、冻结、表数据、ROADMAP/STATUS；未提交 Git；未提交任何\n"
    "  预注册目录改动。\n"
)
replace(
    "python -B probe/build_probe.py\n"
    "python -B tamper.py\n"
    "```\n",
    "python -B probe/build_probe.py\n"
    "python -B tamper.py\n"
    "python -B snapshot_originals.py --verify\n"
    "```\n\n"
    "`snapshot_originals.py --verify` 只重新计算 `runs/**`、`inputs/**` 与 `preserved/`\n"
    "副本的 SHA-256，要求与 `originals-manifest.json` 一致；它不写文件、不触碰运行，\n"
    "也不比较 manifest 自身或脚本源码。\n"
)

text = text.rstrip("\n") + """

## 11. R1 修复记录（2026-11-05）

独立审查 `docs/collab/reviews/20261105-q2-uncertainty-execution-review-v1.md` 判定
初版 v1 的三处证据缺口（不涉及后端物理错误）。R1 只在候选目录内修比较器、组件 probe、
副本反例与报告；原 69 次运行没有重跑。

| 审查定位 | 问题 | R1 修复 | 验证 |
| --- | --- | --- | --- |
| `tamper.py:157` | CE-WORKER-AVERAGE 只复制 event_edep 行，未换成 worker 误差平均，无可区分 fixture | probe 新增真实两 worker 合并 fixture（`[1,1]`/`[0,4]` → R=0.5 vs 错误平均 0.353553…）；`mutate_worker_average` 改为替换 master dose 的 `rel_error`，预期检查改为 MT-DOSE-STATS（审查允许二选一） | 8/8 冻结反例检出，originals_unchanged=true |
| `compare.py:682` | MT-LET-MERGE 只比 R，不核公开 master 比值 | 要求 `let_t`/`let_d` 行单位为 `keV/um`，且公开 value 与合并矩比值一致（保留 R 检查） | `ce-let-master-value` 副本 ×1.01 被 MT-LET-MERGE 检出 |
| `compare.py:827` | COV-PATH 未核统计 entries=K | 每批核 fluence CSV（N、K、S、S²）与 statistics 行（N、entries、sum、sum_sq、mean、unit、estimator、uncertainty_estimator、status） | `ce-coverage-entries` 副本 entries+1 被 COV-PATH 检出 |

同时订正报告措辞：冻结覆盖区间 [1347,1429] 与实测 K 范围 1351…1436 并列，
`covered=63/64`、`ΣK=88809` 是正常结果；不把单批未覆盖写成失败，也不把
“错误 worker 平均”的可区分性归给稀疏运行本身。

比较器结论：**status=pass，527 项检查（526 项 + CMP-WORKER-MERGE），0 fail**。
原件复验：`originals unchanged: runs=982 inputs=17`，
`runs_manifest_sha256=efa84ba51f5c66c6…`。

R1 的新回执在 `docs/collab/outbox/20261105-q2-uncertainty-v1-r1.md`；
本文件更新前的 v1 版本保存在 `preserved/README-v1.md`。
"""

readme.write_text(text, encoding="utf-8")
print("README updated:", len(text.encode("utf-8")), "bytes")
