# Q2-4 执行候选 R1：比较证据最小修复回执

- 任务：m16866（2026-11-05），依据独立审查
  `docs/collab/reviews/20261105-q2-uncertainty-execution-review-v1.md`。
- 状态：三项修复 + 两个最小副本检查完成并通过；**没有重跑任何模拟**；
  未修改产品、正式测试/基准、冻结合同、输入、identity 或运行字节；未提交 Git。
- 候选目录：`out/collab/q2-uncertainty-v1/`（gitignore 的 `out/` 下）。
- 新报告：`out/collab/q2-uncertainty-v1/README.md`（R1 修订版，见第 8 节哈希）；
  R1 之前的 v1 报告保存在 `preserved/`。

## 1. 原件指纹与“无重跑”证据

`snapshot_originals.py` 在修改前保存了原件清单
`originals-manifest.json`（186783 B，SHA-256
`f7df0f9d37f644e1690680d41cdd1b7020a8189fcc8d4f4a1ebe133a482b9594`）：

| 项 | 值 |
| --- | --- |
| runs 文件数 / 字节 | 982 / 64,853,211 |
| `runs_manifest_sha256` | `efa84ba51f5c66c65047021f3a8251df4b575b4a2b5a66f38ddb8526fb763684` |
| inputs 数 / `inputs_manifest_sha256` | 17 / `36f0f3952c9500e7107e08be7c8b5e022e09a34c3a5538ad129e779d9c63fde2` |
| `identity.json` | 32131 B / `35796e2e5143b98b0865bf94195ecd5599790e294aa8ba9395d0c22b0361728d` |
| 冻结 JSON | `5768cc413d7e05b586fdbe8074342e52ec14cdbf27fbc037163604775e0381b6` |
| 后端 exe | `f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f` |

修复后执行 `python -B snapshot_originals.py --verify` 输出
`originals unchanged: runs=982 inputs=17 runs_manifest_sha256=efa84ba5…`，退出 0。
校验只重算 `runs/**`、`inputs/**` 与 `preserved/` 副本的 SHA-256/size，不比较
manifest 自身或脚本源码；`preserved/` 的 R1 前报告哈希为
`results-v1.json` `3529cb987b687d29…`、`tamper-results-v1.json`
`f8b26cf32ab7d3e9…`、`probe-results-v1.json` `c9e4c2c419f37c25…`、
`README-v1.md` `5946cd53961b6d39…`。

结论：69 次运行、输入、identity、冻结合同与后端 exe 的字节均未变。

## 2. 审查三条 → 修复 → 验证

| 审查定位 | 修复 | 验证 |
| --- | --- | --- |
| `tamper.py:157`：CE-WORKER-AVERAGE 只复制 event_edep 行，未换成 worker 误差平均，无可区分 fixture | ① `probe/history_statistics_probe.cc` 新增真实两 worker 合并 fixture：worker A `[1,1]`、B `[0,4]`，经真实 `HistoryTallySet`/`Submit`/`Take` 合并得 N=4、S=6、S2=18、entries=3、`R=0.5`；per-worker R `[0, 0.7071067811865476]`；错误平均 `0.3535533905932738`。② `mutate_worker_average` 改为只把 master `scorer_statistics.csv` 中 dose 行 `rel_error` 替换为 `0.353553390593`（并同步 `std_error`），预期检查改为 **MT-DOSE-STATS**（审查允许 MT-NO-WORKER-AVERAGE 或 MT-DOSE-STATS 之一）。 | 组件 fixture 实跑输出如上；`ce-worker-average` 由 `MT-DOSE-STATS` 唯一拒绝；8/8 冻结反例仍全部检出。 |
| `compare.py:682`：MT-LET-MERGE 只比 R，不核公开 master 比值 | MT-LET-MERGE 现在要求 `let_t`/`let_d` 行 `unit == "keV/um"`，且公开 `value` 与合并矩比值 `S1/S0`、`S2/S1` 一致（`MeV/mm` 与 `keV/µm` 数值相同），并保留原有 R 检查。 | 新增最小副本 `ce-let-master-value`（只把副本 master `let_t` 值 ×1.01）被 `MT-LET-MERGE` 检出（连带 `MT-NO-WORKER-AVERAGE`，因共享合并值一致性）。 |
| `compare.py:827`：COV-PATH 未核统计 entries=K | COV-PATH 每批核对：fluence CSV 的 `n_events=2000`、`volume_mm3=10`、raw/weighted `length=K/10`、`fluence=K/100`、`sum_sq=K/100`；以及 `scorer_statistics.csv` 的 `scorer=fluence`、`unit=mm-2`、`estimator=total`、`uncertainty_estimator=uncorrected_event_moments_v1`、`status=approximate`、`n_events=2000`、`entries=K`、`value/sum=K/100`、`sum_sq=K/10000`、`mean=K/100/2000`，并统计 `entries_match`。 | 新增最小副本 `ce-coverage-entries`（副本 batch_000 的 raw/weighted entries 各 +1）被 `COV-PATH` 唯一拒绝。 |

同时新增比较器检查 `CMP-WORKER-MERGE`，把组件 probe 的 worker 合并值与错误平均
纳入真实输出检查：比较器从 526 项变为 **527 项**。

## 3. 组件 probe：真实编译与运行

编译并运行真实 `src/Scoring/HistoryStatistics.cc`（不是 Python 镜像）：

```text
D:/msys64/ucrt64/bin/g++.exe -std=c++17 -O2 -Wall -Wextra -I D:\Geant4\G4UniversalSim\include
  ...\probe\history_statistics_probe.cc ...\src\Scoring\HistoryStatistics.cc
  -o ...\probe\history_statistics_probe.exe
```

- 源码 SHA-256（与冻结合同一致）：`HistoryStatistics.cc` =
  `91fdcc6421507286ffddc1a021e716acac6d2bb43f4ac4a841ac8001b7b4eaaa`、
  `include/Scoring/HistoryStatistics.hh` = `abad43750bb54036…`、
  `include/Scoring/NumericChecks.hh` = `dae1399a57fee4a0…`。
- 二进制 SHA-256：`15285b12cf439998f8809c08c058b6c22b0253608bbb9f61b88d471d20fb9d22`；
  `run_exit_code=0`、`ok=true`。
- 7 个状态 fixture 全部符合优先级（`insufficient_events` / `undefined_ratio` /
  `zero_total` / `approximate`）；协方差 fixture `A=[1,2,0]`、`B=[2,1,0]` →
  `R=√2/3=0.4714045207910318`；总矩 fixture `[2,0,2]` →
  `R=0.408248290463863`。
- 两 worker 合并 fixture（新增）：`merged {sum: 6, sum_sq: 18, entries: 3,
  relative_error: 0.5}`，`per_worker_relative_errors: [0, 0.7071067811865476]`，
  `wrong_average_relative_error: 0.3535533905932738`。worker 各两事件是合成组件，
  不冒充本次冻结 N=2 的真实 worker 分配。
- probe 结果 JSON：`probe/probe_results.json`，3611 B，SHA-256
  `03bc66163da02d1e20f7ed0fa4e87b0ba85a742335442d03654899ec5e0d06b0`。

## 4. 反例：8/8 冻结 + 2/2 附加最小检查

`python -B tamper.py` 退出 0，`status=pass`、`detected=8/8`、
`additional_detected=2/2`、`originals_unchanged=true`；baseline 为
`status=pass`、527 检查、0 fail，因此没有任何 limited/failed 充当检出。

| 反例 / 副本检查 | 预期检查 | 实际失败 id |
| --- | --- | --- |
| ce-drop-zero-row | TOT-EVENT-ROWS | TOT-EVENT-ROWS, TOT-ZERO-ROWS-KEPT, TOT-NOT-HITS-ROWS |
| ce-hits-as-n | TOT-NOT-HITS-ROWS | TOT-EVENT-ROWS, TOT-ZERO-ROWS-KEPT, TOT-EDEP-EQ-DOSE, TOT-MOMENTS, TOT-NOT-HITS-ROWS |
| ce-zero-error | ZERO-STATS-ABSENT | ZERO-STATS-ABSENT, ZERO-NO-FABRICATION |
| ce-unknown-covariance-zero | LET-COV-CROSS-MOMENTS | LET-COV-RT, LET-COV-RD, LET-COV-CROSS-MOMENTS |
| ce-worker-average | MT-DOSE-STATS | MT-DOSE-STATS |
| ce-missing-metadata | EVID-METADATA-UNC-TOT | EVID-METADATA-UNC-TOT |
| ce-resample | COV-BATCHES | COV-BATCHES, COV-PATH, COV-AGGREGATE |
| ce-mass-unit | TOT-EDEP-EQ-DOSE | TOT-EDEP-EQ-DOSE, TOT-MASS |
| **ce-let-master-value（附加）** | MT-LET-MERGE | MT-LET-MERGE, MT-NO-WORKER-AVERAGE |
| **ce-coverage-entries（附加）** | COV-PATH | COV-PATH |

附加检查只改副本中的一个字段，用于证明修复后的检查确实覆盖被改字段；结果单独记录在
`tamper-results.json.additional_minimal_checks`，不混入冻结的 8 个反例。

`tamper-results.json`：3789 B，SHA-256
`264470b5ce28e15f9ee36d47d97f1ea9dec7eab9f5de5ec9fefddc1008abffd2`。

## 5. 比较器结论

`python -B compare.py --write` 退出 0：

```text
status=pass checks=527 pass=527 fail=0
```

分层：ID 5、EVID 483、TOT 6、N1 4、ZERO 5、LET 6、MT 6、CMP 5、COV 7。
本结论只表示本次冻结候选的证据链与预注册检查一致；不表示新增物理结论。

`results.json`：1446968 B，SHA-256
`f0a8e9f950ce2a63fe64616b3d3b9dcb2913ebba8b730816839ae0e849d0c4a0`。

## 6. 覆盖 K 的措辞订正

冻结覆盖整数区间是 `[1347,1429]`；实测 64 批 `K` 范围为 `1351…1436`，
其中 63 批落在冻结区间内、1 批 `K=1436` 在区间外，因此 `covered=63/64`、
`ΣK=88809` 是正常结果（不是失败）。冻结的覆盖数下限是 57。该结论只适用于本冻结
模型、种子与 64 样本分布。

## 7. 复演

```text
cd out/collab/q2-uncertainty-v1
python -B setup_inputs.py          # 只校验身份；--force 不重跑模拟
python -B probe/build_probe.py     # 编译并运行真实组件 probe
python -B compare.py --write       # 527 项检查，期望 status=pass
python -B tamper.py                # 8/8 + 2/2，期望 exit 0
python -B snapshot_originals.py --verify   # 期望 originals unchanged
```

不重跑模拟：`run_cases.py` 的复用规则要求 identity、exit、完成事件与全部产物 SHA
一致；本次没有调用它。`compare.py` / `tamper.py` 失败时退出码非零；后端 exit code
与比较器 exit code 分开记录。

## 8. 文件哈希（R1 后）

| 文件 | 字节 | SHA-256 |
| --- | --- | --- |
| README.md | 15740 | `a05522585f88d3757f957d2d876207766a78c2e5a334f26fe042cb43b827d1ea` |
| compare.py | 50633 | `b6a8bb4b3fc79fc687370524fab31cca643b8c9deec96b32dacc010ea3db831c` |
| tamper.py | 15586 | `df9ae1e2d8111a9397605ae4e1122cdee1ee8fb326ea59c6a550bebe6f115b51` |
| snapshot_originals.py | 7295 | `6cac9e47e68d812c5cd15f254f1433342a10e2805169ecdcbee3f36bc6846762` |
| results.json | 1446968 | `f0a8e9f950ce2a63fe64616b3d3b9dcb2913ebba8b730816839ae0e849d0c4a0` |
| tamper-results.json | 3789 | `264470b5ce28e15f9ee36d47d97f1ea9dec7eab9f5de5ec9fefddc1008abffd2` |
| originals-manifest.json | 186783 | `f7df0f9d37f644e1690680d41cdd1b7020a8189fcc8d4f4a1ebe133a482b9594` |
| probe/history_statistics_probe.cc | 8405 | `b34e492e67038ef68f7d82f500a6ca9fcc46de6e47d002c95fb1e6dc0304a6e7` |
| probe/probe_results.json | 3611 | `03bc66163da02d1e20f7ed0fa4e87b0ba85a742335442d03654899ec5e0d06b0` |
| probe/build_probe.py | 4067 | `c7ee67097a6d22a3d6b8240ade11f4a5c703f662eb44b1f78b4e5fb8255b05ea` |
| setup_inputs.py | 12256 | `10dafa2e9e2a139dd7242ce2e35341690b775e3996226194edf38ad4b8e842e6` |
| run_cases.py | 14423 | `88feaa8280fe0ba75d31281cb8307077214adc66548fbcd25807f6fdd9927b04` |
| identity.json | 32131 | `35796e2e5143b98b0865bf94195ecd5599790e294aa8ba9395d0c22b0361728d` |

`README.md` 更新前的 v1 版本见 `preserved/README-v1.md`（10287 B、
`5946cd53961b6d39…`）。

## 9. 边界与声明

- 本回执不新增物理结论，也不把两次最小副本检查算作新的科学病例。
- 不对后端物理结果作任何重新判定；`runs/**` 的原始产物与 v1 完全相同。
- `CMP-WORKER-MERGE` 对账的是真实 `HistoryStatistics` 的合并路径；worker 各两事件
  是合成组件，不冒充本实验的真实线程分配。
- 稀疏运行 `UNC-MT-SPARSE` 本身仍不能区分“错误 worker 平均”；可区分性由组件
  fixture 提供。
- 覆盖 64 批 `hits=false`，没有逐事件路径观测；只有打印矩与解析模型的一致性。
- 未修改产品、正式测试/基准、冻结合同、输入/identity/运行字节；未提交 Git。
