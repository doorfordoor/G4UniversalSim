// One-off component probe for the frozen Q2-4 uncertainty experiment.
//
// This program links the repository's real shared implementation
// (src/Scoring/HistoryStatistics.cc) instead of a Python re-implementation and
// evaluates the pre-registered component fixtures:
//   * uncertainty-status priority table,
//   * delta-method covariance fixture A=[1,2,0], B=[2,1,0],
//   * tally accumulation over per-event values (zero events included),
//   * the pre-registered two-worker merge fixture: per-event contributions
//     [1,1] and [0,4] submitted through the real HistoryStatistics::Submit/
//     Take path merge to N=4, sum=6, sumSq=18, entries=3, R=0.5, which is
//     distinguishable from the wrong average of the worker-local errors.
//
// It is a candidate-local artifact, not a product interface.

#include "Scoring/HistoryStatistics.hh"

#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace {

struct Fixture {
    const char* name;
    long long events;
    double numerator;
    bool ratio;
    double denominator;
    const char* expected;
};

const Fixture kFixtures[] = {
    {"N=0,num=1,total", 0, 1.0, false, 0.0, "insufficient_events"},
    {"N=1,num=0,ratio,den=0", 1, 0.0, true, 0.0, "insufficient_events"},
    {"N=2,num=1,ratio,den=0", 2, 1.0, true, 0.0, "undefined_ratio"},
    {"N=2,num=0,total", 2, 0.0, false, 0.0, "zero_total"},
    {"N=2,num=0,ratio,den=1", 2, 0.0, true, 1.0, "zero_total"},
    {"N=2,num=1,total", 2, 1.0, false, 0.0, "approximate"},
    {"N=2,num=1,ratio,den=1", 2, 1.0, true, 1.0, "approximate"},
};

std::string Quote(const std::string& value)
{
    std::string out = "\"";
    for (char c : value) {
        if (c == '\\' || c == '"') out += '\\';
        out += c;
    }
    out += '"';
    return out;
}

}  // namespace

int main()
{
    std::printf("{\n");
    std::printf("  \"schema\": \"g4usim_q2_uncertainty_history_probe_v1\",\n");

    std::printf("  \"fixtures\": [\n");
    for (std::size_t index = 0; index < sizeof(kFixtures) / sizeof(kFixtures[0]); ++index) {
        const Fixture& fixture = kFixtures[index];
        const char* status = HistoryStatistics::UncertaintyStatus(
            fixture.events, fixture.numerator, fixture.ratio, fixture.denominator);
        if (std::string(status) != fixture.expected) {
            std::fprintf(stderr, "fixture %s: got %s expected %s\n",
                         fixture.name, status, fixture.expected);
            return 1;
        }
        std::printf("    {\"fixture\": %s, \"events\": %lld, \"numerator\": %.17g, "
                    "\"ratio\": %s, \"denominator\": %.17g, \"status\": %s}%s\n",
                    Quote(fixture.name).c_str(), fixture.events, fixture.numerator,
                    fixture.ratio ? "true" : "false", fixture.denominator,
                    Quote(status).c_str(),
                    index + 1 == sizeof(kFixtures) / sizeof(kFixtures[0]) ? "" : ",");
    }
    std::printf("  ],\n");

    // Delta-method covariance fixture A=[1,2,0], B=[2,1,0].
    const double valuesA[] = {1.0, 2.0, 0.0};
    const double valuesB[] = {2.0, 1.0, 0.0};
    HistoryTally tallyA;
    HistoryTally tallyB;
    HistoryTallySet set;
    double cross = 0.0;
    for (int index = 0; index < 3; ++index) {
        set.Add(tallyA, valuesA[index]);
        set.Add(tallyB, valuesB[index]);
        set.EndEvent();
        cross += valuesA[index] * valuesB[index];
    }
    if (tallyA.sum != 3.0 || tallyB.sum != 3.0 || tallyA.sumSq != 5.0 || tallyB.sumSq != 5.0
        || tallyA.entries != 2 || tallyB.entries != 2 || cross != 4.0) {
        std::fprintf(stderr, "tally fixture mismatch\n");
        return 1;
    }
    const double ratio = tallyB.sum != 0.0 ? tallyB.sum / tallyA.sum : 0.0;
    const double relative = HistoryStatistics::RatioRelativeError(
        tallyB.sum, tallyB.sumSq, tallyA.sum, tallyA.sumSq, cross);
    const double expected = std::sqrt(2.0) / 3.0;
    if (std::fabs(ratio - 1.0) > 1e-15 || std::fabs(relative - expected) > 1e-15) {
        std::fprintf(stderr, "covariance fixture mismatch: %g vs %g\n", relative, expected);
        return 1;
    }
    std::printf("  \"covariance\": {\"A\": %.17g, \"B\": %.17g, \"sum_sq_A\": %.17g, "
                "\"sum_sq_B\": %.17g, \"cross\": %.17g, \"entries_A\": %lld, "
                "\"entries_B\": %lld, \"ratio\": %.17g, \"relative_error\": %.17g,\n",
                tallyA.sum, tallyB.sum, tallyA.sumSq, tallyB.sumSq, cross,
                tallyA.entries, tallyB.entries, ratio, relative);
    std::printf("    \"tally_source\": \"HistoryTallySet per-event accumulation\", "
                "\"expected_relative_error\": %.17g},\n", expected);

    // Total-estimator relative error fixture: values [2,0,2] on N=3.
    HistoryTally total;
    HistoryTallySet totals;
    for (double value : {2.0, 0.0, 2.0}) {
        totals.Add(total, value);
        totals.EndEvent();
    }
    const double totalRelative = HistoryStatistics::RelativeError(total.sum, total.sumSq, 3);
    const double expectedTotal = std::sqrt(8.0 / 16.0 - 1.0 / 3.0);
    if (total.entries != 2 || total.sum != 4.0 || total.sumSq != 8.0
        || std::fabs(totalRelative - expectedTotal) > 1e-15) {
        std::fprintf(stderr, "total fixture mismatch\n");
        return 1;
    }
    std::printf("  \"total_moments\": {\"sum\": %.17g, \"sum_sq\": %.17g, \"entries\": %lld, "
                "\"relative_error\": %.17g, \"expected_relative_error\": %.17g},\n",
                total.sum, total.sumSq, total.entries, totalRelative, expectedTotal);

    // Two-worker merge fixture for the pre-registered worker-average
    // counterexample.  The real Submit/Take path merges the per-event moments
    // of worker A [1,1] and worker B [0,4]; on N=4 events the merged line is
    // sum=6, sumSq=18, entries=3 and R=0.5, while averaging the worker-local
    // relative errors (0 and sqrt(0.5)) gives 0.3535533905932738.
    const double workerValues[2][2] = {{1.0, 1.0}, {0.0, 4.0}};
    double workerR[2] = {0.0, 0.0};
    for (int worker = 0; worker < 2; ++worker) {
        HistoryTally tally;
        HistoryTallySet set;
        for (int event = 0; event < 2; ++event) {
            set.Add(tally, workerValues[worker][event]);
            set.EndEvent();
        }
        workerR[worker] = HistoryStatistics::RelativeError(tally.sum, tally.sumSq, 2);
        HistoryStatistics::Entry entry;
        entry.name = "WorkerMerge";
        entry.unit = "MeV";
        entry.sum = tally.sum;
        entry.sumSq = tally.sumSq;
        entry.entries = tally.entries;
        HistoryStatistics::Submit(7, "component", "worker_merge", "merged", entry);
    }
    const auto mergedMap = HistoryStatistics::Take(7);
    const auto mergedIt =
        mergedMap.find(HistoryStatistics::Key("component", "worker_merge", "merged"));
    if (mergedIt == mergedMap.end()) {
        std::fprintf(stderr, "worker merge fixture: no merged entry\n");
        return 2;
    }
    const HistoryStatistics::Entry& merged = mergedIt->second;
    const double mergedR = HistoryStatistics::RelativeError(merged.sum, merged.sumSq, 4);
    const double wrongAverage = 0.5 * (workerR[0] + workerR[1]);
    const double expectedWorkerR = std::sqrt(0.5);
    const double expectedWrong = 0.5 * expectedWorkerR;
    if (merged.sum != 6.0 || merged.sumSq != 18.0 || merged.entries != 3
        || std::fabs(mergedR - 0.5) > 1e-15
        || std::fabs(workerR[0]) > 1e-15
        || std::fabs(workerR[1] - expectedWorkerR) > 1e-15
        || std::fabs(wrongAverage - expectedWrong) > 1e-15) {
        std::fprintf(stderr, "worker merge fixture mismatch\n");
        return 2;
    }
    std::printf("  \"worker_merge\": {\"worker_values\": [[1, 1], [0, 4]], "
                "\"events_total\": 4, \"merged\": {\"sum\": %.17g, \"sum_sq\": %.17g, "
                "\"entries\": %lld, \"relative_error\": %.17g}, "
                "\"per_worker_relative_errors\": [%.17g, %.17g], "
                "\"wrong_average_relative_error\": %.17g, "
                "\"expected_wrong_average_relative_error\": %.17g, "
                "\"source\": \"HistoryTallySet + HistoryStatistics::Submit/Take real implementation\"},\n",
                merged.sum, merged.sumSq, merged.entries, mergedR, workerR[0], workerR[1],
                wrongAverage, expectedWrong);

    std::printf("  \"ok\": true\n}\n");
    return 0;
}
