#!/usr/bin/env python3
"""Counterexamples for the frozen Q2-4 uncertainty comparison.

Each counterexample is applied to a byte copy of one run output directory (or to
a deep copy of the stored results mapping), never to the originals.  The copy's
generated-file metadata and the stored artifact listing are re-sealed after the
deliberate edit, so only the intended semantic checks can fail.  Every mutated
baseline must turn at least one explicitly expected check into a real ``fail``
while the unmodified baseline stays ``pass`` with zero failed checks.
"""

from __future__ import annotations

import copy
import csv
import hashlib
import io
import json
import shutil
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
IDENTITY = BASE / "identity.json"
RESULTS = BASE / "results.json"
TAMPERED = BASE / "tampered"
REPORT = BASE / "tamper-results.json"

sys.path.insert(0, str(BASE))
import compare  # noqa: E402  (candidate-local comparator module)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def run_output(record: dict) -> Path:
    return compare.resolve(record["output_dir"])


def read_rows(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    lines = path.read_text(encoding="utf-8").splitlines()
    header = [item.strip() for item in lines[0].split(",")]
    rows = [dict(zip(header, [cell.strip() for cell in line.split(",")]))
            for line in lines[1:] if line.strip()]
    return header, rows


def write_rows(path: Path, header: list[str], rows: list[dict[str, str]]) -> None:
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=header, lineterminator="\n")
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    path.write_text(buffer.getvalue(), encoding="utf-8")


def seal_copy(output: Path, record: dict, results: dict,
              identity: dict) -> tuple[dict, dict, dict]:
    """Re-seal generated-file metadata and the record artifact listing."""
    metadata_path = output / "run_metadata.json"
    if metadata_path.is_file():
        metadata = read_json(metadata_path)
        for item in metadata.get("generated_files", []):
            name = Path(str(item.get("path", ""))).name
            copied = output / name
            if name == "run_metadata.json" or not copied.is_file():
                continue
            item["sha256"] = sha256(copied)
            item["size_bytes"] = copied.stat().st_size
        metadata_path.write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8")
    artifacts = {}
    for path in sorted(output.iterdir()):
        if path.is_file() and path.name != "run_metadata.json":
            name = compare.repo_relative(path)
            artifacts[name] = {"path": name, "sha256": sha256(path),
                               "size_bytes": path.stat().st_size}
    record["artifacts"] = artifacts
    results["runs"][record["case"]] = record
    return results, identity, record


def copy_case(name: str, label: str) -> tuple[Path, dict, dict, dict]:
    results = read_json(RESULTS)
    identity = read_json(IDENTITY)
    record = copy.deepcopy(results["runs"][name])
    source = run_output(record)
    target = TAMPERED / label / "output"
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(source, target)
    record["output_dir"] = compare.repo_relative(target)
    identity["cases"][name]["output_dir"] = compare.repo_relative(target)
    results["runs"][name] = record
    return target, record, results, identity


def mutate_drop_zero_row() -> tuple[dict, dict, dict]:
    output, record, results, identity = copy_case("UNC-TOT", "ce-drop-zero-row")
    path = output / "event_edep_t0.csv"
    header, rows = read_rows(path)
    kept = [row for row in rows if float(row["raw_edep_MeV"]) != 0.0]
    kept = kept[:len(rows) - 1]
    write_rows(path, header, kept)
    results, identity, _ = seal_copy(output, record, results, identity)
    return results, identity, {"rows": len(kept)}


def mutate_hits_as_rows() -> tuple[dict, dict, dict]:
    output, record, results, identity = copy_case("UNC-TOT", "ce-hits-as-n")
    header, rows = read_rows(output / "event_edep_t0.csv")
    # One scoring contribution duplicated as if it were a second event.
    write_rows(output / "event_edep_t0.csv", header, rows + [rows[0]])
    results, identity, _ = seal_copy(output, record, results, identity)
    return results, identity, {"rows": len(rows) + 1}


def mutate_zero_stats() -> tuple[dict, dict, dict]:
    output, record, results, identity = copy_case("UNC-ZERO", "ce-zero-error")
    header = compare.STATS_HEADER
    row = {name: "" for name in header}
    row.update({"runID": "0", "scorer": "dose", "quantity": "raw_dose",
                "key": "Slab_PV", "name": "Slab", "unit": "Gy",
                "estimator": "total", "n_events": "100", "entries": "0",
                "value": "0", "mean_per_event": "0", "std_error": "0",
                "rel_error": "0",
                "uncertainty_estimator": "uncorrected_event_moments_v1",
                "uncertainty_status": "zero_total"})
    write_rows(output / "scorer_statistics.csv", header, [row])
    results, identity, _ = seal_copy(output, record, results, identity)
    return results, identity, {}


def mutate_cross_zero() -> tuple[dict, dict, dict]:
    output, record, results, identity = copy_case(
        "UNC-LET-COV", "ce-unknown-covariance-zero")
    path = output / "let_volume_summary_t0.csv"
    header, rows = read_rows(path)
    for row in rows:
        row["sum_wl_x_wSl_MeV_mm"] = "0"
        row["sum_wSl_x_wS2l_MeV3_per_mm"] = "0"
    write_rows(path, header, rows)
    results, identity, _ = seal_copy(output, record, results, identity)
    return results, identity, {}


def mutate_worker_average() -> tuple[dict, dict, dict]:
    """Replace the master rel_error with the pre-registered wrong worker average.

    The component fixture in ``probe/history_statistics_probe.cc`` establishes
    the correct merged R (0.5 for contributions [1,1] and [0,4]) and the wrong
    average of the worker-local errors (0.3535533905932738).  This copy keeps
    the event rows and replaces only the printed master rel_error, so the check
    that must reject it is MT-DOSE-STATS.
    """
    output, record, results, identity = copy_case(
        "UNC-MT-SPARSE", "ce-worker-average")
    path = output / "scorer_statistics.csv"
    header, rows = read_rows(path)
    if not any(row.get("scorer") == "dose" for row in rows):
        raise SystemExit("no dose statistics rows to mutate")
    for row in rows:
        if row.get("scorer") == "dose":
            row["rel_error"] = "0.353553390593"
            row["std_error"] = repr(float(row["value"]) * 0.353553390593)
    write_rows(path, header, rows)
    results, identity, _ = seal_copy(output, record, results, identity)
    return results, identity, {"replaced_with_wrong_average": "0.353553390593"}


def mutate_missing_metadata() -> tuple[dict, dict, dict]:
    output, record, results, identity = copy_case(
        "UNC-TOT", "ce-missing-metadata")
    (output / "run_metadata.json").unlink()
    results, identity, _ = seal_copy(output, record, results, identity)
    return results, identity, {}


def mutate_resample() -> tuple[dict, dict, dict]:
    results = read_json(RESULTS)
    identity = read_json(IDENTITY)
    results["runs"].pop("UNC-COVERAGE/batch_063")
    return results, identity, {"dropped_batch": "batch_063"}


def mutate_mass_unit() -> tuple[dict, dict, dict]:
    output, record, results, identity = copy_case("UNC-TOT", "ce-mass-unit")
    path = output / "dose_volume_summary_t0.csv"
    header, rows = read_rows(path)
    for row in rows:
        row["mass_kg"] = repr(float(row["mass_kg"]) * 1000.0)
    write_rows(path, header, rows)
    results, identity, _ = seal_copy(output, record, results, identity)
    return results, identity, {}


def mutate_let_master_value() -> tuple[dict, dict, dict]:
    """Minimal copy check: change only the published master let_t value.

    The repaired MT-LET-MERGE now reconciles both public master LET values with
    the merged moments, so this edit must fail that check while every other
    datum in the copy stays unchanged.
    """
    output, record, results, identity = copy_case(
        "UNC-MT-SPARSE", "ce-let-master-value")
    path = output / "scorer_statistics.csv"
    header, rows = read_rows(path)
    changed = False
    for row in rows:
        if row.get("quantity") == "let_t":
            row["value"] = repr(float(row["value"]) * 1.01)
            changed = True
    if not changed:
        raise SystemExit("no let_t statistics row to mutate")
    write_rows(path, header, rows)
    results, identity, _ = seal_copy(output, record, results, identity)
    return results, identity, {}


def mutate_coverage_entries() -> tuple[dict, dict, dict]:
    """Minimal copy check: change only one coverage batch's printed entries.

    The repaired COV-PATH reconciles every batch's statistics entries with K
    from the raw path length, so this edit must fail that check while the rest
    of the batch output is unchanged.
    """
    name = "UNC-COVERAGE/batch_000"
    results = read_json(RESULTS)
    identity = read_json(IDENTITY)
    record = copy.deepcopy(results["runs"][name])
    source = run_output(record)
    target = TAMPERED / "ce-coverage-entries" / "output"
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(source, target)
    record["output_dir"] = compare.repo_relative(target)
    results["runs"][name] = record
    identity["cases"]["UNC-COVERAGE"]["batches"][0]["output_dir"] = \
        compare.repo_relative(target)
    path = target / "scorer_statistics.csv"
    header, rows = read_rows(path)
    changed = 0
    for row in rows:
        if row.get("quantity") in ("raw_fluence", "weighted_fluence"):
            row["entries"] = str(int(row["entries"]) + 1)
            changed += 1
    if changed == 0:
        raise SystemExit("no fluence statistics rows to mutate")
    write_rows(path, header, rows)
    results, identity, _ = seal_copy(target, record, results, identity)
    return results, identity, {"batch": "batch_000", "mutated_entries": "K+1"}


CASES = [
    ("ce-drop-zero-row", "TOT-EVENT-ROWS", mutate_drop_zero_row),
    ("ce-hits-as-n", "TOT-NOT-HITS-ROWS", mutate_hits_as_rows),
    ("ce-zero-error", "ZERO-STATS-ABSENT", mutate_zero_stats),
    ("ce-unknown-covariance-zero", "LET-COV-CROSS-MOMENTS", mutate_cross_zero),
    ("ce-worker-average", "MT-DOSE-STATS", mutate_worker_average),
    ("ce-missing-metadata", "EVID-METADATA-UNC-TOT", mutate_missing_metadata),
    ("ce-resample", "COV-BATCHES", mutate_resample),
    ("ce-mass-unit", "TOT-EDEP-EQ-DOSE", mutate_mass_unit),
]

# The frozen contract fixes the eight counterexamples above.  The review also
# asked for two minimal copy checks that prove the repaired checks actually see
# the fields they now reconcile; they are reported separately and are not
# counted as part of the frozen eight.
ADDITIONAL = [
    ("ce-let-master-value", "MT-LET-MERGE", mutate_let_master_value,
     "only the published master let_t value changes"),
    ("ce-coverage-entries", "COV-PATH", mutate_coverage_entries,
     "only one coverage batch's printed statistics entries change"),
]


def main() -> int:
    TAMPERED.mkdir(parents=True, exist_ok=True)
    baseline = read_json(RESULTS)
    identity = read_json(IDENTITY)
    originals = {}
    for path in sorted((BASE / "runs").rglob("*")):
        if path.is_file():
            originals[compare.repo_relative(path)] = sha256(path)
    originals[compare.repo_relative(IDENTITY)] = sha256(IDENTITY)
    originals[compare.repo_relative(RESULTS)] = sha256(RESULTS)

    baseline_eval = compare.evaluate(identity, baseline)
    if baseline_eval["status"] != "pass" or baseline_eval["checks_failed"] != 0:
        print("baseline is not a clean pass; counterexamples are not meaningful")
        return 2

    report = {"schema": "g4usim_q2_uncertainty_tamper_v2",
              "baseline": {"status": baseline_eval["status"],
                           "checks_total": baseline_eval["checks_total"],
                           "checks_failed": baseline_eval["checks_failed"]},
              "cases": [],
              "additional_minimal_checks": []}
    detected = 0
    for label, expected, mutate in CASES:
        results, case_identity, extra = mutate()
        evaluation = compare.evaluate(case_identity, results)
        failed = evaluation["failed_ids"]
        ok = expected in failed
        detected += 1 if ok else 0
        report["cases"].append({
            "counterexample": label,
            "expected_failed_check": expected,
            "detected": ok,
            "status": evaluation["status"],
            "checks_failed": evaluation["checks_failed"],
            "failed_ids": failed[:40],
            "extra": extra,
        })
        print(f"{label}: expected {expected} in {len(failed)} failed ids -> "
              f"{'detected' if ok else 'MISSED'}")

    additional_detected = 0
    for label, expected, mutate, note in ADDITIONAL:
        results, case_identity, extra = mutate()
        evaluation = compare.evaluate(case_identity, results)
        failed = evaluation["failed_ids"]
        ok = expected in failed
        additional_detected += 1 if ok else 0
        report["additional_minimal_checks"].append({
            "counterexample": label,
            "expected_failed_check": expected,
            "detected": ok,
            "status": evaluation["status"],
            "checks_failed": evaluation["checks_failed"],
            "failed_ids": failed[:40],
            "extra": extra,
            "note": note,
        })
        print(f"{label}: expected {expected} in {len(failed)} failed ids -> "
              f"{'detected' if ok else 'MISSED'}")

    changed = [name for name, digest in originals.items()
               if not compare.resolve(name).is_file()
               or sha256(compare.resolve(name)) != digest]
    report["originals_unchanged"] = not changed
    report["changed_originals"] = changed
    report["detected"] = detected
    report["cases_total"] = len(CASES)
    report["additional_detected"] = additional_detected
    report["additional_total"] = len(ADDITIONAL)
    report["status"] = ("pass" if detected == len(CASES)
                        and additional_detected == len(ADDITIONAL) and not changed
                        else "fail")
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n",
                      encoding="utf-8")
    print(f"detected {detected}/{len(CASES)} frozen counterexamples; "
          f"additional {additional_detected}/{len(ADDITIONAL)}; "
          f"originals_unchanged={not changed}")
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
