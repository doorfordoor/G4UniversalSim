# Q2-4 冻结统计实验：执行候选 v1 + R1 修复（REF-UNC-01）

本目录是冻结预注册（`docs/collab/decisions/20261105-q2-uncertainty-freeze-v1.json`，
SHA-256 `5768cc413d7e05b586fdbe8074342e52ec14cdbf27fbc037163604775e0381b6`，
status `frozen`，`execution_authorized: true`）的执行候选。它只执行已经冻结的
5 个主病例与 64 个覆盖批次，不修改预注册目录、产品代码、正式测试/基准、冻结合同、
NIEL/参考表或阶段文件，也不提交 Git。

本目录位于 gitignore 的 `out/` 下。执行后停写，等待独立复验。

本目录另有 R1 修复（2026-11-05）：按独立审查 `docs/collab/reviews/20261105-q2-uncertainty-execution-review-v1.md` 的三条定位，只修比较器、组件 probe、副本反例和报告，**没有重跑任何模拟**。69 次运行、输入、identity 与冻结合同字节保持不变；R1 之前的 v1 报告保存在 `preserved/`，原件指纹保存在 `originals-manifest.json`。详见第 11 节。

## 1. 身份（运行前校验）

| 项 | 值 |
| --- | --- |
| 冻结 JSON | `docs/collab/decisions/20261105-q2-uncertainty-freeze-v1.json`，SHA-256 `5768cc413d7e05b5…` |
| 后端 build | `864bc036d6d7752475e52db4efd2b950cabfcc3d` |
| 后端 exe | `out/collab/q2-backend-864bc036/G4UniversalSim.exe`，SHA-256 `f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f` |
| 源指纹 | `e7de615d4e342114104f970688a7ea5f9789f7b70240b2562a388a50a45704e7` |
| Geant4 | 11.3.2（`--check-geant4-data`：`required_complete: true`） |
| 输入 | 17 个草案输入逐字节复制并按 `inputs_manifest.json` 逐个校验 SHA-256，全部 `relocated:false` |
| 输入清单 SHA-256 | `d191f86888db8b230b6f2ac7aa0d0688d3873b0909823246a5d42c9488f9823b` |
| 计划 | 69 次运行、130123 个事件（5 主病例 + 64 覆盖批次） |
| 实际 | 69/69 运行，全部 exit 0；130123/130123 完成事件 |

`identity.json`（SHA-256 `35796e2e5143b98b0865bf94195ecd5599790e294aa8ba9395d0c22b0361728d`）
记录冻结、参考文档、17 个输入、5 个主病例、64 个覆盖批次、组件源码与计划计数。

## 2. 执行方式

```text
python -B setup_inputs.py      # 校验身份并逐字节复制 17 个输入
python -B run_cases.py         # 5 主病例 + 64 覆盖批次；已完成的运行复用，--force 重跑
python -B compare.py --write   # 六层比较写入 results.json 的 evaluation
python -B probe/build_probe.py # 编译并运行真实 HistoryStatistics 组件 probe
python -B tamper.py            # 8 个副本反例
```

每个运行记录 `runs/<case>/record.json`（schema `g4usim_q2_uncertainty_run_record_v1`：
argv、cwd、环境、起止、exit、日志路径、summary、产物 SHA-256/大小、identity SHA）。
运行复用要求身份不变、exit 0、完成事件一致、全部产物 SHA/大小一致。

## 3. 比较器与 527 项检查（R1 后）

`compare.py` 用 Python `Decimal` 的显式半单位区间传播 12 位有效数字的公共打印值：
非零 `h = 0.5 × 10^(floor(log10|d|) − 11)`，打印的精确零是精确 0（不赋 0.5 容差）。
所有和、平方和、质量、体积、面积、rel_error、sigma、差值都按同一规则传播。

`results.json.evaluation`：**status `pass`，527 项检查，527 pass，0 fail**。
分层：ID 5、EVID 483、TOT 6、N1 4、ZERO 5、LET 6、MT 6、CMP 5、COV 7。
R1 增加的 `CMP-WORKER-MERGE` 对账真实组件合并（见第 5 节）。

## 4. 主病例结果

- **UNC-TOT**（20 事件，1 线程，seed 20261120）：event_edep 20 行、20 个不同事件、
  5 个零沉积事件保留；dose `entries=15`（15+5=20）；raw/weighted 剂量
  `8.67866495335e-08 Gy` 与 hits 独立复算一致（区间重叠）；
  `R=0.131457123022…`；质量 `4.66e-06 kg`。
- **UNC-N1**（1 事件，seed 20261121）：dose 与 LET 行均存在且有限非零
  （`dose=3.43814728326e-09 Gy`，`let_t=14.021046061 keV/µm`）；4 行
  `scorer_statistics` 全部 `n_events=1`、`uncertainty_status=insufficient_events`；
  没有伪造 `approximate` 误差。
- **UNC-ZERO**（100 事件 geantino，seed 20261122）：dose/LET 文件只有表头、无数据行、
  不写 `scorer_statistics.csv`；两个 header-only 文件在 metadata 中有 SHA；没有伪造
  `zero_total`/`undefined_ratio` 行。
- **UNC-LET-COV**（2000 事件，FTFP_BERT_EMZ，cut 10 µm，seed 20261123）：单行
  `let_t=1.46108573803 keV/µm`、`let_d=3.37461108049 keV/µm`；
  公开矩重算 `R_t²=0.004724488639…`（printed 0.0687349157191）、
  `R_d²=0.305772026375…`（printed 0.552966568951）；把交叉矩 BA/AC 置零会改变两个
  相对误差（反例 CE-UNKNOWN-COVARIANCE-ZERO 检出）。无 5% 外部物理门槛被应用。
- **UNC-MT-SPARSE**（2 事件，4 线程，seed 20261124）：`actual_threads=4`、完成 2 事件；
  全局事件 ID 集合 `{0,1}`；三个空 worker 文件合法；只有 1 个非空 event_edep worker；
  dose/let 的 raw/weighted 长度由各线程 CSV 合并；`R=[0, 3.16e-06]`（2 个相等值）；
  公开 master `let_t=13.9334540572`、`let_d=19.5151524797` 与合并矩比值
  `S1/S0`、`S2/S1` 一致（单位 `keV/µm`，与 `MeV/mm` 数值相同；R1 修复前只比 R，
  不核公开值）；没有把 worker 误差平均。稀疏运行本身不能区分“错误 worker 平均”，
  可区分性由真实组件 probe 的两 worker fixture 提供：合并贡献 `[1,1]`、`[0,4]` 得到
  N=4、S=6、S2=18、entries=3、`R=0.5`，而错误平均 `(0+√0.5)/2=0.353553390593…`。

## 5. 组件 probe（真实共享实现）

`probe/history_statistics_probe.cc` 直接编译并链接仓库真实
`src/Scoring/HistoryStatistics.cc`（不写 Python 镜像），记录编译器命令与源码 SHA：

- 源码 SHA-256：`src/Scoring/HistoryStatistics.cc` = `91fdcc6421507286…`、
  `include/Scoring/HistoryStatistics.hh` = `abad43750bb54036…`、
  `include/Scoring/NumericChecks.hh` = `dae1399a57fee4a0…`（与冻结合同一致）。
- 7 个状态 fixture 全部按优先级返回：`insufficient_events`（N=0；N=1 且
  ratio 零分母）、`undefined_ratio`、`zero_total`（total 与 ratio）、`approximate`
  （total 与 ratio）。
- 协方差 fixture `A=[1,2,0]`、`B=[2,1,0]`：A=B=3、sumSq=5、cross=4、ratio=1、
  `R=√2/3=0.4714045207910318`，与 `HistoryStatistics::RatioRelativeError` 一致。
- 总矩 fixture `[2,0,2]`：sum=4、sumSq=8、entries=2、`R=√(1/2−1/3)`。
- 两 worker 合并 fixture（R1 新增）：用真实 `HistoryTallySet` 逐事件累计 worker A
  `[1,1]` 与 worker B `[0,4]`，真实 `Submit`/`Take` 合并得 sum=6、sum_sq=18、
  entries=3、`R=0.5`；per-worker R 为 `[0, 0.7071067811865476]`，错误平均为
  `0.3535533905932738`。该 fixture 是合成组件，不冒充 N=2 的真实 worker 分配。

## 6. 覆盖批次（64 个固定种子）

- 64/64 批次存在，种子 220001…220064 与冻结一致、各 2000 完成事件；K 列表见
  `results.json` 的 `evaluation.diagnostics.coverage.ks`。
- K 范围 1351…1436。冻结的覆盖整数区间是 [1347,1429]，64 批中恰好 63 批落在
  该区间内、1 批 `K=1436` 落在区间外；因此 `covered=63/64` 是正常结果（不是失败），
  冻结下限是 57。
- `ΣK=88809`，冻结中央 99% 区间 [88464,89313]。
- 单批覆盖概率 `0.9559137115315594504699…`（设计值一致），
  `P(C<57)=0.00698051532398270997…`（与设计 0.006980515324 一致）。
- 覆盖判据用精确整数形式 `N(144K−100N)² ≤ 4·144²·K(N−K)`，与设计一致。
- 结论范围：仅适用于本冻结模型、种子与 64 样本分布；不使用“普适 95% 区间”措辞。

## 7. 反例（8/8 检出，原件 SHA 未变）

每个反例只写入 `tampered/` 副本，重新密封副本的 metadata/artifact 列表后重跑比较器，
要求预先声明的检查出现真实 `fail`；baseline 本身 0 fail，因此不能用 baseline 结果冒充检出。

| 反例 | 预期失败检查 | 结果 |
| --- | --- | --- |
| ce-drop-zero-row | TOT-EVENT-ROWS | 检出（连带 TOT-ZERO-ROWS-KEPT、TOT-NOT-HITS-ROWS） |
| ce-hits-as-n | TOT-NOT-HITS-ROWS | 检出（连带 TOT-EVENT-ROWS/TOT-MOMENTS 等） |
| ce-zero-error | ZERO-STATS-ABSENT | 检出（连带 ZERO-NO-FABRICATION） |
| ce-unknown-covariance-zero | LET-COV-CROSS-MOMENTS | 检出（连带 LET-COV-RT/RD） |
| ce-worker-average | MT-DOSE-STATS | 检出（R1 后只替换 master 统计的 `rel_error` 为错误
平均 `0.353553390593`，由 MT-DOSE-STATS 拒绝；审查允许 MT-NO-WORKER-AVERAGE 或
MT-DOSE-STATS 之一） |
| ce-missing-metadata | EVID-METADATA-UNC-TOT | 检出（唯一失败） |
| ce-resample | COV-BATCHES | 检出（连带 COV-PATH/COV-AGGREGATE） |
| ce-mass-unit | TOT-EDEP-EQ-DOSE | 检出（连带 TOT-MASS） |

`tamper-results.json`：`status=pass`、`detected=8/8`、`originals_unchanged=true`；
运行前后 `runs/**`、`identity.json`、`results.json` 的 SHA 全部不变。

### 7.1 R1 附加最小副本检查（2/2 检出）

审查要求确认修复后的检查确实覆盖被改字段，因此额外做两个最小副本检查（不新增
科学病例，结果单独记录在 `additional_minimal_checks`）：

| 副本检查 | 只改字段 | 预期失败检查 | 结果 |
| --- | --- | --- | --- |
| ce-let-master-value | 副本中 master `let_t` 值 ×1.01 | MT-LET-MERGE | 检出（连带 MT-NO-WORKER-AVERAGE，因共享合并值一致性） |
| ce-coverage-entries | 副本 batch_000 的 raw/weighted fluence `entries` 各 +1 | COV-PATH | 检出（唯一失败） |

两个附加检查都要求预先声明的检查出现真实 `fail`；baseline 仍为 0 fail。

## 8. 关键文件

| 文件 | 字节 | SHA-256 |
| --- | --- | --- |
| setup_inputs.py | 12256 | `10dafa2e9e2a139dd7242ce2e35341690b775e3996226194edf38ad4b8e842e6` |
| run_cases.py | 14423 | `88feaa8280fe0ba75d31281cb8307077214adc66548fbcd25807f6fdd9927b04` |
| compare.py | 50633 | `b6a8bb4b3fc79fc687370524fab31cca643b8c9deec96b32dacc010ea3db831c` |
| tamper.py | 15586 | `df9ae1e2d8111a9397605ae4e1122cdee1ee8fb326ea59c6a550bebe6f115b51` |
| snapshot_originals.py | 7295 | `6cac9e47e68d812c5cd15f254f1433342a10e2805169ecdcbee3f36bc6846762` |
| identity.json | 32131 | `35796e2e5143b98b0865bf94195ecd5599790e294aa8ba9395d0c22b0361728d` |
| inputs_manifest.json | 1707 | `d191f86888db8b230b6f2ac7aa0d0688d3873b0909823246a5d42c9488f9823b` |
| results.json | 1446968 | `f0a8e9f950ce2a63fe64616b3d3b9dcb2913ebba8b730816839ae0e849d0c4a0` |
| tamper-results.json | 3789 | `264470b5ce28e15f9ee36d47d97f1ea9dec7eab9f5de5ec9fefddc1008abffd2` |
| originals-manifest.json | 186783 | `f7df0f9d37f644e1690680d41cdd1b7020a8189fcc8d4f4a1ebe133a482b9594` |
| probe/build_probe.py | 4067 | `c7ee67097a6d22a3d6b8240ade11f4a5c703f662eb44b1f78b4e5fb8255b05ea` |
| probe/history_statistics_probe.cc | 8405 | `b34e492e67038ef68f7d82f500a6ca9fcc46de6e47d002c95fb1e6dc0304a6e7` |
| probe/probe_results.json | 3611 | `03bc66163da02d1e20f7ed0fa4e87b0ba85a742335442d03654899ec5e0d06b0` |

`preserved/` 保存 R1 之前的 v1 报告：`results-v1.json` 1446174 B
`3529cb987b687d29…`、`tamper-results-v1.json` 2993 B `f8b26cf32ab7d3e9…`、
`probe-results-v1.json` 3042 B `c9e4c2c419f37c25…`、`README-v1.md` 10287 B
`5946cd53961b6d39…`。`originals-manifest.json` 记录 982 个 runs 文件与 17 个输入的
SHA-256 清单（`runs_manifest_sha256=efa84ba51f5c66c6…`、
`inputs_manifest_sha256=36f0f3952c9500e7…`）。

`runs/` 共 982 个文件、64.9 MB 原始产物（每个运行的 stdout/stderr、backend.log、
record.json、run_summary.txt、run_metadata.json、effective_config、CSV 与日志）；
`inputs/` 为 17 个逐字节复制的草案输入；`probe/` 为一次性 C++ 组件验证。

## 9. 边界与未覆盖

- 物理范围：仅冻结合同中“仅电磁（EM option4）或明确 FTFP_BERT_EMZ 参考”的
  质子/geantino 病例、固定几何、源、cut、N、种子；不扩展专业结论。
- 统计范围：64 个固定种子批次的覆盖结论仅针对该冻结模型与样本；不把
  `0.9559137115…` 说成通用 95% 置信区间。
- 已知观测限制：UNC-MT-SPARSE 的稀疏运行不能区分“错误 worker 平均”，其可区分性由
  预指定组件 fixture 提供；`hits=false` 的覆盖批次没有逐事件路径观测，只用打印矩一致性；
  `event_edep` 每个 worker 独立文件；header-only 文件是合法的“无有效贡献”表示。
- R1 未重跑任何模拟：`runs/**`（982 文件、64,853,211 B）、`inputs/**`、
  `identity.json`、冻结合同与后端 exe 的字节均未变；`snapshot_originals.py`
  的 `--verify` 在修复前后都通过。
- 未修改产品、测试、基准、冻结、表数据、ROADMAP/STATUS；未提交 Git；未提交任何
  预注册目录改动。

## 10. 复演

```text
cd out/collab/q2-uncertainty-v1
python -B setup_inputs.py
python -B run_cases.py
python -B compare.py --write
python -B probe/build_probe.py
python -B tamper.py
python -B snapshot_originals.py --verify
```

`snapshot_originals.py --verify` 只重新计算 `runs/**`、`inputs/**` 与 `preserved/`
副本的 SHA-256，要求与 `originals-manifest.json` 一致；它不写文件、不触碰运行，
也不比较 manifest 自身或脚本源码。

`compare.py` 失败时退出码非零；反例脚本失败时退出码非零；后端 exit code 与比较器
exit code 分开记录（`results.json` 的 `backend_exit_codes` 与
`comparison_exit_is_not_backend_exit`）。

## 11. R1 修复记录（2026-11-05）

独立审查 `docs/collab/reviews/20261105-q2-uncertainty-execution-review-v1.md` 判定
初版 v1 的三处证据缺口（不涉及后端物理错误）。R1 只在候选目录内修比较器、组件 probe、
副本反例与报告；原 69 次运行没有重跑。

| 审查定位 | 问题 | R1 修复 | 验证 |
| --- | --- | --- | --- |
| `tamper.py:157` | CE-WORKER-AVERAGE 只复制 event_edep 行，未换成 worker 误差平均，无可区分 fixture | probe 新增真实两 worker 合并 fixture（`[1,1]`/`[0,4]` → R=0.5 vs 错误平均 0.353553…）；`mutate_worker_average` 改为替换 master dose 的 `rel_error`，预期检查改为 MT-DOSE-STATS（审查允许二选一） | 8/8 冻结反例检出，originals_unchanged=true |
| `compare.py:682` | MT-LET-MERGE 只比 R，不核公开 master 比值 | 要求 `let_t`/`let_d` 行单位为 `keV/um`，且公开 value 与合并矩比值一致（保留 R 检查） | `ce-let-master-value` 副本 ×1.01 被 MT-LET-MERGE 检出 |
| `compare.py:827` | COV-PATH 未核统计 entries=K | 每批核 fluence CSV（N、K、S、S²）与 statistics 行（N、entries、sum、sum_sq、mean、unit、estimator、uncertainty_estimator、status） | `ce-coverage-entries` 副本 entries+1 被 COV-PATH 检出 |

同时订正报告措辞：冻结覆盖区间 [1347,1429] 与实测 K 范围 1351…1436 并列，
`covered=63/64`、`ΣK=88809` 是正常结果；不把单批未覆盖写成失败，也不把
“错误 worker 平均”的可区分性归给稀疏运行本身。

比较器结论：**status=pass，527 项检查（526 项 + CMP-WORKER-MERGE），0 fail**。
原件复验：`originals unchanged: runs=982 inputs=17`，
`runs_manifest_sha256=efa84ba51f5c66c6…`。

R1 的新回执在 `docs/collab/outbox/20261105-q2-uncertainty-v1-r1.md`；
本文件更新前的 v1 版本保存在 `preserved/README-v1.md`。
