# Q2-4 冻结统计实验：执行候选 v1（REF-UNC-01）

本目录是冻结预注册（`docs/collab/decisions/20261105-q2-uncertainty-freeze-v1.json`，
SHA-256 `5768cc413d7e05b586fdbe8074342e52ec14cdbf27fbc037163604775e0381b6`，
status `frozen`，`execution_authorized: true`）的执行候选。它只执行已经冻结的
5 个主病例与 64 个覆盖批次，不修改预注册目录、产品代码、正式测试/基准、冻结合同、
NIEL/参考表或阶段文件，也不提交 Git。

本目录位于 gitignore 的 `out/` 下。执行后停写，等待独立复验。

## 1. 身份（运行前校验）

| 项 | 值 |
| --- | --- |
| 冻结 JSON | `docs/collab/decisions/20261105-q2-uncertainty-freeze-v1.json`，SHA-256 `5768cc413d7e05b5…` |
| 后端 build | `864bc036d6d7752475e52db4efd2b950cabfcc3d` |
| 后端 exe | `out/collab/q2-backend-864bc036/G4UniversalSim.exe`，SHA-256 `f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f` |
| 源指纹 | `e7de615d4e342114104f970688a7ea5f9789f7b70240b2562a388a50a45704e7` |
| Geant4 | 11.3.2（`--check-geant4-data`：`required_complete: true`） |
| 输入 | 17 个草案输入逐字节复制并按 `inputs_manifest.json` 逐个校验 SHA-256，全部 `relocated:false` |
| 输入清单 SHA-256 | `d191f86888db8b230b6f2ac7aa0d0688d3873b0909823246a5d42c9488f9823b` |
| 计划 | 69 次运行、130123 个事件（5 主病例 + 64 覆盖批次） |
| 实际 | 69/69 运行，全部 exit 0；130123/130123 完成事件 |

`identity.json`（SHA-256 `35796e2e5143b98b0865bf94195ecd5599790e294aa8ba9395d0c22b0361728d`）
记录冻结、参考文档、17 个输入、5 个主病例、64 个覆盖批次、组件源码与计划计数。

## 2. 执行方式

```text
python -B setup_inputs.py      # 校验身份并逐字节复制 17 个输入
python -B run_cases.py         # 5 主病例 + 64 覆盖批次；已完成的运行复用，--force 重跑
python -B compare.py --write   # 六层比较写入 results.json 的 evaluation
python -B probe/build_probe.py # 编译并运行真实 HistoryStatistics 组件 probe
python -B tamper.py            # 8 个副本反例
```

每个运行记录 `runs/<case>/record.json`（schema `g4usim_q2_uncertainty_run_record_v1`：
argv、cwd、环境、起止、exit、日志路径、summary、产物 SHA-256/大小、identity SHA）。
运行复用要求身份不变、exit 0、完成事件一致、全部产物 SHA/大小一致。

## 3. 比较器与 526 项检查

`compare.py` 用 Python `Decimal` 的显式半单位区间传播 12 位有效数字的公共打印值：
非零 `h = 0.5 × 10^(floor(log10|d|) − 11)`，打印的精确零是精确 0（不赋 0.5 容差）。
所有和、平方和、质量、体积、面积、rel_error、sigma、差值都按同一规则传播。

`results.json.evaluation`：**status `pass`，526 项检查，526 pass，0 fail**。
分层：ID 5、EVID 483、TOT 6、N1 4、ZERO 5、LET 6、MT 6、CMP 4、COV 7。

## 4. 主病例结果

- **UNC-TOT**（20 事件，1 线程，seed 20261120）：event_edep 20 行、20 个不同事件、
  5 个零沉积事件保留；dose `entries=15`（15+5=20）；raw/weighted 剂量
  `8.67866495335e-08 Gy` 与 hits 独立复算一致（区间重叠）；
  `R=0.131457123022…`；质量 `4.66e-06 kg`。
- **UNC-N1**（1 事件，seed 20261121）：dose 与 LET 行均存在且有限非零
  （`dose=3.43814728326e-09 Gy`，`let_t=14.021046061 keV/µm`）；4 行
  `scorer_statistics` 全部 `n_events=1`、`uncertainty_status=insufficient_events`；
  没有伪造 `approximate` 误差。
- **UNC-ZERO**（100 事件 geantino，seed 20261122）：dose/LET 文件只有表头、无数据行、
  不写 `scorer_statistics.csv`；两个 header-only 文件在 metadata 中有 SHA；没有伪造
  `zero_total`/`undefined_ratio` 行。
- **UNC-LET-COV**（2000 事件，FTFP_BERT_EMZ，cut 10 µm，seed 20261123）：单行
  `let_t=1.46108573803 keV/µm`、`let_d=3.37461108049 keV/µm`；
  公开矩重算 `R_t²=0.004724488639…`（printed 0.0687349157191）、
  `R_d²=0.305772026375…`（printed 0.552966568951）；把交叉矩 BA/AC 置零会改变两个
  相对误差（反例 CE-UNKNOWN-COVARIANCE-ZERO 检出）。无 5% 外部物理门槛被应用。
- **UNC-MT-SPARSE**（2 事件，4 线程，seed 20261124）：`actual_threads=4`、完成 2 事件；
  全局事件 ID 集合 `{0,1}`；三个空 worker 文件合法；只有 1 个非空 event_edep worker；
  dose/let 的 raw/weighted 长度由各线程 CSV 合并；`R=[0, 3.16e-06]`（2 个相等值）；
  let_t 合并 `13.9334540571…`；没有把 worker 误差平均；冻结的稀疏运行不强制让“错误平均”
  可区分（可区分性由预指定组件 fixture 提供）。

## 5. 组件 probe（真实共享实现）

`probe/history_statistics_probe.cc` 直接编译并链接仓库真实
`src/Scoring/HistoryStatistics.cc`（不写 Python 镜像），记录编译器命令与源码 SHA：

- 源码 SHA-256：`src/Scoring/HistoryStatistics.cc` = `91fdcc6421507286…`、
  `include/Scoring/HistoryStatistics.hh` = `abad43750bb54036…`、
  `include/Scoring/NumericChecks.hh` = `dae1399a57fee4a0…`（与冻结合同一致）。
- 7 个状态 fixture 全部按优先级返回：`insufficient_events`（N=0；N=1 且
  ratio 零分母）、`undefined_ratio`、`zero_total`（total 与 ratio）、`approximate`
  （total 与 ratio）。
- 协方差 fixture `A=[1,2,0]`、`B=[2,1,0]`：A=B=3、sumSq=5、cross=4、ratio=1、
  `R=√2/3=0.4714045207910318`，与 `HistoryStatistics::RatioRelativeError` 一致。
- 总矩 fixture `[2,0,2]`：sum=4、sumSq=8、entries=2、`R=√(1/2−1/3)`。

## 6. 覆盖批次（64 个固定种子）

- 64/64 批次存在，种子 220001…220064 与冻结一致、各 2000 完成事件；K 列表见
  `results.json` 的 `evaluation.diagnostics.coverage.ks`。
- K 范围 1351…1436，冻结覆盖区间 [1347,1429]；`covered=63/64`（最少 57）。
- `ΣK=88809`，冻结中央 99% 区间 [88464,89313]。
- 单批覆盖概率 `0.9559137115315594504699…`（设计值一致），
  `P(C<57)=0.00698051532398270997…`（与设计 0.006980515324 一致）。
- 覆盖判据用精确整数形式 `N(144K−100N)² ≤ 4·144²·K(N−K)`，与设计一致。
- 结论范围：仅适用于本冻结模型、种子与 64 样本分布；不使用“普适 95% 区间”措辞。

## 7. 反例（8/8 检出，原件 SHA 未变）

每个反例只写入 `tampered/` 副本，重新密封副本的 metadata/artifact 列表后重跑比较器，
要求预先声明的检查出现真实 `fail`；baseline 本身 0 fail，因此不能用 baseline 结果冒充检出。

| 反例 | 预期失败检查 | 结果 |
| --- | --- | --- |
| ce-drop-zero-row | TOT-EVENT-ROWS | 检出（连带 TOT-ZERO-ROWS-KEPT、TOT-NOT-HITS-ROWS） |
| ce-hits-as-n | TOT-NOT-HITS-ROWS | 检出（连带 TOT-EVENT-ROWS/TOT-MOMENTS 等） |
| ce-zero-error | ZERO-STATS-ABSENT | 检出（连带 ZERO-NO-FABRICATION） |
| ce-unknown-covariance-zero | LET-COV-CROSS-MOMENTS | 检出（连带 LET-COV-RT/RD） |
| ce-worker-average | MT-NO-WORKER-AVERAGE | 检出（连带 MT-EVENT-IDS/MT-EDEP-MERGE/MT-DOSE-STATS） |
| ce-missing-metadata | EVID-METADATA-UNC-TOT | 检出（唯一失败） |
| ce-resample | COV-BATCHES | 检出（连带 COV-PATH/COV-AGGREGATE） |
| ce-mass-unit | TOT-EDEP-EQ-DOSE | 检出（连带 TOT-MASS） |

`tamper-results.json`：`status=pass`、`detected=8/8`、`originals_unchanged=true`；
运行前后 `runs/**`、`identity.json`、`results.json` 的 SHA 全部不变。

## 8. 关键文件

| 文件 | 字节 | SHA-256 |
| --- | --- | --- |
| setup_inputs.py | 12256 | `10dafa2e9e2a139dd7242ce2e35341690b775e3996226194edf38ad4b8e842e6` |
| run_cases.py | 14423 | `88feaa8280fe0ba75d31281cb8307077214adc66548fbcd25807f6fdd9927b04` |
| compare.py | 44741 | `2726f5c7c0fbd4290b008e21454157526cec1eefc6e1f7325bd187dc3c4ea85f` |
| tamper.py | 10582 | `f21138ce8f4f430cf7d38f24152df2db57b5f2534a74ec080b8b8f98d26fe705` |
| identity.json | 32131 | `35796e2e5143b98b0865bf94195ecd5599790e294aa8ba9395d0c22b0361728d` |
| inputs_manifest.json | 1707 | `d191f86888db8b230b6f2ac7aa0d0688d3873b0909823246a5d42c9488f9823b` |
| results.json | 1446174 | `3529cb987b687d29d47e42636d38be061dd3fff6c0f6c4cac8d9caa6b9042cc8` |
| tamper-results.json | 2993 | `f8b26cf32ab7d3e963cacde5eef69e4641853e68878396c2f1b9782f6bca8318` |
| probe/build_probe.py | 4067 | `c7ee67097a6d22a3d6b8240ade11f4a5c703f662eb44b1f78b4e5fb8255b05ea` |
| probe/history_statistics_probe.cc | 5324 | `b7baf70d34f7ab079d26faa63e49cef9747b34abf270f910f0c85bbd26265e36` |
| probe/probe_results.json | 3042 | `c9e4c2c419f37c258b0ecff96edfed8ddb1585e0dc0aed1ede60d1f1a44f1f54` |

`runs/` 共 982 个文件、64.9 MB 原始产物（每个运行的 stdout/stderr、backend.log、
record.json、run_summary.txt、run_metadata.json、effective_config、CSV 与日志）；
`inputs/` 为 17 个逐字节复制的草案输入；`probe/` 为一次性 C++ 组件验证。

## 9. 边界与未覆盖

- 物理范围：仅冻结合同中“仅电磁（EM option4）或明确 FTFP_BERT_EMZ 参考”的
  质子/geantino 病例、固定几何、源、cut、N、种子；不扩展专业结论。
- 统计范围：64 个固定种子批次的覆盖结论仅针对该冻结模型与样本；不把
  `0.9559137115…` 说成通用 95% 置信区间。
- 已知观测限制：UNC-MT-SPARSE 的稀疏运行不能区分“错误 worker 平均”，其可区分性由
  预指定组件 fixture 提供；`hits=false` 的覆盖批次没有逐事件路径观测，只用打印矩一致性；
  `event_edep` 每个 worker 独立文件；header-only 文件是合法的“无有效贡献”表示。
- 未修改产品、测试、基准、冻结、表数据、ROADMAP/STATUS；未提交 Git；未提交任何
  预注册目录改动。

## 10. 复演

```text
cd out/collab/q2-uncertainty-v1
python -B setup_inputs.py
python -B run_cases.py
python -B compare.py --write
python -B probe/build_probe.py
python -B tamper.py
```

`compare.py` 失败时退出码非零；反例脚本失败时退出码非零；后端 exit code 与比较器
exit code 分开记录（`results.json` 的 `backend_exit_codes` 与
`comparison_exit_is_not_backend_exit`）。
