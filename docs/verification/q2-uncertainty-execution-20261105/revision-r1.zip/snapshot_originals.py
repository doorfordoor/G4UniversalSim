#!/usr/bin/env python3
"""Preserve the v1 reports and fingerprint the original run bytes.

The independent review of the first delivery requires the comparison evidence
to be repaired without re-running, re-sampling or touching the original bytes.
This candidate-local helper:

* copies the v1 results / tamper / probe reports and README into ``preserved/``
  (only when the preserved copy is absent, so a second invocation is a no-op),
* writes ``originals-manifest.json`` with a SHA-256 over every file under
  ``runs/``, every input under ``inputs/``, ``identity.json`` and the freeze
  contract,
* computes one aggregate ``runs_manifest_sha256`` over the sorted
  ``<relative path> <sha256>`` lines so the receipt can cite a single value,
* in ``--verify`` mode recomputes the manifest and compares it with the stored
  file, exiting non-zero on any difference.

It never runs Geant4 and never writes outside this candidate directory.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
PRESERVED = BASE / "preserved"
MANIFEST = BASE / "originals-manifest.json"

PRESERVE = [
    ("results.json", "results-v1.json"),
    ("tamper-results.json", "tamper-results-v1.json"),
    ("probe/probe_results.json", "probe-results-v1.json"),
    ("README.md", "README-v1.md"),
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def tree_fingerprint(root: Path) -> dict[str, dict[str, object]]:
    files: dict[str, dict[str, object]] = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(BASE).as_posix()
        files[relative] = {"sha256": sha256(path), "size_bytes": path.stat().st_size}
    return files


def aggregate(files: dict[str, dict[str, object]]) -> str:
    digest = hashlib.sha256()
    for relative in sorted(files):
        digest.update(f"{relative} {files[relative]['sha256']}\n".encode("utf-8"))
    return digest.hexdigest()


def build() -> dict:
    identity = json.loads((BASE / "identity.json").read_text(encoding="utf-8"))
    preserved: dict[str, dict[str, object]] = {}
    PRESERVED.mkdir(exist_ok=True)
    for source, target in PRESERVE:
        source_path = BASE / source
        target_path = PRESERVED / target
        if target_path.exists():
            preserved[target] = {"sha256": sha256(target_path),
                                 "size_bytes": target_path.stat().st_size,
                                 "source_sha256": sha256(source_path) if source_path.is_file() else None}
            continue
        if not source_path.is_file():
            raise SystemExit(f"missing report to preserve: {source}")
        shutil.copy2(source_path, target_path)
        preserved[target] = {"sha256": sha256(target_path),
                             "size_bytes": target_path.stat().st_size,
                             "source_sha256": sha256(source_path)}
    runs = tree_fingerprint(BASE / "runs")
    inputs = tree_fingerprint(BASE / "inputs")
    freeze_path = ROOT / str(identity["freeze"]["path"])
    manifest = {
        "schema": "g4usim_q2_uncertainty_originals_v1",
        "created_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "freeze": {
            "path": identity["freeze"]["path"],
            "sha256": sha256(freeze_path),
            "expected_sha256": identity["freeze"]["sha256"],
        },
        "backend": {
            "path": identity["backend"]["path"],
            "sha256": sha256(ROOT / identity["backend"]["path"]),
            "expected_sha256": identity["backend"]["sha256"],
        },
        "identity": {"sha256": sha256(BASE / "identity.json"), "size_bytes": (BASE / "identity.json").stat().st_size},
        "preserved": preserved,
        "runs": runs,
        "inputs": inputs,
        "summary": {
            "runs_files": len(runs),
            "runs_bytes": sum(int(item["size_bytes"]) for item in runs.values()),
            "runs_manifest_sha256": aggregate(runs),
            "inputs_files": len(inputs),
            "inputs_manifest_sha256": aggregate(inputs),
        },
    }
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true",
                        help="recompute and compare with the stored manifest")
    args = parser.parse_args()
    current = build()
    if args.verify:
        if not MANIFEST.is_file():
            print("no stored manifest")
            return 2
        stored = json.loads(MANIFEST.read_text(encoding="utf-8"))
        mismatches: list[str] = []
        for section in ("runs", "inputs"):
            old = stored.get(section, {})
            new = current.get(section, {})
            for name in sorted(set(old) | set(new)):
                if old.get(name) != new.get(name):
                    mismatches.append(f"{section}:{name}")
        # The preserved v1 copies are immutable bytes; their source files were
        # intentionally regenerated with repaired content, so compare only the
        # preserved copy itself.
        old = stored.get("preserved", {})
        new = current.get("preserved", {})
        for name in sorted(set(old) | set(new)):
            old_item = old.get(name) or {}
            new_item = new.get(name) or {}
            if (old_item.get("sha256"), old_item.get("size_bytes")) !=                     (new_item.get("sha256"), new_item.get("size_bytes")):
                mismatches.append(f"preserved:{name}")
        for section in ("identity", "freeze", "backend"):
            if stored.get(section) != current.get(section):
                mismatches.append(section)
        if mismatches:
            print(f"originals changed: {len(mismatches)}")
            for name in mismatches[:40]:
                print(f"  {name}")
            return 1
        print(f"originals unchanged: runs={len(current['runs'])} "
              f"inputs={len(current['inputs'])} "
              f"runs_manifest_sha256={current['summary']['runs_manifest_sha256']}")
        return 0
    MANIFEST.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    print(f"manifest written: {MANIFEST.name} sha256={sha256(MANIFEST)}")
    print(f"runs files={len(current['runs'])} bytes={current['summary']['runs_bytes']}")
    print(f"runs_manifest_sha256={current['summary']['runs_manifest_sha256']}")
    print(f"inputs files={len(current['inputs'])} sha256="
          f"{current['summary']['inputs_manifest_sha256']}")
    print(f"identity sha256={current['identity']['sha256']}")
    for name, item in current["preserved"].items():
        print(f"preserved {name} sha256={item['sha256']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
