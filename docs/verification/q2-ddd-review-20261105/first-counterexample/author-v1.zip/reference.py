"""Recompute the two frozen REF-DDD-01 references from the SR-NIEL table bytes.

The contract fixes the reference method as: take the PSTAR mid-slab energy from
the dose freeze, then interpolate the proton SR-NIEL table at that energy with
log-log interpolation, and call the result the expected steady-state
displacement damage dose per unit proton fluence (MeV cm²/g).

This script reads the table bytes directly, verifies their SHA-256, row count
and energy domain, checks that the adjacent interpolation nodes are the ones
frozen in the contract, and recomputes both references.  It performs no
simulation and writes `reference-recompute.json`.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-ddd-v1"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-ddd-reference-freeze-v1.json"
DOSE_FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-dose-reference-freeze-v1.json"
PROTON_TABLE = ROOT / "scenarios" / "semiconductor" / "niel" / "si_proton.csv"
FROZEN_PROTON_TABLE_SHA = "6c21e35aab18495d4bb2597a76be60c7c35ef0df963224e0108c77c2e4c208d5"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_table(path: Path) -> list[tuple[float, float]]:
    rows: list[tuple[float, float]] = []
    header_seen = False
    for line in path.read_text(encoding="utf-8").splitlines():
        text = line.strip()
        if not text or text.startswith("#"):
            continue
        if not header_seen:
            if text != "energy_MeV,niel_MeV_cm2_g":
                raise SystemExit(f"unexpected table header: {text}")
            header_seen = True
            continue
        energy, niel = text.split(",")[:2]
        rows.append((float(energy), float(niel)))
    if not header_seen or len(rows) < 2:
        raise SystemExit("proton NIEL table is incomplete")
    return rows


def interpolate_loglog(rows: list[tuple[float, float]], energy: float) -> tuple[float, float, int]:
    """Return (value, lower_node_energy, lower_node_index) with log-log interpolation."""
    if not (rows[0][0] <= energy <= rows[-1][0]):
        raise SystemExit(f"energy {energy} is outside the table domain")
    index = 0
    while index + 1 < len(rows) and rows[index + 1][0] < energy:
        index += 1
    e0, v0 = rows[index]
    e1, v1 = rows[index + 1]
    if e1 == e0:
        raise SystemExit("degenerate interpolation interval")
    fraction = math.log(energy / e0) / math.log(e1 / e0)
    value = math.exp(math.log(v0) + fraction * (math.log(v1) - math.log(v0)))
    return value, e0, index


def main(argv: list[str] | None = None) -> int:
    argparse.ArgumentParser().parse_args(argv)
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    dose_freeze = json.loads(DOSE_FREEZE.read_text(encoding="utf-8"))
    dose_cases = {float(case["energy_MeV"]): case for case in dose_freeze["cases"]}
    table_sha = sha256(PROTON_TABLE)
    rows = load_table(PROTON_TABLE)
    spec = freeze["tables"]["proton"]

    checks: list[dict] = []

    def check(cid: str, ok: bool, detail: str) -> None:
        checks.append({"id": cid, "status": "pass" if ok else "fail", "detail": detail})

    check("REF-TABLE-SHA", table_sha == spec["sha256"] == FROZEN_PROTON_TABLE_SHA,
          f"disk={table_sha} frozen={spec['sha256']}")
    check("REF-TABLE-ROWS", len(rows) == int(spec["rows"]),
          f"rows={len(rows)} frozen={spec['rows']}")
    domain = [rows[0][0], rows[-1][0]]
    check("REF-TABLE-DOMAIN",
          all(abs(a - b) <= 1e-15 for a, b in zip(domain, spec["energy_domain_MeV"])),
          f"domain={domain} frozen={spec['energy_domain_MeV']}")
    check("REF-TABLE-ASCENDING",
          all(rows[i][0] < rows[i + 1][0] for i in range(len(rows) - 1)),
          "energies strictly increasing")
    check("REF-TABLE-NONNEGATIVE",
          all(value >= 0.0 for _, value in rows), "all NIEL values non-negative")

    results: dict[str, dict] = {}
    ok = True
    for case in freeze["cases"]:
        name = str(case["case"])
        energy = float(case["energy_MeV"])
        mid_energy = float(case["reference_mid_energy_MeV"])
        dose_case = dose_cases[energy]
        mid_from_dose_freeze = float(dose_case["reference_mid_energy_MeV"])
        value, lower_energy, lower_index = interpolate_loglog(rows, mid_energy)
        upper_energy = rows[lower_index + 1][0]
        nodes = [float(item) for item in case["interpolation_nodes"]]
        frozen_value = float(case["reference_ddd_per_fluence_MeV_cm2_g"])
        check(f"REF-{name}-MID-ENERGY-SOURCE",
              abs(mid_energy - mid_from_dose_freeze) <= 1e-12,
              f"ddd={mid_energy} dose_freeze={mid_from_dose_freeze}")
        check(f"REF-{name}-NODES",
              [lower_energy, upper_energy] == nodes[0:2]
              and [rows[lower_index][1], rows[lower_index + 1][1]] == nodes[2:4],
              f"table={[lower_energy, upper_energy, rows[lower_index][1], rows[lower_index + 1][1]]} "
              f"frozen={nodes}")
        delta = value - frozen_value
        relative_delta = delta / frozen_value
        matches = abs(relative_delta) <= 1e-12
        check(f"REF-{name}-VALUE", matches,
              f"recomputed={value!r} frozen={frozen_value!r} relative_delta={relative_delta:.3e}")
        results[name] = {
            "case": name,
            "energy_MeV": energy,
            "reference_mid_energy_MeV": mid_energy,
            "mid_energy_matches_dose_freeze": abs(mid_energy - mid_from_dose_freeze) <= 1e-12,
            "interpolation": {
                "method": "log-log linear between adjacent table nodes",
                "lower_node_energy_MeV": lower_energy,
                "upper_node_energy_MeV": upper_energy,
                "lower_node_niel_MeV_cm2_g": rows[lower_index][1],
                "upper_node_niel_MeV_cm2_g": rows[lower_index + 1][1],
                "fraction": math.log(mid_energy / lower_energy) / math.log(upper_energy / lower_energy),
            },
            "recomputed_ddd_per_fluence_MeV_cm2_g": value,
            "frozen_ddd_per_fluence_MeV_cm2_g": frozen_value,
            "absolute_delta": delta,
            "relative_delta": relative_delta,
            "matches_freeze": matches,
        }
        ok &= matches

    status = "pass" if ok and all(item["status"] == "pass" for item in checks) else "fail"
    payload = {
        "schema": "g4usim_q2_ref_ddd_recompute_v1",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "case": freeze["case"],
        "freeze": {
            "path": str(FREEZE.relative_to(ROOT)).replace("\\", "/"),
            "sha256": sha256(FREEZE),
            "schema": freeze["schema"],
        },
        "table": {
            "path": str(PROTON_TABLE.relative_to(ROOT)).replace("\\", "/"),
            "sha256": table_sha,
            "rows": len(rows),
            "energy_domain_MeV": domain,
            "matches_freeze": table_sha == spec["sha256"] == FROZEN_PROTON_TABLE_SHA,
        },
        "checks": checks,
        "cases": results,
        "status": status,
    }
    (BASE / "reference-recompute.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    for name, item in results.items():
        print(f"{name}: mid={item['reference_mid_energy_MeV']} "
              f"recomputed={item['recomputed_ddd_per_fluence_MeV_cm2_g']!r} "
              f"frozen={item['frozen_ddd_per_fluence_MeV_cm2_g']!r} "
              f"relative_delta={item['relative_delta']:.3e}")
    print("status:", status, "checks:", len(checks),
          "failed:", [item["id"] for item in checks if item["status"] != "pass"])
    return 0 if status == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
