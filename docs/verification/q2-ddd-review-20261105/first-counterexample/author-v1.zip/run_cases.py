"""Run the two frozen REF-DDD-01 cases against the frozen backend.

A run result is reusable only when the freeze SHA, backend identity, generated
inputs and every declared output (sha256 and size) are unchanged, and the
recorded run really completed the frozen sample size.  ``--force`` re-runs.

The results file is written before the comparison runs, so a comparator defect
can never destroy the fact that a real simulation happened.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

import compare

BASE = Path(__file__).resolve().parent
FREEZE_PATH = compare.FREEZE
FROZEN_BACKEND_SHA = compare.FROZEN_BACKEND_SHA
EXPECTED_OUTPUTS = [
    "run_summary.txt",
    "run_metadata.json",
    "hits_t0.csv",
    "displacement_volume_summary_t0.csv",
    "scorer_statistics.csv",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def backend_path(identity: dict) -> Path:
    return compare.ROOT / identity["backend"]["path"]


def input_sha256(identity: dict, path: str) -> str | None:
    item = identity.get("inputs", {}).get(Path(path).name)
    return item.get("sha256") if item else None


def output_dir_for(name: str) -> Path:
    return BASE / "runs" / name / "output"


def env() -> dict[str, str]:
    result = dict(os.environ)
    geant4_bin = Path("D:/ProgramFiles/Geant4/bin")
    if geant4_bin.is_dir():
        result["PATH"] = str(geant4_bin) + os.pathsep + result.get("PATH", "")
    data_dir = Path("D:/ProgramFiles/Geant4/share/Geant4-11.3.2/data")
    if data_dir.is_dir():
        result.setdefault("GEANT4_DATA_DIR", str(data_dir))
    return result


def macro_for(events: int) -> str:
    return "/run/initialize\n/run/beamOn " + str(events) + "\n"


def artifact_record(path: Path) -> dict:
    return {
        "path": compare.relative(path),
        "sha256": sha256(path),
        "size_bytes": path.stat().st_size,
    }


def record_is_reusable(record: dict | None, identity: dict, freeze: dict, case: dict,
                       output: Path, events: int) -> bool:
    if not record:
        return False
    if not record.get("reused") and record.get("completed_events") != events:
        return False
    if record.get("completed_events") != events or record.get("exit_code") != 0:
        return False
    if record.get("freeze_sha256") != sha256(FREEZE_PATH):
        return False
    if record.get("backend_sha256") != FROZEN_BACKEND_SHA:
        return False
    if record.get("main_ini_sha256") != case.get("main_ini_sha256"):
        return False
    if record.get("geometry_ini_sha256") != case.get("geometry_ini_sha256"):
        return False
    for name in EXPECTED_OUTPUTS:
        item = record.get("artifacts", {}).get(name)
        path = output / name
        if not item or not path.is_file():
            return False
        if sha256(path) != item.get("sha256") or path.stat().st_size != item.get("size_bytes"):
            return False
    for name, item in identity.get("tables", {}).items():
        table = compare.ROOT / item.get("path", "")
        if not table.is_file() or sha256(table) != item.get("sha256"):
            return False
    return True


def run_case(name: str, case: dict, freeze: dict, identity: dict, force: bool) -> dict:
    output = output_dir_for(name)
    events = int(freeze["events_per_case"])
    record_path = BASE / "runs" / name / "record.json"
    existing = json.loads(record_path.read_text(encoding="utf-8")) if record_path.is_file() else None
    if not force and record_is_reusable(existing, identity, freeze, case, output, events):
        existing["reused"] = True
        record_path.write_text(json.dumps(existing, ensure_ascii=False, indent=2) + "\n",
                               encoding="utf-8")
        return existing

    if output.exists():
        for path in sorted(output.rglob("*"), reverse=True):
            if path.is_file():
                path.unlink()
            else:
                path.rmdir()
    output.mkdir(parents=True, exist_ok=True)
    macro_path = BASE / "runs" / name / "run.mac"
    macro_path.parent.mkdir(parents=True, exist_ok=True)
    macro_path.write_text(macro_for(events), encoding="utf-8")
    log_path = BASE / "runs" / name / "backend.log"
    command = [
        str(backend_path(identity).resolve()),
        "--config", str((compare.ROOT / case["main_ini"]).resolve()),
        "--macro", str(macro_path.resolve()),
        "--output", str(output.resolve()),
        "--threads", str(int(freeze["threads"])),
        "--seed", str(int(case["seed"])),
    ]
    started = time.perf_counter()
    with log_path.open("wb") as log:
        log.write(("$ " + " ".join(command) + "\n").encode("utf-8"))
        log.flush()
        completed = subprocess.run(command, cwd=str(compare.ROOT), env=env(),
                                   stdout=log, stderr=subprocess.STDOUT)
    duration = time.perf_counter() - started
    summary_text = (output / "run_summary.txt").read_text(encoding="utf-8", errors="replace") \
        if (output / "run_summary.txt").is_file() else ""
    summary = compare.parse_run_summary(output / "run_summary.txt") \
        if (output / "run_summary.txt").is_file() else {}
    record = {
        "case": name,
        "seed": int(case["seed"]),
        "events_requested": events,
        "completed_events": int(summary.get("actual_completed_event_count", 0) or 0),
        "exit_code": int(completed.returncode),
        "duration_s": round(duration, 3),
        "freeze_sha256": sha256(FREEZE_PATH),
        "backend_sha256": sha256(backend_path(identity)),
        "main_ini": case["main_ini"],
        "main_ini_sha256": case["main_ini_sha256"],
        "geometry_ini": case["geometry_ini"],
        "geometry_ini_sha256": case["geometry_ini_sha256"],
        "command": command,
        "output_dir": compare.relative(output),
        "run_summary_sha256": sha256(output / "run_summary.txt")
        if (output / "run_summary.txt").is_file() else None,
        "run_metadata_sha256": sha256(output / "run_metadata.json")
        if (output / "run_metadata.json").is_file() else None,
        "backend_log": compare.relative(log_path),
        "artifacts": {name: artifact_record(output / name) for name in EXPECTED_OUTPUTS
                      if (output / name).is_file()},
        "summary_status": summary.get("status"),
        "reused": False,
    }
    record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return record


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--force", action="store_true", help="re-run even when the record is reusable")
    args = parser.parse_args(argv)
    freeze = json.loads(FREEZE_PATH.read_text(encoding="utf-8"))
    identity_path = BASE / "identity.json"
    if not identity_path.is_file():
        raise SystemExit("identity.json is missing; run setup_inputs.py first")
    identity = json.loads(identity_path.read_text(encoding="utf-8"))
    prior_path = BASE / "results.json"
    prior = json.loads(prior_path.read_text(encoding="utf-8")) if prior_path.is_file() else {}
    results = {
        "schema": "g4usim_q2_ref_ddd_run_results_v1",
        "freeze": {"path": compare.relative(FREEZE_PATH), "sha256": sha256(FREEZE_PATH)},
        "backend": {
            "path": identity["backend"]["path"],
            "sha256": sha256(backend_path(identity)),
            "build_git_commit": identity["backend"].get("build_git_commit"),
            "source_fingerprint": identity["backend"].get("source_fingerprint"),
        },
        "cases": {},
        "evaluation": prior.get("evaluation"),
    }
    for name in sorted(identity["cases"]):
        case = dict(identity["cases"][name])
        case["main_ini_sha256"] = input_sha256(identity, case["main_ini"])
        case["geometry_ini_sha256"] = input_sha256(identity, case["geometry_ini"])
        results["cases"][name] = run_case(name, case, freeze, identity, args.force)
        summary = results["cases"][name]
        print(f"{name}: exit={summary['exit_code']} completed={summary['completed_events']} "
              f"reused={summary['reused']} duration={summary['duration_s']}s")
    prior_path.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"results written to {compare.relative(prior_path)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
