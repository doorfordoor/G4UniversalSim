"""Generate the frozen REF-DDD-01 inputs and record the product/table identity.

Derived from `docs/collab/decisions/20261105-q2-ddd-reference-freeze-v1.json`
and, for the geometry/source that the DDD contract reuses, from
`docs/collab/decisions/20261105-q2-dose-reference-freeze-v1.json`.  The script
refuses to continue when the backend, either freeze file, the proton/neutron
SR-NIEL tables or the Geant4 data check disagree with the frozen contract.
It writes inputs only: no simulation is executed here.
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-ddd-v1"
INPUTS = BASE / "inputs"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-ddd-reference-freeze-v1.json"
DOSE_FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-dose-reference-freeze-v1.json"
BACKEND = ROOT / "out" / "collab" / "q2-backend-864bc036" / "G4UniversalSim.exe"
BACKEND_ID = ROOT / "out" / "collab" / "q2-backend-864bc036" / "identity.json"
PROTON_TABLE = ROOT / "scenarios" / "semiconductor" / "niel" / "si_proton.csv"
NEUTRON_TABLE = ROOT / "scenarios" / "semiconductor" / "niel" / "si_neutron.csv"
GEANT4_PREFIX = Path("D:/ProgramFiles/Geant4")
GEANT4_DATA = GEANT4_PREFIX / "share" / "Geant4" / "data"
GEANT4_BIN = GEANT4_PREFIX / "bin"

FROZEN_BACKEND_SHA = "f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f"
FROZEN_DOSE_FREEZE_SHA = "a2a799e90bd941b4969beab62be408013420dfbd684c4e8e52f07775308e498d"
FROZEN_PROTON_TABLE_SHA = "6c21e35aab18495d4bb2597a76be60c7c35ef0df963224e0108c77c2e4c208d5"
FROZEN_NEUTRON_TABLE_SHA = "a2ad28a9fcce3500fca363946e09e19125d084f1b596eff76662b272c242034f"
FROZEN_GEANT4_VERSION = 1132


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def env() -> dict:
    merged = os.environ.copy()
    merged["PATH"] = str(GEANT4_BIN) + os.pathsep + merged.get("PATH", "")
    merged["GEANT4_DATA_DIR"] = str(GEANT4_DATA)
    merged.pop("QT_QPA_PLATFORM", None)
    return merged


def run(command: list[str], timeout: int = 300) -> subprocess.CompletedProcess:
    return subprocess.run(
        command, cwd=str(ROOT), env=env(),
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout,
    )


def table_rows(path: Path) -> list[tuple[float, float]]:
    rows: list[tuple[float, float]] = []
    header_seen = False
    for line in path.read_text(encoding="utf-8").splitlines():
        text = line.strip()
        if not text or text.startswith("#"):
            continue
        if not header_seen:
            if text != "energy_MeV,niel_MeV_cm2_g":
                raise SystemExit(f"{path.name}: unexpected table header: {text}")
            header_seen = True
            continue
        energy, niel = text.split(",")[:2]
        rows.append((float(energy), float(niel)))
    if not header_seen:
        raise SystemExit(f"{path.name}: missing table header")
    return rows


def relative(path: Path) -> str:
    return str(path.resolve().relative_to(ROOT.resolve())).replace("\\", "/")


def render_materials() -> str:
    return """[galactic]
material = G4_Galactic

[silicon]
material = G4_Si
"""


def render_geometry(freeze: dict, dose_freeze: dict, case: dict) -> str:
    world_x, world_y, world_z = freeze["world_size_mm"]
    block_x, block_y = freeze["block_xy_mm"]
    slab_x, slab_y = freeze["slab_xy_mm"]
    block_z = float(case["block_z_mm"])
    center_z = float(case["block_center_z_mm"])
    slab_z = float(case["slab_mm"])
    material = dose_freeze["material"]
    return f"""[world]
shape = box
size = {world_x} mm, {world_y} mm, {world_z} mm
material = G4_Galactic

[volume.Block]
parent = world
shape = box
size = {block_x} mm, {block_y} mm, {block_z:g} mm
material = {material}
position = 0 mm, 0 mm, {center_z:g} mm

[volume.Slab]
parent = Block
shape = box
size = {slab_x} mm, {slab_y} mm, {slab_z:g} mm
material = {material}
position = 0 mm, 0 mm, 0 mm
sensitive = true
"""


def render_main(freeze: dict, case: dict, output_dir: Path) -> str:
    source = freeze["source"]
    center = ", ".join(f"{item:g}" for item in source["center_mm"])
    direction = ", ".join(f"{item:g}" for item in source["direction"])
    return f"""[run]
name = {case['case']}
threads = {int(freeze['threads'])}
seed = {int(case['seed'])}
interactive = false
verbose = 0
check_overlaps = false
dry_run = false

[output]
dir = {output_dir.as_posix()}
format = csv

[materials]
file = {(INPUTS / 'materials.ini').as_posix()}

[geometry]
template = hierarchical
config = {(INPUTS / ('geometry_' + case['case'] + '.ini')).as_posix()}
default_world_material = G4_Galactic

[physics]
em = {freeze['physics_em']}
default_cut = {freeze['default_cut']}

[scoring]
enabled = true
hits = true
event_edep = false
edep = false
dose = false
displacement = true
auto_create_default_scorers = true

[scoring.displacement]
proton = {PROTON_TABLE.as_posix()}

[source]
particle = proton
energy = {float(case['energy_MeV']):g} MeV
position_type = {source['position_type']}
shape = {source['shape']}
halfx = {float(source['halfx_mm']):g} mm
center = {center} mm
direction = {direction}
"""


def main() -> int:
    freeze_text = FREEZE.read_text(encoding="utf-8")
    freeze_sha = hashlib.sha256(freeze_text.encode("utf-8")).hexdigest()
    freeze = json.loads(freeze_text)
    if freeze.get("schema") != "q2_reference_ddd_freeze_v1":
        raise SystemExit("unexpected DDD freeze schema")
    dose_freeze_text = DOSE_FREEZE.read_text(encoding="utf-8")
    dose_freeze_sha = hashlib.sha256(dose_freeze_text.encode("utf-8")).hexdigest()
    dose_freeze = json.loads(dose_freeze_text)
    if dose_freeze.get("schema") != "q2_reference_dose_freeze_v1":
        raise SystemExit("unexpected dose freeze schema")
    if dose_freeze_sha != FROZEN_DOSE_FREEZE_SHA or freeze["geometry_source_freeze_sha256"] != FROZEN_DOSE_FREEZE_SHA:
        raise SystemExit("geometry source freeze SHA does not match the frozen contract")
    if not BACKEND.is_file():
        raise SystemExit(f"frozen backend missing: {BACKEND}")
    if sha256(BACKEND) != FROZEN_BACKEND_SHA:
        raise SystemExit("frozen backend sha256 mismatch")
    backend_identity = json.loads(BACKEND_ID.read_text(encoding="utf-8"))
    capabilities_path = backend_identity.get("capabilities_file")
    capabilities = (
        json.loads(Path(capabilities_path).read_text(encoding="utf-8"))
        if capabilities_path and Path(capabilities_path).is_file()
        else json.loads(run([str(BACKEND), "--capabilities"]).stdout.decode("utf-8"))
    )
    if capabilities["build_git_commit"] != freeze["backend_build"]:
        raise SystemExit("backend build does not match the freeze")
    if int(capabilities["geant4_version_number"]) != FROZEN_GEANT4_VERSION:
        raise SystemExit("Geant4 version does not match the frozen evidence level")
    check = run([str(BACKEND), "--check-geant4-data"])
    check_text = check.stdout.decode("utf-8", errors="replace")
    (BASE / "backend-data-check.txt").write_text(check_text, encoding="utf-8")
    if check.returncode != 0 or '"required_complete": true' not in check_text:
        raise SystemExit(f"--check-geant4-data not complete: exit={check.returncode}\n{check_text}")

    tables: dict[str, dict] = {}
    for particle, path, frozen_sha in (
        ("proton", PROTON_TABLE, FROZEN_PROTON_TABLE_SHA),
        ("neutron", NEUTRON_TABLE, FROZEN_NEUTRON_TABLE_SHA),
    ):
        spec = freeze["tables"][particle]
        if sha256(path) != frozen_sha or sha256(path) != spec["sha256"]:
            raise SystemExit(f"{particle} NIEL table sha256 mismatch")
        rows = table_rows(path)
        if len(rows) != int(spec["rows"]):
            raise SystemExit(f"{particle} NIEL table row count {len(rows)} != {spec['rows']}")
        domain = [rows[0][0], rows[-1][0]]
        if any(abs(a - b) > 1e-15 for a, b in zip(domain, spec["energy_domain_MeV"])):
            raise SystemExit(f"{particle} NIEL table domain {domain} != {spec['energy_domain_MeV']}")
        if any(rows[i][0] >= rows[i + 1][0] for i in range(len(rows) - 1)):
            raise SystemExit(f"{particle} NIEL table energies are not strictly increasing")
        if any(not (rows_value[1] >= 0.0) for rows_value in rows):
            raise SystemExit(f"{particle} NIEL table has a negative value")
        tables[particle] = {
            "path": relative(path),
            "sha256": frozen_sha,
            "rows": len(rows),
            "energy_domain_MeV": domain,
            "matches_freeze": True,
        }

    dose_cases = {float(case["energy_MeV"]): case for case in dose_freeze["cases"]}
    INPUTS.mkdir(parents=True, exist_ok=True)
    files: dict[str, str] = {"materials.ini": render_materials()}
    cases: dict[str, dict] = {}
    for case in freeze["cases"]:
        name = str(case["case"])
        energy = float(case["energy_MeV"])
        buildup = float(case["buildup_mm"])
        slab = float(case["slab_mm"])
        block_z = float(case["block_z_mm"])
        center_z = float(case["block_center_z_mm"])
        if abs(block_z - (2.0 * buildup + slab)) > 1e-12:
            raise SystemExit(f"{name}: block_z_mm is not 2*buildup+slab")
        if abs(center_z - (buildup + 0.5 * slab)) > 1e-12:
            raise SystemExit(f"{name}: block_center_z_mm is not buildup+slab/2")
        dose_case = dose_cases.get(energy)
        if dose_case is None:
            raise SystemExit(f"{name}: energy {energy} is absent from the dose freeze")
        for field in ("reference_mid_energy_MeV", "electronic_stopping_MeV_cm2_g", "sensitive_mass_kg"):
            if abs(float(case[field]) - float(dose_case[field])) > 1e-15:
                raise SystemExit(f"{name}: {field} disagrees with the dose freeze")
        volume_mm3 = float(freeze["slab_xy_mm"][0]) * float(freeze["slab_xy_mm"][1]) * slab
        mass_kg = float(freeze["density_g_cm3"]) * volume_mm3 * 1e-3 / 1000.0
        if abs(mass_kg - float(case["sensitive_mass_kg"])) > 1e-15:
            raise SystemExit(f"{name}: sensitive mass is not density*volume")
        run_dir = BASE / "runs" / name
        output_dir = run_dir / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        geometry_name = "geometry_" + name + ".ini"
        main_name = "main_" + name + ".ini"
        files[geometry_name] = render_geometry(freeze, dose_freeze, case)
        files[main_name] = render_main(freeze, case, output_dir)
        cases[name] = {
            "case": name,
            "energy_MeV": energy,
            "buildup_mm": buildup,
            "slab_mm": slab,
            "block_z_mm": block_z,
            "block_center_z_mm": center_z,
            "seed": int(case["seed"]),
            "threads": int(freeze["threads"]),
            "events": int(freeze["events_per_case"]),
            "sensitive_mass_kg": float(case["sensitive_mass_kg"]),
            "slab_volume_mm3": volume_mm3,
            "reference_mid_energy_MeV": float(case["reference_mid_energy_MeV"]),
            "electronic_stopping_MeV_cm2_g": float(case["electronic_stopping_MeV_cm2_g"]),
            "reference_ddd_per_fluence_MeV_cm2_g": float(case["reference_ddd_per_fluence_MeV_cm2_g"]),
            "interpolation_nodes": [float(item) for item in case["interpolation_nodes"]],
            "main_ini": relative(INPUTS / main_name),
            "geometry_ini": relative(INPUTS / geometry_name),
            "output_dir": relative(output_dir),
            "run_dir": relative(run_dir),
        }
    for name, content in files.items():
        (INPUTS / name).write_text(content, encoding="utf-8")

    identity = {
        "schema": "g4usim_q2_ref_ddd_identity_v1",
        "generated_at": now(),
        "case": freeze["case"],
        "workspace": str(ROOT).replace("\\", "/"),
        "freeze": {
            "path": relative(FREEZE),
            "sha256": freeze_sha,
            "schema": freeze["schema"],
        },
        "geometry_source_freeze": {
            "path": relative(DOSE_FREEZE),
            "sha256": dose_freeze_sha,
            "schema": dose_freeze["schema"],
        },
        "backend": {
            "path": relative(BACKEND),
            "sha256": sha256(BACKEND),
            "bytes": BACKEND.stat().st_size,
            "build_git_commit": capabilities["build_git_commit"],
            "source_fingerprint": capabilities["source_fingerprint"],
            "geant4_version_number": capabilities["geant4_version_number"],
            "compiler_id": capabilities["compiler_id"],
        },
        "geant4": {
            "prefix": str(GEANT4_PREFIX),
            "data": str(GEANT4_DATA),
            "data_check_exit": check.returncode,
            "data_check_sha256": sha256(BASE / "backend-data-check.txt"),
        },
        "tables": tables,
        "inputs": {
            name: {
                "path": relative(INPUTS / name),
                "sha256": sha256(INPUTS / name),
            }
            for name in files
        },
        "cases": cases,
        "environment": {
            "GEANT4_DATA_DIR": str(GEANT4_DATA),
            "PATH_prefix": str(GEANT4_BIN),
            "platform": "Windows",
            "cwd": str(ROOT),
        },
    }
    (BASE / "identity.json").write_text(
        json.dumps(identity, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    for name, item in sorted(identity["inputs"].items()):
        print(f"input {name}: {item['sha256'][:16]}")
    for name, item in sorted(cases.items()):
        print(f"case {name}: seed={item['seed']} volume={item['slab_volume_mm3']:g} mm3 "
              f"mid={item['reference_mid_energy_MeV']}")
    print("freeze:", freeze_sha)
    print("tables:", {key: value["sha256"][:16] for key, value in tables.items()})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
