# REF-DDD-01 交付回执（等待独立复验）

日期：2026-11-05
任务：`docs/collab/inbox/20261105-q2-reference-ddd-v1.md`
冻结：`docs/collab/decisions/20261105-q2-ddd-reference-freeze-v1.md` 与同名 JSON

## 结论

两个冻结的质子 NIEL 表折积病例（10 MeV / 100 MeV，各 20000 事件，单线程，仅电磁
`option4`，cut 10 um）在冻结后端 `864bc036` 上真实运行成功，`compare.py` 的 **261 项检查
0 失败**，两例均通过冻结的 **1% + 3σ** 判据。该结果只说明**表折积与径迹长度归一化**在本
冻结输入下成立，不评价 SR-NIEL 数据本身（REF-DDD-02 另案）。

## 冻结身份

| 项 | 值 |
| --- | --- |
| 冻结 JSON SHA-256 | `65877c33ad74111f5c567d060f495eccea074b378b3c5bd0b9bdd4f6e40b6a7c` |
| 几何来源冻结 | Dose 冻结 `20261105-q2-dose-reference-freeze-v1.json`，SHA-256 `a2a799e90bd941b4969beab62be408013420dfbd684c4e8e52f07775308e498d` |
| 后端 | build `864bc036d6d7752475e52db4efd2b950cabfcc3d`，exe SHA-256 `f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f`（2 786 304 B） |
| 源码指纹 | `e7de615d4e342114104f970688a7ea5f9789f7b70240b2562a388a50a45704e7` |
| Geant4 | 11.3.2，`--check-geant4-data` 退出 0 / `required_complete=true` |
| NIEL 表 | `si_proton.csv` 146 行 `[1e-6, 1e4]` MeV，SHA-256 `6c21e35aab18495d4bb2597a76be60c7c35ef0df963224e0108c77c2e4c208d5`；中子表仅登记身份 `a2ad28a9…`，未使用 |

## 交付物

候选目录：`out/collab/q2-reference-ddd-v1/`

| 文件 | 说明 / SHA-256 前缀 |
| --- | --- |
| `setup_inputs.py` | 冻结/后端/表校验，生成 5 个输入与 `identity.json` |
| `reference.py` | 从表字节独立重算参考，`--check` 退出 0 |
| `run_cases.py` | 真实运行、复用判断、先写 `results.json` 再比较 |
| `compare.py` | 六层检查（ID/IN/EVID/MOM/STAT/REF）与 `--update` |
| `tamper.py` | 7 个副本反例 |
| `identity.json` | `11f27eb0ab5a700b…` |
| `reference-recompute.json` | `378bd91c16f3fe00…` |
| `results.json` | `984f43ff04c4dbc8…` |
| `tamper-results.json` | `31490b16f2756188…` |
| `README.md` | `80da92e6e2ff1d27…` |
| `inputs/` | materials、两个 geometry、两个 main（SHA 见 README §2） |
| `runs/<case>/` | `run.mac`、`backend.log`、`output/` 原始产物 |
| `backend-data-check.txt` | `--check-geant4-data` 原始输出 |

## 参考（独立重算）

`reference.py` 直接读 `si_proton.csv` 字节，校验表头/SHA/行数/能量域/严格递增/非负，在冻结
`reference_mid_energy_MeV` 处做 log-log 插值并核对冻结的两个节点：

| 病例 | 重算 NIEL (MeV·cm²/g) | 冻结值 | 相对差 |
| --- | --- | --- | --- |
| `ref_ddd_10` | `0.009666310206360254` | `0.009666310206360261` | `-7.178e-16` |
| `ref_ddd_100` | `0.0029929239738930983` | 同值 | `0` |

`reference-recompute.json` 记录 11 项检查全部通过。

## 运行事实

| 病例 | 后端退出码 | 完成事件 | 用时 (s) | 说明 |
| --- | --- | --- | --- | --- |
| `ref_ddd_10` | 0 | 20000 | 1.775 | 首跑，未复用 |
| `ref_ddd_100` | 0 | 20000 | 3.296 | 首跑，未复用 |

产物 SHA-256（前 16 位）：10 MeV 的 summary `aef1dffcb2b832fa`、metadata `1821c40c3ecf9ded`、
hits `960125abc8627aaf`、DDD 汇总 `606c66ddd03d51be`、统计 `dc3d7d1ec65c1ea1`；100 MeV 的
summary `2ae05e51c97879c1`、metadata `a8a0fa1f40830f75`、hits `d6d835a37b9c8044`、DDD 汇总
`6dbecc3d12e69fef`、统计 `54ea3a3fc24073d7`。`run_metadata.json` 对本文件自身的完整性字段为
`self_reference_excluded`（不要求自哈希），其余产物均按 SHA+大小核对。

## 比较结果（261 项检查，0 失败）

| 层 | 项数 |
| --- | --- |
| ID | 19 |
| IN | 64 |
| EVID | 86 |
| MOM | 40 |
| STAT | 46 |
| REF | 6 |

| 病例 | DDD (MeV/g) | DDD/Phi (MeV·cm²/g) | 参考 | 绝对差 | 相对差 | σ | 允许 | 判据 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `ref_ddd_10` | `133.691937374` | `9.625819490927999e-03` | `9.666310206360261e-03` | `-4.049071543226271e-05` | `-4.188849e-03` | `4.548226878772154e-05` | `2.3310990842676725e-04` | pass |
| `ref_ddd_100` | `41.5611752708` | `2.9924046194976e-03` | `2.9929239738930983e-03` | `-5.19354395498231e-07` | `-1.735274e-04` | `1.4040181148458543e-05` | `7.20497831843066e-05` | pass |

统计：`n_events = 20000`（零贡献事件计入分母），`entries = 13828 / 13889`（有质子 hits 的事件），
`rel_error = 4.72502822545e-03 / 4.69193940451e-03`，`uncertainty_estimator =
uncorrected_event_moments_v1`、`uncertainty_status = approximate`；比较器用公开矩独立重算上述量。

## 实现层核对（只用公开输出）

- **长度下界**：hits 质子 `Σ(w·L)` 必须 ≤ CSV `track_length_mm`。10 MeV 差 `-3.9e-10` mm；
  100 MeV 差 `+6.272387e-04` mm（相对 `4.5e-7`）。该差额是公开输出无法消除的观测：hits CSV
  只记录正沉积步，而 DDD 计分器还会收到零沉积输运步；本候选**不断言**其为零，也不据此修改任何值。
- **折叠区间**：`E_post ≤ E_mean ≤ E_pre` 且表在节点间单调，用 hits 的 `Σ(w·L)`、体积与 ×100
  因子在窗口端点/节点取极值，得到精确上下界：10 MeV `[133.0564565442143, 134.35157031222855]`
  （CSV `133.691937374`，宽 `9.64e-03`）；100 MeV `[41.54536640848074, 41.57476113137182]`
  （CSV `41.5611752708`，宽 `7.07e-04`）。该检查验证 mm⁻²→cm⁻² 与体积归一化。
- **越界长度**：两例 `out_of_range_track_length_mm = 0`。

## 负例（7/7 检出，原件 SHA 未变）

| 反例 | 检出项 |
| --- | --- |
| 删除 metadata | `EVID-METADATA-FILE` |
| DDD 体积列 ×2 | `MOM-DDD-VOLUME-COLUMN` |
| 冻结束面积 ×100 | `REF-DDD-PHI-ABS` |
| 冻结参考值 ×1.06 | `REF-DDD-PHI-ABS` |
| identity 中质子表 SHA 改为 0 | `ID-TABLE-SHA-PROTON` |
| summary 完成事件改为 19999 | `EVID-RUN-0-COMPLETED-EVENTS`、`EVID-ACTUAL-COMPLETED-EVENT-COUNT` |
| 篡改 hits 后保留旧记录 SHA | `EVID-RECORDED-hits_t0.csv` |

`tamper-results.json` 记录 `status = pass`、`originals_unchanged = true`；反例只在 `tampered/`
副本上进行并在运行后删除。

## 复现

```bash
cd out/collab/q2-reference-ddd-v1
python -B setup_inputs.py
python -B reference.py --check
python -B run_cases.py
python -B compare.py --update
python -B tamper.py
```

## 边界与声明

- 只检验**表折积 + 径迹长度归一化**；不验证 SR-NIEL 数据、截面或物理列表选择（REF-DDD-02 另案）。
- 不声称逐步折积已重放：公开 hits CSV 只有一个动能列（步前能量），无计分器的步平均动能列；
  本候选用单调表区间给出精确上下界，而不是伪造逐步证据。
- 两例、两个能点、单线程、仅电磁 `option4`、固定几何/源/cut/种子；不覆盖强子输运、中子、活化、
  非平板几何或其他容差。
- 未修改产品、正式测试/基准、冻结文件、表数据、其它候选、ROADMAP/STATUS；未提交 Git。
  交付后停写，等待监督端独立复验。

## 已知驱动/比较器修正（诚实记录）

1. `run_cases.py` 需要把 identity 中仓库相对路径解析到仓库根（首次运行 FileNotFoundError）。
2. identity 的 case 记录不含主/几何 INI 的 SHA，运行驱动从 `inputs` 映射补齐。
3. `compare.main` 首次运行时结果文件未内嵌 identity，导致 ID 层全挂；已改为从 `identity.json` 加载。
4. 初版把 hits 长度与 CSV 径迹长度做 1e-9 相等检查，100 MeV 病例因未记录的零沉积步差
   `6.27e-04` mm 失败；改为“下界 + 精确折叠区间”，并把差额作为观测记录。
5. 折叠区间初版用忽略 buildup 的能量窗口，10 MeV 的隐含 NIEL 落在窗口之外；改为
   `E_post = E_pre − Edep` 的严格区间后两例都通过。
6. diagnostics 键名曾误拼为 `dddddd`，已改为 `ddd_per_fluence` 并重新生成 `results.json`。
