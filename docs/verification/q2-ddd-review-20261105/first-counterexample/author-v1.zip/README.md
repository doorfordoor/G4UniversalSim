# REF-DDD-01：两个冻结质子表折积病例（候选证据包）

本候选只响应 `docs/collab/inbox/20261105-q2-reference-ddd-v1.md` 与
`docs/collab/decisions/20261105-q2-ddd-reference-freeze-v1.md`（同名 JSON）：
用冻结后端 `864bc036` 对 10 MeV 与 100 MeV 质子各跑 20000 事件，检验**敏感片 DDD 的质子
NIEL 表折积与径迹长度归一化**，并与冻结解析参考比较。

本候选**不是**表数据物理审计（REF-DDD-02 另案），不验证 SR-NIEL 数据本身的正确性；
也不含强子输运、中子、活化或完整剂量学声明。

## 1. 冻结与身份

| 项 | 值 |
| --- | --- |
| 冻结文件 | `docs/collab/decisions/20261105-q2-ddd-reference-freeze-v1.json` |
| 冻结 SHA-256 | `65877c33ad74111f5c567d060f495eccea074b378b3c5bd0b9bdd4f6e40b6a7c` |
| schema | `q2_reference_ddd_freeze_v1` |
| 几何来源冻结 | `20261105-q2-dose-reference-freeze-v1.json`，SHA-256 `a2a799e90bd941b4969beab62be408013420dfbd684c4e8e52f07775308e498d` |
| 后端 build | `864bc036d6d7752475e52db4efd2b950cabfcc3d` |
| 后端可执行 | `out/collab/q2-backend-864bc036/G4UniversalSim.exe`，SHA-256 `f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f`（2 786 304 B） |
| C++ 源码指纹 | `e7de615d4e342114104f970688a7ea5f9789f7b70240b2562a388a50a45704e7` |
| Geant4 | 11.3.2（`G4VERSION_NUMBER=1132`），`--check-geant4-data` 退出 0、`required_complete=true` |

**NIEL 表**（`[scoring.displacement]/proton`）：

| 表 | 行数 | 能量域 (MeV) | SHA-256 |
| --- | --- | --- | --- |
| `scenarios/semiconductor/niel/si_proton.csv` | 146 | `[1e-6, 1e4]` | `6c21e35aab18495d4bb2597a76be60c7c35ef0df963224e0108c77c2e4c208d5` |
| `scenarios/semiconductor/niel/si_neutron.csv` | 640 | `[1.025e-10, 19.95]` | `a2ad28a9fcce3500fca363946e09e19125d084f1b596eff76662b272c242034f` |

中子表只作为冻结身份登记（本候选不使用中子）；两表都在 `setup_inputs.py` 中被重新哈希并与
冻结记录比较。**未写入或修改任何表数据**。

## 2. 几何、源与输入

两例共享几何（来自 Dose 冻结，SHA 锁定）：

- world：3000 mm 立方 `G4_Galactic`；
- `Block`：40 × 40 × `block_z` mm `G4_Si`，中心 z = `block_center_z`（前表面 z = 0）；
- `Slab`：10 × 10 × `slab` mm `G4_Si`，位于 Block 局部中心 `(0,0,0)`，`sensitive = true`。

| 病例 | E (MeV) | buildup (mm) | slab (mm) | block_z (mm) | 片中点深度 (mm) | seed | 片质量 (kg) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `ref_ddd_10` | 10 | 0.05 | 0.02 | 0.12 | 0.06 | 20261113 | 4.66e-06 |
| `ref_ddd_100` | 100 | 0.6 | 0.1 | 1.3 | 0.65 | 20261114 | 2.33e-05 |

源：质子、平面方束 `halfx = 6 mm`（**只写 halfx，不写 halfy**），中心 `(0,0,-1)` mm、方向
`(0,0,1)`，束面积 144 mm² = 1.44 cm²。物理：仅电磁 `option4`，无 `reference`；`default_cut = 10 um`；
单线程；各 20000 事件。计分：`hits = true`、`displacement = true`、`dose = false`、
`event_edep = false`、`auto_create_default_scorers = true`。

输入 SHA-256（写入 `identity.json` 并由比较器复核）：

| 文件 | SHA-256 |
| --- | --- |
| `inputs/materials.ini` | `fb05cfd6f448f12805a15c3b423cb16889fc34e64bbbc1a1a7bce45a6d0ef858` |
| `inputs/geometry_ref_ddd_10.ini` | `68812cef753f32c3171d4180a90860db57fad79cc474e01d39c9c6862ca26964` |
| `inputs/geometry_ref_ddd_100.ini` | `33005980bcc481bf7cc3bbb2b2540c321ae18636b92db4f5dbd569e05ff0bcb7` |
| `inputs/main_ref_ddd_10.ini` | `b6d541182c0bd1ce0461dc01eab64398b06bd8a606afd8fdbcedf2c76cca11a8` |
| `inputs/main_ref_ddd_100.ini` | `565471a146e81acd0531af3d5bfbabc10fefe017e81acaee35bb9b7180e2f357` |

DOS 刻度与片位置：Block 厚 `2b + slab`，中心在 `b + slab/2`；片在 Block 局部中心，因此片中点
深度 = `block_center_z`（0.06 / 0.65 mm），与冻结 `reference_mid_energy` 的 PSTAR 中点一致。
比较器逐项校验了 Block 前表面 z = 0、片中心、片中点深度、源在块外、束面积等。

## 3. 独立参考重算

`reference.py` 只读 `si_proton.csv` 原始字节（跳过注释、校验表头/SHA/行数/能量域/严格递增/非负），
在冻结的 `reference_mid_energy_MeV` 处做 **log-log 插值**，并核对冻结给的两个插值节点：

| 病例 | 重算 NIEL (MeV·cm²/g) | 冻结值 | 相对差 |
| --- | --- | --- | --- |
| `ref_ddd_10` | `0.009666310206360254` | `0.009666310206360261` | `-7.178e-16` |
| `ref_ddd_100` | `0.0029929239738930983` | 同值 | `0` |

`reference-recompute.json` 记录全部 11 项检查，`--check` 退出 0。线性插值会比冻结值偏约 9e-8，
本候选不使用。

参考是**表折积**参考：`DDD/Phi = NIEL(E_mid)`，其中 `E_mid` 由 Dose 冻结的 PSTAR 中点能量给出。
`DDD/Phi` 的换算为 `DDD × 1.44 cm² / N`。

## 4. 真实运行

两例都是真实 Geant4 运行，不是只解析配置、不是相空间导出：

| 病例 | 后端退出码 | 完成事件 | 用时 (s) | 复用 |
| --- | --- | --- | --- | --- |
| `ref_ddd_10` | 0 | 20000 | 1.775 | 本次首跑 |
| `ref_ddd_100` | 0 | 20000 | 3.296 | 本次首跑 |

`run_cases.py` 先写 `results.json` 再调用比较器，因此比较器缺陷不会抹掉真实运行事实。复用判断
比较冻结 SHA、后端 SHA、输入 SHA、每个产物的 SHA 与大小和完成事件数；输入未变时不重跑（`--force` 才重跑）。

产物（一例一份，均登记在 `results.json` 与 `run_metadata.json`）：

| 病例 | 文件 | 字节 | SHA-256（前 16 位） |
| --- | --- | --- | --- |
| 10 | `run_summary.txt` | 12118 | `aef1dffcb2b832fa` |
| 10 | `run_metadata.json` | 17537 | `1821c40c3ecf9ded` |
| 10 | `hits_t0.csv` | 2 980 120 | `960125abc8627aaf` |
| 10 | `displacement_volume_summary_t0.csv` | 316 | `606c66ddd03d51be` |
| 10 | `scorer_statistics.csv` | 674 | `dc3d7d1ec65c1ea1` |
| 100 | `run_summary.txt` | 12163 | `2ae05e51c97879c1` |
| 100 | `run_metadata.json` | 17575 | `a8a0fa1f40830f75` |
| 100 | `hits_t0.csv` | 16 674 600 | `d6d835a37b9c8044` |
| 100 | `displacement_volume_summary_t0.csv` | 318 | `6dbecc3d12e69fef` |
| 100 | `scorer_statistics.csv` | 680 | `54ea3a3fc24073d7` |

## 5. 证据门禁（fail-closed）

`compare.py` 共 **261 项检查，0 失败**，分六层：

| 层 | 项数 | 内容 |
| --- | --- | --- |
| ID | 19 | 后端 SHA/build/源码指纹、Geant4 版本、数据检查、冻结 SHA/schema、几何来源冻结 SHA、两张 NIEL 表 SHA/行数/能量域、输入 SHA |
| IN | 64 | 仅电磁且无 reference、cut、计分开关、线程/种子、源粒子/能量/形状/无 halfy/halfx/中心/方向、NIEL 表路径与 SHA、几何模板/世界材料/Block/Slab/敏感/片中点深度/源在块外/束面积、输入身份 |
| EVID | 86 | summary 与 metadata 必需字段、后端退出码、完成事件 = 20000、计划事件、seed、能量、metadata runs、hashed 产物、记录产物 SHA+大小、输出目录、日志、输入 SHA |
| MOM | 40 | hits 表头、质子行、volume、正步长/权重、有限性、事件数约束、DDD 表头/行/体积列/长度下界/越界长度 0/事件数、长度归一化、折叠区间 |
| STAT | 46 | 两行统计的 unit/estimator/n_events/entries/rel_error/std_error/mean/uncertainty_estimator/status/有限性、总量等于质子量、CSV 值/平方和一致 |
| REF | 6 | `DDD/Phi = DDD × 1.44/N`、`sigma = DDD/Phi × rel_error`、`allowed = 0.01 × ref + 3 sigma`、N = 20000、sigma 有效 |

任何一项缺失或失败都会使比较器退出 1；失败不会覆盖原始运行，也不会自动调参数或容差。

## 6. 实现层交叉核对（只用公开输出）

hits CSV 只记录正沉积步；DDD 计分器还会收到零（电离+非电离）沉积的输运步，因此 hits 派生的
质子加权径迹长度**不承诺与 CSV 完全相等**。本候选这样核对：

1. **长度下界**：hits 质子 `Σ(w·L)` 必须 ≤ CSV `track_length_mm`（打印精度内）。实测
   - 10 MeV：`276.65399240839093` 对 CSV `276.653992408`，差 `-3.9e-10` mm；
   - 100 MeV：`1388.624873981282` 对 CSV `1388.62550122`，差 `+6.272387e-04` mm（相对 `4.5e-7`）。
     这个差额是**公开输出无法消除的观测**，不是被断言为零的通过项；其可能来源是 hits CSV
     未记录的零沉积输运步（代码路径存在），本候选不把它解释为物理或产品正确性证据。
2. **折叠区间**：记分器的步平均动能满足 `E_post ≤ E_mean ≤ E_pre`，`E_post = max(E_pre − Edep, 0)`；
   表在节点间单调，因此在窗口节点与端点取极值即可给出精确的 `DDD` 上下界：
   - 10 MeV：`[133.0564565442143, 134.35157031222855]`，CSV `133.691937374`，相对宽度 `9.64e-03`；
   - 100 MeV：`[41.54536640848074, 41.57476113137182]`，CSV `41.5611752708`，相对宽度 `7.07e-04`。
   该检查直接用 hits 的长度、权重与体积/100 因子复算，验证 `mm⁻² → cm⁻²`（×100）与体积归一化。
3. **越界长度**：两例 `out_of_range_track_length_mm = 0`。
4. **事件矩与统计**：`n_events = 20000`（零贡献事件计入分母），`entries` = 有质子 hits 的事件数
   （13828 / 13889），`rel_error` 与 `sqrt(sum_sq/value² − 1/N)` 一致（打印精度内），
   `mean = value/N`、`std_error = rel_error × value`，`uncertainty_estimator = uncorrected_event_moments_v1`。

## 7. 结果（冻结 1% + 3σ）

| 病例 | DDD (MeV/g) | DDD/Phi (MeV·cm²/g) | 参考 | 绝对差 | 相对差 | σ | 允许 | 判据 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `ref_ddd_10` | `133.691937374` | `9.625819490927999e-03` | `9.666310206360261e-03` | `-4.049071543226271e-05` | `-4.188849e-03` | `4.548226878772154e-05` | `2.3310990842676725e-04` | pass |
| `ref_ddd_100` | `41.5611752708` | `2.9924046194976e-03` | `2.9929239738930983e-03` | `-5.19354395498231e-07` | `-1.735274e-04` | `1.4040181148458543e-05` | `7.20497831843066e-05` | pass |

结论：在本冻结输入、两能点、单线程、仅电磁 `option4` 条件下，**表折积与径迹长度归一化**
通过冻结参考判据。该结论不表示 SR-NIEL 数据本身的物理评价已通过（REF-DDD-02 另行安排）。

## 8. 负例（只在副本）

`tamper.py` 生成 7 个副本反例，全部被检出，且原始候选文件 SHA 前后一致
（`tamper-results.json` 的 `originals_unchanged = true`）：

| 反例 | 被检出的检查 |
| --- | --- |
| 删除 `run_metadata.json` | `EVID-METADATA-FILE` |
| DDD 体积列 ×2 | `MOM-DDD-VOLUME-COLUMN` |
| 冻结束面积 ×100 | `REF-DDD-PHI-ABS` |
| 冻结参考值 ×1.06 | `REF-DDD-PHI-ABS` |
| identity 中质子表 SHA 改为 0 | `ID-TABLE-SHA-PROTON` |
| summary 完成事件改为 19999 | `EVID-RUN-0-COMPLETED-EVENTS`、`EVID-ACTUAL-COMPLETED-EVENT-COUNT` |
| 篡改 hits 后保留旧记录 SHA | `EVID-RECORDED-hits_t0.csv` |

反例都在 `tampered/` 下的临时副本上进行，运行结束后删除；正例原件从未被覆盖。

## 9. 复现

```bash
cd out/collab/q2-reference-ddd-v1
python -B setup_inputs.py        # 校验冻结/后端/表并生成 inputs/ 与 identity.json
python -B reference.py --check   # 独立重算参考，退出 0
python -B run_cases.py           # 两例真实运行（输入未变时复用）
python -B compare.py --update    # 261 项检查，退出 0/1
python -B tamper.py              # 7 个副本反例，退出 0/1
```

环境：Windows，后端 `out/collab/q2-backend-864bc036/G4UniversalSim.exe`，Geant4 数据目录
`D:/ProgramFiles/Geant4/share/Geant4-11.3.2/data`（`run_cases.py` 只在该目录存在时设置
`GEANT4_DATA_DIR`，不覆盖用户已有环境）。

## 10. 边界与未覆盖

- **只检验折积与归一化**：两例的通过只说明从表值到计分器输出的单位、体积、长度与参考换算一致；
  不证明 SR-NIEL 数据、截面或物理列表选择正确。
- **不是逐步折积证明**：公开 hits CSV 只有一个动能列（`kineticEnergy_MeV` 是步前能量），
  没有计分器内部的步平均动能列；本候选用单调表区间给出精确上下界，不伪造逐步重放。
- **hits 与 CSV 径迹长度的微小差额是观测**：100 MeV 病例为 `6.27e-04` mm（相对 `4.5e-7`），
  10 MeV 病例为打印精度内零差。差额未被断言为零，也未据此调整任何输出。
- **仅两个能点、单线程、仅电磁**：不覆盖强子输运、中子、NIEL 表审计、活化、非平板几何或
  不同 cut/物理列表。
- 未新增或修改任何产品字段、正式测试、基准目录、冻结文件或表数据；未提交 Git。

## 11. 文件清单

| 文件 | 说明 |
| --- | --- |
| `setup_inputs.py` | 冻结/后端/表身份校验，生成 5 个输入与 `identity.json` |
| `reference.py` | PSTAR/表独立重算与 `--check` |
| `run_cases.py` | 真实运行、复用判断、`results.json`（先写后比较） |
| `compare.py` | 六层检查与 `--update` |
| `tamper.py` | 7 个副本反例 |
| `identity.json` | 冻结/后端/Geant4/表/输入身份（SHA `11f27eb0ab5a700b…`） |
| `reference-recompute.json` | 参考重算结果（SHA `378bd91c16f3fe00…`） |
| `results.json` | 运行事实与 261 项评估（SHA `984f43ff04c4dbc8…`） |
| `tamper-results.json` | 7/7 负例结果 |
| `backend-data-check.txt` | `--check-geant4-data` 原始输出 |
| `inputs/` | materials、两个 geometry、两个 main |
| `runs/<case>/` | `run.mac`、`backend.log`、`output/` 全部原始产物 |
| `tampered/` | 反例运行期间的临时副本（结束后删除） |

候选目录完整路径：`out/collab/q2-reference-ddd-v1/`；回执：
`docs/collab/outbox/20261105-q2-reference-ddd-v1.md`。
