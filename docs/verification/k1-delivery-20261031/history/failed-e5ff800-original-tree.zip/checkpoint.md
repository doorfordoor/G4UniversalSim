# K1 首轮冻结验收失败检查点

冻结 e5ff80009975fc9d7d783eaa0865c7c894d1975b，173用例；分支 roadmap/K1-trusted-workflow 已普通推送，codex 尚未集成。正式后端 SHA400a0ffbda4bd7e21f0450d1852b4afab36ce40dac32b46b23caa6dc43682dfa。D: 独立检出未修改。

Windows全量 session33236 于10:44启动，10:56仍运行；完整 windows-run.log。已见 K1 环境探测、来源证据和 platform_paths 失败，须等终态收集全部报告，不重复启动。

真实 CI Linux41161341378、M041161341423 全部 static 失败；Linux两版本实际构建成功。四份官方ZIP已下载并逐个校验官方大小/SHA，原始报告和日志在 ci/。共同失败 doc_links（指向未提交out文件）与 platform_paths（测试硬编码盘符数据）；M0 Windows另有 i1_environment UTF8子进程样例断言失败。后续profile未执行，不是通过。

native visible/ 仅完成字段、失败初始化、环境界面观察，主窗口正常关闭exit0；验收未通过。

长路径：LongPathsEnabled=1，原EXE无longPathAware manifest；仅out独立副本合并manifest实验，短cwd190/输出268字符时 original exit1无摘要，manifest副本exit0 completed（out/collab/k1-longpath-experiment/*-r2-receipt.json）。真实存在的260字符cwd在原/manifest子进程和普通/extended路径均WinError267，不能仅manifest修复启动。原冻结EXE没有修改。

Bohr只读分析Python启动/路径；Dalton独立审查候选修复。主线程负责C++/CMake和整体验证。当前均未改冻结源码。下一步：完整报告终态、最小启动目录协议与manifest修复、明确跨平台负例/UTF8fixture/可追溯文档链接，新增真实深路径回归，独立复审后新冻结重建/全矩阵及实窗。
