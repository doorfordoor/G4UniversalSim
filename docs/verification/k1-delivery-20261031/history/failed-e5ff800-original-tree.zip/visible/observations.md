# K1 e5ff800 原生窗口观察：未通过

2026-10-31，实际 MainWindow，Windows @oai/sky。identity.json 绑定 GUI 源码、e5ff800 与正式后端 SHA；launcher.json 实际退出 0。截图已由图像工具实际查看，窗口关闭后 ID 不再复用。

1. 初始四层验证均未观测；字段校验后仅字段层通过。
2. 点击检查初始化：后端完成初始化、几何检查和 mesh，但最终配置快照写入失败。GUI 显示初始化失败、退出 1，没有把进度/mesh 当成成功；执行/物理层仍未观测。
3. output_failure_stage=effective_config_open；排他临时文件路径包含长目录与时间/序号后缀。原始 run_summary.txt 与 actions.jsonl 保留。
4. 环境对话框实际显示后端就绪、x86_64、Geant4 11.3.2、MSVC、必需数据集完整；摘要可读，JSON 默认折叠。路径列略去过长部分，完整信息在摘要可见。
5. Escape 关闭对话框、Alt+F4 正常关闭应用。未完成运行、导出、搬移加载、修改后重新验证、取消/恢复的正式实窗验收。

文件 01-initial.jpg、02-fields.jpg、03-initialization.jpg、04-environment*.jpg 是实际窗口证据。本轮不能计作 K1 原生验收通过。
