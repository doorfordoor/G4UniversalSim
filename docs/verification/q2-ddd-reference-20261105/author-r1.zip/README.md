# REF-DDD-01：两个冻结质子表折积病例（候选证据包，观测限制修订 r1）

本候选响应 `docs/collab/inbox/20261105-q2-reference-ddd-v1.md` 与
`docs/collab/decisions/20261105-q2-ddd-reference-freeze-v1.md`（同名 JSON），用冻结后端
`864bc036` 对 10 MeV 与 100 MeV 质子各跑 20000 事件，检验**敏感片 DDD 的质子 NIEL 表折积与
径迹长度归一化**，并与冻结解析参考比较。

**本修订（observability r1）只修验证器与报告**：按独审
（`docs/collab/reviews/20261105-q2-ddd-reference-review-r1.md`）撤回不成立的
`[pre − Edep, pre]` 折积区间与 5% 宽度门槛；没有重跑 Geant4，没有改输入、原始输出、冻结、
NIEL 表、产品、正式测试/基准或容差；两例原始运行的参考比较仍通过。

**机器判定为 `limited`，不是 `pass`**：两例物理参考点通过、0 项真实失败，但公开输出无法证明
完整径迹长度对账与逐步折积（共 6 项观测限制）。本候选不声称“完整折积验证通过”，也不声称
SR-NIEL 数据本身获得物理验证（REF-DDD-02 另案）。

## 1. 冻结与身份

| 项 | 值 |
| --- | --- |
| 冻结文件 | `docs/collab/decisions/20261105-q2-ddd-reference-freeze-v1.json` |
| 冻结 SHA-256 | `65877c33ad74111f5c567d060f495eccea074b378b3c5bd0b9bdd4f6e40b6a7c` |
| schema | `q2_reference_ddd_freeze_v1` |
| 几何来源冻结 | `20261105-q2-dose-reference-freeze-v1.json`，SHA-256 `a2a799e90bd941b4969beab62be408013420dfbd684c4e8e52f07775308e498d` |
| 后端 build | `864bc036d6d7752475e52db4efd2b950cabfcc3d` |
| 后端可执行 | `out/collab/q2-backend-864bc036/G4UniversalSim.exe`，SHA-256 `f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f`（2 786 304 B） |
| C++ 源码指纹 | `e7de615d4e342114104f970688a7ea5f9789f7b70240b2562a388a50a45704e7` |
| Geant4 | 11.3.2（`G4VERSION_NUMBER=1132`），`--check-geant4-data` 退出 0、`required_complete=true` |

**NIEL 表**（`[scoring.displacement]/proton`）：

| 表 | 行数 | 能量域 (MeV) | SHA-256 |
| --- | --- | --- | --- |
| `scenarios/semiconductor/niel/si_proton.csv` | 146 | `[1e-6, 1e4]` | `6c21e35aab18495d4bb2597a76be60c7c35ef0df963224e0108c77c2e4c208d5` |
| `scenarios/semiconductor/niel/si_neutron.csv` | 640 | `[1.025e-10, 19.95]` | `a2ad28a9fcce3500fca363946e09e19125d084f1b596eff76662b272c242034f` |

中子表只作为冻结身份登记（本候选不使用中子）；两表都在 `setup_inputs.py` 中被重新哈希并与
冻结记录比较。**未写入或修改任何表数据**。

## 2. 几何、源与输入

两例共享几何（来自 Dose 冻结，SHA 锁定）：

- world：3000 mm 立方 `G4_Galactic`；
- `Block`：40 × 40 × `block_z` mm `G4_Si`，中心 z = `block_center_z`（前表面 z = 0）；
- `Slab`：10 × 10 × `slab` mm `G4_Si`，位于 Block 局部中心 `(0,0,0)`，`sensitive = true`。

| 病例 | E (MeV) | buildup (mm) | slab (mm) | block_z (mm) | 片中点深度 (mm) | seed | 片质量 (kg) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `ref_ddd_10` | 10 | 0.05 | 0.02 | 0.12 | 0.06 | 20261113 | 4.66e-06 |
| `ref_ddd_100` | 100 | 0.6 | 0.1 | 1.3 | 0.65 | 20261114 | 2.33e-05 |

源：质子、平面方束 `halfx = 6 mm`（**只写 halfx，不写 halfy**），中心 `(0,0,-1)` mm、方向
`(0,0,1)`，束面积 144 mm² = 1.44 cm²。物理：仅电磁 `option4`，无 `reference`；`default_cut = 10 um`；
单线程；各 20000 事件。计分：`hits = true`、`displacement = true`、`dose = false`、
`event_edep = false`、`auto_create_default_scorers = true`。

输入 SHA-256（写入 `identity.json` 并由比较器复核）：

| 文件 | SHA-256 |
| --- | --- |
| `inputs/materials.ini` | `fb05cfd6f448f12805a15c3b423cb16889fc34e64bbbc1a1a7bce45a6d0ef858` |
| `inputs/geometry_ref_ddd_10.ini` | `68812cef753f32c3171d4180a90860db57fad79cc474e01d39c9c6862ca26964` |
| `inputs/geometry_ref_ddd_100.ini` | `33005980bcc481bf7cc3bbb2b2540c321ae18636b92db4f5dbd569e05ff0bcb7` |
| `inputs/main_ref_ddd_10.ini` | `b6d541182c0bd1ce0461dc01eab64398b06bd8a606afd8fdbcedf2c76cca11a8` |
| `inputs/main_ref_ddd_100.ini` | `565471a146e81acd0531af3d5bfbabc10fefe017e81acaee35bb9b7180e2f357` |

DOS 刻度与片位置：Block 厚 `2b + slab`，中心在 `b + slab/2`；片在 Block 局部中心，因此片中点
深度 = `block_center_z`（0.06 / 0.65 mm），与冻结 `reference_mid_energy` 的 PSTAR 中点一致。
比较器逐项校验了 Block 前表面 z = 0、片中心、片中点深度、源在块外、束面积等。

## 3. 独立参考重算

`reference.py` 只读 `si_proton.csv` 原始字节（跳过注释、校验表头/SHA/行数/能量域/严格递增/非负），
在冻结的 `reference_mid_energy_MeV` 处做 **log-log 插值**，并核对冻结给的两个插值节点：

| 病例 | 重算 NIEL (MeV·cm²/g) | 冻结值 | 相对差 |
| --- | --- | --- | --- |
| `ref_ddd_10` | `0.009666310206360254` | `0.009666310206360261` | `-7.178e-16` |
| `ref_ddd_100` | `0.0029929239738930983` | 同值 | `0` |

`reference-recompute.json` 记录全部 11 项检查。**注意调用方式**：默认运行
`python -B reference.py` 即执行 11 项校验；脚本**没有** `--check` 参数（传 `--check` 返回 2，
首候选 README/回执的复演命令即因写错而被独审记录）。

参考是**表折积**参考：`DDD/Phi = NIEL(E_mid)`，其中 `E_mid` 由 Dose 冻结的 PSTAR 中点能量给出。
`DDD/Phi` 的换算为 `DDD × 1.44 cm² / N`。线性插值会比冻结值偏约 9e-8，本候选不使用。

## 4. 真实运行（本次修订未重跑）

两例都是真实 Geant4 运行，不是只解析配置、不是相空间导出。observability r1 **没有运行任何
后端**，直接复用原始两例输出：

| 病例 | 后端退出码 | 完成事件 | 用时 (s) | 本次修订 |
| --- | --- | --- | --- | --- |
| `ref_ddd_10` | 0 | 20000 | 1.775 | 复用原始输出，未重跑 |
| `ref_ddd_100` | 0 | 20000 | 3.296 | 复用原始输出，未重跑 |

`run_cases.py` 先写 `results.json` 再调用比较器，因此比较器缺陷不会抹掉真实运行事实。复用判断
比较冻结 SHA、后端 SHA、输入 SHA、每个产物的 SHA 与大小和完成事件数；输入未变时不重跑（`--force` 才重跑）。

产物（一例一份，均登记在 `results.json` 与 `run_metadata.json`）：

| 病例 | 文件 | 字节 | SHA-256（前 16 位） |
| --- | --- | --- | --- |
| 10 | `run_summary.txt` | 12118 | `aef1dffcb2b832fa` |
| 10 | `run_metadata.json` | 17537 | `1821c40c3ecf9ded` |
| 10 | `hits_t0.csv` | 2 980 120 | `960125abc8627aaf` |
| 10 | `displacement_volume_summary_t0.csv` | 316 | `606c66ddd03d51be` |
| 10 | `scorer_statistics.csv` | 674 | `dc3d7d1ec65c1ea1` |
| 100 | `run_summary.txt` | 12163 | `2ae05e51c97879c1` |
| 100 | `run_metadata.json` | 17575 | `a8a0fa1f40830f75` |
| 100 | `hits_t0.csv` | 16 674 600 | `d6d835a37b9c8044` |
| 100 | `displacement_volume_summary_t0.csv` | 318 | `6dbecc3d12e69fef` |
| 100 | `scorer_statistics.csv` | 680 | `54ea3a3fc24073d7` |

## 5. 机器判定：pass / fail / limited 分开

`compare.py` 共 **263 项检查：257 pass / 0 fail / 6 limited**；整体判定为 **`limited`**。
冻结清单要求逐例报告通过/失败/限制，因此整体不能写 `pass`。

| 层 | 项数 | 内容 |
| --- | --- | --- |
| ID | 19 | 后端 SHA/build/源码指纹、Geant4 版本、数据检查、冻结 SHA/schema、几何来源冻结 SHA、两张 NIEL 表 SHA/行数/能量域、输入 SHA |
| IN | 64 | 仅电磁且无 reference、cut、计分开关、线程/种子、源粒子/能量/形状/无 halfy/halfx/中心/方向、NIEL 表路径与 SHA、几何模板/世界材料/Block/Slab/敏感/片中点深度/源在块外/束面积、输入身份 |
| EVID | 86 | summary 与 metadata 必需字段、后端退出码、完成事件 = 20000、计划事件、seed、能量、metadata runs、hashed 产物、记录产物 SHA+大小、输出目录、日志、输入 SHA |
| MOM | 42 | hits 表头、质子行、volume、正步长/权重、有限性、事件数约束、DDD 表头/行/体积列/长度下界/越界长度 0/事件数、长度归一化、公开事件矩；其中 6 项为观测限制 |
| STAT | 46 | 两行统计的 unit/estimator/n_events/entries/rel_error/std_error/mean/uncertainty_estimator/status/有限性、总量等于质子量、CSV 值/平方和一致 |
| REF | 6 | `DDD/Phi = DDD × 1.44/N`、`sigma = DDD/Phi × rel_error`、`allowed = 0.01 × ref + 3 sigma`、N = 20000、sigma 有效 |

6 项 `limited`（每例 3 项，均不参与 pass）：

| 检查 id | 含义 |
| --- | --- |
| `MOM-<case>-TRACK-LENGTH-FULL` | 精确径迹长度对账不可恢复：hits 只记录正沉积步，DDD 计分器还会收到零沉积输运步；可见长度只是下界 |
| `MOM-<case>-VISIBLE-EVENTS-SUBSET` | 可见事件集合只是“贡献 DDD 的事件”的下界，不是完整集合 |
| `MOM-<case>-FOLDING-STEPWISE` | 逐步折积需要内部步平均动能，公开列没有；旧区间已撤回，不发明替代区间 |

退出码：`compare.py` 维持“非全 pass 即非零”的既有约定，因此 `limited` 也返回 1。这是**比较器
判定**，不是后端失败；两例后端真实退出码都是 0，已在 `results.json` 与 receipt 中分列。

## 6. 可见路径报告（hits 只是下界）

| 病例 | hits 质子加权长度 (mm) | scorer `track_length_mm` (mm) | gap = scorer − hits (mm) | gap 相对值 | hits 行 / 可见事件 |
| --- | --- | --- | --- | --- | --- |
| `ref_ddd_10` | 276.65399240839093 | 276.653992408 | -3.909121915e-10（打印精度内） | -1.413e-12 | 13828 / 13828 |
| `ref_ddd_100` | 1388.624873981282 | 1388.62550122 | 6.272387179e-04 | 4.516975364e-07 | 17964 / 13889 |

独审用 C 盘独立输出把 100 MeV 的 gap 复算为 **0.0006272387224726117 mm**；用公开 CSV 的 12 位
打印值重算得到 `6.272387179e-04` mm（相对 `4.517e-7`），两者只在打印末位不同，不改变结论。
差额与零沉积步计分但不入普通 hits 的既有语义一致；本候选**不**把差额断言为零，也**不**据此
声称产品缺陷或物理正确性。可见事件数也不是一般的 DDD 贡献事件全集：

- 10 MeV：13828 个可见事件，恰等于 hits 行数（每事件一行）；
- 100 MeV：17964 行、13889 个可见事件（同一事件多行），N 仍为 20000（零贡献事件保留在分母）。

## 7. 已撤回的折积区间（不得再用于验证）

首候选曾声称步平均动能必在 `[pre − Edep, pre]`，并据此给出 DDD 精确上下界（以及 5% 宽度门槛）。
**该推导不成立**：局部沉积 `Edep` 不包含显式次级带走的动能，不能代替步前后动能差。独审给出的
能量账本合成反例（**不是实测步**，见 `counterexample_bracket.py` 生成的
`evidence/withdrawn-bracket-counterexample.json`）：

| 量 | 值 (MeV) |
| --- | --- |
| pre 动能 | 100 |
| post 动能 | 99.899 |
| 局部 Edep | 0.001 |
| 次级携能 | 0.100 |
| 前后差 = Edep + 次级 | 0.101 |
| 真实步平均 (pre+post)/2 | **99.9495** |
| 旧声称区间 `[pre − Edep, pre]` | `[99.999, 100]` |

真实步平均落在旧区间之外，且 `pre − Edep` 不存在任何上界关系。本候选**撤回并删除**
`folding_bracket`/`niel_window_bounds` 与 `MOM-DDD-FOLDING-BRACKET`/`MOM-BRACKET-WIDTH`，
不建立替代区间，只把不可恢复项登记为 `limited`。旧证据归档见
`docs/verification/q2-ddd-review-20261105/first-counterexample/README.md`
（含 author-v1.zip、independent-v1.zip、首轮 counterexample、失败脚本与 archives-manifest；
未被本修订覆盖）。

## 8. 冻结参考比较（两例仍通过）

| 病例 | DDD (MeV/g) | DDD/Phi (MeV·cm²/g) | 参考 | 绝对差 | 相对差 | σ | 允许 | 判据 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `ref_ddd_10` | `133.691937374` | `9.625819490927999e-03` | `9.666310206360261e-03` | `-4.049071543226271e-05` | `-4.188849e-03` | `4.548226878772154e-05` | `2.3310990842676725e-04` | pass |
| `ref_ddd_100` | `41.5611752708` | `2.9924046194976e-03` | `2.9929239738930983e-03` | `-5.19354395498231e-07` | `-1.735274e-04` | `1.4040181148458543e-05` | `7.20497831843066e-05` | pass |

结论限定：在冻结输入、两能点、单线程、仅电磁 `option4` 条件下，**两个冻结参考点通过 1% + 3σ**。
这不等于完整逐步折积验证通过（见 §7），也不表示 SR-NIEL 数据本身获得物理验证。

## 9. 负例（只在副本，7/7 真实 fail）

`tamper.py` 生成 7 个副本反例。修订后的判定要求每个预期检查以 **`status = fail`** 命中，
不能把 baseline 的 `limited` 当作反例检出；同时要求 baseline 有 0 项真实失败、原始候选文件
SHA 前后一致。`tamper-results.json`（schema `g4usim_q2_ref_ddd_tamper_v2`）记录 baseline 计数
（263 / 257 / 0 / 6）、每个反例命中的检查、`originals_unchanged = true`、`status = pass`。

| 反例 | 被检出的检查（真实 fail） |
| --- | --- |
| 删除 `run_metadata.json` | `EVID-METADATA-FILE` |
| DDD 体积列 ×2 | `MOM-DDD-VOLUME-COLUMN` |
| 冻结束面积 ×100 | `REF-DDD-PHI-ABS` |
| 冻结参考值 ×1.06 | `REF-DDD-PHI-ABS` |
| identity 中质子表 SHA 改为 0 | `ID-TABLE-SHA-PROTON` |
| summary 完成事件改为 19999 | `EVID-RUN-0-COMPLETED-EVENTS`、`EVID-ACTUAL-COMPLETED-EVENT-COUNT` |
| 篡改 hits 后保留旧记录 SHA | `EVID-RECORDED-hits_t0.csv` |

反例都在 `tampered/` 下的临时副本上进行，运行结束后删除；正例原件从未被覆盖。

## 10. 复现（不重跑后端）

```bash
cd out/collab/q2-reference-ddd-v1
python -B setup_inputs.py            # 校验冻结/后端/表并生成 inputs/ 与 identity.json
python -B reference.py               # 11 项参考校验；没有 --check 参数（传 --check 返回 2）
python -B run_cases.py               # 输入未变时复用；reused=true 时不重跑后端
python -B compare.py --update        # 263 项：257 pass / 0 fail / 6 limited，退出 1
python -B tamper.py                  # base=limited，7/7 反例真实 fail，退出 0
python -B counterexample_bracket.py  # 合成能量账本反例，退出 0
```

环境：Windows，后端 `out/collab/q2-backend-864bc036/G4UniversalSim.exe`，Geant4 数据目录
`D:/ProgramFiles/Geant4/share/Geant4-11.3.2/data`（`run_cases.py` 只在该目录存在时设置
`GEANT4_DATA_DIR`，不覆盖用户已有环境）。本次修订只重跑了比较器/反例/合成账本脚本，未运行 Geant4。

## 11. 边界与限制

- **整体判定 limited**：0 项真实失败，但 6 项观测限制存在，不能写 `pass`，不能声称完整折积
  验证通过。两个冻结参考点仍通过。
- **不是逐步折积证明**：公开 hits CSV 只有一个动能列（`kineticEnergy_MeV` 是步前能量），没有
  计分器内部的步平均动能列；旧区间已撤回，本候选不发明替代区间。
- **可见长度只是下界**：hits 不含零沉积步，100 MeV 可见 gap 为 `6.27e-04` mm（相对 `4.5e-7`），
  10 MeV 在打印精度内；差额作为观测保留，不据此调整输出或容差。
- **仅两个能点、单线程、仅电磁**：不覆盖强子输运、中子、NIEL 表审计、活化、非平板几何或
  不同 cut/物理列表。
- 未新增或修改任何产品字段、正式测试、基准目录、冻结文件或表数据；未提交 Git。

## 12. 文件清单

| 文件 | 说明 | SHA-256（前 16 位） |
| --- | --- | --- |
| `setup_inputs.py` | 冻结/后端/表身份校验，生成 5 个输入与 `identity.json` | `—` |
| `reference.py` | PSTAR/表独立重算（默认运行即校验） | `—` |
| `run_cases.py` | 真实运行、复用判断、`results.json`（先写后比较） | `—` |
| `compare.py` | 六层检查、pass/fail/limited 判定与 `--update` | `ac28944a83c7bd6a` |
| `tamper.py` | 7 个副本反例（要求真实 fail） | `cf85fcca73c42a4c` |
| `counterexample_bracket.py` | 合成能量账本反例（撤回旧区间） | `d7096a3e737bba8e` |
| `identity.json` | 冻结/后端/Geant4/表/输入身份 | `11f27eb0ab5a700b` |
| `reference-recompute.json` | 参考重算结果 | `3c4ce05ccb6ffa05` |
| `results.json` | 运行事实与 263 项评估 | `667504b609509aa0` |
| `tamper-results.json` | base=limited，7/7 反例真实 fail | `a6a87db76443753d` |
| `evidence/withdrawn-bracket-counterexample.json` | 合成账本反例记录 | `cb1bd717d07796f1` |
| `backend-data-check.txt` | `--check-geant4-data` 原始输出 | `—` |
| `inputs/` | materials、两个 geometry、两个 main | 见 §2 |
| `runs/<case>/` | `run.mac`、`backend.log`、`output/` 全部原始产物 | 见 §4 |
| `patches/observability_r1*.py` | 本次有限修订的一次性补丁（只改候选内 compare/tamper） | `—` |
| `tampered/` | 反例运行期间的临时副本（结束后删除） | `—` |

候选目录完整路径：`out/collab/q2-reference-ddd-v1/`；回执：
`docs/collab/outbox/20261105-q2-reference-ddd-v1.md`。

## 13. 历史与撤回记录（不覆盖旧证据）

- **首候选**（原 turn64 交付）：两例后端各 20000 事件、exit 0；两点参考 `pass`；
  比较器 **261 项 pass**（ID 19 / IN 64 / EVID 86 / MOM 40 / STAT 46 / REF 6）；
  7 个副本反例检出。该历史保留在归档
  `docs/verification/q2-ddd-review-20261105/first-counterexample/`（author-v1.zip /
  independent-v1.zip / logs / manifest），本修订不覆盖、不改写其原始身份。
- **独审拒绝**：首候选把 hits 当完整计分路径、并用 `[pre − Edep, pre]` 区间宣称精确折积，
  均不成立（见 `reviews/20261105-q2-ddd-reference-review-r1.md`）。
- **本修订撤回项**：原 261 项中有 4 项被撤回——每例的 `MOM-DDD-FOLDING-BRACKET` 与
  `MOM-BRACKET-WIDTH`（2 例 × 2 项），改记 6 项 `limited`（每例 3 项，见 §5）；
  其余 **257 项保留并通过**；原 2 项长度下界检查保留且 pass。总检查数 261 → 263。
- **未撤回的结论**：两例运行完成事实、身份/完成/表 SHA、有效体积、公开事件矩与统计、
  两个冻结参考点比较仍然有效。
