"""One-off patch for REF-DDD-01 observability r1 (author-side, no product change).

Rewrites only `compare.py` in this candidate:
  1. `check()` gains an explicit `limited` status and a `limited()` helper.
  2. The withdrawn [pre-Edep, pre] folding bracket and the arbitrary 5% width
     gate are removed; they were rejected because secondaries carry kinetic
     energy that local Edep does not account for.
  3. `verify_implementation()` reports the visible hits length lower bound,
     the scorer length, the unlogged gap, and marks full length reconciliation
     and stepwise folding as `limited`.
  4. `evaluate()` separates pass / fail / limited counts and derives an overall
     verdict that can never be `pass` while a limitation remains.
  5. `main()` prints the three counts and explains a non-zero exit code for a
     `limited` verdict (comparison verdict, not a backend failure).
"""

from pathlib import Path

PATH = Path(__file__).resolve().parent.parent / "compare.py"
text = PATH.read_text(encoding="utf-8")


def replace_once(old: str, new: str) -> None:
    global text
    if text.count(old) != 1:
        raise SystemExit(f"anchor not unique: {old[:60]!r} count={text.count(old)}")
    text = text.replace(old, new)


# 1. check() with explicit status and the limited() helper.
replace_once(
    '''def check(checks: list[dict], cid: str, ok: bool, detail: str) -> bool:
    checks.append({"id": cid, "status": "pass" if ok else "fail", "detail": detail})
    return bool(ok)
''',
    '''def check(checks: list[dict], cid: str, ok: bool, detail: str, *,
          status: str | None = None) -> bool:
    """Record one machine check.

    ``status`` derives from ``ok`` unless the caller passes it explicitly.  A
    check recorded as ``limited`` means the public evidence cannot decide the
    claim: it is not a pass and it does not count as a detected failure.
    """
    if status is None:
        status = "pass" if ok else "fail"
    if status not in ("pass", "fail", "limited"):
        raise ValueError(f"unknown check status {status!r}")
    checks.append({"id": cid, "status": status, "detail": detail})
    return status == "pass"


def limited(checks: list[dict], cid: str, detail: str) -> None:
    """Record an observational limitation (neither pass nor failure)."""
    check(checks, cid, False, detail, status="limited")
''',
)

# 2. Replace the withdrawn folding proof and verify_implementation.
start = text.index("def niel_window_bounds(")
end = text.index("def verify_reference(")
new_block = '''def verify_implementation(ddd: dict, hits: dict, checks: list[dict]) -> dict:
    """Reconcile the public DDD summary with the public hits file.

    The hits CSV records only steps with positive local deposition.  The DDD
    scorer also receives zero-deposit steps (``SensitiveDetector`` calls the
    displacement scorer before returning without writing a hit), so the visible
    proton length is a *lower bound* for the scored length.  The exact gap and
    the stepwise fold (which needs the internal pre/post-step mean kinetic
    energy) cannot be reconstructed from public columns.  Those claims are
    recorded as ``limited``; they are never reported as pass.

    The withdrawn ``[pre - Edep, pre]`` interval is not a bound on the step mean
    energy: local Edep does not include the kinetic energy carried by explicit
    secondaries.  A synthetic ledger counterexample is kept in
    ``counterexample_bracket.py`` output.
    """
    volume_mm3 = ddd["volume_mm3"]
    hits_length = hits["weighted_length_mm"]
    scorer_length = ddd["track_length_mm"]
    gap = scorer_length - hits_length
    gap_relative = gap / scorer_length if scorer_length > 0.0 else float("nan")
    track_fluence_cm2 = hits_length * MM2_PER_CM2 / volume_mm3
    check(checks, "MOM-TRACK-FLUENCE-FINITE",
          math.isfinite(track_fluence_cm2) and track_fluence_cm2 > 0.0,
          f"track_fluence_cm2={track_fluence_cm2} "
          f"from hits weighted length {hits_length} mm / {volume_mm3} mm3")
    total_from_events = sum(hits["event_lengths_mm"].values())
    check(checks, "MOM-EVENT-LENGTH-SUM",
          close_enough(hits_length, total_from_events)[0],
          f"rows={hits_length} from_events={total_from_events}")
    tolerance = half_width(scorer_length) + 1e-12 * scorer_length
    check(checks, "MOM-DDD-TRACK-LENGTH-LOWER-BOUND",
          hits_length <= scorer_length + tolerance,
          f"hits={hits_length} scorer={scorer_length} unlogged_gap_mm={gap} "
          f"gap_relative={gap_relative:.6e} tolerance={tolerance:.3e}")
    limited(checks, "MOM-DDD-TRACK-LENGTH-FULL",
            "exact length reconciliation is not recoverable from public outputs: the hits CSV "
            "omits zero-deposit steps that the DDD scorer still receives. "
            f"hits_weighted_length_mm={hits_length} scorer_track_length_mm={scorer_length} "
            f"unlogged_gap_mm={gap} unlogged_gap_relative={gap_relative:.6e}. "
            "The visible set is a lower bound, not the complete scored set.")
    limited(checks, "MOM-VISIBLE-EVENTS-SUBSET",
            f"visible proton-hit events={hits['events_with_hits']} (of n_events={hits['n_events']}) "
            "are only a lower bound for the events that contributed DDD; there is no public "
            "evidence of the complete contributing event set.")
    limited(checks, "MOM-DDD-FOLDING-STEPWISE",
            "stepwise folding is not recoverable: the scorer folds the NIEL table at the internal "
            "pre/post-step mean kinetic energy, which is not a public column. The withdrawn "
            "[pre-Edep, pre] interval is invalid because secondaries carry kinetic energy "
            "(synthetic counterexample: counterexample_bracket.py -> "
            "evidence/withdrawn-bracket-counterexample.json). No substitute interval is asserted.")
    return {
        "hits_proton_weighted_length_mm": hits_length,
        "scorer_track_length_mm": scorer_length,
        "unlogged_gap_mm": gap,
        "unlogged_gap_relative": gap_relative,
        "track_fluence_cm2_from_hits": track_fluence_cm2,
    }


'''
text = text[:start] + new_block + text[end:]

# 3. evaluate(): three-state verdict and diagnostics.
replace_once(
    '''        if ddd:
            verify_implementation(ddd, hits, freeze, freeze_case, niel_rows, checks)
''',
    '''        if ddd:
            diagnostics[name].update(verify_implementation(ddd, hits, checks))
''',
)
replace_once(
    '''    failed = [item["id"] for item in checks if item["status"] != "pass"]
    return {
        "schema": "g4usim_q2_ref_ddd_evaluation_v1",
        "checks_total": len(checks),
        "checks_failed": len(failed),
        "failed_ids": failed,
        "status": "pass" if not failed else "fail",
        "checks": checks,
        "cases": cases,
        "diagnostics": diagnostics,
    }
''',
    '''    failed = [item["id"] for item in checks if item["status"] == "fail"]
    limited_ids = [item["id"] for item in checks if item["status"] == "limited"]
    passed = [item["id"] for item in checks if item["status"] == "pass"]
    if failed:
        status = "fail"
    elif limited_ids:
        # The frozen requirements distinguish pass, fail and limited; an
        # observation gap can never be promoted to an overall pass.
        status = "limited"
    else:
        status = "pass"
    return {
        "schema": "g4usim_q2_ref_ddd_evaluation_v1",
        "checks_total": len(checks),
        "checks_pass": len(passed),
        "checks_failed": len(failed),
        "checks_limited": len(limited_ids),
        "failed_ids": failed,
        "limited_ids": limited_ids,
        "status": status,
        "checks": checks,
        "cases": cases,
        "diagnostics": diagnostics,
    }
''',
)

# 4. main(): print three counts; explain the non-zero comparison verdict.
replace_once(
    '''    print(json.dumps({key: evaluation[key] for key in
                      ("status", "checks_total", "checks_failed", "failed_ids")},
                     indent=2, ensure_ascii=False))
''',
    '''    print(json.dumps({key: evaluation[key] for key in
                      ("status", "checks_total", "checks_pass", "checks_failed",
                       "checks_limited", "failed_ids", "limited_ids")},
                     indent=2, ensure_ascii=False))
''',
)
replace_once(
    '''    return 0 if evaluation["status"] == "pass" else 1
''',
    '''    if evaluation["status"] == "limited":
        print("verdict=limited: no check failed, but public outputs cannot prove exact length "
              "reconciliation or stepwise folding; exit 1 is the comparison verdict, not a "
              "backend failure (both runs exited 0).")
    return 0 if evaluation["status"] == "pass" else 1
''',
)

# 5. Module docstring: state the limited semantics up front.
replace_once(
    '''The comparison tests table folding and track-length normalization only.  It
does not validate the SR-NIEL physical evaluation: the public hits CSV exposes
one kinetic-energy column and not the internal pre/post-step mean energy used
by the scorer, so full step-by-step recovery is not claimed here.
''',
    '''The comparison tests the two frozen reference points, the run/identity/table
evidence, the valid slab volume, the public event moments and the visible hits
length lower bound.  It does not validate the SR-NIEL physical evaluation: the
public hits CSV exposes only the pre-step kinetic energy, not the internal
pre/post-step mean used by the scorer, and it omits zero-deposit steps that the
scorer still receives.  Full length reconciliation and stepwise folding are
therefore reported as ``limited``; the overall verdict stays ``limited`` while
any such limitation remains.
''',
)

PATH.write_text(text, encoding="utf-8")
print("compare.py patched:", PATH)
