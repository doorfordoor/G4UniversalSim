"""Fix tamper matching: an id may appear once per case, so match the fail set."""

from pathlib import Path

PATH = Path(__file__).resolve().parent.parent / "tamper.py"
text = PATH.read_text(encoding="utf-8")


def replace_once(old: str, new: str) -> None:
    global text
    if text.count(old) != 1:
        raise SystemExit(f"anchor not unique: {old[:60]!r} count={text.count(old)}")
    text = text.replace(old, new)


replace_once(
    '''        statuses = {entry["id"]: entry["status"] for entry in evaluation["checks"]}
        hit = [expected for expected in item["expect"] if statuses.get(expected) == "fail"]
        # A baseline `limited` item must never be accepted as negative-control
        # detection: only an actual fail counts.
        not_real_fail = [expected for expected in item["expect"]
                         if expected in statuses and statuses[expected] != "fail"]
''',
    '''        checks = evaluation["checks"]
        failed_statuses = {entry["id"] for entry in checks if entry["status"] == "fail"}
        present_statuses = {entry["id"]: entry["status"] for entry in checks}
        hit = [expected for expected in item["expect"] if expected in failed_statuses]
        # A `limited` entry must never be accepted as negative-control
        # detection: only an actual fail counts.  An id can appear once per case,
        # so match the set of failed ids rather than one dictionary value.
        not_real_fail = [expected for expected in item["expect"]
                         if expected in present_statuses
                         and expected not in failed_statuses]
''',
)
PATH.write_text(text, encoding="utf-8")
print("tamper.py patched (fail-set matching):", PATH)
