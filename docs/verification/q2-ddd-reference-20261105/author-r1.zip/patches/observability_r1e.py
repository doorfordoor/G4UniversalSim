"""Patch tamper.py for the r1 three-state comparator.

Changes:
  * the baseline must be `limited` with zero real failures (the observation gap
    is not a failure and must not be sold as a pass);
  * every expected negative-control check must be a *real* `fail`, never a
    baseline `limited` item;
  * the payload records the baseline counts and the limited ids so a reader can
    see which limitations existed before tampering.
"""

from pathlib import Path

PATH = Path(__file__).resolve().parent.parent / "tamper.py"
text = PATH.read_text(encoding="utf-8")


def replace_once(old: str, new: str) -> None:
    global text
    if text.count(old) != 1:
        raise SystemExit(f"anchor not unique: {old[:60]!r} count={text.count(old)}")
    text = text.replace(old, new)


replace_once(
    '''def main() -> int:
    before = snapshot()
    outcomes: list[dict] = []
    failed_expectations: list[str] = []
''',
    '''def main() -> int:
    before = snapshot()
    originals = json.loads((BASE / "results.json").read_text(encoding="utf-8"))
    identity = json.loads((BASE / "identity.json").read_text(encoding="utf-8"))
    freeze = json.loads(compare.FREEZE.read_text(encoding="utf-8"))
    baseline = compare.evaluate(originals, freeze, identity)
    baseline_ok = (baseline["status"] == "limited" and baseline["checks_failed"] == 0
                   and baseline["checks_limited"] > 0)
    outcomes: list[dict] = []
    failed_expectations: list[str] = []
''',
)
replace_once(
    '''        evaluation = compare.evaluate(item["results"], item["freeze"], item["identity"])
        failed_ids = evaluation["failed_ids"]
        hit = [expected for expected in item["expect"] if expected in failed_ids]
        passed = bool(hit)
        if not passed:
            failed_expectations.append(item["name"])
        outcomes.append({
            "name": item["name"],
            "expected_checks": item["expect"],
            "matched_checks": hit,
            "evaluation_status": evaluation["status"],
            "checks_failed": evaluation["checks_failed"],
            "failed_ids": failed_ids,
            "status": "pass" if passed else "fail",
        })
        print(f"{item['name']}: expected={item['expect']} matched={hit} "
              f"evaluation={evaluation['status']} failed={evaluation['checks_failed']}")
''',
    '''        evaluation = compare.evaluate(item["results"], item["freeze"], item["identity"])
        statuses = {entry["id"]: entry["status"] for entry in evaluation["checks"]}
        hit = [expected for expected in item["expect"] if statuses.get(expected) == "fail"]
        # A baseline `limited` item must never be accepted as negative-control
        # detection: only an actual fail counts.
        not_real_fail = [expected for expected in item["expect"]
                         if expected in statuses and statuses[expected] != "fail"]
        passed = bool(hit) and not not_real_fail
        if not passed:
            failed_expectations.append(item["name"])
        outcomes.append({
            "name": item["name"],
            "expected_checks": item["expect"],
            "matched_checks": hit,
            "expected_that_were_not_real_fail": not_real_fail,
            "evaluation_status": evaluation["status"],
            "checks_pass": evaluation["checks_pass"],
            "checks_failed": evaluation["checks_failed"],
            "checks_limited": evaluation["checks_limited"],
            "failed_ids": evaluation["failed_ids"],
            "limited_ids": evaluation["limited_ids"],
            "status": "pass" if passed else "fail",
        })
        print(f"{item['name']}: expected={item['expect']} matched={hit} "
              f"evaluation={evaluation['status']} failed={evaluation['checks_failed']} "
              f"limited={evaluation['checks_limited']}")
''',
)
replace_once(
    '''    payload = {
        "schema": "g4usim_q2_ref_ddd_tamper_v1",
        "originals_unchanged": originals_unchanged,
        "cases": outcomes,
        "status": "pass" if not failed_expectations and originals_unchanged else "fail",
        "failed_expectations": failed_expectations,
    }
''',
    '''    payload = {
        "schema": "g4usim_q2_ref_ddd_tamper_v2",
        "originals_unchanged": originals_unchanged,
        "baseline": {
            "status": baseline["status"],
            "checks_total": baseline["checks_total"],
            "checks_pass": baseline["checks_pass"],
            "checks_failed": baseline["checks_failed"],
            "checks_limited": baseline["checks_limited"],
            "limited_ids": baseline["limited_ids"],
            "zero_real_failures": baseline["checks_failed"] == 0,
            "expected_limited_baseline": baseline_ok,
        },
        "cases": outcomes,
        "status": ("pass" if baseline_ok and not failed_expectations
                   and originals_unchanged else "fail"),
        "failed_expectations": failed_expectations,
    }
''',
)
PATH.write_text(text, encoding="utf-8")
print("tamper.py patched:", PATH)
