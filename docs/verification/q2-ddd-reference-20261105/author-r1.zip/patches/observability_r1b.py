"""Second small fix for REF-DDD-01 observability r1: expose n_events to hits reader."""

from pathlib import Path

PATH = Path(__file__).resolve().parent.parent / "compare.py"
text = PATH.read_text(encoding="utf-8")


def replace_once(old: str, new: str) -> None:
    global text
    if text.count(old) != 1:
        raise SystemExit(f"anchor not unique: {old[:60]!r} count={text.count(old)}")
    text = text.replace(old, new)


replace_once(
    '''    return {
        "proton_rows": proton_rows,
        "weighted_length_mm": total_weighted_length,
''',
    '''    return {
        "n_events": n_events,
        "proton_rows": proton_rows,
        "weighted_length_mm": total_weighted_length,
''',
)
replace_once(
    '''    niel_rows = load_table(PROTON_TABLE)
    checks: list[dict] = []
''',
    '''    checks: list[dict] = []
''',
)
PATH.write_text(text, encoding="utf-8")
print("compare.py patched (n_events):", PATH)
