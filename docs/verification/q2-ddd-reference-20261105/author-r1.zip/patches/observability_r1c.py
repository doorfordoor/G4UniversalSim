"""Third small fix for REF-DDD-01 observability r1: build diagnostics before merging."""

from pathlib import Path

PATH = Path(__file__).resolve().parent.parent / "compare.py"
text = PATH.read_text(encoding="utf-8")


def replace_once(old: str, new: str) -> None:
    global text
    if text.count(old) != 1:
        raise SystemExit(f"anchor not unique: {old[:60]!r} count={text.count(old)}")
    text = text.replace(old, new)


replace_once(
    '''        if ddd:
            diagnostics[name].update(verify_implementation(ddd, hits, checks))
        reference = verify_reference(freeze, freeze_case, ddd, stats, checks)
''',
    '''        reference = verify_reference(freeze, freeze_case, ddd, stats, checks)
''',
)
replace_once(
    '''        diagnostics[name] = {
            "hits_proton_rows": hits["proton_rows"],
            "hits_weighted_length_mm": hits["weighted_length_mm"],
            "events_with_proton_hits": hits["events_with_hits"],
            "ddd_per_fluence": reference.get("ddd_per_fluence_MeV_cm2_g"),
            "reference_ddd_per_fluence": reference.get("reference"),
        }
''',
    '''        diagnostics[name] = {
            "hits_proton_rows": hits["proton_rows"],
            "hits_weighted_length_mm": hits["weighted_length_mm"],
            "events_with_proton_hits": hits["events_with_hits"],
            "ddd_per_fluence": reference.get("ddd_per_fluence_MeV_cm2_g"),
            "reference_ddd_per_fluence": reference.get("reference"),
        }
        if ddd:
            diagnostics[name].update(verify_implementation(ddd, hits, checks))
''',
)
PATH.write_text(text, encoding="utf-8")
print("compare.py patched (diagnostics order):", PATH)
