"""Fourth small fix: unique per-case limited ids; keep the single lower-bound check."""

from pathlib import Path

PATH = Path(__file__).resolve().parent.parent / "compare.py"
text = PATH.read_text(encoding="utf-8")


def replace_once(old: str, new: str) -> None:
    global text
    if text.count(old) != 1:
        raise SystemExit(f"anchor not unique: {old[:60]!r} count={text.count(old)}")
    text = text.replace(old, new)


replace_once(
    "def verify_implementation(ddd: dict, hits: dict, checks: list[dict]) -> dict:",
    "def verify_implementation(ddd: dict, hits: dict, case_name: str,\n"
    "                          checks: list[dict]) -> dict:",
)
replace_once(
    '''    tolerance = half_width(scorer_length) + 1e-12 * scorer_length
    check(checks, "MOM-DDD-TRACK-LENGTH-LOWER-BOUND",
          hits_length <= scorer_length + tolerance,
          f"hits={hits_length} scorer={scorer_length} unlogged_gap_mm={gap} "
          f"gap_relative={gap_relative:.6e} tolerance={tolerance:.3e}")
    limited(checks, "MOM-DDD-TRACK-LENGTH-FULL",
''',
    '''    limited(checks, f"MOM-{case_name}-TRACK-LENGTH-FULL",
''',
)
replace_once(
    '''    limited(checks, "MOM-VISIBLE-EVENTS-SUBSET",
''',
    '''    limited(checks, f"MOM-{case_name}-VISIBLE-EVENTS-SUBSET",
''',
)
replace_once(
    '''    limited(checks, "MOM-DDD-FOLDING-STEPWISE",
''',
    '''    limited(checks, f"MOM-{case_name}-FOLDING-STEPWISE",
''',
)
replace_once(
    "            diagnostics[name].update(verify_implementation(ddd, hits, checks))",
    "            diagnostics[name].update(verify_implementation(ddd, hits, name, checks))",
)
PATH.write_text(text, encoding="utf-8")
print("compare.py patched (unique limited ids):", PATH)
