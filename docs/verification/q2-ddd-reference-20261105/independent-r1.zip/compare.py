"""Evaluate REF-DDD-01: identity gate, run evidence, implementation, then physics.

Order is deliberate: frozen identity first, then the run really completed at the
frozen sample size, then the product's own DDD output is cross-checked against
the raw hits (proton weighted track length, independent slab volume, event
moments).  Only then the two fixed references are compared with the frozen
1% + 3 sigma rule.

The comparison tests the two frozen reference points, the run/identity/table
evidence, the valid slab volume, the public event moments and the visible hits
length lower bound.  It does not validate the SR-NIEL physical evaluation: the
public hits CSV exposes only the pre-step kinetic energy, not the internal
pre/post-step mean used by the scorer, and it omits zero-deposit steps that the
scorer still receives.  Full length reconciliation and stepwise folding are
therefore reported as ``limited``; the overall verdict stays ``limited`` while
any such limitation remains.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "out" / "collab" / "q2-reference-ddd-v1"
FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-ddd-reference-freeze-v1.json"
DOSE_FREEZE = ROOT / "docs" / "collab" / "decisions" / "20261105-q2-dose-reference-freeze-v1.json"
PROTON_TABLE = ROOT / "scenarios" / "semiconductor" / "niel" / "si_proton.csv"
NEUTRON_TABLE = ROOT / "scenarios" / "semiconductor" / "niel" / "si_neutron.csv"

FROZEN_BACKEND_SHA = "f8a8119da5d68814a14920056d85a7f30e4f8380d393ea1d439cc8ca2726820f"
FROZEN_GEANT4_VERSION = 1132
FROZEN_PROTON_TABLE_SHA = "6c21e35aab18495d4bb2597a76be60c7c35ef0df963224e0108c77c2e4c208d5"
FROZEN_NEUTRON_TABLE_SHA = "a2ad28a9fcce3500fca363946e09e19125d084f1b596eff76662b272c242034f"
FROZEN_DOSE_FREEZE_SHA = "a2a799e90bd941b4969beab62be408013420dfbd684c4e8e52f07775308e498d"
SIG_DIGITS = 12
MM2_PER_CM2 = 100.0
FROZEN_TOLERANCE = 0.01

HITS_HEADER = [
    "runID", "eventID", "trackID", "parentID", "particle", "edep_MeV", "ndep_MeV",
    "stepLength_mm", "x0_mm", "y0_mm", "z0_mm", "x1_mm", "y1_mm", "z1_mm",
    "px", "py", "pz", "kineticEnergy_MeV", "process", "volume", "weight",
]
DDD_HEADER = [
    "runID", "volume_path", "volume_name", "particle", "niel_table", "volume_mm3",
    "track_length_mm", "out_of_range_track_length_mm", "ddd_MeV_g",
    "ddd_sum_sq_MeV2_g2", "n_events",
]
STAT_HEADER = [
    "runID", "scorer", "quantity", "key", "name", "unit", "estimator", "n_events",
    "entries", "value", "mean_per_event", "std_error", "rel_error", "fom_per_s",
    "run_wall_time_s", "sum", "sum_sq", "uncertainty_estimator", "uncertainty_status",
]
REQUIRED_SUMMARY_FIELDS = [
    "status", "summary_write_status", "output_failure_status", "macro_execution_status",
    "simulation_executed", "program_exit_code", "run_count",
]


def relative(path: Path) -> str:
    """Repository-relative POSIX path, used in the JSON records."""
    try:
        return path.resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def numbers(text: str) -> list[float]:
    """Numbers from a generated field such as ``0, 0, -1 mm``."""
    tokens = str(text).replace(",", " ").split()
    values: list[float] = []
    for token in tokens:
        cleaned = token.replace("mm", "").replace("MeV", "")
        try:
            values.append(float(cleaned))
        except ValueError:
            continue
    return values


def half_width(value: float) -> float:
    """Half width of a decimal printed with 12 significant digits."""
    if value == 0.0 or not math.isfinite(value):
        return 0.0
    return 0.5 * 10.0 ** (math.floor(math.log10(abs(value))) - (SIG_DIGITS - 1))


def parse_run_summary(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith("[") or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        return list(reader.fieldnames or []), list(reader)


def parse_simple_ini(path: Path) -> dict[str, dict[str, str]]:
    """Parse the small, generated INIs (no escapes, one '=' per line)."""
    sections: dict[str, dict[str, str]] = {}
    current = ""
    for line in path.read_text(encoding="utf-8").splitlines():
        text = line.strip()
        if not text or text.startswith("#"):
            continue
        if text.startswith("[") and text.endswith("]"):
            current = text[1:-1].strip()
            sections.setdefault(current, {})
            continue
        if "=" in text and current:
            key, value = text.split("=", 1)
            sections[current][key.strip()] = value.strip()
    return sections


def check(checks: list[dict], cid: str, ok: bool, detail: str, *,
          status: str | None = None) -> bool:
    """Record one machine check.

    ``status`` derives from ``ok`` unless the caller passes it explicitly.  A
    check recorded as ``limited`` means the public evidence cannot decide the
    claim: it is not a pass and it does not count as a detected failure.
    """
    if status is None:
        status = "pass" if ok else "fail"
    if status not in ("pass", "fail", "limited"):
        raise ValueError(f"unknown check status {status!r}")
    checks.append({"id": cid, "status": status, "detail": detail})
    return status == "pass"


def limited(checks: list[dict], cid: str, detail: str) -> None:
    """Record an observational limitation (neither pass nor failure)."""
    check(checks, cid, False, detail, status="limited")


def close_enough(reported: str | float, recomputed: float, *, relative: float = 1e-9) -> tuple[bool, float]:
    """Compare a 12-significant-digit printed value with an independent recomputation."""
    value = float(reported)
    bound = relative * max(abs(value), abs(recomputed)) + half_width(value) + half_width(recomputed)
    delta = abs(value - recomputed)
    return delta <= bound, delta


def load_table(path: Path) -> list[tuple[float, float]]:
    rows: list[tuple[float, float]] = []
    header_seen = False
    for line in path.read_text(encoding="utf-8").splitlines():
        text = line.strip()
        if not text or text.startswith("#"):
            continue
        if not header_seen:
            if text != "energy_MeV,niel_MeV_cm2_g":
                raise SystemExit(f"{path.name}: unexpected table header: {text}")
            header_seen = True
            continue
        energy, niel = text.split(",")[:2]
        rows.append((float(energy), float(niel)))
    return rows


def table_niel(rows: list[tuple[float, float]], energy: float) -> float:
    """Log-log interpolation between the two adjacent table nodes."""
    if energy <= rows[0][0]:
        return rows[0][1]
    if energy >= rows[-1][0]:
        return rows[-1][1]
    index = 0
    while index + 1 < len(rows) and rows[index + 1][0] < energy:
        index += 1
    e0, v0 = rows[index]
    e1, v1 = rows[index + 1]
    fraction = math.log(energy / e0) / math.log(e1 / e0)
    return math.exp(math.log(v0) + fraction * (math.log(v1) - math.log(v0)))


def verify_identity(identity: dict, freeze: dict, checks: list[dict]) -> bool:
    ok = True
    backend = identity.get("backend", {})
    ok &= check(checks, "ID-BACKEND-SHA", backend.get("sha256") == FROZEN_BACKEND_SHA,
                f"sha256={backend.get('sha256')}")
    ok &= check(checks, "ID-BUILD-COMMIT", backend.get("build_git_commit") == freeze["backend_build"],
                f"build_git_commit={backend.get('build_git_commit')}")
    fingerprint = backend.get("source_fingerprint", "")
    ok &= check(checks, "ID-SOURCE-FINGERPRINT",
                isinstance(fingerprint, str) and len(fingerprint) == 64
                and all(ch in "0123456789abcdef" for ch in fingerprint),
                f"source_fingerprint={fingerprint}")
    ok &= check(checks, "ID-GEANT4-VERSION",
                int(backend.get("geant4_version_number", -1)) == FROZEN_GEANT4_VERSION,
                f"geant4_version_number={backend.get('geant4_version_number')}")
    geant4 = identity.get("geant4", {})
    ok &= check(checks, "ID-GEANT4-DATA-CHECK",
                geant4.get("data_check_exit") == 0
                and sha256(BASE / "backend-data-check.txt") == geant4.get("data_check_sha256")
                and '"required_complete": true' in (BASE / "backend-data-check.txt").read_text(encoding="utf-8"),
                f"data_check_exit={geant4.get('data_check_exit')}")
    freeze_info = identity.get("freeze", {})
    freeze_path = ROOT / freeze_info.get("path", "")
    ok &= check(checks, "ID-FREEZE-SHA",
                freeze_path.is_file() and sha256(freeze_path) == freeze_info.get("sha256"),
                f"path={freeze_info.get('path')} recorded={freeze_info.get('sha256')}")
    ok &= check(checks, "ID-FREEZE-SCHEMA",
                freeze_info.get("schema") == freeze.get("schema"),
                f"identity={freeze_info.get('schema')} freeze={freeze.get('schema')}")
    source = identity.get("geometry_source_freeze", {})
    source_path = ROOT / source.get("path", "")
    ok &= check(checks, "ID-GEOMETRY-SOURCE-FREEZE-SHA",
                source.get("sha256") == FROZEN_DOSE_FREEZE_SHA
                and freeze["geometry_source_freeze_sha256"] == FROZEN_DOSE_FREEZE_SHA
                and source_path.is_file() and sha256(source_path) == FROZEN_DOSE_FREEZE_SHA,
                f"recorded={source.get('sha256')}")
    tables = identity.get("tables", {})
    for particle, path, frozen_sha in (
        ("proton", PROTON_TABLE, FROZEN_PROTON_TABLE_SHA),
        ("neutron", NEUTRON_TABLE, FROZEN_NEUTRON_TABLE_SHA),
    ):
        record = tables.get(particle, {})
        spec = freeze["tables"][particle]
        ok &= check(checks, f"ID-TABLE-SHA-{particle.upper()}",
                    record.get("sha256") == frozen_sha == spec["sha256"]
                    and path.is_file() and sha256(path) == frozen_sha,
                    f"recorded={record.get('sha256')}")
        ok &= check(checks, f"ID-TABLE-ROWS-{particle.upper()}",
                    int(record.get("rows", -1)) == int(spec["rows"]),
                    f"recorded={record.get('rows')} frozen={spec['rows']}")
        ok &= check(checks, f"ID-TABLE-DOMAIN-{particle.upper()}",
                    all(abs(float(a) - float(b)) <= 1e-15
                        for a, b in zip(record.get("energy_domain_MeV", []), spec["energy_domain_MeV"])),
                    f"recorded={record.get('energy_domain_MeV')}")
    inputs = identity.get("inputs", {})
    for name, item in sorted(inputs.items()):
        input_path = ROOT / item.get("path", "")
        ok &= check(checks, f"ID-INPUT-SHA-{name.upper().replace('.', '-').replace('_', '-')}",
                    input_path.is_file() and sha256(input_path) == item.get("sha256"),
                    f"path={item.get('path')}")
    return bool(ok)


def verify_inputs(case: dict, freeze: dict, dose_freeze: dict, freeze_case: dict,
                  checks: list[dict]) -> bool:
    ok = True
    main = parse_simple_ini(ROOT / case["main_ini"])
    geometry = parse_simple_ini(ROOT / case["geometry_ini"])
    source = main.get("source", {})
    physics = main.get("physics", {})
    scoring = main.get("scoring", {})
    displacement = main.get("scoring.displacement", {})
    run = main.get("run", {})
    ok &= check(checks, "IN-EM-ONLY", "em" in physics and "reference" not in physics,
                f"physics keys={sorted(physics)}")
    ok &= check(checks, "IN-EM-VALUE", physics.get("em") == freeze["physics_em"],
                f"em={physics.get('em')}")
    ok &= check(checks, "IN-CUT", physics.get("default_cut") == freeze["default_cut"],
                f"default_cut={physics.get('default_cut')}")
    ok &= check(checks, "IN-SCORING-DISPLACEMENT", scoring.get("displacement") == "true",
                f"displacement={scoring.get('displacement')}")
    ok &= check(checks, "IN-SCORING-HITS", scoring.get("hits") == "true",
                f"hits={scoring.get('hits')}")
    ok &= check(checks, "IN-SCORING-NO-DOSE", scoring.get("dose") == "false",
                f"dose={scoring.get('dose')}")
    ok &= check(checks, "IN-SCORING-NO-EVENT-EDEP", scoring.get("event_edep") == "false",
                f"event_edep={scoring.get('event_edep')}")
    ok &= check(checks, "IN-THREADS", run.get("threads") == str(int(freeze["threads"])),
                f"threads={run.get('threads')}")
    ok &= check(checks, "IN-SEED", run.get("seed") == str(int(freeze_case["seed"])),
                f"seed={run.get('seed')}")
    ok &= check(checks, "IN-SOURCE-PARTICLE", source.get("particle") == "proton",
                f"particle={source.get('particle')}")
    ok &= check(checks, "IN-SOURCE-ENERGY",
                abs(float(str(source.get("energy", "nan")).split()[0])
                    - float(freeze_case["energy_MeV"])) <= 1e-12,
                f"energy={source.get('energy')}")
    ok &= check(checks, "IN-SOURCE-PLANE",
                source.get("position_type") == "plane" and source.get("shape") == "square",
                f"position_type={source.get('position_type')} shape={source.get('shape')}")
    ok &= check(checks, "IN-SOURCE-NO-HALFY", "halfy" not in source,
                f"halfy={source.get('halfy')!r}")
    ok &= check(checks, "IN-SOURCE-HALFX",
                abs(float(str(source.get("halfx", "nan")).split()[0])
                    - float(freeze["source"]["halfx_mm"])) <= 1e-12,
                f"halfx={source.get('halfx')}")
    center = numbers(source.get("center"))
    ok &= check(checks, "IN-SOURCE-CENTER",
                len(center) == 3 and abs(center[0]) <= 1e-12 and abs(center[1]) <= 1e-12
                and abs(center[2] - float(freeze["source"]["center_mm"][2])) <= 1e-12,
                f"center={center}")
    direction = numbers(source.get("direction"))
    ok &= check(checks, "IN-SOURCE-DIRECTION", direction == [0.0, 0.0, 1.0],
                f"direction={direction}")
    table_path = ROOT / displacement.get("proton", "")
    ok &= check(checks, "IN-NIEL-TABLE-PATH",
                table_path.is_file() and table_path.resolve() == PROTON_TABLE.resolve(),
                f"configured={displacement.get('proton')!r}")
    ok &= check(checks, "IN-NIEL-TABLE-SHA",
                table_path.is_file() and sha256(table_path) == FROZEN_PROTON_TABLE_SHA,
                f"sha256={sha256(table_path) if table_path.is_file() else None}")
    block = geometry.get("volume.Block", {})
    slab = geometry.get("volume.Slab", {})
    block_position = numbers(block.get("position"))
    block_size = numbers(block.get("size"))
    slab_position = numbers(slab.get("position"))
    slab_size = numbers(slab.get("size"))
    ok &= check(checks, "IN-GEOMETRY-TEMPLATE",
                main.get("geometry", {}).get("template") == "hierarchical",
                f"template={main.get('geometry', {}).get('template')}")
    ok &= check(checks, "IN-WORLD-MATERIAL", geometry.get("world", {}).get("material") == "G4_Galactic",
                f"material={geometry.get('world', {}).get('material')}")
    ok &= check(checks, "IN-BLOCK-MATERIAL", block.get("material") == dose_freeze["material"],
                f"material={block.get('material')}")
    ok &= check(checks, "IN-BLOCK-FRONT-AT-ZERO",
                abs(block_position[2] - 0.5 * block_size[2]) <= 1e-12,
                f"center_z={block_position[2]} half_thickness={0.5 * block_size[2]}")
    ok &= check(checks, "IN-BLOCK-THICKNESS",
                abs(block_size[2] - float(freeze_case["block_z_mm"])) <= 1e-12,
                f"block_z={block_size[2]} frozen={freeze_case['block_z_mm']}")
    ok &= check(checks, "IN-BLOCK-XY",
                abs(block_size[0] - float(freeze["block_xy_mm"][0])) <= 1e-12
                and abs(block_size[1] - float(freeze["block_xy_mm"][1])) <= 1e-12,
                f"block_size={block_size[:2]}")
    ok &= check(checks, "IN-SLAB-AT-BLOCK-CENTER", slab_position == [0.0, 0.0, 0.0],
                f"slab_position={slab_position}")
    ok &= check(checks, "IN-SLAB-SIZE",
                abs(slab_size[0] - float(freeze["slab_xy_mm"][0])) <= 1e-12
                and abs(slab_size[1] - float(freeze["slab_xy_mm"][1])) <= 1e-12
                and abs(slab_size[2] - float(freeze_case["slab_mm"])) <= 1e-12,
                f"slab_size={slab_size}")
    ok &= check(checks, "IN-SLAB-SENSITIVE", slab.get("sensitive") == "true",
                f"sensitive={slab.get('sensitive')}")
    ok &= check(checks, "IN-SLAB-MATERIAL", slab.get("material") == dose_freeze["material"],
                f"material={slab.get('material')}")
    slab_mid_depth = block_position[2] + slab_position[2]
    ok &= check(checks, "IN-SLAB-MID-DEPTH",
                abs(slab_mid_depth - (float(freeze_case["buildup_mm"])
                                      + 0.5 * float(freeze_case["slab_mm"]))) <= 1e-12,
                f"slab_mid_depth={slab_mid_depth}")
    ok &= check(checks, "IN-SOURCE-OUTSIDE-BLOCK",
                center[2] < (block_position[2] - 0.5 * block_size[2]),
                f"source_z={center[2]} front_z={block_position[2] - 0.5 * block_size[2]}")
    beam_area_cm2 = (2.0 * float(freeze["source"]["halfx_mm"]) * 0.1) ** 2
    ok &= check(checks, "IN-SOURCE-AREA",
                abs(float(freeze["source"]["area_cm2"]) - beam_area_cm2) <= 1e-12,
                f"area_cm2={freeze['source']['area_cm2']} beam={beam_area_cm2}")
    ok &= check(checks, "IN-INPUT-IDENTITY",
                sha256(ROOT / case["main_ini"]) == case["main_ini_sha256"]
                and sha256(ROOT / case["geometry_ini"]) == case["geometry_ini_sha256"],
                "generated input SHA-256 recorded in identity")
    return bool(ok)


def verify_case_evidence(case: dict, freeze: dict, freeze_case: dict, checks: list[dict]) -> bool:
    n_expected = int(freeze["events_per_case"])
    output = ROOT / case["run"]["output_dir"]
    run = case["run"]
    summary_path = output / "run_summary.txt"
    metadata_path = output / "run_metadata.json"
    hits_path = output / "hits_t0.csv"
    ddd_path = output / "displacement_volume_summary_t0.csv"
    stats_path = output / "scorer_statistics.csv"
    ok = True
    ok &= check(checks, "EVID-SUMMARY-FILE", summary_path.is_file(), str(summary_path))
    ok &= check(checks, "EVID-METADATA-FILE", metadata_path.is_file(), str(metadata_path))
    ok &= check(checks, "EVID-HITS-FILE", hits_path.is_file(), str(hits_path))
    ok &= check(checks, "EVID-DDD-FILE", ddd_path.is_file(), str(ddd_path))
    ok &= check(checks, "EVID-STATISTICS-FILE", stats_path.is_file(), str(stats_path))
    ok &= check(checks, "EVID-BACKEND-EXIT", run.get("exit_code") == 0,
                f"backend_exit={run.get('exit_code')}")
    if not all(path.is_file() for path in (summary_path, metadata_path, hits_path,
                                           ddd_path, stats_path)):
        return False
    ok &= check(checks, "EVID-SUMMARY-SHA", sha256(summary_path) == run.get("run_summary_sha256"),
                str(run.get("run_summary_sha256")))
    ok &= check(checks, "EVID-METADATA-SHA", sha256(metadata_path) == run.get("run_metadata_sha256"),
                str(run.get("run_metadata_sha256")))
    summary = parse_run_summary(summary_path)
    expected = {
        "status": "completed",
        "summary_write_status": "completed",
        "output_failure_status": "none",
        "macro_execution_status": "completed",
        "simulation_executed": "true",
        "program_exit_code": "0",
        "run_count": "1",
        "actual_threads": str(int(freeze["threads"])),
        "source_particle": "proton",
        "physics_em": "G4EmStandardPhysics_option4",
        "scoring_hits_enabled": "true",
        "scoring_dose_enabled": "false",
    }
    for key, value in expected.items():
        ok &= check(checks, f"EVID-SUMMARY-{key.upper().replace('_', '-')}",
                    summary.get(key) == value, f"{key}={summary.get(key)}")
    ok &= check(checks, "EVID-SUMMARY-PHYSICS-REFERENCE-EMPTY",
                (summary.get("physics_reference") or "").strip() == "",
                f"physics_reference={summary.get('physics_reference')!r}")
    for key in ("run_0_planned_events", "run_0_completed_events", "planned_event_count",
                "actual_completed_event_count"):
        ok &= check(checks, f"EVID-{key.upper().replace('_', '-')}",
                    summary.get(key) == str(n_expected), f"{key}={summary.get(key)}")
    ok &= check(checks, "EVID-CONFIGURED-SEED",
                summary.get("configured_seed") == str(int(freeze_case["seed"])),
                f"configured_seed={summary.get('configured_seed')}")
    ok &= check(checks, "EVID-SOURCE-ENERGY",
                abs(float(summary.get("effective_source_energy_MeV", "nan"))
                    - float(freeze_case["energy_MeV"])) <= 1e-12,
                f"effective_source_energy_MeV={summary.get('effective_source_energy_MeV')}")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    runs = metadata.get("runs", [])
    ok &= check(checks, "EVID-METADATA-SCHEMA", metadata.get("schema") == "run_metadata_json_v1",
                str(metadata.get("schema")))
    ok &= check(checks, "EVID-METADATA-RUNS", len(runs) == 1, f"runs={len(runs)}")
    if len(runs) == 1:
        ok &= check(checks, "EVID-METADATA-PLANNED",
                    int(runs[0].get("planned_events", -1)) == n_expected,
                    f"planned={runs[0].get('planned_events')}")
        ok &= check(checks, "EVID-METADATA-COMPLETED",
                    int(runs[0].get("completed_events", -1)) == n_expected,
                    f"completed={runs[0].get('completed_events')}")
    declared = {Path(item.get("path", "")).name: item
                for item in metadata.get("generated_files", [])}
    for name in ("hits_t0.csv", "displacement_volume_summary_t0.csv", "scorer_statistics.csv"):
        item = declared.get(name)
        ok &= check(checks, f"EVID-ASSET-DECLARED-{name}",
                    item is not None and item.get("integrity_status") == "hashed",
                    f"declared={item is not None}")
    recorded = run.get("artifacts", {})
    for name in ("hits_t0.csv", "displacement_volume_summary_t0.csv", "scorer_statistics.csv",
                 "run_summary.txt", "run_metadata.json"):
        item = recorded.get(name)
        path = ROOT / item.get("path", "") if item else None
        ok &= check(checks, f"EVID-RECORDED-{name}",
                    item is not None and path is not None and path.is_file()
                    and sha256(path) == item.get("sha256")
                    and path.stat().st_size == item.get("size_bytes"),
                    f"recorded={item.get('sha256') if item else None}")
    ok &= check(checks, "EVID-OUTPUT-DIR",
                Path(summary.get("actual_output_dir", "").replace("\\", "/")).resolve()
                == output.resolve(),
                f"summary={summary.get('actual_output_dir')} expected={output}")
    ok &= check(checks, "EVID-BACKEND-LOG",
                (ROOT / run.get("backend_log", "")).is_file(), str(run.get("backend_log")))
    ok &= check(checks, "EVID-MAIN-INI-SHA",
                sha256(ROOT / case["main_ini"]) == case["main_ini_sha256"],
                f"path={case['main_ini']}")
    ok &= check(checks, "EVID-GEOMETRY-INI-SHA",
                sha256(ROOT / case["geometry_ini"]) == case["geometry_ini_sha256"],
                f"path={case['geometry_ini']}")
    return bool(ok)


def read_hits(output: Path, n_events: int, checks: list[dict]) -> dict:
    header, rows = read_csv(output / "hits_t0.csv")
    check(checks, "MOM-HITS-HEADER", header == HITS_HEADER, f"header={header}")
    proton_rows = 0
    total_weighted_length = 0.0
    per_event: dict[int, float] = {}
    energies: list[float] = []
    steps: list[dict] = []
    weights_positive = True
    step_positive = True
    finite = True
    volumes: set[str] = set()
    for row in rows:
        try:
            event = int(row["eventID"])
            step = float(row["stepLength_mm"])
            weight = float(row["weight"])
            energy = float(row["kineticEnergy_MeV"])
            edep = float(row["edep_MeV"])
        except (KeyError, TypeError, ValueError):
            finite = False
            continue
        volumes.add(str(row.get("volume", "")))
        finite &= all(math.isfinite(item) for item in (step, weight, energy, edep))
        if str(row.get("particle")) != "proton":
            continue
        proton_rows += 1
        step_positive &= step > 0.0
        weights_positive &= weight > 0.0 and math.isfinite(weight)
        weighted = weight * step
        total_weighted_length += weighted
        per_event[event] = per_event.get(event, 0.0) + weighted
        energies.append(energy)
        steps.append({"weighted_length_mm": weighted, "pre_MeV": energy, "edep_MeV": edep})
    check(checks, "MOM-HITS-PROTON-ROWS", proton_rows > 0, f"proton_rows={proton_rows}")
    check(checks, "MOM-HITS-VOLUME-SLAB",
          volumes == {"Slab_PV"} or (len(volumes) == 1 and next(iter(volumes)).endswith("Slab_PV")),
          f"volumes={sorted(volumes)}")
    check(checks, "MOM-HITS-STEP-POSITIVE", step_positive, "all proton step lengths > 0")
    check(checks, "MOM-HITS-WEIGHT-POSITIVE", weights_positive, "all proton weights finite and > 0")
    check(checks, "MOM-HITS-FINITE", finite, "hit rows finite")
    check(checks, "MOM-HITS-EVENTS-NOT-ROWS",
          len(per_event) <= n_events and proton_rows >= len(per_event),
          f"rows={proton_rows} events={len(per_event)} n={n_events}")
    return {
        "n_events": n_events,
        "proton_rows": proton_rows,
        "weighted_length_mm": total_weighted_length,
        "event_lengths_mm": per_event,
        "events_with_hits": len(per_event),
        "energy_min_MeV": min(energies) if energies else float("nan"),
        "energy_max_MeV": max(energies) if energies else float("nan"),
        "steps": steps,
    }


def read_ddd(output: Path, freeze: dict, freeze_case: dict, n_events: int,
             hits: dict, checks: list[dict]) -> dict:
    header, rows = read_csv(output / "displacement_volume_summary_t0.csv")
    check(checks, "MOM-DDD-HEADER", header == DDD_HEADER, f"header={header}")
    selected = [row for row in rows if str(row.get("particle")) == "proton"]
    check(checks, "MOM-DDD-ROW-PROTON", len(selected) == 1,
          f"proton_rows={len(selected)} all={[row.get('particle') for row in rows]}")
    if len(selected) != 1:
        return {}
    row = selected[0]
    volume_mm3 = float(row["volume_mm3"])
    track_length = float(row["track_length_mm"])
    out_of_range = float(row["out_of_range_track_length_mm"])
    ddd = float(row["ddd_MeV_g"])
    ddd_sum_sq = float(row["ddd_sum_sq_MeV2_g2"])
    table_name = Path(str(row.get("niel_table", ""))).name
    geometric_volume = (float(freeze["slab_xy_mm"][0]) * float(freeze["slab_xy_mm"][1])
                        * float(freeze_case["slab_mm"]))
    check(checks, "MOM-DDD-VOLUME-COLUMN",
          abs(volume_mm3 - geometric_volume) <= 1e-12 * geometric_volume,
          f"csv={volume_mm3} geometry={geometric_volume}")
    hits_length = hits["weighted_length_mm"]
    length_tolerance = half_width(track_length) + 1e-12 * track_length
    check(checks, "MOM-DDD-TRACK-LENGTH-LOWER-BOUND",
          hits_length <= track_length + length_tolerance,
          f"csv={track_length} hits={hits_length} "
          f"unlogged_gap_mm={track_length - hits_length}")
    check(checks, "MOM-DDD-OUT-OF-RANGE", out_of_range == 0.0,
          f"out_of_range_track_length_mm={out_of_range}")
    check(checks, "MOM-DDD-N-EVENTS", int(row["n_events"]) == n_events,
          f"n_events={row['n_events']}")
    check(checks, "MOM-DDD-FINITE",
          all(math.isfinite(item) for item in (volume_mm3, track_length, out_of_range, ddd, ddd_sum_sq))
          and ddd > 0.0 and ddd_sum_sq > 0.0,
          f"ddd={ddd} ddd_sum_sq={ddd_sum_sq}")
    check(checks, "MOM-DDD-TABLE-NAME", table_name == "si_proton.csv", f"niel_table={table_name}")
    table_path = ROOT / "scenarios" / "semiconductor" / "niel" / table_name
    check(checks, "MOM-DDD-TABLE-SHA",
          table_path.is_file() and sha256(table_path) == FROZEN_PROTON_TABLE_SHA,
          f"disk={sha256(table_path) if table_path.is_file() else None}")
    return {
        "volume_mm3": volume_mm3,
        "track_length_mm": track_length,
        "out_of_range_mm": out_of_range,
        "ddd_MeV_g": ddd,
        "ddd_sum_sq_MeV2_g2": ddd_sum_sq,
        "n_events": int(row["n_events"]),
        "table": table_name,
    }


def statistics(output: Path, n_events: int, events_with_hits: int, ddd: dict,
               checks: list[dict]) -> dict:
    header, rows = read_csv(output / "scorer_statistics.csv")
    check(checks, "STAT-HEADER", header == STAT_HEADER, f"header={header}")
    selected = {str(row.get("quantity")): row for row in rows
                if str(row.get("scorer")) == "displacement"}
    check(checks, "STAT-ROWS", set(selected) == {"ddd_proton", "ddd_total"},
          f"quantities={sorted(selected)}")
    result: dict[str, dict] = {}
    for quantity in ("ddd_proton", "ddd_total"):
        row = selected.get(quantity)
        if row is None:
            check(checks, f"STAT-{quantity.upper()}-PRESENT", False, "missing row")
            continue
        value = float(row["value"])
        sum_sq = float(row["sum_sq"])
        rel_error = float(row["rel_error"])
        entries = int(row["entries"])
        ok = True
        ok &= check(checks, f"STAT-{quantity.upper()}-UNIT", row["unit"] == "MeV/g",
                    f"unit={row['unit']}")
        ok &= check(checks, f"STAT-{quantity.upper()}-ESTIMATOR", row["estimator"] == "total",
                    f"estimator={row['estimator']}")
        ok &= check(checks, f"STAT-{quantity.upper()}-N-EVENTS", int(row["n_events"]) == n_events,
                    f"n_events={row['n_events']}")
        ok &= check(checks, f"STAT-{quantity.upper()}-ENTRIES", entries == events_with_hits,
                    f"entries={entries} events_with_proton_hits={events_with_hits}")
        expected_rel = math.sqrt(max(sum_sq / (value * value) - 1.0 / n_events, 0.0))
        ok &= check(checks, f"STAT-{quantity.upper()}-REL-ERROR",
                    close_enough(rel_error, expected_rel)[0],
                    f"csv={rel_error} independent={expected_rel}")
        ok &= check(checks, f"STAT-{quantity.upper()}-STD-ERROR",
                    close_enough(row["std_error"], rel_error * abs(value))[0],
                    f"std_error={row['std_error']} rel*|value|={rel_error * abs(value)}")
        ok &= check(checks, f"STAT-{quantity.upper()}-MEAN",
                    close_enough(row["mean_per_event"], value / n_events)[0],
                    f"mean={row['mean_per_event']} value/N={value / n_events}")
        ok &= check(checks, f"STAT-{quantity.upper()}-AVERAGE",
                    row["uncertainty_estimator"] == "uncorrected_event_moments_v1"
                    and row["uncertainty_status"] == "approximate",
                    f"estimator={row['uncertainty_estimator']} status={row['uncertainty_status']}")
        ok &= check(checks, f"STAT-{quantity.upper()}-FINITE",
                    all(math.isfinite(item) for item in (value, sum_sq, rel_error)) and value >= 0.0,
                    f"value={value} sum_sq={sum_sq} rel_error={rel_error}")
        result[quantity] = {
            "value": value, "sum_sq": sum_sq, "rel_error": rel_error,
            "entries": entries, "n_events": int(row["n_events"]),
        }
    if "ddd_proton" in result and "ddd_total" in result:
        check(checks, "STAT-TOTAL-EQUALS-PROTON",
              abs(result["ddd_total"]["value"] - result["ddd_proton"]["value"]) == 0.0,
              f"total={result['ddd_total']['value']} proton={result['ddd_proton']['value']}")
    if ddd and "ddd_proton" in result:
        ok = close_enough(result["ddd_proton"]["value"], ddd["ddd_MeV_g"])
        check(checks, "STAT-CSV-VALUE-MATCH-DDD", ok[0],
              f"stats={result['ddd_proton']['value']} csv={ddd['ddd_MeV_g']} delta={ok[1]}")
        ok = close_enough(result["ddd_proton"]["sum_sq"], ddd["ddd_sum_sq_MeV2_g2"])
        check(checks, "STAT-CSV-SUM-SQ-MATCH", ok[0],
              f"stats={result['ddd_proton']['sum_sq']} csv={ddd['ddd_sum_sq_MeV2_g2']} delta={ok[1]}")
    return result


def verify_implementation(ddd: dict, hits: dict, case_name: str,
                          checks: list[dict]) -> dict:
    """Reconcile the public DDD summary with the public hits file.

    The hits CSV records only steps with positive local deposition.  The DDD
    scorer also receives zero-deposit steps (``SensitiveDetector`` calls the
    displacement scorer before returning without writing a hit), so the visible
    proton length is a *lower bound* for the scored length.  The exact gap and
    the stepwise fold (which needs the internal pre/post-step mean kinetic
    energy) cannot be reconstructed from public columns.  Those claims are
    recorded as ``limited``; they are never reported as pass.

    The withdrawn ``[pre - Edep, pre]`` interval is not a bound on the step mean
    energy: local Edep does not include the kinetic energy carried by explicit
    secondaries.  A synthetic ledger counterexample is kept in
    ``counterexample_bracket.py`` output.
    """
    volume_mm3 = ddd["volume_mm3"]
    hits_length = hits["weighted_length_mm"]
    scorer_length = ddd["track_length_mm"]
    gap = scorer_length - hits_length
    gap_relative = gap / scorer_length if scorer_length > 0.0 else float("nan")
    track_fluence_cm2 = hits_length * MM2_PER_CM2 / volume_mm3
    check(checks, "MOM-TRACK-FLUENCE-FINITE",
          math.isfinite(track_fluence_cm2) and track_fluence_cm2 > 0.0,
          f"track_fluence_cm2={track_fluence_cm2} "
          f"from hits weighted length {hits_length} mm / {volume_mm3} mm3")
    total_from_events = sum(hits["event_lengths_mm"].values())
    check(checks, "MOM-EVENT-LENGTH-SUM",
          close_enough(hits_length, total_from_events)[0],
          f"rows={hits_length} from_events={total_from_events}")
    limited(checks, f"MOM-{case_name}-TRACK-LENGTH-FULL",
            "exact length reconciliation is not recoverable from public outputs: the hits CSV "
            "omits zero-deposit steps that the DDD scorer still receives. "
            f"hits_weighted_length_mm={hits_length} scorer_track_length_mm={scorer_length} "
            f"unlogged_gap_mm={gap} unlogged_gap_relative={gap_relative:.6e}. "
            "The visible set is a lower bound, not the complete scored set.")
    limited(checks, f"MOM-{case_name}-VISIBLE-EVENTS-SUBSET",
            f"visible proton-hit events={hits['events_with_hits']} (of n_events={hits['n_events']}) "
            "are only a lower bound for the events that contributed DDD; there is no public "
            "evidence of the complete contributing event set.")
    limited(checks, f"MOM-{case_name}-FOLDING-STEPWISE",
            "stepwise folding is not recoverable: the scorer folds the NIEL table at the internal "
            "pre/post-step mean kinetic energy, which is not a public column. The withdrawn "
            "[pre-Edep, pre] interval is invalid because secondaries carry kinetic energy "
            "(synthetic counterexample: counterexample_bracket.py -> "
            "evidence/withdrawn-bracket-counterexample.json). No substitute interval is asserted.")
    return {
        "hits_proton_weighted_length_mm": hits_length,
        "scorer_track_length_mm": scorer_length,
        "unlogged_gap_mm": gap,
        "unlogged_gap_relative": gap_relative,
        "track_fluence_cm2_from_hits": track_fluence_cm2,
    }


def verify_reference(freeze: dict, freeze_case: dict, ddd: dict, stats: dict,
                     checks: list[dict]) -> dict:
    n_events = int(freeze["events_per_case"])
    area_cm2 = float(freeze["source"]["area_cm2"])
    reference = float(freeze_case["reference_ddd_per_fluence_MeV_cm2_g"])
    result: dict = {"reference": reference}
    if "ddd_proton" not in stats:
        check(checks, "REF-DDD-PHI-ABS", False, "missing ddd_proton statistics row")
        return result
    value = stats["ddd_proton"]["value"]
    rel_error = stats["ddd_proton"]["rel_error"]
    ddd_per_fluence = value * area_cm2 / n_events
    delta = ddd_per_fluence - reference
    sigma = ddd_per_fluence * rel_error
    allowed = FROZEN_TOLERANCE * reference + 3.0 * sigma
    ok = abs(delta) <= allowed
    check(checks, "REF-DDD-PHI-ABS", ok,
          f"ddd/phi={ddd_per_fluence} reference={reference} delta={delta} "
          f"relative_delta={delta / reference:.6e} sigma={sigma} allowed={allowed}")
    check(checks, "REF-EVENTS-N", n_events == 20000, f"frozen events={n_events}")
    check(checks, "REF-SIGMA-VALID",
          math.isfinite(sigma) and sigma > 0.0 and math.isfinite(rel_error)
          and 0.0 < rel_error < 1.0,
          f"sigma={sigma} rel_error={rel_error}")
    result.update({
        "ddd_MeV_g": value,
        "ddd_per_fluence_MeV_cm2_g": ddd_per_fluence,
        "absolute_delta": delta,
        "relative_delta": delta / reference,
        "sigma": sigma,
        "allowed": allowed,
        "status": "pass" if ok else "fail",
    })
    return result


def evaluate(results: dict, freeze: dict, identity: dict | None = None,
             dose_freeze: dict | None = None) -> dict:
    identity = identity or results.get("identity", {})
    dose_freeze = dose_freeze or json.loads(DOSE_FREEZE.read_text(encoding="utf-8"))
    checks: list[dict] = []
    verify_identity(identity, freeze, checks)
    cases: dict[str, dict] = {}
    diagnostics: dict[str, dict] = {}
    for name in sorted(identity.get("cases", {})):
        freeze_case = next(case for case in freeze["cases"] if str(case["case"]) == name)
        case = dict(identity["cases"][name])
        inputs = identity.get("inputs", {})
        case["main_ini_sha256"] = inputs.get(Path(case["main_ini"]).name, {}).get("sha256")
        case["geometry_ini_sha256"] = inputs.get(Path(case["geometry_ini"]).name, {}).get("sha256")
        run = results.get("cases", {}).get(name)
        if run is None:
            check(checks, f"EVID-RUN-{name}", False, "case absent from results")
            continue
        case["run"] = run
        verify_inputs(case, freeze, dose_freeze, freeze_case, checks)
        verify_case_evidence(case, freeze, freeze_case, checks)
        n_events = int(freeze["events_per_case"])
        hits = read_hits(ROOT / run["output_dir"], n_events, checks)
        ddd = read_ddd(ROOT / run["output_dir"], freeze, freeze_case, n_events, hits, checks)
        stats = statistics(ROOT / run["output_dir"], n_events, hits["events_with_hits"], ddd, checks)
        reference = verify_reference(freeze, freeze_case, ddd, stats, checks)
        cases[name] = {"ddd": ddd, "statistics": stats, "reference": reference}
        diagnostics[name] = {
            "hits_proton_rows": hits["proton_rows"],
            "hits_weighted_length_mm": hits["weighted_length_mm"],
            "events_with_proton_hits": hits["events_with_hits"],
            "ddd_per_fluence": reference.get("ddd_per_fluence_MeV_cm2_g"),
            "reference_ddd_per_fluence": reference.get("reference"),
        }
        if ddd:
            diagnostics[name].update(verify_implementation(ddd, hits, name, checks))
    failed = [item["id"] for item in checks if item["status"] == "fail"]
    limited_ids = [item["id"] for item in checks if item["status"] == "limited"]
    passed = [item["id"] for item in checks if item["status"] == "pass"]
    if failed:
        status = "fail"
    elif limited_ids:
        # The frozen requirements distinguish pass, fail and limited; an
        # observation gap can never be promoted to an overall pass.
        status = "limited"
    else:
        status = "pass"
    return {
        "schema": "g4usim_q2_ref_ddd_evaluation_v1",
        "checks_total": len(checks),
        "checks_pass": len(passed),
        "checks_failed": len(failed),
        "checks_limited": len(limited_ids),
        "failed_ids": failed,
        "limited_ids": limited_ids,
        "status": status,
        "checks": checks,
        "cases": cases,
        "diagnostics": diagnostics,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--update", action="store_true", help="write the evaluation back into results.json")
    args = parser.parse_args(argv)
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    identity_path = BASE / "identity.json"
    identity = json.loads(identity_path.read_text(encoding="utf-8")) if identity_path.is_file() else {}
    results_path = BASE / "results.json"
    results = json.loads(results_path.read_text(encoding="utf-8"))
    evaluation = evaluate(results, freeze, identity)
    if args.update:
        results["evaluation"] = evaluation
        results_path.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n",
                                encoding="utf-8")
    print(json.dumps({key: evaluation[key] for key in
                      ("status", "checks_total", "checks_pass", "checks_failed",
                       "checks_limited", "failed_ids", "limited_ids")},
                     indent=2, ensure_ascii=False))
    for name, item in evaluation["cases"].items():
        reference = item["reference"]
        print(f"{name}: ddd/phi={reference.get('ddd_per_fluence_MeV_cm2_g')} "
              f"reference={reference.get('reference')} delta={reference.get('absolute_delta')} "
              f"allowed={reference.get('allowed')} status={reference.get('status')}")
    if evaluation["status"] == "limited":
        print("verdict=limited: no check failed, but public outputs cannot prove exact length "
              "reconciliation or stepwise folding; exit 1 is the comparison verdict, not a "
              "backend failure (both runs exited 0).")
    return 0 if evaluation["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
