"""Synthetic energy-ledger counterexample for the withdrawn folding interval.

The first REF-DDD-01 candidate claimed that the step mean kinetic energy lies in
``[pre - Edep, pre]`` and used that interval as an exact DDD folding bound.  That
claim is wrong: the local Edep does not include the kinetic energy carried away
by explicit secondaries, so the post-step kinetic energy can be lower than
``pre - Edep``.

This script builds an explicit, energy-conserving ledger from the numbers in the
independent review and shows that the true step mean lies outside the claimed
interval.  It is a synthetic arithmetic counterexample, NOT a measured Geant4
step, and it uses no run output.

Run: python -B counterexample_bracket.py
"""

from __future__ import annotations

import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
EVIDENCE = BASE / "evidence"

# Review r1: pre=100 MeV, post=99.899 MeV, local Edep=0.001 MeV,
# secondary carries 0.100 MeV.  100 - 99.899 = 0.101 = 0.001 + 0.100.
PRE_MEV = 100.0
POST_MEV = 99.899
EDEP_MEV = 0.001
SECONDARY_MEV = 0.100

true_mean = 0.5 * (PRE_MEV + POST_MEV)
claimed_low = PRE_MEV - EDEP_MEV
claimed_high = PRE_MEV
ledger_gap = (PRE_MEV - POST_MEV) - (EDEP_MEV + SECONDARY_MEV)
inside = claimed_low <= true_mean <= claimed_high

EVIDENCE.mkdir(exist_ok=True)
payload = {
    "schema": "g4usim_q2_ddd_withdrawn_bracket_counterexample_v1",
    "synthetic": True,
    "not_a_measured_step": True,
    "purpose": "show that the withdrawn [pre-Edep, pre] interval is not a bound "
               "on the step mean kinetic energy",
    "energy_ledger_MeV": {
        "pre_kinetic": PRE_MEV,
        "post_kinetic": POST_MEV,
        "local_edep": EDEP_MEV,
        "secondary_kinetic": SECONDARY_MEV,
        "pre_minus_post": PRE_MEV - POST_MEV,
        "edep_plus_secondary": EDEP_MEV + SECONDARY_MEV,
        "closure_error_MeV": ledger_gap,
        "energy_conserved": abs(ledger_gap) < 1e-12,
    },
    "withdrawn_claim": "step mean kinetic energy lies in [pre - Edep, pre]",
    "claimed_interval_MeV": [claimed_low, claimed_high],
    "true_step_mean_kinetic_energy_MeV": true_mean,
    "true_mean_inside_claimed_interval": inside,
    "counterexample_valid": abs(ledger_gap) < 1e-12 and not inside,
    "why_the_claim_fails": "local Edep excludes kinetic energy carried by explicit "
                           "secondaries, so the post-step kinetic energy is not "
                           "pre - Edep",
    "used_in": "out/collab/q2-reference-ddd-v1/compare.py limited check "
               "MOM-<case>-FOLDING-STEPWISE",
    "review": "docs/collab/reviews/20261105-q2-ddd-reference-review-r1.md",
    "archived_evidence": "docs/verification/q2-ddd-review-20261105/first-counterexample/README.md",
}
path = EVIDENCE / "withdrawn-bracket-counterexample.json"
path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: payload[key] for key in
                  ("counterexample_valid", "claimed_interval_MeV",
                   "true_step_mean_kinetic_energy_MeV",
                   "true_mean_inside_claimed_interval")}, indent=2))
print("written:", path.relative_to(BASE))
raise SystemExit(0 if payload["counterexample_valid"] else 1)
