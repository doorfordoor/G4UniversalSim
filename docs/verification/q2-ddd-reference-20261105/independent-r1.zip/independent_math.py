"""Fixed DDD-case checks; step-mean energy is not available in hits CSV."""
from collections import defaultdict
from pathlib import Path
import bisect
import csv
import hashlib
import json
import math

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
checks = []


def require(name, valid):
    checks.append({"id": name, "status": "pass" if valid else "fail"})
    assert valid, name


def close(a, b):
    return math.isfinite(a) and math.isfinite(b) and abs(a - b) <= 1e-9 * max(abs(a), abs(b), 1e-300)


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def interp(x, xs, ys):
    i = max(0, min(len(xs) - 2, bisect.bisect_right(xs, x) - 1))
    assert xs[i] <= x <= xs[i + 1]
    fraction = math.log(x / xs[i]) / math.log(xs[i + 1] / xs[i])
    return math.exp(math.log(ys[i]) + fraction * math.log(ys[i + 1] / ys[i]))


def main():
    fp = ROOT / "docs/collab/decisions/20261105-q2-ddd-reference-freeze-v1.json"
    require("freeze-sha", hashlib.sha256(fp.read_bytes()).hexdigest() == "65877c33ad74111f5c567d060f495eccea074b378b3c5bd0b9bdd4f6e40b6a7c")
    f = json.loads(fp.read_text(encoding="utf-8-sig"))
    dp = fp.with_name(f["geometry_source_freeze"])
    require("dose-source-freeze-sha", hashlib.sha256(dp.read_bytes()).hexdigest() == f["geometry_source_freeze_sha256"])
    dose = json.loads(dp.read_text(encoding="utf-8-sig"))
    pstar = ROOT / dose["data_file"]
    require("pstar-sha", hashlib.sha256(pstar.read_bytes()).hexdigest() == dose["data_sha256"])
    table = []
    for line in pstar.read_text(encoding="ascii").splitlines():
        try:
            values = list(map(float, line.split()))
        except ValueError:
            continue
        if len(values) == 7:
            table.append(values)
    energies, ranges = ([row[i] for row in table] for i in (0, 4))
    np = ROOT / f["tables"]["proton"]["file"]
    require("niel-sha", hashlib.sha256(np.read_bytes()).hexdigest() == f["tables"]["proton"]["sha256"])
    with np.open(encoding="utf-8-sig") as handle:
        nr = list(csv.DictReader(line for line in handle if line.strip() and not line.startswith("#")))
    ne, nv = [float(row["energy_MeV"]) for row in nr], [float(row["niel_MeV_cm2_g"]) for row in nr]
    summaries = []
    for case in f["cases"]:
        name = case["case"]
        output = BASE / "runs" / name / "output"
        n = f["events_per_case"]
        volume = math.prod(f["slab_xy_mm"]) * case["slab_mm"]
        records = rows(output / "displacement_volume_summary_t0.csv")
        require(name + ":single-proton-channel", len(records) == 1 and records[0]["particle"] == "proton" and records[0]["volume_name"] == "Slab_PV")
        row = records[0]
        require(name + ":volume", close(float(row["volume_mm3"]), volume))
        require(name + ":actual-table-file", Path(row["niel_table"]).resolve() == np.resolve())
        require(name + ":no-out-of-range-length", float(row["out_of_range_track_length_mm"]) == 0)
        require(name + ":N", int(row["n_events"]) == n)
        hits = rows(output / "hits_t0.csv")
        require(name + ":sensitive-scope", bool(hits) and all(hit["volume"] == "Slab_PV" for hit in hits))
        proton = [hit for hit in hits if hit["particle"] == "proton"]
        require(name + ":unit-proton-weights", bool(proton) and all(float(hit["weight"]) == 1 for hit in proton))
        terms = defaultdict(list)
        for hit in proton:
            event, length = int(hit["eventID"]), float(hit["stepLength_mm"])
            assert 0 <= event < n and math.isfinite(length) and length > 0
            terms[event].append(length * float(hit["weight"]))
        length = math.fsum(math.fsum(values) for values in terms.values())
        require(name + ":weighted-proton-length", close(length, float(row["track_length_mm"])))
        total, squared = float(row["ddd_MeV_g"]), float(row["ddd_sum_sq_MeV2_g2"])
        variance = squared / total**2 - 1 / n
        assert variance > 0
        relative_error = math.sqrt(variance)
        for quantity in ["ddd_proton", "ddd_total"]:
            stat = next(x for x in rows(output / "scorer_statistics.csv") if x["scorer"] == "displacement" and x["quantity"] == quantity)
            require(name + ":" + quantity + ":N-entries", int(stat["n_events"]) == n and int(stat["entries"]) == len(terms))
            require(name + ":" + quantity + ":sum", close(float(stat["sum"]), total))
            require(name + ":" + quantity + ":squares", close(float(stat["sum_sq"]), squared))
            require(name + ":" + quantity + ":value", close(float(stat["value"]), total))
            require(name + ":" + quantity + ":error", close(float(stat["rel_error"]), relative_error))
            require(name + ":" + quantity + ":standard-error", close(float(stat["std_error"]), total * relative_error))
        depth = f["density_g_cm3"] * (case["buildup_mm"] + case["slab_mm"] / 2) / 10
        mid = interp(interp(case["energy_MeV"], energies, ranges) - depth, ranges, energies)
        reference = interp(mid, ne, nv)
        require(name + ":midpoint", close(mid, case["reference_mid_energy_MeV"]))
        require(name + ":reference", close(reference, case["reference_ddd_per_fluence_MeV_cm2_g"]))
        observed = total * f["source"]["area_cm2"] / n
        sigma = observed * relative_error
        threshold = 0.01 * reference + 3 * sigma
        require(name + ":reference-comparison", abs(observed - reference) <= threshold)
        summaries.append({"case": name, "N": n, "nonzero_proton_events": len(terms), "volume_mm3": volume, "proton_path_mm": length, "DDD_MeV_g": total, "public_moment_relative_error": relative_error, "reference": reference, "observed_per_fluence": observed, "sigma": sigma, "threshold": threshold, "implied_path_mean_niel_diagnostic": total * volume / (100 * length)})
    report = {"schema": "q2_ddd_independent_math_v1", "status": "pass", "scope": "length normalization and public-moment consistency plus table-reference comparison; not complete per-step folding or NIEL physical validation", "checks": checks, "cases": summaries}
    (BASE / "independent-math-results.json").write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print("independent math passed", len(checks), "checks", len(summaries), "cases")


if __name__ == "__main__":
    main()
