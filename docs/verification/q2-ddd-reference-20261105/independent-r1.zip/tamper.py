"""Negative controls for REF-DDD-01, run only on copies.

Each case mutates a private copy of the run output, identity or freeze and then
runs the same comparators.  An expected check must fail.  The original run
outputs are hashed before and after, so a tamper test can never be confused with
a real change to the frozen evidence.
"""

from __future__ import annotations

import copy
import hashlib
import json
import shutil
from pathlib import Path

import compare

BASE = Path(__file__).resolve().parent
TAMPERED = BASE / "tampered"
CASE = "ref_ddd_10"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def snapshot() -> dict[str, str]:
    files = sorted((BASE / "runs").rglob("*")) + sorted((BASE / "inputs").glob("*.ini"))
    files += [BASE / "identity.json", BASE / "reference-recompute.json", BASE / "results.json"]
    return {compare.relative(path): sha256(path) for path in files if path.is_file()}


def copy_output(name: str) -> dict:
    target = TAMPERED / name / "output"
    if target.exists():
        shutil.rmtree(target)
    source = compare.ROOT / json.loads((BASE / "results.json").read_text(encoding="utf-8"))[
        "cases"][CASE]["output_dir"]
    shutil.copytree(source, target)
    return {
        "path": compare.relative(target),
        "run": copy.deepcopy(json.loads((BASE / "results.json").read_text(encoding="utf-8"))),
    }


def refresh_record_artifacts(record: dict, output: Path) -> None:
    for item in record["artifacts"].values():
        path = compare.ROOT / item["path"]
        item["sha256"] = sha256(path)
        item["size_bytes"] = path.stat().st_size
    for key in ("run_summary_sha256", "run_metadata_sha256"):
        name = "run_summary.txt" if key.startswith("run_summary") else "run_metadata.json"
        record[key] = sha256(output / name) if (output / name).is_file() else None


def cases() -> list[dict]:
    result: list[dict] = []
    originals = json.loads((BASE / "results.json").read_text(encoding="utf-8"))
    identity = json.loads((BASE / "identity.json").read_text(encoding="utf-8"))
    freeze = json.loads(compare.FREEZE.read_text(encoding="utf-8"))

    # 1. Missing completion evidence file.
    copied = copy_output("missing_metadata")
    output = compare.ROOT / copied["path"]
    output.joinpath("run_metadata.json").unlink()
    copy_results = copied["run"]
    record = copy_results["cases"][CASE]
    record["artifacts"].pop("run_metadata.json", None)
    record["output_dir"] = copied["path"]
    record["run_metadata_sha256"] = None
    result.append({"name": "missing_metadata", "results": copy_results, "identity": identity,
                   "freeze": freeze,
                   "expect": ["EVID-METADATA-FILE"]})

    # 2. Volume factor in the DDD summary (copy only).
    copied = copy_output("volume_factor")
    output = compare.ROOT / copied["path"]
    csv_path = output / "displacement_volume_summary_t0.csv"
    lines = csv_path.read_text(encoding="utf-8").splitlines()
    fields = lines[1].split(",")
    fields[5] = str(float(fields[5]) * 2.0)
    lines[1] = ",".join(fields)
    csv_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    copy_results = copied["run"]
    record = copy_results["cases"][CASE]
    record["output_dir"] = copied["path"]
    refresh_record_artifacts(record, output)
    result.append({"name": "volume_factor", "results": copy_results, "identity": identity,
                   "freeze": freeze, "expect": ["MOM-DDD-VOLUME-COLUMN"]})

    # 3. Beam-area factor in the frozen source definition (copy only).
    copy_freeze = copy.deepcopy(freeze)
    copy_freeze["source"]["area_cm2"] = float(copy_freeze["source"]["area_cm2"]) * 100.0
    result.append({"name": "fluence_area_factor", "results": originals, "identity": identity,
                   "freeze": copy_freeze, "expect": ["REF-DDD-PHI-ABS"]})

    # 4. Reference number changed by +6% (copy only).
    copy_freeze = copy.deepcopy(freeze)
    for case in copy_freeze["cases"]:
        case["reference_ddd_per_fluence_MeV_cm2_g"] = (
            float(case["reference_ddd_per_fluence_MeV_cm2_g"]) * 1.06)
    result.append({"name": "reference_value", "results": originals, "identity": identity,
                   "freeze": copy_freeze, "expect": ["REF-DDD-PHI-ABS"]})

    # 5. NIEL table identity changed in the recorded provenance (copy only).
    copy_identity = copy.deepcopy(identity)
    copy_identity["tables"]["proton"]["sha256"] = "0" * 64
    result.append({"name": "identity_table_sha", "results": originals,
                   "identity": copy_identity, "freeze": freeze,
                   "expect": ["ID-TABLE-SHA-PROTON"]})

    # 6. Completed events rewritten in a summary copy.
    copied = copy_output("completion_evidence")
    output = compare.ROOT / copied["path"]
    summary_path = output / "run_summary.txt"
    summary = summary_path.read_text(encoding="utf-8").splitlines()
    summary = [line.replace("run_0_completed_events = 20000", "run_0_completed_events = 19999")
               .replace("actual_completed_event_count = 20000", "actual_completed_event_count = 19999")
               for line in summary]
    summary_path.write_text("\n".join(summary) + "\n", encoding="utf-8")
    copy_results = copied["run"]
    record = copy_results["cases"][CASE]
    record["output_dir"] = copied["path"]
    refresh_record_artifacts(record, output)
    result.append({"name": "completion_evidence", "results": copy_results, "identity": identity,
                   "freeze": freeze,
                   "expect": ["EVID-RUN-0-COMPLETED-EVENTS", "EVID-ACTUAL-COMPLETED-EVENT-COUNT"]})

    # 7. Output artifact mutated after it was recorded.
    copied = copy_output("artifact_sha")
    output = compare.ROOT / copied["path"]
    hits_path = output / "hits_t0.csv"
    hits_path.write_bytes(hits_path.read_bytes() +
                          b"0,0,0,0,proton,1,0,0.1,0,0,0,0,0,0.1,0,0,1,99.9,msc,Slab_PV,1\n")
    copy_results = copied["run"]
    record = copy_results["cases"][CASE]
    record["output_dir"] = copied["path"]
    # Point the recorded artifact at the modified copy but keep the original digest:
    # the comparator must notice the file no longer matches its recorded hash.
    record["artifacts"]["hits_t0.csv"]["path"] = compare.relative(hits_path)
    result.append({"name": "artifact_sha", "results": copy_results, "identity": identity,
                   "freeze": freeze, "expect": ["EVID-RECORDED-hits_t0.csv"]})
    return result


def main() -> int:
    before = snapshot()
    originals = json.loads((BASE / "results.json").read_text(encoding="utf-8"))
    identity = json.loads((BASE / "identity.json").read_text(encoding="utf-8"))
    freeze = json.loads(compare.FREEZE.read_text(encoding="utf-8"))
    baseline = compare.evaluate(originals, freeze, identity)
    baseline_ok = (baseline["status"] == "limited" and baseline["checks_failed"] == 0
                   and baseline["checks_limited"] > 0)
    outcomes: list[dict] = []
    failed_expectations: list[str] = []
    for item in cases():
        evaluation = compare.evaluate(item["results"], item["freeze"], item["identity"])
        checks = evaluation["checks"]
        failed_statuses = {entry["id"] for entry in checks if entry["status"] == "fail"}
        present_statuses = {entry["id"]: entry["status"] for entry in checks}
        hit = [expected for expected in item["expect"] if expected in failed_statuses]
        # A `limited` entry must never be accepted as negative-control
        # detection: only an actual fail counts.  An id can appear once per case,
        # so match the set of failed ids rather than one dictionary value.
        not_real_fail = [expected for expected in item["expect"]
                         if expected in present_statuses
                         and expected not in failed_statuses]
        passed = bool(hit) and not not_real_fail
        if not passed:
            failed_expectations.append(item["name"])
        outcomes.append({
            "name": item["name"],
            "expected_checks": item["expect"],
            "matched_checks": hit,
            "expected_that_were_not_real_fail": not_real_fail,
            "evaluation_status": evaluation["status"],
            "checks_pass": evaluation["checks_pass"],
            "checks_failed": evaluation["checks_failed"],
            "checks_limited": evaluation["checks_limited"],
            "failed_ids": evaluation["failed_ids"],
            "limited_ids": evaluation["limited_ids"],
            "status": "pass" if passed else "fail",
        })
        print(f"{item['name']}: expected={item['expect']} matched={hit} "
              f"evaluation={evaluation['status']} failed={evaluation['checks_failed']} "
              f"limited={evaluation['checks_limited']}")
        shutil.rmtree(TAMPERED / item["name"], ignore_errors=True)
    after = snapshot()
    originals_unchanged = before == after
    payload = {
        "schema": "g4usim_q2_ref_ddd_tamper_v2",
        "originals_unchanged": originals_unchanged,
        "baseline": {
            "status": baseline["status"],
            "checks_total": baseline["checks_total"],
            "checks_pass": baseline["checks_pass"],
            "checks_failed": baseline["checks_failed"],
            "checks_limited": baseline["checks_limited"],
            "limited_ids": baseline["limited_ids"],
            "zero_real_failures": baseline["checks_failed"] == 0,
            "expected_limited_baseline": baseline_ok,
        },
        "cases": outcomes,
        "status": ("pass" if baseline_ok and not failed_expectations
                   and originals_unchanged else "fail"),
        "failed_expectations": failed_expectations,
    }
    (BASE / "tamper-results.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": payload["status"], "originals_unchanged": originals_unchanged,
                      "failed_expectations": failed_expectations}, indent=2))
    return 0 if payload["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
