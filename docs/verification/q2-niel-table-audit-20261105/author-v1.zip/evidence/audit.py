#!/usr/bin/env python3
"""REF-DDD-02: read-only audit of the two silicon NIEL tables.

Scope (frozen by docs/collab/decisions/20261105-q2-niel-table-audit-freeze-v1.json):
  * structure: exact CSV header, frozen row counts and energy domains, strictly
    increasing positive energies, finite non-negative NIEL values;
  * arithmetic: independently recompute the frozen 95 MeV*mb hypothetical input
    (mass NIEL) and the neutron-table 1 MeV log-log / linear interpolations from
    the raw table nodes, with 1e-6 relative tolerance;
  * physical evaluation: expressly limited - the audit does not and cannot
    validate the NIEL model, the ASTM E722-19 table content, or the provenance
    claims copied into the CSV comment block.

No Geant4 is executed. The data tables are opened read-only and never rewritten.
"""

from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Any

BASE = Path(__file__).resolve().parent
REPO = BASE.parents[2]
FREEZE_PATH = REPO / "docs/collab/decisions/20261105-q2-niel-table-audit-freeze-v1.json"
PROTON_PATH = REPO / "scenarios/semiconductor/niel/si_proton.csv"
NEUTRON_PATH = REPO / "scenarios/semiconductor/niel/si_neutron.csv"

EXPECTED_HEADER = "energy_MeV,niel_MeV_cm2_g"
RELATIVE_TOLERANCE = 1e-6
STRUCTURAL_TOLERANCE = 1e-12
MB_TO_CM2 = 1e-27  # 1 mb = 1e-27 cm^2
MEV_MB_TO_MEV_CM2 = MB_TO_CM2  # 1 MeV*mb = 1e-27 MeV*cm^2
ATOMIC_MASS_UNIT_G = 1.6605390666e-24


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def close_to(actual: float, expected: float, tolerance: float = RELATIVE_TOLERANCE) -> bool:
    """Relative comparison that also accepts exact zero equality."""
    if actual == expected:
        return True
    if expected == 0.0 or not math.isfinite(actual) or not math.isfinite(expected):
        return False
    return abs(actual - expected) <= tolerance * abs(expected)


def check(checks: list[dict[str, Any]], cid: str, status: str, detail: str) -> None:
    if status not in {"pass", "fail", "limited"}:
        raise ValueError(f"bad check status: {status}")
    checks.append({"id": cid, "status": status, "detail": detail})


def read_table(path: Path) -> dict[str, Any]:
    """Parse a two-column NIEL CSV with a leading comment block.

    The parser never edits the file; all raw text needed for identity is kept.
    """
    raw = path.read_bytes()
    text = raw.decode("utf-8")
    lines = text.split("\n")
    comments: list[str] = []
    header: str | None = None
    rows: list[tuple[float, float]] = []
    row_numbers: list[int] = []
    malformed: list[dict[str, Any]] = []
    for number, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#"):
            comments.append(stripped)
            continue
        if header is None:
            header = stripped
            continue
        parts = [part.strip() for part in stripped.split(",")]
        if len(parts) != 2:
            malformed.append({"line": number, "text": stripped, "reason": "expected 2 columns"})
            continue
        try:
            energy = float(parts[0])
            value = float(parts[1])
        except ValueError:
            malformed.append({"line": number, "text": stripped, "reason": "non-numeric field"})
            continue
        rows.append((energy, value))
        row_numbers.append(number)
    return {
        "file": str(path),
        "sha256": sha256_bytes(raw),
        "bytes": len(raw),
        "comments": comments,
        "header": header,
        "rows": rows,
        "row_numbers": row_numbers,
        "malformed": malformed,
        "line_endings": "crlf" if b"\r\n" in raw else "lf",
        "trailing_newline": raw.endswith(b"\n"),
    }


def provenance_claims(table: dict[str, Any]) -> dict[str, Any]:
    """Record CSVs' provenance comments as claims; never treat them as verification."""
    joined = "\n".join(table["comments"])
    claims = {
        "sr_niel_calculator": "sr-niel" in joined.lower(),
        "sr_niel_version_11_1": "SR-NIEL-7 ver. 11.1" in joined,
        "retrieved_2026_10_22": "retrieved 2026-10-22" in joined,
    }
    if table["file"].endswith("si_proton.csv"):
        claims.update(
            {
                "displacement_threshold_21_ev": "Displacement Threshold Energies [eV]: 21.00" in joined,
                "hadron_coulomb_model": "IonModel Selected : Hadron+Coulomb" in joined,
                "added_1ev_zero_row_documented": "added: 1e-06 MeV" in joined,
            }
        )
    else:
        claims.update(
            {
                "astm_e722_19": "ASTM E722-19" in joined,
                "displacement_threshold_declared": "Displacement Threshold Energies [eV]:" in joined,
            }
        )
    claims["note"] = (
        "Comment lines are source claims copied from the calculator output; they are "
        "recorded for identity only and are not independent physical evidence."
    )
    return claims


def structure_checks(
    name: str,
    table: dict[str, Any],
    frozen: dict[str, Any],
    checks: list[dict[str, Any]],
) -> None:
    label = name.upper()
    check(
        checks,
        f"ID-TABLE-FILE-{label}",
        "pass" if Path(table["file"]).is_file() else "fail",
        f"file={Path(table['file']).as_posix()}",
    )
    expected_sha = frozen["sha256"]
    actual_sha = table["sha256"]
    check(
        checks,
        f"ID-TABLE-SHA-{label}",
        "pass" if actual_sha == expected_sha else "fail",
        f"sha256={actual_sha} frozen={expected_sha}",
    )
    header_ok = table["header"] == EXPECTED_HEADER
    check(
        checks,
        f"STRUCT-HEADER-{label}",
        "pass" if header_ok else "fail",
        f"header={table['header']!r} expected={EXPECTED_HEADER!r}",
    )
    rows = table["rows"]
    row_count = len(rows)
    check(
        checks,
        f"STRUCT-ROWS-{label}",
        "pass" if row_count == frozen["rows"] else "fail",
        f"data_rows={row_count} frozen={frozen['rows']}",
    )
    malformed = table["malformed"]
    check(
        checks,
        f"STRUCT-NO-MALFORMED-{label}",
        "pass" if not malformed else "fail",
        f"malformed_rows={len(malformed)}" + (f" first={malformed[0]}" if malformed else ""),
    )
    energies = [row[0] for row in rows]
    values = [row[1] for row in rows]
    increasing = all(
        math.isfinite(a) and math.isfinite(b) and b > a for a, b in zip(energies, energies[1:])
    ) and all(math.isfinite(e) and e > 0.0 for e in energies)
    check(
        checks,
        f"STRUCT-ENERGY-INCREASING-{label}",
        "pass" if increasing else "fail",
        f"energies={row_count} positive={all(e > 0 for e in energies)} "
        f"strictly_increasing={increasing} first={energies[0] if energies else None} "
        f"last={energies[-1] if energies else None}",
    )
    finite_nonneg = all(math.isfinite(v) and v >= 0.0 for v in values)
    check(
        checks,
        f"STRUCT-NIEL-FINITE-NONNEG-{label}",
        "pass" if finite_nonneg else "fail",
        f"values={row_count} finite_non_negative={finite_nonneg} "
        f"min={min(values) if values else None} max={max(values) if values else None}",
    )
    frozen_lo, frozen_hi = frozen["energy_domain_MeV"]
    if rows:
        lo_ok = close_to(energies[0], frozen_lo, STRUCTURAL_TOLERANCE)
        hi_ok = close_to(energies[-1], frozen_hi, STRUCTURAL_TOLERANCE)
    else:
        lo_ok = hi_ok = False
    check(
        checks,
        f"STRUCT-DOMAIN-{label}",
        "pass" if lo_ok and hi_ok else "fail",
        f"domain_MeV=[{energies[0] if rows else None}, {energies[-1] if rows else None}] "
        f"frozen=[{frozen_lo}, {frozen_hi}]",
    )
    claims = provenance_claims(table)
    missing = [key for key, value in claims.items() if value is False]
    check(
        checks,
        f"ID-PROVENANCE-CLAIM-{label}",
        "pass" if not missing else "fail",
        f"claims_missing={missing} note=claims only, not independent verification",
    )


def find_node(rows: list[tuple[float, float]], energy: float) -> tuple[float, float] | None:
    for row_energy, row_value in rows:
        if close_to(row_energy, energy, STRUCTURAL_TOLERANCE):
            return row_energy, row_value
    return None


def arithmetic_checks(
    freeze: dict[str, Any],
    tables: dict[str, dict[str, Any]],
    mb_to_cm2: float,
    checks: list[dict[str, Any]],
) -> dict[str, Any]:
    expected = freeze["expected"]
    neutron_rows = tables["neutron"]["rows"]
    atomic_weight = freeze["hypothetical_input"]["silicon_atomic_weight_u"]
    atomic_mass_unit = freeze["hypothetical_input"]["atomic_mass_unit_g"]
    damage_cross_section = freeze["hypothetical_input"]["damage_cross_section_MeV_mb"]

    atom_mass = atomic_weight * atomic_mass_unit
    check(
        checks,
        "AR-SI-ATOM-MASS",
        "pass" if close_to(atom_mass, expected["Si_atom_mass_g"]) else "fail",
        f"formula=A[Si]*u={atomic_weight}*{atomic_mass_unit} g value={atom_mass!r} "
        f"frozen={expected['Si_atom_mass_g']!r}",
    )

    # 95 MeV*mb is an energy*area product: 1 mb = 1e-27 cm^2, so the product is
    # 95 * 1e-27 MeV*cm^2 per Si atom before dividing by the atom mass.
    mass_niel = damage_cross_section * mb_to_cm2 / atom_mass
    check(
        checks,
        "AR-MB-CM2-FACTOR",
        "pass" if mb_to_cm2 == MB_TO_CM2 else "fail",
        f"1 mb = {mb_to_cm2:g} cm^2; 1 MeV*mb = {mb_to_cm2:g} MeV*cm^2",
    )
    check(
        checks,
        "AR-95-MEV-MB-TO-NIEL",
        "pass" if close_to(mass_niel, expected["hypothetical_mass_niel_MeV_cm2_g"]) else "fail",
        f"formula=({damage_cross_section} MeV*mb * {mb_to_cm2:g} cm^2/mb) / {atom_mass!r} g "
        f"value={mass_niel!r} MeV*cm^2/g frozen={expected['hypothetical_mass_niel_MeV_cm2_g']!r}",
    )

    nodes = expected["bracketing_nodes"]
    node_lo = find_node(neutron_rows, nodes[0])
    node_hi = find_node(neutron_rows, nodes[1])
    nodes_ok = (
        node_lo is not None
        and node_hi is not None
        and close_to(node_lo[1], nodes[2], STRUCTURAL_TOLERANCE)
        and close_to(node_hi[1], nodes[3], STRUCTURAL_TOLERANCE)
    )
    check(
        checks,
        "AR-NEUTRON-NODES",
        "pass" if nodes_ok else "fail",
        f"frozen_nodes=[{nodes[0]}, {nodes[1]}] values=[{nodes[2]}, {nodes[3]}] "
        f"observed=[{node_lo}, {node_hi}]",
    )

    loglog = linear = None
    if node_lo is not None and node_hi is not None:
        e0, v0 = node_lo
        e1, v1 = node_hi
        target = 1.0
        loglog = math.exp(
            math.log(v0) + math.log(target / e0) / math.log(e1 / e0) * math.log(v1 / v0)
        )
        linear = v0 + (target - e0) / (e1 - e0) * (v1 - v0)
    check(
        checks,
        "AR-NEUTRON-1MEV-LOGLOG",
        "pass" if loglog is not None and close_to(loglog, expected["neutron_1MeV_loglog"]) else "fail",
        "definition=ln y = ln y0 + ln(E/E0)/ln(E1/E0) * (ln y1 - ln y0), E=1 MeV, "
        f"units=MeV*cm^2/g value={loglog!r} frozen={expected['neutron_1MeV_loglog']!r}",
    )
    check(
        checks,
        "AR-NEUTRON-1MEV-LINEAR",
        "pass" if linear is not None and close_to(linear, expected["neutron_1MeV_linear"]) else "fail",
        "definition=y = y0 + (E-E0)/(E1-E0) * (y1-y0), E=1 MeV, units=MeV*cm^2/g "
        f"value={linear!r} frozen={expected['neutron_1MeV_linear']!r}",
    )
    relative_difference = None
    if loglog is not None and linear is not None and loglog != 0.0:
        relative_difference = (linear - loglog) / loglog
    check(
        checks,
        "AR-NEUTRON-1MEV-ALGORITHM-RELDIFF",
        "pass"
        if relative_difference is not None
        and close_to(relative_difference, expected["relative_difference_linear_over_loglog"])
        else "fail",
        "definition=(linear-loglog)/loglog dimensionless "
        f"value={relative_difference!r} frozen={expected['relative_difference_linear_over_loglog']!r}",
    )

    point_difference_loglog = None
    point_difference_linear = None
    if loglog is not None and mass_niel != 0.0:
        point_difference_loglog = loglog - mass_niel
        point_difference_linear = linear - mass_niel
    return {
        "si_atom_mass": {
            "formula": "A[Si] * atomic_mass_unit",
            "atomic_weight_u": atomic_weight,
            "atomic_mass_unit_g": atomic_mass_unit,
            "value_g": atom_mass,
            "frozen_value_g": expected["Si_atom_mass_g"],
        },
        "hypothetical_95_MeV_mb": {
            "input": freeze["hypothetical_input"],
            "unit_conversion": {
                "1_mb_cm2": mb_to_cm2,
                "MeV_mb_to_MeV_cm2": "1 MeV*mb = 1e-27 MeV*cm^2 (area 1 mb times energy)",
            },
            "formula": "(95 MeV*mb * 1e-27 cm^2/mb) / m_Si",
            "value_MeV_cm2_g": mass_niel,
            "frozen_value_MeV_cm2_g": expected["hypothetical_mass_niel_MeV_cm2_g"],
            "relative_difference": mass_niel / expected["hypothetical_mass_niel_MeV_cm2_g"] - 1.0,
        },
        "neutron_1MeV": {
            "nodes_MeV_cm2_g": [
                {"energy_MeV": node_lo[0], "niel_MeV_cm2_g": node_lo[1]} if node_lo else None,
                {"energy_MeV": node_hi[0], "niel_MeV_cm2_g": node_hi[1]} if node_hi else None,
            ],
            "interpolations": {
                "loglog": {
                    "definition": "ln y = ln y0 + ln(E/E0)/ln(E1/E0) * (ln y1 - ln y0)",
                    "value_MeV_cm2_g": loglog,
                },
                "linear": {
                    "definition": "y = y0 + (E-E0)/(E1-E0) * (y1-y0)",
                    "value_MeV_cm2_g": linear,
                },
            },
            "algorithm_relative_difference_linear_over_loglog": {
                "definition": "(linear - loglog) / loglog",
                "value": relative_difference,
            },
        },
        "point_differences_not_a_physical_result": {
            "note": (
                "Absolute differences of the 1 MeV neutron-table interpolations versus the "
                "hypothetical 95 MeV*mb input. They are arithmetic point differences, are not "
                "an algorithm-relative comparison and do not identify an evaluation/model cause "
                "or a defect."
            ),
            "loglog_minus_hypothetical_MeV_cm2_g": point_difference_loglog,
            "linear_minus_hypothetical_MeV_cm2_g": point_difference_linear,
            "loglog_relative_percent": (
                None if point_difference_loglog is None else point_difference_loglog / mass_niel * 100.0
            ),
            "linear_relative_percent": (
                None if point_difference_linear is None else point_difference_linear / mass_niel * 100.0
            ),
        },
    }


def physical_limitations() -> list[dict[str, Any]]:
    return [
        {
            "id": "PHY-95-INPUT-NOT-VERIFIED",
            "status": "limited",
            "detail": (
                "The 95 MeV*mb ASTM input is frozen as 'unverified ASTM input; arithmetic "
                "exercise only'. No authoritative full-text ASTM value was consulted or "
                "numerically verified in this audit."
            ),
        },
        {
            "id": "PHY-TABLE-MODEL-NOT-INDEPENDENTLY-CHECKED",
            "status": "limited",
            "detail": (
                "No independent numerical validation of the ASTM E722-19 Table A1.1 content "
                "or of the SR-NIEL evaluation/model choices was performed. The CSV comment "
                "block only records provenance claims; it is not independent physical evidence."
            ),
        },
        {
            "id": "PHY-NO-PHYSICAL-PASS-THRESHOLD",
            "status": "limited",
            "detail": (
                "The frozen contract defines no physical pass/fail threshold. This audit can "
                "only report structure and arithmetic; it cannot certify NIEL physics."
            ),
        },
    ]


def evaluate(
    freeze_path: Path = FREEZE_PATH,
    proton_path: Path = PROTON_PATH,
    neutron_path: Path = NEUTRON_PATH,
    mb_to_cm2: float = MB_TO_CM2,
) -> dict[str, Any]:
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    checks: list[dict[str, Any]] = []
    tables = {
        "proton": read_table(proton_path),
        "neutron": read_table(neutron_path),
    }

    check(
        checks,
        "ID-FREEZE-SCHEMA",
        "pass" if freeze.get("schema") == "q2_niel_table_audit_preregister_v1" else "fail",
        f"schema={freeze.get('schema')!r}",
    )
    check(
        checks,
        "ID-FREEZE-SHA",
        "pass" if sha256_file(freeze_path) == sha256_file(FREEZE_PATH) else "fail",
        f"freeze_sha256={sha256_file(freeze_path)} current={sha256_file(FREEZE_PATH)}",
    )
    for name in ("proton", "neutron"):
        structure_checks(name, tables[name], freeze["tables"][name], checks)
    arithmetic = arithmetic_checks(freeze, tables, mb_to_cm2, checks)
    limited = physical_limitations()

    all_checks = checks + limited
    counts = {"pass": 0, "fail": 0, "limited": 0}
    for item in all_checks:
        counts[item["status"]] += 1
    overall = "fail" if counts["fail"] else ("limited" if counts["limited"] else "pass")
    return {
        "schema": "q2_niel_table_audit_results_v1",
        "case": freeze.get("case", "REF-DDD-02"),
        "freeze": {
            "file": "docs/collab/decisions/20261105-q2-niel-table-audit-freeze-v1.json",
            "sha256": sha256_file(freeze_path),
            "schema": freeze.get("schema"),
        },
        "tables": {
            name: {
                "file": Path(table["file"]).name,
                "sha256": table["sha256"],
                "bytes": table["bytes"],
                "data_rows": len(table["rows"]),
                "header": table["header"],
                "line_endings": table["line_endings"],
                "trailing_newline": table["trailing_newline"],
                "comment_lines": len(table["comments"]),
                "energy_domain_MeV": [
                    table["rows"][0][0] if table["rows"] else None,
                    table["rows"][-1][0] if table["rows"] else None,
                ],
                "provenance_claims": provenance_claims(table),
            }
            for name, table in tables.items()
        },
        "structure": {
            name: {
                "header": table["header"],
                "data_rows": len(table["rows"]),
                "first_row": list(table["rows"][0]) if table["rows"] else None,
                "last_row": list(table["rows"][-1]) if table["rows"] else None,
                "malformed": table["malformed"],
            }
            for name, table in tables.items()
        },
        "arithmetic": arithmetic,
        "checks": all_checks,
        "counts": counts,
        "status": overall,
        "status_detail": {
            "structure_and_arithmetic": "fail" if counts["fail"] else "pass",
            "physical_evaluation": "limited",
            "note": (
                "Overall is limited whenever the frozen physical-evaluation scope is limited "
                "even if every structure and arithmetic check passes; this is not a NIEL "
                "physics validation pass."
            ),
        },
    }


def identity(freeze: dict[str, Any] | None = None) -> dict[str, Any]:
    freeze = freeze or json.loads(FREEZE_PATH.read_text(encoding="utf-8"))
    tables = {}
    for name, path in (("proton", PROTON_PATH), ("neutron", NEUTRON_PATH)):
        parsed = read_table(path)
        tables[name] = {
            "file": f"scenarios/semiconductor/niel/{path.name}",
            "sha256": parsed["sha256"],
            "bytes": parsed["bytes"],
            "data_rows": len(parsed["rows"]),
            "header": parsed["header"],
            "comments": parsed["comments"],
            "energy_domain_MeV": [
                parsed["rows"][0][0] if parsed["rows"] else None,
                parsed["rows"][-1][0] if parsed["rows"] else None,
            ],
            "provenance_claims": provenance_claims(parsed),
        }
    return {
        "schema": "q2_niel_table_audit_identity_v1",
        "case": freeze.get("case", "REF-DDD-02"),
        "freeze": {
            "file": "docs/collab/decisions/20261105-q2-niel-table-audit-freeze-v1.json",
            "sha256": sha256_file(FREEZE_PATH),
            "schema": freeze.get("schema"),
        },
        "tables": tables,
        "note": (
            "Provenance claims are copied text from the CSV comment block. They identify the "
            "source request but are not independent verification of the NIEL evaluation."
        ),
    }


def summarize(results: dict[str, Any]) -> str:
    counts = results["counts"]
    lines = [
        f"REF-DDD-02 read-only NIEL table audit: status={results['status']}",
        f"checks: pass={counts['pass']} fail={counts['fail']} limited={counts['limited']}",
        "structure+arithmetic: " + results["status_detail"]["structure_and_arithmetic"]
        + " | physical evaluation: limited (no physical pass/fail threshold)",
    ]
    ar = results["arithmetic"]
    lines.append(
        f"atom_mass={ar['si_atom_mass']['value_g']!r} g  "
        f"95MeV*mb->{ar['hypothetical_95_MeV_mb']['value_MeV_cm2_g']!r} MeV*cm^2/g"
    )
    neutron = ar["neutron_1MeV"]
    lines.append(
        f"neutron 1 MeV: loglog={neutron['interpolations']['loglog']['value_MeV_cm2_g']!r} "
        f"linear={neutron['interpolations']['linear']['value_MeV_cm2_g']!r} "
        "rel_diff="
        f"{neutron['algorithm_relative_difference_linear_over_loglog']['value']!r}"
    )
    for item in results["checks"]:
        if item["status"] == "fail":
            lines.append(f"FAIL {item['id']}: {item['detail']}")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(
        description="REF-DDD-02 read-only audit of the two silicon NIEL tables (no Geant4 run)."
    )
    parser.parse_args(argv)  # this audit intentionally takes no command-line options
    results = evaluate()
    (BASE / "results.json").write_text(
        json.dumps(results, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (BASE / "identity.json").write_text(
        json.dumps(identity(), indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(summarize(results))
    print(
        "exit 1 = overall limited, not a script error: structure/arithmetic pass, "
        "physical evaluation is limited by the frozen scope"
        if results["status"] != "fail"
        else "exit 1 = one or more structure/arithmetic checks failed"
    )
    return 1 if results["status"] in {"fail", "limited"} else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
