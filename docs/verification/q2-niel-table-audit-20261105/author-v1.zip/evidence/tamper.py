#!/usr/bin/env python3
"""Counterexamples for REF-DDD-02 audit machinery.

Every case must produce a real ``fail`` in the expected check id (a baseline
``limited`` status can never stand in for a detection). Mutations happen only in
throw-away copies under ``tampered/``; the frozen data tables are never edited.
"""

from __future__ import annotations

import hashlib
import json
import shutil
import sys
from pathlib import Path

import audit

BASE = Path(__file__).resolve().parent
TAMPERED = BASE / "tampered"


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def failed_ids(results: dict) -> list[str]:
    return [item["id"] for item in results["checks"] if item["status"] == "fail"]


def write_case(name: str, proton_source: Path, neutron_source: Path, *, proton=None, neutron=None):
    case_dir = TAMPERED / name
    case_dir.mkdir(parents=True, exist_ok=True)
    proton_copy = case_dir / "si_proton.csv"
    neutron_copy = case_dir / "si_neutron.csv"
    shutil.copyfile(proton_source, proton_copy)
    shutil.copyfile(neutron_source, neutron_copy)
    if proton is not None:
        proton_copy.write_text(proton(proton_copy.read_text(encoding="utf-8")), encoding="utf-8")
    if neutron is not None:
        neutron_copy.write_text(neutron(neutron_copy.read_text(encoding="utf-8")), encoding="utf-8")
    return proton_copy, neutron_copy


def header_case(text: str) -> str:
    return text.replace(audit.EXPECTED_HEADER, "energy_MeV,niel_MeV_cm2", 1)


def non_monotonic_case(text: str) -> str:
    lines = text.split("\n")
    data_indexes = [i for i, line in enumerate(lines) if line and not line.startswith("#")]
    header_index, first_data = data_indexes[0], data_indexes[1]
    second = lines[first_data]
    lines[first_data + 1] = second  # duplicate the first energy: no longer strictly increasing
    assert lines[header_index] == audit.EXPECTED_HEADER
    return "\n".join(lines)


def non_finite_case(text: str) -> str:
    lines = text.split("\n")
    data_indexes = [i for i, line in enumerate(lines) if line and not line.startswith("#")]
    first_data = data_indexes[1]
    parts = lines[first_data].split(",")
    lines[first_data] = f"{parts[0]},nan"
    return "\n".join(lines)


def sha_change_case(text: str) -> str:
    lines = text.split("\n")
    data_indexes = [i for i, line in enumerate(lines) if line and not line.startswith("#")]
    last_data = data_indexes[-1]
    energy, value = lines[last_data].split(",")
    lines[last_data] = f"{energy},{float(value) + 1e-6:g}"
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    if TAMPERED.exists():
        shutil.rmtree(TAMPERED)
    originals_before = {
        "proton": sha256_file(audit.PROTON_PATH),
        "neutron": sha256_file(audit.NEUTRON_PATH),
    }
    baseline = audit.evaluate()
    baseline_failed = failed_ids(baseline)
    cases = []

    def record(name: str, mutation: str, results: dict, expected: list[str]) -> None:
        detected = [cid for cid in expected if cid in failed_ids(results)]
        cases.append(
            {
                "name": name,
                "mutation": mutation,
                "expected_failed_ids": expected,
                "failed_ids": failed_ids(results),
                "detected_expected": detected,
                "detected": len(detected) == len(expected),
                "status": results["status"],
            }
        )

    # 1. wrong unit factor: mb treated as barn (1e-24 cm^2 instead of 1e-27 cm^2).
    record(
        "wrong_unit_factor",
        "arithmetic evaluated with 1 mb = 1e-24 cm^2 (barn) instead of 1e-27 cm^2",
        audit.evaluate(mb_to_cm2=1e-24),
        ["AR-MB-CM2-FACTOR", "AR-95-MEV-MB-TO-NIEL"],
    )

    # 2. table SHA change: one NIEL value bumped in a copy.
    proton_copy, neutron_copy = write_case(
        "table_sha_changed", audit.PROTON_PATH, audit.NEUTRON_PATH, neutron=sha_change_case
    )
    record(
        "table_sha_changed",
        "neutron copy last NIEL value +1e-6 MeV*cm^2/g",
        audit.evaluate(proton_path=proton_copy, neutron_path=neutron_copy),
        ["ID-TABLE-SHA-NEUTRON"],
    )

    # 3. non-monotonic energies in a copy.
    proton_copy, neutron_copy = write_case(
        "non_monotonic", audit.PROTON_PATH, audit.NEUTRON_PATH, proton=non_monotonic_case
    )
    record(
        "non_monotonic",
        "proton copy repeats the first data-row energy (not strictly increasing)",
        audit.evaluate(proton_path=proton_copy, neutron_path=neutron_copy),
        ["STRUCT-ENERGY-INCREASING-PROTON"],
    )

    # 4. non-finite NIEL value in a copy.
    proton_copy, neutron_copy = write_case(
        "non_finite", audit.PROTON_PATH, audit.NEUTRON_PATH, proton=non_finite_case
    )
    record(
        "non_finite",
        "proton copy first-data-row NIEL replaced by nan",
        audit.evaluate(proton_path=proton_copy, neutron_path=neutron_copy),
        ["STRUCT-NIEL-FINITE-NONNEG-PROTON"],
    )

    # 5. wrong header in a copy.
    proton_copy, neutron_copy = write_case(
        "header_changed", audit.PROTON_PATH, audit.NEUTRON_PATH, neutron=header_case
    )
    record(
        "header_changed",
        "neutron copy header renamed to energy_MeV,niel_MeV_cm2",
        audit.evaluate(proton_path=proton_copy, neutron_path=neutron_copy),
        ["STRUCT-HEADER-NEUTRON"],
    )

    originals_after = {
        "proton": sha256_file(audit.PROTON_PATH),
        "neutron": sha256_file(audit.NEUTRON_PATH),
    }
    shutil.rmtree(TAMPERED, ignore_errors=True)

    baseline_ok = baseline["status"] == "limited" and not baseline_failed
    detected_all = all(case["detected"] for case in cases)
    originals_unchanged = originals_before == originals_after
    status = "pass" if baseline_ok and detected_all and originals_unchanged else "fail"
    payload = {
        "schema": "q2_niel_table_audit_tamper_v1",
        "baseline": {
            "status": baseline["status"],
            "counts": baseline["counts"],
            "failed_ids": baseline_failed,
            "limited_ids": [item["id"] for item in baseline["checks"] if item["status"] == "limited"],
        },
        "cases": cases,
        "originals_before": originals_before,
        "originals_after": originals_after,
        "originals_unchanged": originals_unchanged,
        "status": status,
    }
    (BASE / "tamper-results.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    for case in cases:
        print(
            f"{case['name']}: detected={case['detected']} status={case['status']} "
            f"failed_ids={case['failed_ids']}"
        )
    print(f"baseline: {baseline['status']} {baseline['counts']} failed={baseline_failed}")
    print(f"originals_unchanged={originals_unchanged} overall={status}")
    return 0 if status == "pass" else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
