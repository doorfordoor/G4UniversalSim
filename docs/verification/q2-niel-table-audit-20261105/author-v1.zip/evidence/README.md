# REF-DDD-02：硅 NIEL 表只读审计（结构 / 算术 / 物理评价限制）

日期：2026-11-05
合同：`docs/collab/decisions/20261105-q2-niel-table-audit-freeze-v1.json`
关联：`docs/collab/inbox/20261105-q2-niel-table-audit-v1.md`、
`docs/collab/decisions/20261105-q2-ddd-reference-freeze-v1.md`
执行方式：**只读**。未运行 Geant4，未修改两张表、产品代码、冻结文件、正式测试/基准、阶段状态，未提交 Git。

## 1. 结论

| 维度 | 判定 | 说明 |
| --- | --- | --- |
| 结构审计 | **pass** | 两表 SHA、表头、行数、能量域、严格递增、有限非负 NIEL 全部符合冻结值 |
| 算术重算 | **pass** | 95 MeV·mb 假设输入换算与中子表 1 MeV 两种插值在 1e-6 相对容差内复现冻结值 |
| 物理评价 | **limited** | 冻结合同本身限定为“未独立核实的 ASTM 输入 + 无物理 pass/fail 门槛”；本次审计**不构成 NIEL 物理验证** |
| 机器总判定 | **limited**（27 pass / 0 fail / 3 limited） | 有 limited 时总体不能写 pass；`audit.py` 对 limited 返回退出码 1 以显式拒绝“整体通过”，这不是脚本错误 |

全部 27 项结构/算术检查均为 pass，0 项 fail。3 项 limited 是**物理评价限制**的显式登记，
不是待修缺陷。

## 2. 冻结身份

| 项 | 值 |
| --- | --- |
| 审计冻结合同 SHA-256 | `92cfff501fcdff2fc0ea40010f02b23f3eabf45cb3b16c1d9a027c08a7702bb4`（1 811 B） |
| schema | `q2_niel_table_audit_preregister_v1` |
| 案例 | `REF-DDD-02` |

| 表 | 文件 | SHA-256 | 行数 | 能量域 (MeV) | 表头 |
| --- | --- | --- | --- | --- | --- |
| 质子 | `scenarios/semiconductor/niel/si_proton.csv` | `6c21e35aab18495d4bb2597a76be60c7c35ef0df963224e0108c77c2e4c208d5` | 146 | `[1e-06, 10000.0]` | `energy_MeV,niel_MeV_cm2_g` |
| 中子 | `scenarios/semiconductor/niel/si_neutron.csv` | `a2ad28a9fcce3500fca363946e09e19125d084f1b596eff76662b272c242034f` | 640 | `[1.025e-10, 19.95]` | `energy_MeV,niel_MeV_cm2_g` |

行数、能量域与冻结值一致；两表均为 LF、末尾换行、无畸形行。质子表 11 行注释 + 表头 + 146 行数据，
中子表 8 行注释 + 表头 + 640 行数据。质子表注释中的 `added: 1e-06 MeV ... NIEL 0` 是既有生成说明，
本次不补点、不改表。

**原始来源声明（仅记录，不是独立证据）**：两表注释声明来自 SR-NIEL 网页计算器
（`sr-niel.org`，SR-NIEL-7 ver. 11.1，retrieved 2026-10-22）；质子表声明阈值 21 eV、
`Hadron+Coulomb`、强子不缩放；中子表声明 ASTM E722-19 损伤函数（Table A1.1）分群值。
这些是 CSV 注释中复制的来源声明，`identity.json` 原样保存；本次审计没有获取或核对
ASTM/SR-NIEL 原始发布物的全文数值，因此不得用注释本身证明物理正确性。

## 3. 结构审计（逐项）

| 检查 id | 结果 | 观测 |
| --- | --- | --- |
| `ID-TABLE-SHA-PROTON` / `ID-TABLE-SHA-NEUTRON` | pass | 与冻结 SHA 完全一致 |
| `STRUCT-HEADER-PROTON` / `STRUCT-HEADER-NEUTRON` | pass | 均等于 `energy_MeV,niel_MeV_cm2_g` |
| `STRUCT-ROWS-PROTON` / `STRUCT-ROWS-NEUTRON` | pass | 146 / 640 |
| `STRUCT-DOMAIN-PROTON` / `STRUCT-DOMAIN-NEUTRON` | pass | 首末能量与冻结域一致 |
| `STRUCT-ENERGY-INCREASING-*` | pass | 正、有限、严格递增 |
| `STRUCT-NIEL-FINITE-NONNEG-*` | pass | 全部有限且非负 |
| `STRUCT-NO-MALFORMED-*` | pass | 无列数错误或非数值字段 |
| `ID-PROVENANCE-CLAIM-*` | pass（身份记录） | 注释声明可解析并原样记录；不构成验证 |

## 4. 算术重算（独立于冻结脚本，单位与公式显式写出）

### 4.1 硅原子质量

\[
m_\mathrm{Si} = 28.0855\ \mathrm{u} \times 1.6605390666\times10^{-24}\ \mathrm{g/u}
= 4.66370699549943\times10^{-23}\ \mathrm{g}
\]

`AR-SI-ATOM-MASS` pass（与冻结值相对差 0）。

### 4.2 95 MeV·mb 假设输入的单位换算

冻结输入为“95 MeV·mb（未核实的 ASTM 输入，仅算术练习）”。`MeV·mb` 是能量×面积：

\[
95\ \mathrm{MeV\cdot mb} = 95\ \mathrm{MeV}\times 10^{-27}\ \mathrm{cm^2/mb}
= 9.5\times10^{-26}\ \mathrm{MeV\cdot cm^2}
\]

\[
\mathrm{NIEL}_\mathrm{hyp}
= \frac{9.5\times10^{-26}\ \mathrm{MeV\cdot cm^2}}{4.66370699549943\times10^{-23}\ \mathrm{g}}
= 2.0370061861021047\times10^{-3}\ \mathrm{MeV\cdot cm^2/g}
\]

`AR-MB-CM2-FACTOR` 与 `AR-95-MEV-MB-TO-NIEL` 均 pass（相对容差 1e-6；复算值
`0.0020370061861021047` 与冻结值完全一致）。单位方向：`mb → cm²` 乘 `1e-27`，
不是除以 1e-27；结果量纲 `MeV·cm²/g`。

### 4.3 中子表 1 MeV 两种插值

冻结的相邻原始节点（直接取自中子表第 0.98 / 1.05 MeV 行，`AR-NEUTRON-NODES` pass）：

| 能量 (MeV) | NIEL (MeV·cm²/g) |
| --- | --- |
| 0.98 | 0.0024078 |
| 1.05 | 0.0016573 |

**log-log 插值**（中子表为 ASTM 分群值，工程上按中点间对数插值）：

\[
\ln y = \ln y_0 + \frac{\ln(E/E_0)}{\ln(E_1/E_0)}\left(\ln y_1 - \ln y_0\right)
\]

在 E = 1.0 MeV 得 `0.0021583350121061676` MeV·cm²/g，与冻结值一致（`AR-NEUTRON-1MEV-LOGLOG` pass）。

**线性插值**：

\[
y = y_0 + \frac{E - E_0}{E_1 - E_0}(y_1 - y_0)
\]

在 E = 1.0 MeV 得 `0.0021933714285714283` MeV·cm²/g，与冻结值一致（`AR-NEUTRON-1MEV-LINEAR` pass）。

**两种算法的相对差**（无量纲，算法差）：

\[
\frac{y_\mathrm{linear} - y_\mathrm{loglog}}{y_\mathrm{loglog}}
= 1.6233076083527528\times10^{-2}\quad(\approx 1.6233\%)
\]

与冻结值一致（`AR-NEUTRON-1MEV-ALGORITHM-RELDIFF` pass，相对容差 1e-6）。

### 4.4 算法相对差与“对参考的点差”分开记录（不推断成因）

| 量 | 含义 | 值 |
| --- | --- | --- |
| `(linear − loglog)/loglog` | 两种插值算法的相对差 | 1.6233% |
| `loglog − NIEL_hyp(95 MeV·mb)` | 对假设输入的**绝对点差** | `1.2132882600406287e-04` MeV·cm²/g |
| 上述点差的相对值 | 点差 / 假设输入 | 5.9562% |
| `linear − NIEL_hyp(95 MeV·mb)` | 对假设输入的绝对点差 | `1.563652424693236e-04` MeV·cm²/g |
| 上述点差的相对值 | 点差 / 假设输入 | 7.6762% |

约 6% 的差异是**中子表 1 MeV 对“95 MeV·mb 常数假设输入”的点差**，与 1.6233% 的算法相对差
量纲/参照都不同，不能混用。95 输入未经 ASTM 全文核实，表注释只是来源声明，因此**不把约 6%
差异判定为缺陷，也不推断评价方法/能量依赖/模型选择的成因**。这些数字只是算术记录。

## 5. 物理评价：limited（不是物理验证）

| 限制 id | 内容 |
| --- | --- |
| `PHY-95-INPUT-NOT-VERIFIED` | 95 MeV·mb 输入在冻结中标注为“未核实 ASTM 输入，仅算术练习”；本次未取得权威全文数值 |
| `PHY-TABLE-MODEL-NOT-INDEPENDENTLY-CHECKED` | 未独立验证 ASTM E722-19 Table A1.1 的分群内容，也未验证 SR-NIEL 的计算模型/版本选择；CSV 注释不是独立物理证据 |
| `PHY-NO-PHYSICAL-PASS-THRESHOLD` | 冻结合同没有物理 pass/fail 门槛，本次不能给 NIEL 物理评价判 pass |

因此：结构/算术可判 pass；**整体只能 limited，不能声称 NIEL 物理验证通过**。

## 6. 反例（副本，5/5 真实 fail）

反例只在 `tampered/` 临时副本上进行，运行后删除；原件 SHA 前后一致（`originals_unchanged=true`）。
每个反例都要求命中的检查是**真实 fail**，baseline 的 limited 不能替代检出。

| 反例 | 变更 | 命中的检查（真实 fail） |
| --- | --- | --- |
| `wrong_unit_factor` | 把 1 mb 当 1 barn（`1e-24 cm²`） | `AR-MB-CM2-FACTOR`、`AR-95-MEV-MB-TO-NIEL` |
| `table_sha_changed` | 中子副本末行 NIEL +1e-6 | `ID-TABLE-SHA-NEUTRON` |
| `non_monotonic` | 质子副本重复首行能量 | `STRUCT-ENERGY-INCREASING-PROTON` |
| `non_finite` | 质子副本某行 NIEL 改 `nan` | `STRUCT-NIEL-FINITE-NONNEG-PROTON` |
| `header_changed` | 中子副本表头改为 `energy_MeV,niel_MeV_cm2` | `STRUCT-HEADER-NEUTRON` |

`tamper-results.json`：baseline = `limited`（27 pass / 0 fail / 3 limited），5/5 detected，
`originals_unchanged=true`，status = `pass`。

## 7. 复演

```bash
cd out/collab/q2-niel-table-audit-v1
python -B audit.py      # 无 CLI 选项（--help 可用）；写 results.json 与 identity.json
python -B tamper.py     # 反例；写 tamper-results.json
```

- `audit.py` 退出码：0 = 全部 pass（本审计不可能）；1 = overall **limited**（预期结果，因物理评价限制）
  或存在 fail。终端会打印哪一种是实际情况。
- 两个脚本都只读原始表；`tamper.py` 结束前删除 `tampered/` 副本目录。
- 没有 `--check`、`--force` 等选项；不要复制不存在于 `--help` 的参数。

## 8. 交付物与 SHA-256 前缀

| 文件 | 说明 | SHA-256 前缀 |
| --- | --- | --- |
| `audit.py` | 结构审计 + 算术重算 + 限制登记 | `c0f894c4a71dc308…` |
| `tamper.py` | 5 个副本反例 | `a3c9ebbdab0f4b42…` |
| `results.json` | 27 pass / 0 fail / 3 limited，逐项检查、身份与算术值 | `e6197f9fcd8bcf49…` |
| `identity.json` | 冻结/表/注释来源身份与声明原文 | `5fb85c0c3d051c38…` |
| `tamper-results.json` | 反例结果与原件不变声明 | `ddb88fc2045edc44…` |
| `README.md` | 本文件 | —（不列自身哈希） |

## 9. 边界与未验证项

- 只审计两张硅 NIEL 表的**结构、SHA、注释身份、95 MeV·mb 单位算术、中子表 1 MeV 两点插值**；
  不验证 NIEL 物理模型、截面、损伤函数、ASTM/SR-NIEL 的原始数值发布物与实际评价方法。
- 不检查其他粒子/材料表（`si_electron.csv`、非硅材料），不补 1 MeV 节点、不改表、不下载付费材料。
- 不重跑 REF-DDD-01 折积；折积候选的 limited 观测限制仍按该候选回执执行。
- 不引入新的物理容差或门槛；本审计的 1e-6 只是算术复现容差。
- 未修改产品、正式测试/基准、冻结合同、表数据、阶段状态；未提交 Git。

## 10. 范围外建议（不在本任务执行）

1. 若要“物理评价 pass”，需要另行冻结可核实的 ASTM E722-19 全文/版本数据、SR-NIEL 计算器输入
   与服务端版本记录，并定义可复现的物理比对方法；这一步需要监督方确认数据许可与范围。
2. 若后续 REF-DDD-01 需要更严格的中子/质子表审计，应作为独立合同追加，不复用本审计的 limited
   状态去支撑折积结论。
