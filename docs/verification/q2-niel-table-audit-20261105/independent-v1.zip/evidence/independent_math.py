"""Read-only high-precision arithmetic; no physical validation claim."""
from pathlib import Path
from decimal import Decimal, localcontext
import bisect
import csv
import hashlib
import json

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
checks = []


def require(name, valid):
    checks.append({"id": name, "status": "pass" if valid else "fail"})
    assert valid, name


def main():
    fp = ROOT / "docs/collab/decisions/20261105-q2-niel-table-audit-freeze-v1.json"
    require("freeze-sha", hashlib.sha256(fp.read_bytes()).hexdigest() == "92cfff501fcdff2fc0ea40010f02b23f3eabf45cb3b16c1d9a027c08a7702bb4")
    f = json.loads(fp.read_text(encoding="utf-8-sig"))
    tables, identity = {}, {}
    for species, spec in f["tables"].items():
        path = ROOT / spec["file"]
        raw = path.read_bytes()
        require(species + ":sha", hashlib.sha256(raw).hexdigest() == spec["sha256"])
        records = list(csv.DictReader(line for line in raw.decode("utf-8-sig").splitlines() if line.strip() and not line.startswith("#")))
        require(species + ":header", set(records[0]) == {"energy_MeV", "niel_MeV_cm2_g"})
        xs = [Decimal(row["energy_MeV"]) for row in records]
        ys = [Decimal(row["niel_MeV_cm2_g"]) for row in records]
        require(species + ":row-count", len(xs) == spec["rows"])
        require(species + ":energy-domain", all(x.is_finite() and x > 0 for x in xs) and all(a < b for a, b in zip(xs, xs[1:])) and [xs[0], xs[-1]] == [Decimal(str(x)) for x in spec["energy_domain_MeV"]])
        require(species + ":finite-nonnegative", all(y.is_finite() and y >= 0 for y in ys))
        tables[species] = xs, ys
        identity[species] = {"sha256": spec["sha256"], "rows": len(xs), "numeric_domain_MeV": [str(xs[0]), str(xs[-1])]}
    with localcontext() as context:
        context.prec = 60
        inputs = f["hypothetical_input"]
        atom = Decimal(str(inputs["silicon_atomic_weight_u"])) * Decimal(str(inputs["atomic_mass_unit_g"]))
        hypothetical = Decimal(str(inputs["damage_cross_section_MeV_mb"])) * Decimal("1e-27") / atom
        xs, ys = tables["neutron"]
        x = Decimal(1)
        i = bisect.bisect_right(xs, x) - 1
        x0, x1, y0, y1 = xs[i], xs[i + 1], ys[i], ys[i + 1]
        linear = y0 + (x - x0) / (x1 - x0) * (y1 - y0)
        loglog = (y0.ln() + (x / x0).ln() / (x1 / x0).ln() * (y1 / y0).ln()).exp()
        values = {"Si_atom_mass_g": atom, "hypothetical_mass_niel_MeV_cm2_g": hypothetical, "neutron_1MeV_loglog": loglog, "neutron_1MeV_linear": linear, "relative_difference_linear_over_loglog": linear / loglog - 1}
        for key, value in values.items():
            expected = Decimal(str(f["expected"][key]))
            require(key, abs(value - expected) <= Decimal("1e-6") * abs(expected))
        require("bracketing-nodes", [x0, x1, y0, y1] == [Decimal(str(v)) for v in f["expected"]["bracketing_nodes"]])
    report = {"schema": "q2_niel_independent_decimal_audit_v1", "status": "limited", "structure_and_arithmetic": "pass", "physical_evaluation": "limited", "hypothetical_95_input_physically_verified": False, "table_physical_evaluation_verified": False, "checks": checks, "tables": identity, "high_precision_values": {k: str(v) for k, v in values.items()}, "scope": "frozen arithmetic fixture and table structure only; comments are provenance claims"}
    (BASE / "independent-math-results.json").write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print("independent Decimal audit", len(checks), "checks passed; physical verdict LIMITED")


if __name__ == "__main__":
    main()
